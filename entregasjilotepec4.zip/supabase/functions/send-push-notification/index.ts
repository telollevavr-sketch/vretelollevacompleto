import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import * as jose from 'https://deno.land/x/jose@v5.2.0/index.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Helper to get a proper ArrayBuffer from Uint8Array
function toArrayBuffer(arr: Uint8Array): ArrayBuffer {
  const copy = new ArrayBuffer(arr.byteLength);
  new Uint8Array(copy).set(arr);
  return copy;
}

// Base64URL encoding/decoding utilities
function base64UrlEncode(data: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < data.length; i++) {
    binary += String.fromCharCode(data[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlDecode(str: string): Uint8Array {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  const binary = atob(str);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

// Extract x and y coordinates from VAPID public key (65 bytes uncompressed point)
function extractPublicKeyCoordinates(publicKeyBase64: string): { x: string; y: string } {
  const publicKeyBytes = base64UrlDecode(publicKeyBase64);
  if (publicKeyBytes.length !== 65 || publicKeyBytes[0] !== 0x04) {
    throw new Error('Invalid VAPID public key format');
  }
  const x = base64UrlEncode(publicKeyBytes.slice(1, 33));
  const y = base64UrlEncode(publicKeyBytes.slice(33, 65));
  return { x, y };
}

// Generate VAPID JWT using jose library with proper JWK format
async function generateVapidJwt(
  audience: string,
  subject: string,
  publicKeyBase64: string,
  privateKeyBase64: string
): Promise<string> {
  const { x, y } = extractPublicKeyCoordinates(publicKeyBase64);
  
  const privateJwk = {
    kty: 'EC',
    crv: 'P-256',
    x,
    y,
    d: privateKeyBase64,
  };

  const key = await jose.importJWK(privateJwk, 'ES256');

  const jwt = await new jose.SignJWT({})
    .setAudience(audience)
    .setExpirationTime('12h')
    .setSubject(subject)
    .setProtectedHeader({ alg: 'ES256', typ: 'JWT' })
    .sign(key);

  return jwt;
}

// HKDF implementation for key derivation
async function hkdf(
  salt: Uint8Array,
  ikm: Uint8Array,
  info: Uint8Array,
  length: number
): Promise<Uint8Array> {
  const saltBuffer = salt.length > 0 ? toArrayBuffer(salt) : new ArrayBuffer(32);
  const saltKey = await crypto.subtle.importKey(
    'raw',
    saltBuffer,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const prkBuffer = await crypto.subtle.sign('HMAC', saltKey, toArrayBuffer(ikm));
  const prk = new Uint8Array(prkBuffer);

  const prkKey = await crypto.subtle.importKey(
    'raw',
    toArrayBuffer(prk),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  let prev = new Uint8Array(0);
  const output = new Uint8Array(length);
  let offset = 0;
  let counter = 1;

  while (offset < length) {
    const input = new Uint8Array(prev.length + info.length + 1);
    input.set(prev);
    input.set(info, prev.length);
    input[prev.length + info.length] = counter;
    
    const signedBuffer = await crypto.subtle.sign('HMAC', prkKey, toArrayBuffer(input));
    prev = new Uint8Array(signedBuffer);
    const toCopy = Math.min(prev.length, length - offset);
    output.set(prev.slice(0, toCopy), offset);
    offset += toCopy;
    counter++;
  }

  return output;
}

// Create info for HKDF as per RFC 8291
function createInfo(type: string, context: Uint8Array): Uint8Array {
  const typeBytes = new TextEncoder().encode(type);
  const info = new Uint8Array(18 + typeBytes.length + 1 + context.length);
  
  info.set(new TextEncoder().encode('Content-Encoding: '), 0);
  info.set(typeBytes, 18);
  info[18 + typeBytes.length] = 0x00;
  info.set(context, 18 + typeBytes.length + 1);
  
  return info;
}

// Encrypt payload using aes128gcm as per RFC 8291
async function encryptPayload(
  payload: string,
  p256dhBase64: string,
  authBase64: string
): Promise<Uint8Array> {
  const payloadBytes = new TextEncoder().encode(payload);
  
  const subscriberPublicKey = base64UrlDecode(p256dhBase64);
  const authSecret = base64UrlDecode(authBase64);

  const localKeyPair = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveBits']
  );

  const localPublicKeyBuffer = await crypto.subtle.exportKey('raw', localKeyPair.publicKey);
  const localPublicKeyRaw = new Uint8Array(localPublicKeyBuffer);

  const subscriberKey = await crypto.subtle.importKey(
    'raw',
    toArrayBuffer(subscriberPublicKey),
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    []
  );

  const sharedSecretBits = await crypto.subtle.deriveBits(
    { name: 'ECDH', public: subscriberKey },
    localKeyPair.privateKey,
    256
  );
  const sharedSecret = new Uint8Array(sharedSecretBits);

  const salt = crypto.getRandomValues(new Uint8Array(16));

  // Build context for key derivation (RFC 8291)
  const contextLabel = new TextEncoder().encode('P-256');
  const context = new Uint8Array(5 + 1 + 2 + subscriberPublicKey.length + 2 + localPublicKeyRaw.length);
  let contextOffset = 0;
  context.set(contextLabel, contextOffset); contextOffset += 5;
  context[contextOffset++] = 0x00;
  context[contextOffset++] = (subscriberPublicKey.length >> 8) & 0xff;
  context[contextOffset++] = subscriberPublicKey.length & 0xff;
  context.set(subscriberPublicKey, contextOffset); contextOffset += subscriberPublicKey.length;
  context[contextOffset++] = (localPublicKeyRaw.length >> 8) & 0xff;
  context[contextOffset++] = localPublicKeyRaw.length & 0xff;
  context.set(localPublicKeyRaw, contextOffset);

  const authInfo = new TextEncoder().encode('Content-Encoding: auth\0');
  const prk = await hkdf(authSecret, sharedSecret, authInfo, 32);

  const cekInfo = createInfo('aes128gcm', context);
  const nonceInfo = createInfo('nonce', context);
  
  const cek = await hkdf(salt, prk, cekInfo, 16);
  const nonce = await hkdf(salt, prk, nonceInfo, 12);

  // Add padding (RFC 8291)
  const paddedPayload = new Uint8Array(payloadBytes.length + 2);
  paddedPayload[0] = 0x02;
  paddedPayload[1] = 0x00;
  paddedPayload.set(payloadBytes, 2);

  const aesKey = await crypto.subtle.importKey(
    'raw',
    toArrayBuffer(cek),
    { name: 'AES-GCM' },
    false,
    ['encrypt']
  );
  const encryptedBuffer = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: toArrayBuffer(nonce), tagLength: 128 },
    aesKey,
    toArrayBuffer(paddedPayload)
  );
  const encryptedBytes = new Uint8Array(encryptedBuffer);

  // Build aes128gcm header (RFC 8188)
  const recordSize = 4096;
  const result = new Uint8Array(16 + 4 + 1 + localPublicKeyRaw.length + encryptedBytes.length);
  let resultOffset = 0;
  result.set(salt, resultOffset); resultOffset += 16;
  result[resultOffset++] = (recordSize >> 24) & 0xff;
  result[resultOffset++] = (recordSize >> 16) & 0xff;
  result[resultOffset++] = (recordSize >> 8) & 0xff;
  result[resultOffset++] = recordSize & 0xff;
  result[resultOffset++] = localPublicKeyRaw.length;
  result.set(localPublicKeyRaw, resultOffset); resultOffset += localPublicKeyRaw.length;
  result.set(encryptedBytes, resultOffset);

  return result;
}

async function sendPushNotification(
  subscription: { endpoint: string; p256dh: string; auth: string },
  payload: string,
  vapidPublicKey: string,
  vapidPrivateKey: string,
  subject: string
): Promise<{ success: boolean; statusCode?: number; error?: string }> {
  try {
    const audience = new URL(subscription.endpoint).origin;
    const jwt = await generateVapidJwt(audience, subject, vapidPublicKey, vapidPrivateKey);
    const encrypted = await encryptPayload(payload, subscription.p256dh, subscription.auth);

    console.log(`[send-push] Sending to endpoint: ${subscription.endpoint.substring(0, 50)}...`);

    const response = await fetch(subscription.endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `vapid t=${jwt}, k=${vapidPublicKey}`,
        'Content-Type': 'application/octet-stream',
        'Content-Encoding': 'aes128gcm',
        'TTL': '86400',
        'Urgency': 'high',
      },
      body: toArrayBuffer(encrypted),
    });

    console.log(`[send-push] Response status: ${response.status}`);

    if (response.status === 201 || response.status === 200) {
      return { success: true, statusCode: response.status };
    } else if (response.status === 410 || response.status === 404) {
      return { success: false, statusCode: response.status, error: 'Subscription expired' };
    } else {
      const text = await response.text();
      console.log(`[send-push] Error response: ${text}`);
      return { success: false, statusCode: response.status, error: text };
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('[send-push] Error:', errorMessage);
    return { success: false, error: errorMessage };
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orderId, orderNumber, businessName, businessId } = await req.json();

    console.log('[send-push] Received request for order:', orderId, 'businessId:', businessId);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const vapidPublicKey = Deno.env.get('VAPID_PUBLIC_KEY')!;
    const vapidPrivateKey = Deno.env.get('VAPID_PRIVATE_KEY')!;

    if (!vapidPublicKey || !vapidPrivateKey) {
      console.error('[send-push] VAPID keys not configured');
      return new Response(
        JSON.stringify({ error: 'VAPID keys not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get all user IDs to notify (admins + business owner)
    const userIdsToNotify: string[] = [];

    // 1. Get admin user IDs
    const { data: adminRoles, error: rolesError } = await supabase
      .from('user_roles')
      .select('user_id')
      .eq('role', 'admin');

    if (rolesError) {
      console.error('[send-push] Error fetching admin roles:', rolesError);
    } else {
      const adminUserIds = adminRoles?.map(r => r.user_id) || [];
      userIdsToNotify.push(...adminUserIds);
      console.log('[send-push] Found admin users:', adminUserIds.length);
    }

    // 2. Get business owner user ID if businessId is provided
    if (businessId) {
      const { data: business, error: businessError } = await supabase
        .from('businesses')
        .select('user_id')
        .eq('id', businessId)
        .single();

      if (businessError) {
        console.error('[send-push] Error fetching business:', businessError);
      } else if (business?.user_id) {
        // Add business owner if not already in the list (in case they're also admin)
        if (!userIdsToNotify.includes(business.user_id)) {
          userIdsToNotify.push(business.user_id);
        }
        console.log('[send-push] Added business owner:', business.user_id);
      }
    }

    if (userIdsToNotify.length === 0) {
      return new Response(
        JSON.stringify({ message: 'No users to notify' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('[send-push] Total users to notify:', userIdsToNotify.length);

    // Get push subscriptions for all target users
    const { data: subscriptions, error: subsError } = await supabase
      .from('push_subscriptions')
      .select('*')
      .in('user_id', userIdsToNotify);

    if (subsError) {
      console.error('[send-push] Error fetching subscriptions:', subsError);
      throw subsError;
    }

    console.log('[send-push] Found subscriptions:', subscriptions?.length || 0);

    if (!subscriptions || subscriptions.length === 0) {
      return new Response(
        JSON.stringify({ message: 'No push subscriptions found for target users' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const notificationPayload = JSON.stringify({
      title: '🛵 Nuevo Pedido',
      body: `Pedido #${orderNumber} de ${businessName}`,
      icon: '/icons/icon-192x192.png',
      badge: '/icons/icon-72x72.png',
      data: { orderId, url: '/admin?tab=pending' },
      actions: [{ action: 'view', title: 'Ver pedido' }],
    });

    const results = await Promise.all(
      subscriptions.map(async (sub) => {
        const result = await sendPushNotification(
          { endpoint: sub.endpoint, p256dh: sub.p256dh, auth: sub.auth },
          notificationPayload,
          vapidPublicKey,
          vapidPrivateKey,
          'mailto:henryvae@yahoo.com'
        );

        if (result.statusCode === 410 || result.statusCode === 404) {
          console.log('[send-push] Removing expired subscription:', sub.id);
          await supabase.from('push_subscriptions').delete().eq('id', sub.id);
        }

        return { subscriptionId: sub.id, userId: sub.user_id, ...result };
      })
    );

    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;

    console.log(`[send-push] Sent: ${successful} successful, ${failed} failed`);

    return new Response(
      JSON.stringify({ message: 'Notifications processed', successful, failed, results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('[send-push] Unhandled error:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
