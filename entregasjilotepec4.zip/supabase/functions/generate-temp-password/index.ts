import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Generate random alphanumeric password
function generateTempPassword(length: number = 8): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const { phone, userId, adminId, customPassword } = await req.json();
    
    console.log('Request received:', { phone, userId, adminId, hasCustomPassword: !!customPassword });

    let targetUserId = userId;
    let userPhone = phone;

    // If phone is provided, find the user by phone
    if (phone && !userId) {
      console.log('Searching user by phone:', phone);
      
      // Clean phone number - remove spaces and special chars
      const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
      
      // Get ALL profiles with this phone (not just one)
      const { data: profiles, error: profileError } = await supabaseAdmin
        .from('profiles')
        .select('id, phone, name')
        .or(`phone.eq.${cleanPhone},phone.eq.${phone}`);

      if (profileError || !profiles || profiles.length === 0) {
        console.log('No profiles found for phone:', phone, profileError);
        return new Response(
          JSON.stringify({ 
            error: 'No se encontró ningún usuario con ese número de teléfono',
            code: 'USER_NOT_FOUND'
          }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log(`Found ${profiles.length} profiles with phone:`, phone);

      // If multiple profiles found, we need to check roles and filter
      if (profiles.length > 1) {
        // Get roles for all found profiles
        const profileIds = profiles.map(p => p.id);
        const { data: roles, error: rolesError } = await supabaseAdmin
          .from('user_roles')
          .select('user_id, role')
          .in('user_id', profileIds);

        if (rolesError) {
          console.log('Error fetching roles:', rolesError);
          return new Response(
            JSON.stringify({ 
              error: 'Error al verificar usuarios',
              code: 'ROLE_FETCH_ERROR'
            }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Filter to only allowed roles
        const allowedRoles = ['client', 'business', 'delivery'];
        const validProfiles = profiles.filter(p => {
          const userRole = roles?.find(r => r.user_id === p.id);
          return userRole && allowedRoles.includes(userRole.role);
        });

        if (validProfiles.length === 0) {
          return new Response(
            JSON.stringify({ 
              error: 'No hay usuarios válidos con ese número de teléfono',
              code: 'NO_VALID_USERS'
            }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        if (validProfiles.length > 1) {
          console.log('Multiple valid users found:', validProfiles.length);
          return new Response(
            JSON.stringify({ 
              error: 'Hay múltiples cuentas registradas con este número de teléfono. Por favor contacta a soporte para recuperar tu cuenta.',
              code: 'MULTIPLE_ACCOUNTS'
            }),
            { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Exactly one valid profile
        targetUserId = validProfiles[0].id;
        userPhone = validProfiles[0].phone;
        console.log('Found single valid user:', validProfiles[0].id, validProfiles[0].name);
      } else {
        // Only one profile found - use it
        targetUserId = profiles[0].id;
        userPhone = profiles[0].phone;
        console.log('Found user:', profiles[0].id, profiles[0].name);
      }
    }

    if (!targetUserId) {
      return new Response(
        JSON.stringify({ error: 'Se requiere teléfono o ID de usuario' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify user has 'client' role
    console.log('Checking user role for:', targetUserId);
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', targetUserId)
      .single();

    if (roleError) {
      console.log('Role error:', roleError);
      return new Response(
        JSON.stringify({ 
          error: 'No se pudo verificar el rol del usuario',
          code: 'ROLE_CHECK_FAILED'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const allowedRoles = ['client', 'business', 'delivery'];
    if (!allowedRoles.includes(roleData.role)) {
      console.log('User role not allowed:', roleData.role);
      return new Response(
        JSON.stringify({ 
          error: 'Esta función solo está disponible para usuarios con rol de cliente, negocio o repartidor',
          code: 'ROLE_NOT_ALLOWED'
        }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get user's phone if not already retrieved
    if (!userPhone) {
      const { data: profileData } = await supabaseAdmin
        .from('profiles')
        .select('phone')
        .eq('id', targetUserId)
        .single();
      
      userPhone = profileData?.phone;
    }

    // Use custom password if provided and valid, otherwise generate one
    let tempPassword: string;
    if (customPassword && typeof customPassword === 'string' && customPassword.length >= 6) {
      tempPassword = customPassword;
      console.log('Using custom password for user:', targetUserId);
    } else {
      tempPassword = generateTempPassword(8);
      console.log('Generated temp password for user:', targetUserId);
    }

    // Update user password in Auth
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
      targetUserId,
      { password: tempPassword }
    );

    if (updateError) {
      console.error('Error updating password:', updateError);
      return new Response(
        JSON.stringify({ 
          error: 'No se pudo actualizar la contraseña',
          details: updateError.message
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Record the password reset in the database
    const { error: insertError } = await supabaseAdmin
      .from('password_resets')
      .insert({
        user_id: targetUserId,
        temp_password: '***REDACTED***', // Don't store actual password
        created_by: adminId || null,
      });

    if (insertError) {
      console.warn('Could not record password reset:', insertError);
      // Don't fail the request, password was already changed
    }

    console.log('Password reset successful for user:', targetUserId);

    return new Response(
      JSON.stringify({ 
        success: true,
        tempPassword,
        userPhone,
        message: 'Contraseña temporal generada exitosamente'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Unexpected error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Error interno del servidor', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
