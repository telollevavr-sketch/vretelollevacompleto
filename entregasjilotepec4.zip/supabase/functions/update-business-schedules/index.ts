import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get current time in Mexico City timezone
    const now = new Date();
    const mexicoTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/Mexico_City' }));
    
    const currentDayOfWeek = mexicoTime.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const currentHour = mexicoTime.getHours();
    const currentMinute = mexicoTime.getMinutes();
    const currentTimeString = `${currentHour.toString().padStart(2, '0')}:${currentMinute.toString().padStart(2, '0')}:00`;

    console.log(`[update-business-schedules] Running at Mexico City time: ${mexicoTime.toISOString()}`);
    console.log(`[update-business-schedules] Day of week: ${currentDayOfWeek}, Time: ${currentTimeString}`);

    // Get all businesses with auto_schedule_enabled = true
    const { data: businesses, error: businessError } = await supabase
      .from('businesses')
      .select('id, name, is_open, auto_schedule_enabled')
      .eq('auto_schedule_enabled', true);

    if (businessError) {
      console.error('[update-business-schedules] Error fetching businesses:', businessError);
      throw businessError;
    }

    if (!businesses || businesses.length === 0) {
      console.log('[update-business-schedules] No businesses with auto_schedule_enabled');
      return new Response(
        JSON.stringify({ message: 'No businesses with auto schedule enabled', updated: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[update-business-schedules] Found ${businesses.length} businesses with auto schedule enabled`);

    let updatedCount = 0;
    const updates: { businessId: string; name: string; shouldBeOpen: boolean; wasOpen: boolean }[] = [];

    for (const business of businesses) {
      // Get schedule for current day
      const { data: schedule, error: scheduleError } = await supabase
        .from('business_schedules')
        .select('*')
        .eq('business_id', business.id)
        .eq('day_of_week', currentDayOfWeek)
        .single();

      if (scheduleError && scheduleError.code !== 'PGRST116') {
        console.error(`[update-business-schedules] Error fetching schedule for ${business.name}:`, scheduleError);
        continue;
      }

      let shouldBeOpen = false;

      if (schedule && schedule.is_open) {
        // Check if current time is within business hours
        const openingTime = schedule.opening_time; // Format: "HH:MM:SS"
        const closingTime = schedule.closing_time; // Format: "HH:MM:SS"

        // Handle closing time that crosses midnight
        if (closingTime < openingTime) {
          // Business closes after midnight (e.g., 10:00 - 02:00)
          shouldBeOpen = currentTimeString >= openingTime || currentTimeString < closingTime;
        } else {
          // Normal hours (e.g., 09:00 - 21:00)
          shouldBeOpen = currentTimeString >= openingTime && currentTimeString < closingTime;
        }

        console.log(`[update-business-schedules] ${business.name}: opening=${openingTime}, closing=${closingTime}, current=${currentTimeString}, shouldBeOpen=${shouldBeOpen}`);
      } else {
        console.log(`[update-business-schedules] ${business.name}: No schedule for day ${currentDayOfWeek} or marked as closed`);
      }

      // Only update if status needs to change
      if (business.is_open !== shouldBeOpen) {
        const { error: updateError } = await supabase
          .from('businesses')
          .update({ is_open: shouldBeOpen })
          .eq('id', business.id);

        if (updateError) {
          console.error(`[update-business-schedules] Error updating ${business.name}:`, updateError);
          continue;
        }

        updatedCount++;
        updates.push({
          businessId: business.id,
          name: business.name,
          shouldBeOpen,
          wasOpen: business.is_open
        });

        console.log(`[update-business-schedules] Updated ${business.name}: ${business.is_open ? 'OPEN' : 'CLOSED'} -> ${shouldBeOpen ? 'OPEN' : 'CLOSED'}`);
      }
    }

    const response = {
      message: 'Business schedules updated successfully',
      timestamp: mexicoTime.toISOString(),
      dayOfWeek: currentDayOfWeek,
      currentTime: currentTimeString,
      businessesChecked: businesses.length,
      updated: updatedCount,
      updates
    };

    console.log('[update-business-schedules] Completed:', response);

    return new Response(
      JSON.stringify(response),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[update-business-schedules] Error:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
