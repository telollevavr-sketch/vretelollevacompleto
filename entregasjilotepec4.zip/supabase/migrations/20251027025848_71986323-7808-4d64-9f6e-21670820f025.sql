-- Create business_types table
CREATE TABLE IF NOT EXISTS public.business_types (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  icon text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on business_types
ALTER TABLE public.business_types ENABLE ROW LEVEL SECURITY;

-- Create policies for business_types
CREATE POLICY "Todos pueden ver tipos de negocio activos"
ON public.business_types
FOR SELECT
USING (is_active = true OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins pueden gestionar todos los tipos de negocio"
ON public.business_types
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Migrate current categories data to business_types
INSERT INTO public.business_types (name, description, icon, is_active)
SELECT name, description, icon, is_active
FROM public.categories;

-- Add business_type_id column to businesses table
ALTER TABLE public.businesses ADD COLUMN IF NOT EXISTS business_type_id uuid REFERENCES public.business_types(id);

-- Migrate business category to business_type_id
UPDATE public.businesses b
SET business_type_id = (
  SELECT bt.id 
  FROM public.business_types bt 
  WHERE bt.name = b.category
  LIMIT 1
);

-- Clear categories table and add new product categories
TRUNCATE public.categories;

INSERT INTO public.categories (name, description, is_active) VALUES
('Entradas', 'Aperitivos y entradas', true),
('Plato Fuerte', 'Platos principales', true),
('Bebidas', 'Bebidas y refrescos', true),
('Postres', 'Postres y dulces', true),
('Ensaladas', 'Ensaladas y guarniciones', true),
('Sopas', 'Sopas y caldos', true),
('Pizzas', 'Pizzas artesanales', true),
('Hamburguesas', 'Hamburguesas gourmet', true),
('Tacos', 'Tacos y antojitos', true),
('Sushi', 'Sushi y rollos', true),
('Pastas', 'Pastas y platillos italianos', true),
('Desayunos', 'Desayunos y brunch', true);

-- Create trigger for business_types updated_at
CREATE TRIGGER update_business_types_updated_at
BEFORE UPDATE ON public.business_types
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_businesses_business_type_id ON public.businesses(business_type_id);
CREATE INDEX IF NOT EXISTS idx_business_types_is_active ON public.business_types(is_active);