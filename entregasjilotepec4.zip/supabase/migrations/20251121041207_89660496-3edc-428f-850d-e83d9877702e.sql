-- Crear tabla para plantillas de complementos predefinidas
CREATE TABLE IF NOT EXISTS public.complement_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price NUMERIC NOT NULL DEFAULT 0,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.complement_templates ENABLE ROW LEVEL SECURITY;

-- Políticas RLS: todos pueden ver plantillas activas
CREATE POLICY "Todos pueden ver plantillas activas"
ON public.complement_templates
FOR SELECT
USING (is_active = true);

-- Solo admins pueden gestionar plantillas
CREATE POLICY "Admins gestionan plantillas"
ON public.complement_templates
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger para actualizar updated_at
CREATE TRIGGER update_complement_templates_updated_at
BEFORE UPDATE ON public.complement_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insertar plantillas predefinidas comunes
INSERT INTO public.complement_templates (name, category, price, description) VALUES
-- Quesos
('Queso Mozzarella Extra', 'quesos', 15.00, 'Porción adicional de queso mozzarella'),
('Queso Parmesano', 'quesos', 18.00, 'Queso parmesano rallado'),
('Queso Cheddar', 'quesos', 16.00, 'Queso cheddar gratinado'),
('Queso Azul', 'quesos', 20.00, 'Queso azul importado'),
('Queso Crema', 'quesos', 12.00, 'Queso crema Philadelphia'),

-- Salsas
('Salsa BBQ', 'salsas', 8.00, 'Salsa barbecue ahumada'),
('Salsa Ranch', 'salsas', 8.00, 'Salsa ranch cremosa'),
('Salsa Picante', 'salsas', 5.00, 'Salsa picante casera'),
('Salsa de Ajo', 'salsas', 7.00, 'Salsa de ajo y hierbas'),
('Salsa Búfalo', 'salsas', 10.00, 'Salsa búfalo picante'),
('Salsa Teriyaki', 'salsas', 9.00, 'Salsa teriyaki oriental'),
('Mayonesa de Ajo', 'salsas', 6.00, 'Mayonesa con ajo'),

-- Vegetales
('Champiñones', 'vegetales', 12.00, 'Champiñones frescos salteados'),
('Pimientos', 'vegetales', 8.00, 'Pimientos morrones asados'),
('Cebolla Caramelizada', 'vegetales', 10.00, 'Cebolla caramelizada'),
('Jalapeños', 'vegetales', 7.00, 'Jalapeños en rodajas'),
('Aceitunas', 'vegetales', 9.00, 'Aceitunas negras'),
('Tomate Cherry', 'vegetales', 8.00, 'Tomates cherry frescos'),

-- Carnes
('Tocino', 'carnes', 20.00, 'Tocino ahumado crujiente'),
('Pepperoni Extra', 'carnes', 18.00, 'Porción adicional de pepperoni'),
('Jamón', 'carnes', 15.00, 'Jamón de pierna'),
('Salchicha Italiana', 'carnes', 22.00, 'Salchicha italiana especiada'),
('Pollo a la Parrilla', 'carnes', 25.00, 'Pechuga de pollo marinada'),

-- Extras
('Papas Fritas', 'otros', 15.00, 'Porción de papas fritas crujientes'),
('Aros de Cebolla', 'otros', 18.00, 'Aros de cebolla empanizados'),
('Pan de Ajo', 'otros', 12.00, 'Pan de ajo con mantequilla'),
('Aderezo Extra', 'otros', 5.00, 'Porción adicional de aderezo'),
('Guacamole', 'otros', 20.00, 'Guacamole fresco casero');

-- Índice para mejorar búsquedas por categoría
CREATE INDEX idx_complement_templates_category ON public.complement_templates(category);
CREATE INDEX idx_complement_templates_active ON public.complement_templates(is_active) WHERE is_active = true;