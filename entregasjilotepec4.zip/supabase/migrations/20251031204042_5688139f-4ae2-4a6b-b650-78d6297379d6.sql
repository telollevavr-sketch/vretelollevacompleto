-- Permitir a los propietarios de negocios ver los perfiles de repartidores asignados a sus negocios
CREATE POLICY "Propietarios de negocios pueden ver repartidores asignados"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.businesses b
    WHERE b.id = profiles.assigned_business_id
    AND b.user_id = auth.uid()
  )
);

-- Permitir a los repartidores ver su propio perfil completo
CREATE POLICY "Repartidores pueden ver perfiles de otros repartidores"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'delivery'::app_role)
  AND EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_roles.user_id = profiles.id
    AND user_roles.role = 'delivery'::app_role
  )
);