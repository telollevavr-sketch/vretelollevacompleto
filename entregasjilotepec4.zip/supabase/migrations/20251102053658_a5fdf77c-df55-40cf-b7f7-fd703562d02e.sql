-- Paso 1: ELIMINAR TODAS las políticas de INSERT para notifications
DROP POLICY IF EXISTS "authenticated_can_insert_any_notification" ON notifications;
DROP POLICY IF EXISTS "Usuarios autenticados pueden crear notificaciones" ON notifications;
DROP POLICY IF EXISTS "allow_any_authenticated_insert" ON notifications;
DROP POLICY IF EXISTS "allow_authenticated_insert_notifications" ON notifications;

-- Paso 2: DESHABILITAR temporalmente RLS para ver si ese es el problema
-- NO LO HAREMOS, en su lugar crearemos una política SUPER PERMISIVA

-- Paso 3: Crear política completamente permisiva que NO dependa del role
-- Esta permite INSERT a CUALQUIER usuario que tenga un uid válido
CREATE POLICY "allow_all_authenticated_inserts"
ON notifications
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM auth.users 
    WHERE id = auth.uid()
  )
);

COMMENT ON POLICY "allow_all_authenticated_inserts" ON notifications IS 
'Permite a cualquier usuario autenticado crear notificaciones verificando directamente en auth.users';