-- Eliminar la política actual de INSERT
DROP POLICY IF EXISTS "allow_authenticated_insert_notifications" ON notifications;

-- Crear nueva política que verifica explícitamente que el usuario esté autenticado
-- Sin importar el user_id del registro que se está insertando
CREATE POLICY "authenticated_users_can_create_notifications"
ON notifications
FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

-- Comentario explicativo
COMMENT ON POLICY "authenticated_users_can_create_notifications" ON notifications IS 
'Permite a cualquier usuario autenticado crear notificaciones, incluso para otros usuarios. Necesario para que negocios y repartidores notifiquen a clientes.';