-- Eliminar todas las políticas INSERT existentes para notifications
DROP POLICY IF EXISTS "Usuarios autenticados pueden crear notificaciones" ON notifications;

-- Crear nueva política que permita a cualquier usuario autenticado crear notificaciones
-- Esta política es necesaria para que negocios y repartidores puedan notificar a clientes
CREATE POLICY "allow_authenticated_insert_notifications"
ON notifications
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Verificar que la política se aplicó correctamente
COMMENT ON POLICY "allow_authenticated_insert_notifications" ON notifications IS 
'Permite a usuarios autenticados crear notificaciones para cualquier usuario';