CREATE POLICY "Admins can upload antojo images"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'antojo-images'
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can update antojo images"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'antojo-images'
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can delete antojo images"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'antojo-images'
  AND has_role(auth.uid(), 'admin'::app_role)
);