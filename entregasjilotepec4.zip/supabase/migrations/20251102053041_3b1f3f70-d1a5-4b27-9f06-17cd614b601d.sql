-- Paso 1: Eliminar la política problemática actual
DROP POLICY IF EXISTS "allow_any_authenticated_insert" ON notifications;

-- Paso 2: Crear una política simple y directa que definitivamente funcione
-- Esta política permite a CUALQUIER usuario autenticado crear notificaciones
-- sin importar el user_id que esté insertando
CREATE POLICY "authenticated_can_insert_any_notification"
ON notifications
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Comentario explicativo
COMMENT ON POLICY "authenticated_can_insert_any_notification" ON notifications IS 
'Permite a usuarios autenticados (negocios, repartidores, clientes) crear notificaciones para cualquier usuario';