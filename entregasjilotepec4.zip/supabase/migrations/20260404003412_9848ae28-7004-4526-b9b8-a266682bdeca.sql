
-- Add image_url and category to antojo_businesses
ALTER TABLE public.antojo_businesses ADD COLUMN image_url text;
ALTER TABLE public.antojo_businesses ADD COLUMN category text;

-- Create antojo_categories table
CREATE TABLE public.antojo_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  icon text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.antojo_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Todos ven categorías antojo activas"
  ON public.antojo_categories FOR SELECT TO public
  USING (is_active = true OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins gestionan categorías antojo"
  ON public.antojo_categories FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

-- Insert initial categories
INSERT INTO public.antojo_categories (name, icon) VALUES
  ('Tamales', '🫔'),
  ('Elotes', '🌽'),
  ('Esquites', '🥤'),
  ('Helados', '🍦'),
  ('Antojitos Mexicanos', '🌮'),
  ('Cocteles de Fruta', '🍹'),
  ('Dulcería', '🍬'),
  ('Bocadillos', '🥪');

-- Add custom business fields to antojo_orders
ALTER TABLE public.antojo_orders ALTER COLUMN antojo_business_id DROP NOT NULL;
ALTER TABLE public.antojo_orders ADD COLUMN custom_business_name text;
ALTER TABLE public.antojo_orders ADD COLUMN custom_business_description text;
