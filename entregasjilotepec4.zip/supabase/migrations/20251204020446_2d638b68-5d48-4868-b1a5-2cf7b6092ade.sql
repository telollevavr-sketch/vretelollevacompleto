-- Política RLS para permitir a clientes ver el perfil del repartidor de su pedido activo
CREATE POLICY "Clientes pueden ver repartidor de su pedido"
ON public.profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 
    FROM public.orders 
    WHERE orders.delivery_person_id = profiles.id 
    AND orders.client_id = auth.uid() 
    AND orders.status = 'in_delivery'
  )
);