-- Fix RLS policy for notifications to allow authenticated users to create notifications for others
-- This is necessary because businesses need to notify clients, delivery persons need to notify clients, etc.

DROP POLICY IF EXISTS "Usuarios autenticados pueden crear notificaciones" ON notifications;

CREATE POLICY "Usuarios autenticados pueden crear notificaciones"
ON notifications
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL);