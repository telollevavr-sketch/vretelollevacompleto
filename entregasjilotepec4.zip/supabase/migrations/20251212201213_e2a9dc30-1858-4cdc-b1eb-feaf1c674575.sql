-- Create table for menu images
CREATE TABLE public.business_menu_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES public.businesses(id) ON DELETE CASCADE,
  image_data text NOT NULL,
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.business_menu_images ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Admins pueden gestionar todas las imágenes de menú"
ON public.business_menu_images FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Propietarios pueden gestionar imágenes de su menú"
ON public.business_menu_images FOR ALL
USING (EXISTS (
  SELECT 1 FROM businesses
  WHERE businesses.id = business_menu_images.business_id
  AND businesses.user_id = auth.uid()
));

CREATE POLICY "Todos pueden ver imágenes activas de menús de negocios activos"
ON public.business_menu_images FOR SELECT
USING (
  is_active = true
  AND EXISTS (
    SELECT 1 FROM businesses
    WHERE businesses.id = business_menu_images.business_id
    AND businesses.is_active = true
  )
);

-- Trigger for updated_at
CREATE TRIGGER update_business_menu_images_updated_at
BEFORE UPDATE ON public.business_menu_images
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();