-- Agregar columna is_specialty a la tabla products
ALTER TABLE products ADD COLUMN IF NOT EXISTS is_specialty boolean NOT NULL DEFAULT false;

-- Crear índice para mejorar el rendimiento de consultas
CREATE INDEX IF NOT EXISTS idx_products_is_specialty ON products(is_specialty) WHERE is_specialty = true;

-- Comentario descriptivo
COMMENT ON COLUMN products.is_specialty IS 'Indica si el producto es una especialidad individual (el cliente debe elegir una especialidad del negocio)';