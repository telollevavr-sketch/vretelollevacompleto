-- Permitir a los clientes actualizar solo las calificaciones de sus propias órdenes entregadas
CREATE POLICY "Clientes pueden calificar sus órdenes entregadas" 
ON public.orders 
FOR UPDATE 
USING (
  auth.uid() = client_id 
  AND status = 'delivered'
)
WITH CHECK (
  auth.uid() = client_id 
  AND status = 'delivered'
);