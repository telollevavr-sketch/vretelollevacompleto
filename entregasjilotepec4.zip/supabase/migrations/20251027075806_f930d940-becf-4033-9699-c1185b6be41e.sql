-- Arreglar función para incluir search_path y prevenir warning de seguridad
CREATE OR REPLACE FUNCTION sync_profile_role_type()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    UPDATE profiles 
    SET role_type = NEW.role::text 
    WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public';