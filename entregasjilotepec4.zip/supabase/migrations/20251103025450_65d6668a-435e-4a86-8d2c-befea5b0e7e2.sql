-- Asegurar que la política para anónimos funcione correctamente
DROP POLICY IF EXISTS "Anónimos ven negocios activos" ON public.businesses;

CREATE POLICY "Anónimos y autenticados ven negocios activos" 
ON public.businesses 
FOR SELECT 
USING (is_active = true);