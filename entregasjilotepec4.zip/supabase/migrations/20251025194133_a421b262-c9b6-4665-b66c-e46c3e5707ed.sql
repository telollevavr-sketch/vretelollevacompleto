-- Agregar política para permitir a usuarios crear sus propios roles durante el registro
-- Por seguridad, NO permitimos auto-asignación del rol 'admin'
CREATE POLICY "Usuarios pueden crear sus propios roles no-admin durante registro"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id 
  AND role IN ('client'::app_role, 'business'::app_role, 'delivery'::app_role)
);