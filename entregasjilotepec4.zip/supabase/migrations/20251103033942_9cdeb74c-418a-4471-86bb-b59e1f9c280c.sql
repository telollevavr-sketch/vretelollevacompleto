-- Eliminar TODAS las políticas de SELECT existentes
DROP POLICY IF EXISTS "Anónimos y autenticados ven negocios activos" ON public.businesses;
DROP POLICY IF EXISTS "Ver negocios activos o propios" ON public.businesses;
DROP POLICY IF EXISTS "Ver negocios" ON public.businesses;

-- Crear una nueva política simple y directa
CREATE POLICY "public_can_view_active_businesses"
ON public.businesses
FOR SELECT
USING (
  is_active = true 
  OR user_id = auth.uid()
  OR has_role(auth.uid(), 'admin')
);