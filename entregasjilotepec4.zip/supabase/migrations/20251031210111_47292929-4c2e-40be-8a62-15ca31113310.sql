-- Eliminar la política existente de inserción que podría estar causando problemas
DROP POLICY IF EXISTS "System can create notifications" ON public.notifications;

-- Crear nueva política que permita a cualquier usuario autenticado crear notificaciones
CREATE POLICY "Usuarios autenticados pueden crear notificaciones"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Asegurar que los usuarios puedan ver sus propias notificaciones
DROP POLICY IF EXISTS "Users can view their own notifications" ON public.notifications;
CREATE POLICY "Usuarios pueden ver sus propias notificaciones"
ON public.notifications
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Permitir actualizar sus propias notificaciones (marcar como leídas)
DROP POLICY IF EXISTS "Users can update their own notifications" ON public.notifications;
CREATE POLICY "Usuarios pueden actualizar sus propias notificaciones"
ON public.notifications
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);