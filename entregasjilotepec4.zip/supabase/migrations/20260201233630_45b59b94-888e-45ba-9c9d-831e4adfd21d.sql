-- Agregar columna is_coming_soon a businesses
ALTER TABLE businesses 
ADD COLUMN is_coming_soon BOOLEAN DEFAULT false;