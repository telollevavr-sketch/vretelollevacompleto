-- Add delivery tracking enabled column to businesses table
ALTER TABLE businesses 
ADD COLUMN delivery_tracking_enabled BOOLEAN DEFAULT false;