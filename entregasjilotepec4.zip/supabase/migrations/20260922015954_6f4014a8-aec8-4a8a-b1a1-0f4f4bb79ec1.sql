CREATE TABLE public.delivery_incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_person_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount numeric NOT NULL,
  notes text,
  occurred_at timestamp with time zone NOT NULL DEFAULT now(),
  created_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.delivery_incidents TO authenticated;
GRANT ALL ON public.delivery_incidents TO service_role;

ALTER TABLE public.delivery_incidents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage delivery incidents"
ON public.delivery_incidents FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_delivery_incidents_occurred_at ON public.delivery_incidents (occurred_at DESC);
CREATE INDEX idx_delivery_incidents_person ON public.delivery_incidents (delivery_person_id);

CREATE TRIGGER update_delivery_incidents_updated_at
BEFORE UPDATE ON public.delivery_incidents
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();