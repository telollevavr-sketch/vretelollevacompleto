-- Drop overly permissive policy
DROP POLICY IF EXISTS "Service role acceso total password_resets" ON public.password_resets;

-- Add proper policies for edge function operations
-- Note: Edge functions use service role key which bypasses RLS anyway
-- So we just need policies for admin access from client side

-- Allow admins to update (mark as used)
CREATE POLICY "Admins pueden actualizar resets"
ON public.password_resets
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Allow admins to delete old resets
CREATE POLICY "Admins pueden eliminar resets"
ON public.password_resets
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));