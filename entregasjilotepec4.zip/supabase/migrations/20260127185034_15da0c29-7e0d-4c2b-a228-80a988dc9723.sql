-- =============================================
-- FIX RLS POLICIES FOR BACKUP SYSTEM
-- Change restrictive policies to permissive for admin access
-- =============================================

-- PROFILES: Drop restrictive policy and recreate as permissive
DROP POLICY IF EXISTS "Admins ven todos los perfiles" ON profiles;
CREATE POLICY "Admins ven todos los perfiles" 
  ON profiles FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- ORDERS: Add admin policy for full access
DROP POLICY IF EXISTS "Admins ven todas las ordenes" ON orders;
CREATE POLICY "Admins ven todas las ordenes" 
  ON orders FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- NOTIFICATIONS: Add admin policy
DROP POLICY IF EXISTS "Admins ven todas las notificaciones" ON notifications;
CREATE POLICY "Admins ven todas las notificaciones" 
  ON notifications FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- ORDER_MESSAGES: Add admin policy
DROP POLICY IF EXISTS "Admins ven todos los mensajes" ON order_messages;
CREATE POLICY "Admins ven todos los mensajes" 
  ON order_messages FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- PRODUCT_COMPLEMENTS: Ensure admin can read all
DROP POLICY IF EXISTS "Admins gestionan todos los complementos" ON product_complements;
CREATE POLICY "Admins ven todos los complementos" 
  ON product_complements FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- PIZZA_SPECIALTIES: Ensure admin can read all
DROP POLICY IF EXISTS "Admins pueden gestionar todas las especialidades" ON pizza_specialties;
CREATE POLICY "Admins ven todas las especialidades" 
  ON pizza_specialties FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- BUSINESS_MENU_IMAGES: Ensure admin can read all
DROP POLICY IF EXISTS "Admins pueden gestionar todas las imagenes" ON business_menu_images;
CREATE POLICY "Admins ven todas las imagenes de menu" 
  ON business_menu_images FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- BUSINESS_PROMOTIONS: Ensure admin can read all
DROP POLICY IF EXISTS "Admins pueden gestionar todas las promociones" ON business_promotions;
CREATE POLICY "Admins ven todas las promociones" 
  ON business_promotions FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));