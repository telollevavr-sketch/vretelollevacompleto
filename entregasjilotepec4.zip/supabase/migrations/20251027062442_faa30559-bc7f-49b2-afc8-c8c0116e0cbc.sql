-- Crear tabla para promociones de negocios
CREATE TABLE IF NOT EXISTS public.business_promotions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  business_id UUID NOT NULL REFERENCES public.businesses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  image_data TEXT NOT NULL, -- Base64 de imagen comprimida (máx 250kb)
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.business_promotions ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Todos pueden ver promociones activas de negocios activos"
ON public.business_promotions
FOR SELECT
USING (
  is_active = true AND 
  EXISTS (
    SELECT 1 FROM businesses 
    WHERE businesses.id = business_promotions.business_id 
    AND businesses.is_active = true
  )
);

CREATE POLICY "Propietarios pueden gestionar promociones de su negocio"
ON public.business_promotions
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM businesses 
    WHERE businesses.id = business_promotions.business_id 
    AND businesses.user_id = auth.uid()
  )
);

CREATE POLICY "Admins pueden gestionar todas las promociones"
ON public.business_promotions
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger para updated_at
CREATE TRIGGER update_business_promotions_updated_at
BEFORE UPDATE ON public.business_promotions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Habilitar realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.business_promotions;