-- Eliminar política actual
DROP POLICY IF EXISTS "authenticated_users_can_create_notifications" ON notifications;

-- Crear política más permisiva sin restricción TO authenticated
-- Usar USING para INSERT se ignora, solo importa WITH CHECK
CREATE POLICY "allow_any_authenticated_insert"
ON notifications
AS PERMISSIVE
FOR INSERT
TO public
WITH CHECK (
  (SELECT auth.uid()) IS NOT NULL
);

COMMENT ON POLICY "allow_any_authenticated_insert" ON notifications IS 
'Permite a usuarios autenticados crear notificaciones para cualquier user_id';