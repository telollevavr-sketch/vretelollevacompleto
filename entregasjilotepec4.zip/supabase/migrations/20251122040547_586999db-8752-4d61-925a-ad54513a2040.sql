-- Agregar columna specialty_type a la tabla pizza_specialties
ALTER TABLE pizza_specialties 
ADD COLUMN specialty_type TEXT DEFAULT 'pizza';

-- Crear índice para mejorar el rendimiento de consultas filtradas
CREATE INDEX IF NOT EXISTS idx_pizza_specialties_type 
ON pizza_specialties(business_id, specialty_type, is_active);

-- Comentario para documentar el campo
COMMENT ON COLUMN pizza_specialties.specialty_type IS 
'Tipo de especialidad: pizza, refresco, salsa, queso, torta, hamburguesa, etc. Usado para filtrar en combos promocionales';

-- Actualizar especialidades existentes para que tengan el valor por defecto
UPDATE pizza_specialties 
SET specialty_type = 'pizza' 
WHERE specialty_type IS NULL;