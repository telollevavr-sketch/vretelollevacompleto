-- Permitir a negocios ver roles de repartidores en user_roles
CREATE POLICY "Negocios pueden ver roles de repartidores"
ON public.user_roles
FOR SELECT
TO authenticated
USING (
  role = 'delivery'::app_role 
  AND has_role(auth.uid(), 'business'::app_role)
);

-- Permitir a negocios ver repartidores independientes y asignados
CREATE POLICY "Negocios pueden ver repartidores disponibles"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'business'::app_role)
  AND id IN (
    SELECT user_id FROM user_roles WHERE role = 'delivery'::app_role
  )
  AND (
    assigned_business_id IS NULL  -- Repartidores independientes
    OR assigned_business_id IN (  -- O asignados a su negocio
      SELECT id FROM businesses WHERE user_id = auth.uid()
    )
  )
);