-- Habilitar real-time para la tabla notifications
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;