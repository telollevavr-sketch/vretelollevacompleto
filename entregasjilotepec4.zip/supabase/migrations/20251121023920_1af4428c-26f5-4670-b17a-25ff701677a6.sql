-- Agregar columnas para días de atención y horarios
ALTER TABLE businesses 
ADD COLUMN IF NOT EXISTS business_days TEXT,
ADD COLUMN IF NOT EXISTS business_hours TEXT;

COMMENT ON COLUMN businesses.business_days IS 'Días de atención del negocio (ej: Lun-Dom, Lun-Vie)';
COMMENT ON COLUMN businesses.business_hours IS 'Horarios de atención del negocio (ej: 10:00 AM - 10:00 PM)';