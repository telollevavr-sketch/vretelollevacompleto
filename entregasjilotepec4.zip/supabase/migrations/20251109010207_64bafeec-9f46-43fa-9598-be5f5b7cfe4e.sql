-- Crear tabla de especialidades de pizzas
CREATE TABLE IF NOT EXISTS public.pizza_specialties (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  business_id UUID NOT NULL REFERENCES public.businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS en pizza_specialties
ALTER TABLE public.pizza_specialties ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para pizza_specialties
CREATE POLICY "Todos pueden ver especialidades activas de negocios activos"
ON public.pizza_specialties
FOR SELECT
USING (
  is_active = true 
  AND EXISTS (
    SELECT 1 FROM businesses 
    WHERE businesses.id = pizza_specialties.business_id 
    AND businesses.is_active = true
  )
);

CREATE POLICY "Propietarios pueden gestionar especialidades de su negocio"
ON public.pizza_specialties
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM businesses 
    WHERE businesses.id = pizza_specialties.business_id 
    AND businesses.user_id = auth.uid()
  )
);

CREATE POLICY "Admins pueden gestionar todas las especialidades"
ON public.pizza_specialties
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Agregar campos a la tabla products para promociones
ALTER TABLE public.products 
ADD COLUMN IF NOT EXISTS is_promotional_combo BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN IF NOT EXISTS combo_configuration JSONB;

-- Trigger para updated_at en pizza_specialties
CREATE TRIGGER update_pizza_specialties_updated_at
BEFORE UPDATE ON public.pizza_specialties
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();