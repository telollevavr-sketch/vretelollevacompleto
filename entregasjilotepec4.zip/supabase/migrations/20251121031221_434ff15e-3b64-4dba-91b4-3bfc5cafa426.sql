-- Crear tabla de complementos de productos
CREATE TABLE IF NOT EXISTS product_complements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price NUMERIC NOT NULL DEFAULT 0,
  category TEXT NOT NULL,
  description TEXT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Índices para mejorar el rendimiento
CREATE INDEX idx_product_complements_business_id ON product_complements(business_id);
CREATE INDEX idx_product_complements_category ON product_complements(category);
CREATE INDEX idx_product_complements_is_available ON product_complements(is_available);

-- Trigger para actualizar updated_at
CREATE TRIGGER update_product_complements_updated_at
  BEFORE UPDATE ON product_complements
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- RLS Policies
ALTER TABLE product_complements ENABLE ROW LEVEL SECURITY;

-- Política: Propietarios pueden gestionar complementos de su negocio
CREATE POLICY "Propietarios gestionan sus complementos"
  ON product_complements
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM businesses
      WHERE businesses.id = product_complements.business_id
      AND businesses.user_id = auth.uid()
    )
  );

-- Política: Clientes y anónimos pueden ver complementos disponibles de negocios activos
CREATE POLICY "Ver complementos disponibles"
  ON product_complements
  FOR SELECT
  USING (
    is_available = true
    AND EXISTS (
      SELECT 1 FROM businesses
      WHERE businesses.id = product_complements.business_id
      AND businesses.is_active = true
    )
  );

-- Política: Admins pueden gestionar todos los complementos
CREATE POLICY "Admins gestionan todos los complementos"
  ON product_complements
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Comentarios para documentación
COMMENT ON TABLE product_complements IS 'Complementos que pueden agregarse a productos de un negocio (quesos, salsas, extras, etc.)';
COMMENT ON COLUMN product_complements.business_id IS 'Negocio al que pertenecen los complementos';
COMMENT ON COLUMN product_complements.name IS 'Nombre del complemento (ej: Queso Extra, Salsa Brava)';
COMMENT ON COLUMN product_complements.price IS 'Precio del complemento (puede ser 0 para complementos gratuitos)';
COMMENT ON COLUMN product_complements.category IS 'Categoría del complemento (QUESO, SALSA, EXTRA, BEBIDA, etc.)';
COMMENT ON COLUMN product_complements.description IS 'Descripción opcional del complemento';
COMMENT ON COLUMN product_complements.is_available IS 'Si el complemento está disponible para selección';