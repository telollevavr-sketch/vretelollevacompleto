-- Agregar columna de precio a especialidades (para promociones 2x1)
ALTER TABLE pizza_specialties 
ADD COLUMN price DECIMAL(10,2) DEFAULT 0;

-- Agregar bandera para combos con precio calculado (paga el mayor)
ALTER TABLE products 
ADD COLUMN is_priced_combo BOOLEAN DEFAULT FALSE;

-- Comentarios para documentación
COMMENT ON COLUMN pizza_specialties.price IS 'Precio de la especialidad para combos 2x1 donde se paga el de mayor precio';
COMMENT ON COLUMN products.is_priced_combo IS 'Si true, el precio del combo se calcula como el máximo de las especialidades seleccionadas';