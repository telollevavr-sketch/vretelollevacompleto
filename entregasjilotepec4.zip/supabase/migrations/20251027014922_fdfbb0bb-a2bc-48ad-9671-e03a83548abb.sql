-- Agregar campo para asignar repartidores a negocios
ALTER TABLE public.profiles
ADD COLUMN assigned_business_id uuid REFERENCES public.businesses(id) ON DELETE SET NULL;

-- Crear índice para mejorar rendimiento de consultas
CREATE INDEX idx_profiles_assigned_business ON public.profiles(assigned_business_id);

COMMENT ON COLUMN public.profiles.assigned_business_id IS 'Negocio al que está adscrito el repartidor (null = independiente)';