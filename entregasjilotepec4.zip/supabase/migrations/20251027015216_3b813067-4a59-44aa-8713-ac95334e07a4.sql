-- Agregar campo para clasificar negocios como especial (con creador de pizzas) o estándar
ALTER TABLE public.businesses
ADD COLUMN is_special_business boolean DEFAULT false NOT NULL;

COMMENT ON COLUMN public.businesses.is_special_business IS 'true = Negocio especial con creador de pizzas, false = Negocio estándar';