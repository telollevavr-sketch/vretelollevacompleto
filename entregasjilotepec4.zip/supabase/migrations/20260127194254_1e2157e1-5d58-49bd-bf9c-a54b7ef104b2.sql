-- Create table for password reset records
CREATE TABLE public.password_resets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  temp_password TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (now() + interval '24 hours'),
  used_at TIMESTAMP WITH TIME ZONE NULL,
  created_by UUID NULL
);

-- Enable RLS
ALTER TABLE public.password_resets ENABLE ROW LEVEL SECURITY;

-- Index for faster lookups
CREATE INDEX idx_password_resets_user_id ON public.password_resets(user_id);

-- RLS Policies
-- Admins can view all password resets
CREATE POLICY "Admins pueden ver todos los resets"
ON public.password_resets
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can insert password resets
CREATE POLICY "Admins pueden crear resets"
ON public.password_resets
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Service role can do everything (for edge function)
CREATE POLICY "Service role acceso total password_resets"
ON public.password_resets
FOR ALL
USING (true)
WITH CHECK (true);