-- Agregar columnas de calificación separadas a la tabla orders
ALTER TABLE orders 
ADD COLUMN business_rating integer CHECK (business_rating >= 1 AND business_rating <= 5),
ADD COLUMN delivery_rating integer CHECK (delivery_rating >= 1 AND delivery_rating <= 5);

-- Función para actualizar calificación de negocios
CREATE OR REPLACE FUNCTION update_business_rating()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.business_rating IS NOT NULL AND OLD.business_rating IS NULL THEN
    UPDATE businesses
    SET 
      rating = (
        SELECT COALESCE(AVG(business_rating)::numeric, 0)
        FROM orders 
        WHERE business_id = NEW.business_id 
        AND business_rating IS NOT NULL
      ),
      review_count = (
        SELECT COUNT(*)
        FROM orders 
        WHERE business_id = NEW.business_id 
        AND business_rating IS NOT NULL
      )
    WHERE id = NEW.business_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Función para actualizar calificación de repartidores
CREATE OR REPLACE FUNCTION update_delivery_rating()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.delivery_rating IS NOT NULL AND OLD.delivery_rating IS NULL AND NEW.delivery_person_id IS NOT NULL THEN
    UPDATE profiles
    SET 
      rating = (
        SELECT COALESCE(AVG(delivery_rating)::numeric, 0)
        FROM orders 
        WHERE delivery_person_id = NEW.delivery_person_id 
        AND delivery_rating IS NOT NULL
      ),
      review_count = (
        SELECT COUNT(*)
        FROM orders 
        WHERE delivery_person_id = NEW.delivery_person_id 
        AND delivery_rating IS NOT NULL
      )
    WHERE id = NEW.delivery_person_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Agregar columnas de rating a profiles si no existen
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS rating numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS review_count integer DEFAULT 0;

-- Trigger para actualizar calificación de negocios
CREATE TRIGGER update_business_rating_trigger
AFTER UPDATE ON orders
FOR EACH ROW
WHEN (NEW.business_rating IS NOT NULL AND OLD.business_rating IS NULL)
EXECUTE FUNCTION update_business_rating();

-- Trigger para actualizar calificación de repartidores
CREATE TRIGGER update_delivery_rating_trigger
AFTER UPDATE ON orders
FOR EACH ROW
WHEN (NEW.delivery_rating IS NOT NULL AND OLD.delivery_rating IS NULL)
EXECUTE FUNCTION update_delivery_rating();