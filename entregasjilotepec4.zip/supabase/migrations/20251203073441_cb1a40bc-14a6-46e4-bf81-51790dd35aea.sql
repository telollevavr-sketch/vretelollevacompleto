-- Función para desactivar perfiles de business/delivery al registrarse
CREATE OR REPLACE FUNCTION public.set_inactive_for_business_delivery()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Si el rol es business o delivery, marcar el perfil como inactivo
  IF NEW.role IN ('business', 'delivery') THEN
    UPDATE profiles 
    SET is_active = false 
    WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger que se ejecuta después de insertar un rol
CREATE TRIGGER on_role_created_set_inactive
  AFTER INSERT ON user_roles
  FOR EACH ROW
  EXECUTE FUNCTION set_inactive_for_business_delivery();