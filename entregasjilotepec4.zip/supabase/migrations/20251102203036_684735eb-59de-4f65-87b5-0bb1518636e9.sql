-- 1. Eliminar todas las políticas actuales de profiles
DROP POLICY IF EXISTS "Actualizar propio perfil" ON public.profiles;
DROP POLICY IF EXISTS "Admins actualizan perfiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins ven perfiles" ON public.profiles;
DROP POLICY IF EXISTS "Repartidores ven repartidores" ON public.profiles;
DROP POLICY IF EXISTS "Ver perfiles business" ON public.profiles;
DROP POLICY IF EXISTS "Ver propio perfil" ON public.profiles;

-- 2. Recrear políticas seguras usando has_role()
CREATE POLICY "Ver propio perfil"
ON public.profiles FOR SELECT
TO authenticated
USING (id = auth.uid());

CREATE POLICY "Actualizar propio perfil"
ON public.profiles FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

CREATE POLICY "Admins ven todos los perfiles"
ON public.profiles FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins actualizan perfiles"
ON public.profiles FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Ver perfiles business"
ON public.profiles FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT user_id FROM public.user_roles 
    WHERE role = 'business'
  )
);

CREATE POLICY "Repartidores ven repartidores"
ON public.profiles FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'delivery')
  AND id IN (
    SELECT user_id FROM public.user_roles 
    WHERE role = 'delivery'
  )
);

-- 3. Eliminar columnas innecesarias
ALTER TABLE public.profiles 
DROP COLUMN IF EXISTS direct_business_id,
DROP COLUMN IF EXISTS is_direct_client;