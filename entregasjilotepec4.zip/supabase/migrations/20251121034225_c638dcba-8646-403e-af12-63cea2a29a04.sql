-- Primero eliminar políticas antiguas que dependen de business_id
DROP POLICY IF EXISTS "Admins gestionan todos los complementos" ON public.product_complements;
DROP POLICY IF EXISTS "Propietarios gestionan sus complementos" ON public.product_complements;
DROP POLICY IF EXISTS "Ver complementos disponibles" ON public.product_complements;

-- Eliminar todos los datos existentes ya que cambiaremos la estructura
DELETE FROM public.product_complements;

-- Eliminar la columna business_id y agregar product_id
ALTER TABLE public.product_complements
DROP COLUMN business_id,
ADD COLUMN product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE;

-- Crear nuevas políticas RLS para producto → complementos
CREATE POLICY "Admins gestionan todos los complementos"
ON public.product_complements
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Propietarios gestionan complementos de sus productos"
ON public.product_complements
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.products p
    JOIN public.businesses b ON b.id = p.business_id
    WHERE p.id = product_complements.product_id
    AND b.user_id = auth.uid()
  )
);

CREATE POLICY "Ver complementos disponibles de productos activos"
ON public.product_complements
FOR SELECT
USING (
  is_available = true
  AND EXISTS (
    SELECT 1 FROM public.products p
    JOIN public.businesses b ON b.id = p.business_id
    WHERE p.id = product_complements.product_id
    AND p.is_available = true
    AND b.is_active = true
  )
);

-- Crear índice para optimizar consultas por producto
CREATE INDEX IF NOT EXISTS idx_product_complements_product_id ON public.product_complements(product_id);