-- Corregir política de products para usuarios anónimos
-- Eliminar la restricción is_special_business
DROP POLICY IF EXISTS "Anónimos ven productos disponibles" ON public.products;

CREATE POLICY "Anónimos ven productos disponibles"
ON public.products FOR SELECT
TO anon
USING (
  is_available = true 
  AND EXISTS (
    SELECT 1 FROM public.businesses
    WHERE businesses.id = products.business_id
    AND businesses.is_active = true
  )
);

-- Corregir política de business_promotions para usuarios anónimos
DROP POLICY IF EXISTS "Anónimos ven promociones activas" ON public.business_promotions;

CREATE POLICY "Anónimos ven promociones activas"
ON public.business_promotions FOR SELECT
TO anon
USING (
  is_active = true 
  AND EXISTS (
    SELECT 1 FROM public.businesses
    WHERE businesses.id = business_promotions.business_id
    AND businesses.is_active = true
  )
);

-- También corregir política de businesses para usuarios anónimos
DROP POLICY IF EXISTS "Anónimos ven negocios activos públicos" ON public.businesses;

CREATE POLICY "Anónimos ven negocios activos"
ON public.businesses FOR SELECT
TO anon
USING (is_active = true);