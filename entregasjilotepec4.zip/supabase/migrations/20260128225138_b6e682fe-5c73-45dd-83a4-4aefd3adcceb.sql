-- Create table for structured business schedules
CREATE TABLE public.business_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES public.businesses(id) ON DELETE CASCADE,
  day_of_week INTEGER NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
  is_open BOOLEAN DEFAULT true,
  opening_time TIME NOT NULL,
  closing_time TIME NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(business_id, day_of_week)
);

-- Add auto_schedule_enabled column to businesses table
ALTER TABLE public.businesses 
ADD COLUMN auto_schedule_enabled BOOLEAN DEFAULT false;

-- Enable RLS on business_schedules
ALTER TABLE public.business_schedules ENABLE ROW LEVEL SECURITY;

-- RLS Policies for business_schedules

-- Admins can manage all schedules
CREATE POLICY "Admins gestionan todos los horarios"
ON public.business_schedules
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Business owners can manage their own schedules
CREATE POLICY "Propietarios gestionan horarios de su negocio"
ON public.business_schedules
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.businesses
    WHERE businesses.id = business_schedules.business_id
    AND businesses.user_id = auth.uid()
  )
);

-- Everyone can view schedules of active businesses
CREATE POLICY "Todos pueden ver horarios de negocios activos"
ON public.business_schedules
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.businesses
    WHERE businesses.id = business_schedules.business_id
    AND businesses.is_active = true
  )
);

-- Create trigger for updated_at
CREATE TRIGGER update_business_schedules_updated_at
BEFORE UPDATE ON public.business_schedules
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for business_schedules
ALTER PUBLICATION supabase_realtime ADD TABLE public.business_schedules;