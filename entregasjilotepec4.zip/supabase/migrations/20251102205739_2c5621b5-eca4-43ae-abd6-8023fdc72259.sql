-- 1. Corregir políticas de products para usuarios anónimos
DROP POLICY IF EXISTS "Anónimos ven productos de negocios activos" ON public.products;

CREATE POLICY "Anónimos ven productos disponibles"
ON public.products FOR SELECT
TO anon
USING (
  is_available = true 
  AND EXISTS (
    SELECT 1 FROM public.businesses
    WHERE businesses.id = products.business_id
    AND businesses.is_active = true
  )
);

-- 2. Corregir políticas de business_promotions para usuarios anónimos
DROP POLICY IF EXISTS "Anónimos ven promociones activas públicas" ON public.business_promotions;

CREATE POLICY "Anónimos ven promociones activas"
ON public.business_promotions FOR SELECT
TO anon
USING (
  is_active = true 
  AND EXISTS (
    SELECT 1 FROM public.businesses
    WHERE businesses.id = business_promotions.business_id
    AND businesses.is_active = true
  )
);

-- 3. Agregar políticas para que admins gestionen user_roles
DROP POLICY IF EXISTS "Admins gestionan roles" ON public.user_roles;

CREATE POLICY "Admins gestionan roles"
ON public.user_roles FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 4. Asegurar que admins puedan ver todos los roles
DROP POLICY IF EXISTS "Admins ven todos los roles" ON public.user_roles;

CREATE POLICY "Admins ven todos los roles"
ON public.user_roles FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));