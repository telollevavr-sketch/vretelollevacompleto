-- Agregar campo is_pickup_at_counter a la tabla orders
ALTER TABLE orders ADD COLUMN IF NOT EXISTS is_pickup_at_counter boolean DEFAULT false;