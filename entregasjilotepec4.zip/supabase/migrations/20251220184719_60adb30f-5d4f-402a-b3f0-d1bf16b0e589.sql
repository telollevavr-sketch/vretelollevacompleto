-- Add free_delivery column to businesses table
ALTER TABLE businesses ADD COLUMN free_delivery boolean DEFAULT false;

-- Update Hugo's Pizza locations to have free delivery
UPDATE businesses 
SET free_delivery = true, delivery_fee = 0 
WHERE name ILIKE '%hugo%' OR name ILIKE '%constituyentes%' OR name ILIKE '%vicente guerrero%';