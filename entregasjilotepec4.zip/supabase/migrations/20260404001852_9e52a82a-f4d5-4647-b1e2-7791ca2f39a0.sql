
-- Create antojo_businesses table
CREATE TABLE public.antojo_businesses (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  address text NOT NULL,
  phone text,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  menu_image text,
  menu_text text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create antojo_orders table
CREATE TABLE public.antojo_orders (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_number text NOT NULL,
  client_id uuid NOT NULL,
  antojo_business_id uuid NOT NULL REFERENCES public.antojo_businesses(id),
  order_description text,
  order_image text,
  delivery_address text NOT NULL,
  delivery_latitude double precision NOT NULL,
  delivery_longitude double precision NOT NULL,
  business_latitude double precision NOT NULL,
  business_longitude double precision NOT NULL,
  delivery_fee numeric NOT NULL DEFAULT 0,
  sale_total numeric,
  total numeric,
  status public.order_status NOT NULL DEFAULT 'pending',
  payment_method public.payment_method NOT NULL,
  delivery_person_id uuid,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.antojo_businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.antojo_orders ENABLE ROW LEVEL SECURITY;

-- RLS for antojo_businesses: public read, admin manage
CREATE POLICY "Todos ven negocios antojo activos" ON public.antojo_businesses
  FOR SELECT TO public USING (is_active = true OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins gestionan negocios antojo" ON public.antojo_businesses
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

-- RLS for antojo_orders
CREATE POLICY "Clientes crean pedidos antojo" ON public.antojo_orders
  FOR INSERT TO authenticated
  WITH CHECK (client_id = auth.uid() AND has_role(auth.uid(), 'client'));

CREATE POLICY "Clientes ven sus pedidos antojo" ON public.antojo_orders
  FOR SELECT TO authenticated USING (client_id = auth.uid());

CREATE POLICY "Admins gestionan pedidos antojo" ON public.antojo_orders
  FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Repartidores ven pedidos antojo asignados" ON public.antojo_orders
  FOR SELECT TO authenticated
  USING (delivery_person_id = auth.uid() OR (delivery_person_id IS NULL AND status = 'ready'));

CREATE POLICY "Repartidores actualizan pedidos antojo" ON public.antojo_orders
  FOR UPDATE TO authenticated
  USING (delivery_person_id = auth.uid() OR has_role(auth.uid(), 'admin'));

-- Enable realtime for antojo_orders
ALTER PUBLICATION supabase_realtime ADD TABLE public.antojo_orders;

-- Storage bucket for antojo images
INSERT INTO storage.buckets (id, name, public) VALUES ('antojo-images', 'antojo-images', true);

-- Storage RLS
CREATE POLICY "Authenticated users can upload antojo images" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'antojo-images');

CREATE POLICY "Anyone can view antojo images" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'antojo-images');
