-- Eliminar la política antigua de repartidores que solo les permitía ver sus órdenes asignadas
DROP POLICY IF EXISTS "Repartidores pueden ver sus órdenes asignadas" ON public.orders;

-- Crear nueva política que permite a repartidores ver sus órdenes asignadas Y pedidos disponibles
CREATE POLICY "Repartidores pueden ver sus órdenes y pedidos disponibles"
ON public.orders
FOR SELECT
USING (
  auth.uid() = delivery_person_id 
  OR 
  (delivery_person_id IS NULL AND status = 'ready')
);

-- Mantener la política de actualización para repartidores solo en sus órdenes asignadas
DROP POLICY IF EXISTS "Repartidores pueden actualizar sus órdenes asignadas" ON public.orders;

CREATE POLICY "Repartidores pueden actualizar sus órdenes asignadas"
ON public.orders
FOR UPDATE
USING (auth.uid() = delivery_person_id OR delivery_person_id IS NULL);
