-- Crear enums para roles y estados
CREATE TYPE public.app_role AS ENUM ('admin', 'client', 'business', 'delivery');
CREATE TYPE public.order_status AS ENUM ('pending', 'accepted', 'preparing', 'ready', 'in_delivery', 'delivered', 'cancelled');
CREATE TYPE public.payment_method AS ENUM ('cash', 'transfer');
CREATE TYPE public.business_type AS ENUM ('restaurant', 'pharmacy', 'supermarket', 'other');

-- Tabla de perfiles de usuario
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  avatar_url TEXT,
  vehicle_type TEXT,
  vehicle_plate TEXT,
  is_online BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tabla de roles de usuario (seguridad)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Función para verificar roles (security definer para evitar recursión RLS)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- Tabla de negocios
CREATE TABLE public.businesses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  business_type business_type NOT NULL,
  description TEXT,
  address TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  phone TEXT,
  image_url TEXT,
  rating NUMERIC(3,2) DEFAULT 0,
  review_count INTEGER DEFAULT 0,
  is_open BOOLEAN DEFAULT true,
  opening_time TIME,
  closing_time TIME,
  min_order_amount NUMERIC(10,2) DEFAULT 0,
  delivery_fee NUMERIC(10,2) DEFAULT 0,
  delivery_time_minutes INTEGER DEFAULT 30,
  max_delivery_distance_km NUMERIC(5,2) DEFAULT 10,
  accepts_cash BOOLEAN DEFAULT true,
  accepts_transfer BOOLEAN DEFAULT true,
  is_active BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Tabla de productos
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES public.businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  category TEXT NOT NULL,
  image_url TEXT,
  is_available BOOLEAN DEFAULT true,
  preparation_time_minutes INTEGER DEFAULT 15,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tabla de órdenes
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT NOT NULL UNIQUE,
  client_id UUID NOT NULL REFERENCES auth.users(id),
  business_id UUID NOT NULL REFERENCES public.businesses(id),
  delivery_person_id UUID REFERENCES auth.users(id),
  items JSONB NOT NULL,
  subtotal NUMERIC(10,2) NOT NULL,
  delivery_fee NUMERIC(10,2) NOT NULL DEFAULT 0,
  total NUMERIC(10,2) NOT NULL,
  status order_status NOT NULL DEFAULT 'pending',
  payment_method payment_method NOT NULL,
  delivery_address TEXT NOT NULL,
  delivery_latitude DOUBLE PRECISION NOT NULL,
  delivery_longitude DOUBLE PRECISION NOT NULL,
  notes TEXT,
  rating INTEGER,
  review TEXT,
  accepted_at TIMESTAMPTZ,
  ready_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tabla de mensajes de órdenes
CREATE TABLE public.order_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id),
  sender_role app_role NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Habilitar RLS en todas las tablas
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_messages ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para profiles
CREATE POLICY "Usuarios pueden ver su propio perfil"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Usuarios pueden actualizar su propio perfil"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Todos pueden ver perfiles de negocios activos"
  ON public.profiles FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = profiles.id AND role = 'business'
  ));

CREATE POLICY "Admins pueden ver todos los perfiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins pueden actualizar todos los perfiles"
  ON public.profiles FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- Políticas RLS para user_roles
CREATE POLICY "Usuarios pueden ver sus propios roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins pueden gestionar todos los roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Políticas RLS para businesses
CREATE POLICY "Todos pueden ver negocios activos"
  ON public.businesses FOR SELECT
  USING (is_active = true OR auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Propietarios pueden actualizar su negocio"
  ON public.businesses FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Usuarios con rol business pueden crear negocios"
  ON public.businesses FOR INSERT
  WITH CHECK (auth.uid() = user_id AND public.has_role(auth.uid(), 'business'));

CREATE POLICY "Admins pueden gestionar todos los negocios"
  ON public.businesses FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Políticas RLS para products
CREATE POLICY "Todos pueden ver productos de negocios activos"
  ON public.products FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.businesses 
      WHERE id = products.business_id AND is_active = true
    )
  );

CREATE POLICY "Propietarios pueden gestionar productos de su negocio"
  ON public.products FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.businesses 
      WHERE id = products.business_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "Admins pueden gestionar todos los productos"
  ON public.products FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Políticas RLS para orders
CREATE POLICY "Clientes pueden ver sus propias órdenes"
  ON public.orders FOR SELECT
  USING (auth.uid() = client_id);

CREATE POLICY "Negocios pueden ver órdenes de su negocio"
  ON public.orders FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.businesses 
      WHERE id = orders.business_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "Repartidores pueden ver sus órdenes asignadas"
  ON public.orders FOR SELECT
  USING (auth.uid() = delivery_person_id);

CREATE POLICY "Clientes pueden crear órdenes"
  ON public.orders FOR INSERT
  WITH CHECK (auth.uid() = client_id AND public.has_role(auth.uid(), 'client'));

CREATE POLICY "Negocios pueden actualizar órdenes de su negocio"
  ON public.orders FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.businesses 
      WHERE id = orders.business_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "Repartidores pueden actualizar sus órdenes asignadas"
  ON public.orders FOR UPDATE
  USING (auth.uid() = delivery_person_id);

CREATE POLICY "Admins pueden gestionar todas las órdenes"
  ON public.orders FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Políticas RLS para order_messages
CREATE POLICY "Participantes pueden ver mensajes de sus órdenes"
  ON public.order_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.orders 
      WHERE id = order_messages.order_id 
      AND (
        client_id = auth.uid() 
        OR delivery_person_id = auth.uid()
        OR business_id IN (
          SELECT id FROM public.businesses WHERE user_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "Participantes pueden crear mensajes en sus órdenes"
  ON public.order_messages FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id
    AND EXISTS (
      SELECT 1 FROM public.orders 
      WHERE id = order_messages.order_id 
      AND (
        client_id = auth.uid() 
        OR delivery_person_id = auth.uid()
        OR business_id IN (
          SELECT id FROM public.businesses WHERE user_id = auth.uid()
        )
      )
    )
  );

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Triggers para actualizar updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_businesses_updated_at
  BEFORE UPDATE ON public.businesses
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger para crear perfil automáticamente al registrarse
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.email)
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Crear índices para mejorar el rendimiento
CREATE INDEX idx_businesses_user_id ON public.businesses(user_id);
CREATE INDEX idx_businesses_location ON public.businesses(latitude, longitude);
CREATE INDEX idx_products_business_id ON public.products(business_id);
CREATE INDEX idx_orders_client_id ON public.orders(client_id);
CREATE INDEX idx_orders_business_id ON public.orders(business_id);
CREATE INDEX idx_orders_delivery_person_id ON public.orders(delivery_person_id);
CREATE INDEX idx_orders_status ON public.orders(status);
CREATE INDEX idx_order_messages_order_id ON public.order_messages(order_id);
CREATE INDEX idx_user_roles_user_id ON public.user_roles(user_id);