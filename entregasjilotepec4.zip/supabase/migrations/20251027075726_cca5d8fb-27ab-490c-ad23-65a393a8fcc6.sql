-- Agregar columna role_type a la tabla profiles para evitar necesidad de consultar user_roles
-- Esto permitirá que los negocios vean qué usuarios son repartidores sin problemas RLS

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role_type text;

-- Poblar la columna role_type con los datos existentes de user_roles
UPDATE profiles 
SET role_type = (
  SELECT role::text 
  FROM user_roles 
  WHERE user_roles.user_id = profiles.id 
  LIMIT 1
);

-- Crear índice para mejorar rendimiento
CREATE INDEX IF NOT EXISTS idx_profiles_role_type ON profiles(role_type);

-- Crear función para actualizar role_type automáticamente cuando se inserta/actualiza user_roles
CREATE OR REPLACE FUNCTION sync_profile_role_type()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    UPDATE profiles 
    SET role_type = NEW.role::text 
    WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Crear trigger para mantener sincronizado
DROP TRIGGER IF EXISTS trigger_sync_profile_role_type ON user_roles;
CREATE TRIGGER trigger_sync_profile_role_type
AFTER INSERT OR UPDATE ON user_roles
FOR EACH ROW
EXECUTE FUNCTION sync_profile_role_type();