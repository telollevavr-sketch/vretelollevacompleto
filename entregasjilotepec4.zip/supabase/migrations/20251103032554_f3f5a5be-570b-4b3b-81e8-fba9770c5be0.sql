-- Eliminar políticas existentes de SELECT
DROP POLICY IF EXISTS "Anónimos y autenticados ven negocios activos" ON public.businesses;
DROP POLICY IF EXISTS "Ver negocios activos o propios" ON public.businesses;

-- Crear una única política de SELECT que cubra todos los casos
CREATE POLICY "Ver negocios" 
ON public.businesses 
FOR SELECT 
TO public, authenticated
USING (
  is_active = true 
  OR user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);