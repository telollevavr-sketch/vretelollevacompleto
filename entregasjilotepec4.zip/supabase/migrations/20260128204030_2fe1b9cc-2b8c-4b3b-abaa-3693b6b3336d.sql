-- Add column to track how many items to charge in priced combos
-- 1 = pay for 1 item (2x1), 2 = pay for 2 items (3x2), etc.
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS priced_items_count INTEGER DEFAULT 1;

COMMENT ON COLUMN products.priced_items_count IS 
'Number of items to charge in priced combos. 1 = 2x1 (pay highest), 2 = 3x2 (pay 2 highest), etc.';