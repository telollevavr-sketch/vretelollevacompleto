
-- Actualizar política RLS para notificaciones
-- Permitir que usuarios autenticados creen notificaciones para otros usuarios
-- Esto es necesario para que negocios y repartidores notifiquen a clientes

DROP POLICY IF EXISTS "Usuarios autenticados pueden crear notificaciones" ON notifications;

CREATE POLICY "Usuarios autenticados pueden crear notificaciones"
ON notifications
FOR INSERT
TO authenticated
WITH CHECK (true);
