-- Eliminar la política anterior
DROP POLICY IF EXISTS "allow_all_authenticated_inserts" ON notifications;

-- Crear la política MÁS SIMPLE POSIBLE
-- Esta permite INSERT a TODO usuario autenticado, sin verificaciones adicionales
CREATE POLICY "simple_insert_policy"
ON notifications
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Asegurar que no haya ninguna otra política restrictiva
-- Ver comentario
COMMENT ON POLICY "simple_insert_policy" ON notifications IS 
'Política simple que permite a usuarios autenticados crear cualquier notificación';