-- Add full_address field to businesses table for complete postal address
ALTER TABLE businesses 
ADD COLUMN IF NOT EXISTS full_address TEXT;

COMMENT ON COLUMN businesses.full_address IS 'Complete postal address including all postal details';