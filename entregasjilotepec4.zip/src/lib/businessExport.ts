import * as XLSX from 'xlsx';
import { format } from 'date-fns';

// Función para exportar menú (productos)
export const exportMenuToExcel = (products: any[], businessName: string) => {
  const workbook = XLSX.utils.book_new();
  
  // Preparar datos del menú
  const menuData = products.map((product, index) => ({
    '#': index + 1,
    'Nombre': product.name,
    'Categoría': product.category,
    'Precio': `$${product.price.toFixed(2)}`,
    'Descripción': product.description || '',
    'Disponible': product.isAvailable ? 'Sí' : 'No',
    'Es Promocional': product.isPromotionalCombo ? 'Sí' : 'No',
    'Es Especialidad': product.isSpecialty ? 'Sí' : 'No',
    'Items en Combo': product.comboConfiguration?.itemCount || 'N/A',
    'Tipo de Combo': product.comboConfiguration?.itemType || 'N/A',
    'Tiempo Prep (min)': product.preparationTimeMinutes || 15,
    'URL Imagen': product.image || ''
  }));
  
  const worksheet = XLSX.utils.json_to_sheet(menuData);
  
  // Ajustar ancho de columnas
  worksheet['!cols'] = [
    { wch: 5 },  // #
    { wch: 30 }, // Nombre
    { wch: 15 }, // Categoría
    { wch: 10 }, // Precio
    { wch: 50 }, // Descripción
    { wch: 10 }, // Disponible
    { wch: 15 }, // Es Promocional
    { wch: 15 }, // Es Especialidad
    { wch: 15 }, // Items en Combo
    { wch: 15 }, // Tipo de Combo
    { wch: 15 }, // Tiempo Prep
    { wch: 50 }  // URL Imagen
  ];
  
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Menú');
  
  // Agregar hoja de resumen
  const summaryData = [
    ['REPORTE DE MENÚ'],
    ['Negocio:', businessName],
    ['Fecha de Exportación:', format(new Date(), 'dd/MM/yyyy HH:mm')],
    ['Total de Productos:', products.length],
    ['Productos Disponibles:', products.filter(p => p.isAvailable).length],
    ['Productos No Disponibles:', products.filter(p => !p.isAvailable).length],
    ['Promocionales:', products.filter(p => p.isPromotionalCombo).length],
    ['Especialidades:', products.filter(p => p.isSpecialty).length]
  ];
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumen');
  
  const fileName = `menu-${businessName.replace(/\s+/g, '_')}-${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};

// Función para exportar especialidades
export const exportSpecialtiesToExcel = (specialties: any[], businessName: string) => {
  const workbook = XLSX.utils.book_new();
  
  const specialtiesData = specialties.map((specialty, index) => ({
    '#': index + 1,
    'Nombre': specialty.name,
    'Tipo': specialty.specialtyType || 'pizza',
    'Descripción': specialty.description || '',
    'Activa': specialty.isActive ? 'Sí' : 'No',
    'Fecha Creación': format(new Date(specialty.createdAt), 'dd/MM/yyyy')
  }));
  
  const worksheet = XLSX.utils.json_to_sheet(specialtiesData);
  
  worksheet['!cols'] = [
    { wch: 5 },  // #
    { wch: 30 }, // Nombre
    { wch: 15 }, // Tipo
    { wch: 60 }, // Descripción
    { wch: 10 }, // Activa
    { wch: 15 }  // Fecha Creación
  ];
  
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Especialidades');
  
  // Resumen
  const summaryData = [
    ['REPORTE DE ESPECIALIDADES'],
    ['Negocio:', businessName],
    ['Fecha de Exportación:', format(new Date(), 'dd/MM/yyyy HH:mm')],
    ['Total de Especialidades:', specialties.length],
    ['Especialidades Activas:', specialties.filter(s => s.isActive).length],
    ['Especialidades Inactivas:', specialties.filter(s => !s.isActive).length],
    [],
    ['DISTRIBUCIÓN POR TIPO'],
    ['Pizzas:', specialties.filter(s => (s.specialtyType || 'pizza') === 'pizza').length],
    ['Refrescos:', specialties.filter(s => s.specialtyType === 'refresco').length],
    ['Salsas:', specialties.filter(s => s.specialtyType === 'salsa').length],
    ['Quesos:', specialties.filter(s => s.specialtyType === 'queso').length],
    ['Otros:', specialties.filter(s => s.specialtyType && !['pizza', 'refresco', 'salsa', 'queso'].includes(s.specialtyType)).length]
  ];
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumen');
  
  const fileName = `especialidades-${businessName.replace(/\s+/g, '_')}-${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};

// Función para exportar complementos (Master-Detail)
export const exportComplementsToExcel = (products: any[], businessName: string) => {
  const workbook = XLSX.utils.book_new();
  
  // Hoja 1: Vista Master-Detail (todos los complementos con su producto)
  const detailData: any[] = [];
  products.forEach(product => {
    if (product.complements && product.complements.length > 0) {
      product.complements.forEach((complement: any, index: number) => {
        detailData.push({
          'Producto': product.name,
          'Categoría Producto': product.category,
          '#': index + 1,
          'Complemento': complement.name,
          'Categoría Complemento': complement.category,
          'Precio': `$${complement.price.toFixed(2)}`,
          'Descripción': complement.description || '',
          'Disponible': complement.isAvailable ? 'Sí' : 'No'
        });
      });
    }
  });
  
  if (detailData.length > 0) {
    const detailSheet = XLSX.utils.json_to_sheet(detailData);
    detailSheet['!cols'] = [
      { wch: 30 }, // Producto
      { wch: 20 }, // Categoría Producto
      { wch: 5 },  // #
      { wch: 30 }, // Complemento
      { wch: 20 }, // Categoría Complemento
      { wch: 10 }, // Precio
      { wch: 50 }, // Descripción
      { wch: 12 }  // Disponible
    ];
    XLSX.utils.book_append_sheet(workbook, detailSheet, 'Complementos Detalle');
  }
  
  // Hoja 2: Vista Master (productos con conteo de complementos)
  const masterData = products.map((product, index) => ({
    '#': index + 1,
    'Producto': product.name,
    'Categoría': product.category,
    'Total Complementos': product.complements?.length || 0,
    'Complementos Disponibles': product.complements?.filter((c: any) => c.isAvailable).length || 0,
    'Complementos No Disponibles': product.complements?.filter((c: any) => !c.isAvailable).length || 0
  }));
  
  const masterSheet = XLSX.utils.json_to_sheet(masterData);
  masterSheet['!cols'] = [
    { wch: 5 },  // #
    { wch: 30 }, // Producto
    { wch: 20 }, // Categoría
    { wch: 18 }, // Total Complementos
    { wch: 22 }, // Complementos Disponibles
    { wch: 25 }  // Complementos No Disponibles
  ];
  XLSX.utils.book_append_sheet(workbook, masterSheet, 'Resumen por Producto');
  
  // Hoja 3: Resumen general
  const totalComplements = detailData.length;
  const availableComplements = detailData.filter(c => c.Disponible === 'Sí').length;
  
  const summaryData = [
    ['REPORTE DE COMPLEMENTOS'],
    ['Negocio:', businessName],
    ['Fecha de Exportación:', format(new Date(), 'dd/MM/yyyy HH:mm')],
    [],
    ['RESUMEN GENERAL'],
    ['Total de Productos:', products.length],
    ['Productos con Complementos:', products.filter(p => p.complements && p.complements.length > 0).length],
    ['Total de Complementos:', totalComplements],
    ['Complementos Disponibles:', availableComplements],
    ['Complementos No Disponibles:', totalComplements - availableComplements]
  ];
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumen General');
  
  const fileName = `complementos-${businessName.replace(/\s+/g, '_')}-${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};

// Función para exportar a TSV (Tab-Separated Values)
export const exportToTSV = (data: any[], fileName: string) => {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const tsvContent = XLSX.utils.sheet_to_csv(worksheet, { FS: '\t' });
  
  const blob = new Blob([tsvContent], { type: 'text/tab-separated-values' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${fileName}.tsv`;
  link.click();
  window.URL.revokeObjectURL(url);
};
