import jsPDF from "jspdf";
import { Order, Business, PaymentMethod, OrderStatus } from "@/types";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import watermarkImg from "@/assets/vrtelolleva-watermark.png";

// Constantes para cálculo de líneas
const CHARS_PER_LINE = 28; // ~28 caracteres por línea en 70mm de ancho

// Función para estimar líneas de texto
const estimateLines = (text: string, charsPerLine: number = CHARS_PER_LINE): number => {
  return Math.ceil(text.length / charsPerLine);
};

// Función para calcular la altura dinámica del contenido
const calculateContentHeight = (order: Order, business: Business): number => {
  let height = 10; // Inicio

  // Encabezado del negocio
  height += 6; // Nombre
  const businessAddress = business.fullAddress || business.address;
  const addressLines = estimateLines(businessAddress, 30);
  height += addressLines * 3 + 2;
  height += 5; // Teléfono
  height += 5; // Línea separadora

  // Título
  height += 7;

  // Info del pedido
  height += 4; // Pedido ID
  height += 4; // Fecha
  height += 4; // Estado
  height += 4; // Pago
  if (order.isPickupAtCounter) height += 4;
  height += 7; // Espaciado + línea

  // Productos header
  height += 8; // Título + línea

  order.items.forEach((item) => {
    // Nombre del producto con wrap
    const productNameText = `${item.quantity}x ${item.product.name}`;
    const productNameLines = estimateLines(productNameText, CHARS_PER_LINE);
    height += productNameLines * 3 + 1;

    if (item.configuration) {
      if (item.configuration.size) height += 3;
      if (item.configuration.ingredients?.length) {
        height += 3;
        item.configuration.ingredients.forEach((ing) => {
          const ingLines = estimateLines(`   • ${ing}`, 25);
          height += ingLines * 3 + 1;
        });
      }
      if (item.configuration.extraCheese) height += 3;
      if (item.configuration.stuffedCrust) height += 3;
    }

    // Especialidad con wrap
    if (item.specialtySelection) {
      const specialtyText = `   Especialidad: ${item.specialtySelection.specialtyName}`;
      const specialtyLines = estimateLines(specialtyText, CHARS_PER_LINE);
      height += specialtyLines * 3 + 1;
    }
    
    // Combo selections con wrap - usando itemLabel guardado
    if (item.comboSelections?.length) {
      height += 3; // "Combo:" header
      
      item.comboSelections.forEach((combo) => {
        const label = combo.itemLabel || `Producto ${combo.pizzaIndex + 1}`;
        const comboText = `   ${label}: ${combo.specialtyName} (${combo.size})`;
        const comboLines = estimateLines(comboText, CHARS_PER_LINE);
        height += comboLines * 3 + 1;
      });
    }
    
    if (item.notes) {
      const notesLines = estimateLines(`   Notas: ${item.notes}`, 25);
      height += notesLines * 3 + 1;
    }
    
    height += 5; // Precio + espaciado
  });

  // Totales
  height += 5; // Línea
  height += 4; // Subtotal
  height += 4; // Envío
  height += 4; // Línea
  height += 6; // Total
  height += 5; // Línea

  // Dirección de entrega
  if (!order.isPickupAtCounter && order.deliveryLocation) {
    height += 4; // Header
    const deliveryAddressLines = estimateLines(order.deliveryLocation.address || "No especificada", 30);
    height += deliveryAddressLines * 3 + 4;
  }

  // Notas
  if (order.notes) {
    height += 4; // Header
    const notesLines = estimateLines(order.notes, 30);
    height += notesLines * 3 + 4;
  }

  // Pie
  height += 5; // Línea
  height += 10; // Gracias + fecha
  height += 10; // Margen inferior

  return height;
};

export const generateOrderTicketPDF = (order: Order, business: Business) => {
  const pageWidth = 80;
  const margin = 5;
  const contentWidth = pageWidth - margin * 2;

  // Calcular altura dinámica basada en el contenido
  const dynamicHeight = calculateContentHeight(order, business);

  // Crear documento PDF con tamaño dinámico
  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: [pageWidth, dynamicHeight],
  });

  let yPosition = 10;

  // Add watermark in top-left corner at 10% scale
  try {
    const imgWidth = 6;
    const imgHeight = 5;
    const x = margin;
    const y = margin;

    pdf.addImage(watermarkImg, "PNG", x, y, imgWidth, imgHeight, undefined, "FAST");
  } catch (error) {
    console.warn("Could not add watermark to ticket:", error);
  }

  // Función helper para texto centrado
  const addCenteredText = (text: string, y: number, fontSize: number = 10, isBold: boolean = false) => {
    pdf.setFontSize(fontSize);
    if (isBold) pdf.setFont("helvetica", "bold");
    else pdf.setFont("helvetica", "normal");

    const textWidth = pdf.getTextWidth(text);
    const x = (pageWidth - textWidth) / 2;
    pdf.text(text, x, y);
  };

  // Función helper para texto con wrap (soporta bold)
  const addWrappedText = (text: string, x: number, y: number, maxWidth: number, fontSize: number = 8, isBold: boolean = false): number => {
    pdf.setFontSize(fontSize);
    pdf.setFont("helvetica", isBold ? "bold" : "normal");
    const lines = pdf.splitTextToSize(text, maxWidth);
    pdf.text(lines, x, y);
    return lines.length * (fontSize * 0.4);
  };

  // ===== ENCABEZADO =====
  addCenteredText(business.name.toUpperCase(), yPosition, 12, true);
  yPosition += 6;

  pdf.setFontSize(8);
  pdf.setFont("helvetica", "normal");
  const businessAddress = business.fullAddress || business.address;
  const addressHeight = addWrappedText(businessAddress, margin, yPosition, contentWidth, 8);
  yPosition += addressHeight + 2;

  addCenteredText(business.phone, yPosition, 8);
  yPosition += 5;

  // Línea separadora
  pdf.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 5;

  // ===== TÍTULO =====
  addCenteredText("TICKET DE COMPRA", yPosition, 11, true);
  yPosition += 7;

  // ===== INFORMACIÓN DEL PEDIDO =====
  pdf.setFontSize(8);
  pdf.setFont("helvetica", "normal");

  // Pedido ID (acortado)
  pdf.text(`Pedido: #${order.id.slice(0, 8).toUpperCase()}`, margin, yPosition);
  yPosition += 4;

  // Fecha
  const formattedDate = format(new Date(order.createdAt), "dd/MM/yyyy HH:mm", { locale: es });
  pdf.text(`Fecha: ${formattedDate}`, margin, yPosition);
  yPosition += 4;

  // Estado
  const statusLabels: Record<OrderStatus, string> = {
    [OrderStatus.PENDING]: "Pendiente",
    [OrderStatus.IN_PREPARATION]: "En Preparacion",
    [OrderStatus.READY_FOR_PICKUP]: "Listo",
    [OrderStatus.ON_THE_WAY]: "En Camino",
    [OrderStatus.DELIVERED]: "Entregado",
    [OrderStatus.CANCELLED]: "Cancelado",
  };
  pdf.text(`Estado: ${statusLabels[order.status]}`, margin, yPosition);
  yPosition += 4;

  // Método de pago
  const paymentLabels = {
    [PaymentMethod.CASH]: "Efectivo",
    [PaymentMethod.TRANSFER]: "Transferencia",
  };
  pdf.text(`Pago: ${paymentLabels[order.paymentMethod]}`, margin, yPosition);
  yPosition += 4;

  // Tipo de entrega
  if (order.isPickupAtCounter) {
    pdf.text("Tipo: Recoger en mostrador", margin, yPosition);
    yPosition += 4;
  }

  yPosition += 2;

  // Línea separadora
  pdf.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 5;

  // ===== PRODUCTOS =====
  pdf.setFont("helvetica", "bold");
  pdf.text("PRODUCTOS", margin, yPosition);
  yPosition += 4;

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(7);

  // Línea de guiones
  pdf.text("----------------------------------------", margin, yPosition);
  yPosition += 4;

  order.items.forEach((item) => {
    // Nombre del producto CON WRAP
    const productNameHeight = addWrappedText(
      `${item.quantity}x ${item.product.name}`,
      margin + 2,
      yPosition,
      contentWidth - 4,
      8,
      true // Bold
    );
    yPosition += productNameHeight + 1;

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(7);

    // Configuración de pizza
    if (item.configuration) {
      if (item.configuration.size) {
        pdf.text(`   Tamano: ${item.configuration.size}`, margin + 2, yPosition);
        yPosition += 3;
      }

      if (item.configuration.ingredients && item.configuration.ingredients.length > 0) {
        pdf.text(`   Ingredientes:`, margin + 2, yPosition);
        yPosition += 3;

        item.configuration.ingredients.forEach((ing) => {
          const ingHeight = addWrappedText(`   • ${ing}`, margin + 2, yPosition, contentWidth - 4, 7);
          yPosition += ingHeight + 1;
        });
      }

      if (item.configuration.extraCheese) {
        pdf.text(`   ✓ Queso extra`, margin + 2, yPosition);
        yPosition += 3;
      }

      if (item.configuration.stuffedCrust) {
        pdf.text(`   ✓ Orilla rellena`, margin + 2, yPosition);
        yPosition += 3;
      }
    }

    // Selección de especialidad CON WRAP
    if (item.specialtySelection) {
      const specialtyHeight = addWrappedText(
        `   Especialidad: ${item.specialtySelection.specialtyName}`,
        margin + 2,
        yPosition,
        contentWidth - 4,
        7
      );
      yPosition += specialtyHeight + 1;
    }

    // Combo selections CON WRAP - usando itemType e itemLabel guardados
    if (item.comboSelections && item.comboSelections.length > 0) {
      pdf.text(`   Combo:`, margin + 2, yPosition);
      yPosition += 3;

      item.comboSelections.forEach((combo) => {
        // Usar itemLabel guardado en la selección
        const label = combo.itemLabel || `Producto ${combo.pizzaIndex + 1}`;
        const comboHeight = addWrappedText(
          `   ${label}: ${combo.specialtyName} (${combo.size})`,
          margin + 2,
          yPosition,
          contentWidth - 4,
          7
        );
        yPosition += comboHeight + 1;
      });
    }

    // Notas del item
    if (item.notes) {
      const notesHeight = addWrappedText(`   Notas: ${item.notes}`, margin + 2, yPosition, contentWidth - 4, 7);
      yPosition += notesHeight + 1;
    }

    // Precio del item
    pdf.text(`   Precio: $${item.subtotal.toFixed(2)}`, margin + 2, yPosition);
    yPosition += 5;
  });

  // Línea separadora
  pdf.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 5;

  // ===== TOTALES =====
  pdf.setFontSize(8);
  pdf.setFont("helvetica", "normal");

  // Subtotal
  const subtotal = order.totalAmount - (order.deliveryFee || 0);
  pdf.text("Subtotal:", margin, yPosition);
  pdf.text(`$${subtotal.toFixed(2)}`, pageWidth - margin - pdf.getTextWidth(`$${subtotal.toFixed(2)}`), yPosition);
  yPosition += 4;

  // Envío
  pdf.text("Costo de envio:", margin, yPosition);
  pdf.text(
    `$${(order.deliveryFee || 0).toFixed(2)}`,
    pageWidth - margin - pdf.getTextWidth(`$${(order.deliveryFee || 0).toFixed(2)}`),
    yPosition,
  );
  yPosition += 4;

  // Línea de guiones
  pdf.text("----------------------------------------", margin, yPosition);
  yPosition += 4;

  // Total
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(10);
  pdf.text("TOTAL:", margin, yPosition);
  pdf.text(
    `$${order.totalAmount.toFixed(2)}`,
    pageWidth - margin - pdf.getTextWidth(`$${order.totalAmount.toFixed(2)}`),
    yPosition,
  );
  yPosition += 6;

  // Línea separadora
  pdf.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 5;

  // ===== INFORMACIÓN DE ENTREGA =====
  if (!order.isPickupAtCounter && order.deliveryLocation) {
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(8);
    pdf.text("Direccion de Entrega:", margin, yPosition);
    yPosition += 4;

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(7);
    const deliveryAddressHeight = addWrappedText(
      order.deliveryLocation.address || "No especificada",
      margin,
      yPosition,
      contentWidth,
      7,
    );
    yPosition += deliveryAddressHeight + 4;
  }

  // Notas del pedido
  if (order.notes) {
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(8);
    pdf.text("Notas:", margin, yPosition);
    yPosition += 4;

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(7);
    const notesHeight = addWrappedText(order.notes, margin, yPosition, contentWidth, 7);
    yPosition += notesHeight + 4;
  }

  // Línea separadora
  pdf.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 5;

  // ===== PIE =====
  addCenteredText("¡Gracias por su compra!", yPosition, 9, true);
  yPosition += 5;

  pdf.setFontSize(7);
  pdf.setFont("helvetica", "normal");
  const generatedTime = format(new Date(), "dd/MM/yyyy HH:mm", { locale: es });
  addCenteredText(`Generado: ${generatedTime}`, yPosition, 7);

  // Abrir en nueva pestaña para vista previa
  window.open(pdf.output("bloburl"), "_blank");
};
