/**
 * Utilidades para detección de dispositivos y manejo de URLs externas en iOS
 */

export interface DeviceInfo {
  isIOS: boolean;
  isAndroid: boolean;
  isSafari: boolean;
  isChromeiOS: boolean;
  isStandalone: boolean;
  isFirefoxiOS: boolean;
}

/**
 * Detecta el tipo de dispositivo y navegador del usuario
 */
export const detectDevice = (): DeviceInfo => {
  const ua = navigator.userAgent.toLowerCase();
  
  const isIOS = /iphone|ipad|ipod/.test(ua);
  const isAndroid = /android/.test(ua);
  
  // Safari real: contiene 'safari' pero NO contiene 'chrome', 'crios', 'fxios'
  const isSafari = isIOS && /safari/.test(ua) && !/chrome/.test(ua) && !/crios/.test(ua) && !/fxios/.test(ua);
  
  // Chrome en iOS
  const isChromeiOS = isIOS && /crios/.test(ua);
  
  // Firefox en iOS
  const isFirefoxiOS = isIOS && /fxios/.test(ua);
  
  // Detectar modo standalone (PWA instalada)
  const isStandalone = 
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true;
  
  return { isIOS, isAndroid, isSafari, isChromeiOS, isStandalone, isFirefoxiOS };
};

/**
 * Abre una URL externa de forma compatible con iOS en modo standalone
 * En iOS standalone, window.open() no funciona correctamente para apps externas
 */
export const openExternalUrl = (url: string): void => {
  const { isIOS, isStandalone } = detectDevice();
  
  if (isIOS && isStandalone) {
    // Método 1: Crear un anchor y hacer click programático
    // Esto funciona mejor en iOS standalone para deep links
    const a = document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('target', '_blank');
    a.setAttribute('rel', 'noopener noreferrer');
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    
    // Limpiar después de un pequeño delay
    setTimeout(() => {
      document.body.removeChild(a);
    }, 100);
  } else {
    // En otros navegadores, usar window.open normal
    window.open(url, '_blank', 'noopener,noreferrer');
  }
};

/**
 * Abre WhatsApp con un mensaje predefinido
 * Usa wa.me que funciona mejor en iOS que api.whatsapp.com
 */
export const openWhatsApp = (phoneNumber: string, message: string): void => {
  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
  openExternalUrl(whatsappUrl);
};

/**
 * Verifica si el usuario puede instalar la PWA desde Safari
 */
export const canInstallFromSafari = (): boolean => {
  const { isIOS, isSafari, isStandalone } = detectDevice();
  return isIOS && isSafari && !isStandalone;
};

/**
 * Verifica si el usuario está en un navegador iOS que no es Safari
 * (Chrome, Firefox, etc.) donde no pueden instalar la PWA
 */
export const needsSafariForInstall = (): boolean => {
  const { isIOS, isChromeiOS, isFirefoxiOS, isStandalone } = detectDevice();
  return isIOS && (isChromeiOS || isFirefoxiOS) && !isStandalone;
};
