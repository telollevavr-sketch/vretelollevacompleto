import * as XLSX from 'xlsx';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import type { BackupData, TableStats } from '@/hooks/useDataBackup';

const TABLE_ORDER = [
  'profiles',
  'userRoles',
  'categories',
  'businessTypes',
  'businesses',
  'products',
  'productComplements',
  'complementTemplates',
  'pizzaSpecialties',
  'orders',
  'orderMessages',
  'notifications',
  'businessMenuImages',
  'businessPromotions',
];

const TABLE_NAMES_MAP: Record<string, string> = {
  profiles: 'profiles',
  userRoles: 'user_roles',
  categories: 'categories',
  businessTypes: 'business_types',
  businesses: 'businesses',
  products: 'products',
  productComplements: 'product_complements',
  complementTemplates: 'complement_templates',
  pizzaSpecialties: 'pizza_specialties',
  orders: 'orders',
  orderMessages: 'order_messages',
  notifications: 'notifications',
  businessMenuImages: 'business_menu_images',
  businessPromotions: 'business_promotions',
};

const TABLE_DISPLAY_NAMES: Record<string, string> = {
  profiles: 'Perfiles',
  userRoles: 'Roles',
  categories: 'Categorías',
  businessTypes: 'Tipos de Negocio',
  businesses: 'Negocios',
  products: 'Productos',
  productComplements: 'Complementos',
  complementTemplates: 'Plantillas',
  pizzaSpecialties: 'Especialidades',
  orders: 'Pedidos',
  orderMessages: 'Mensajes',
  notifications: 'Notificaciones',
  businessMenuImages: 'Imágenes Menú',
  businessPromotions: 'Promociones',
};

const MAX_CELL_LENGTH = 32000; // Margen de seguridad para límite de Excel (32,767)

const sanitizeDataForExcel = (data: any[]): any[] => {
  return data.map(row => {
    const sanitizedRow: any = {};
    for (const [key, value] of Object.entries(row)) {
      // Excluir campos de imagenes base64
      if (key === 'image_data' && typeof value === 'string' && value.length > 1000) {
        sanitizedRow[key] = '[IMAGEN BASE64 EXCLUIDA]';
        continue;
      }
      
      // Truncar textos muy largos
      if (typeof value === 'string' && value.length > MAX_CELL_LENGTH) {
        sanitizedRow[key] = value.substring(0, MAX_CELL_LENGTH) + '... [TRUNCADO]';
      } else if (typeof value === 'object' && value !== null) {
        const jsonStr = JSON.stringify(value);
        if (jsonStr.length > MAX_CELL_LENGTH) {
          sanitizedRow[key] = jsonStr.substring(0, MAX_CELL_LENGTH) + '... [TRUNCADO]';
        } else {
          sanitizedRow[key] = jsonStr;
        }
      } else {
        sanitizedRow[key] = value;
      }
    }
    return sanitizedRow;
  });
};

const getTimestamp = (): string => {
  return format(new Date(), 'yyyy-MM-dd_HHmm');
};

const escapeSQL = (value: any): string => {
  if (value === null || value === undefined) return 'NULL';
  if (typeof value === 'boolean') return value ? 'TRUE' : 'FALSE';
  if (typeof value === 'number') return String(value);
  if (typeof value === 'object') return `'${JSON.stringify(value).replace(/'/g, "''")}'`;
  return `'${String(value).replace(/'/g, "''")}'`;
};

export const exportAllTablesToExcel = (data: BackupData, stats: TableStats[]): void => {
  const workbook = XLSX.utils.book_new();
  
  // Hoja de resumen
  const summaryData = [
    ['RESPALDO COMPLETO DE BASE DE DATOS'],
    [''],
    ['Fecha de generación:', format(new Date(), "dd 'de' MMMM 'de' yyyy, HH:mm", { locale: es })],
    [''],
    ['RESUMEN POR TABLA'],
    ['Tabla', 'Registros', 'Tamaño Estimado', 'Importancia'],
    ...stats.map(s => [s.displayName, s.count, s.estimatedSize, s.importance]),
    [''],
    ['TOTAL', stats.reduce((sum, s) => sum + s.count, 0), '', ''],
  ];
  
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  summarySheet['!cols'] = [{ wch: 30 }, { wch: 15 }, { wch: 15 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumen');
  
  // Hojas de datos
  TABLE_ORDER.forEach(key => {
    const tableData = (data as any)[key];
    if (tableData && tableData.length > 0) {
      // Sanitizar datos antes de crear la hoja para evitar error de límite de caracteres
      const sanitizedData = sanitizeDataForExcel(tableData);
      const sheet = XLSX.utils.json_to_sheet(sanitizedData);
      const displayName = TABLE_DISPLAY_NAMES[key] || key;
      XLSX.utils.book_append_sheet(workbook, sheet, displayName.substring(0, 31));
    }
  });
  
  const filename = `respaldo_completo_${getTimestamp()}.xlsx`;
  XLSX.writeFile(workbook, filename);
};

export const exportTableToCSV = (tableName: string, tableData: any[]): void => {
  if (!tableData || tableData.length === 0) {
    console.warn(`No hay datos para exportar en ${tableName}`);
    return;
  }
  
  const worksheet = XLSX.utils.json_to_sheet(tableData);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${tableName}_${getTimestamp()}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
};

export const generateSQLInsertScripts = (data: BackupData, stats: TableStats[]): void => {
  const timestamp = format(new Date(), "yyyy-MM-dd HH:mm:ss");
  const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
  
  let sql = `-- =============================================
-- RESPALDO COMPLETO DE BASE DE DATOS
-- Generado: ${timestamp}
-- Total de registros: ${totalRecords}
-- =============================================

-- IMPORTANTE: Este script usa INSERT con ON CONFLICT DO NOTHING
-- para evitar errores si los registros ya existen.
-- Para una restauración completa, primero elimina los datos existentes.

BEGIN;

`;

  TABLE_ORDER.forEach(key => {
    const tableData = (data as any)[key];
    const tableName = TABLE_NAMES_MAP[key];
    
    if (!tableData || tableData.length === 0) {
      sql += `-- TABLA: ${tableName} (0 registros)\n-- Sin datos\n\n`;
      return;
    }
    
    sql += `-- TABLA: ${tableName} (${tableData.length} registros)\n`;
    
    const columns = Object.keys(tableData[0]);
    const columnList = columns.join(', ');
    
    tableData.forEach((row: any) => {
      const values = columns.map(col => escapeSQL(row[col])).join(', ');
      sql += `INSERT INTO public.${tableName} (${columnList}) VALUES (${values}) ON CONFLICT DO NOTHING;\n`;
    });
    
    sql += '\n';
  });

  sql += `COMMIT;

-- =============================================
-- FIN DEL RESPALDO
-- =============================================
`;

  const blob = new Blob([sql], { type: 'text/plain;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `respaldo_sql_${getTimestamp()}.sql`;
  link.click();
  URL.revokeObjectURL(link.href);
};

export const generateDeleteAndInsertSQL = (data: BackupData, stats: TableStats[]): void => {
  const timestamp = format(new Date(), "yyyy-MM-dd HH:mm:ss");
  const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
  
  let sql = `-- =============================================
-- RESPALDO COMPLETO CON DELETE + INSERT
-- Generado: ${timestamp}
-- Total de registros: ${totalRecords}
-- =============================================

-- ⚠️ ADVERTENCIA: Este script ELIMINA todos los datos existentes
-- antes de insertar los datos del respaldo.
-- Úsalo solo si quieres restaurar completamente la base de datos.

BEGIN;

-- PASO 1: Eliminar datos existentes (en orden inverso por FK)
`;

  // Orden inverso para DELETE
  const reverseOrder = [...TABLE_ORDER].reverse();
  reverseOrder.forEach(key => {
    const tableName = TABLE_NAMES_MAP[key];
    sql += `DELETE FROM public.${tableName};\n`;
  });

  sql += `
-- PASO 2: Insertar datos del respaldo
`;

  TABLE_ORDER.forEach(key => {
    const tableData = (data as any)[key];
    const tableName = TABLE_NAMES_MAP[key];
    
    if (!tableData || tableData.length === 0) {
      sql += `-- TABLA: ${tableName} (0 registros)\n\n`;
      return;
    }
    
    sql += `-- TABLA: ${tableName} (${tableData.length} registros)\n`;
    
    const columns = Object.keys(tableData[0]);
    const columnList = columns.join(', ');
    
    tableData.forEach((row: any) => {
      const values = columns.map(col => escapeSQL(row[col])).join(', ');
      sql += `INSERT INTO public.${tableName} (${columnList}) VALUES (${values});\n`;
    });
    
    sql += '\n';
  });

  sql += `COMMIT;

-- =============================================
-- FIN DEL RESPALDO
-- =============================================
`;

  const blob = new Blob([sql], { type: 'text/plain;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `respaldo_sql_completo_${getTimestamp()}.sql`;
  link.click();
  URL.revokeObjectURL(link.href);
};

export const exportToJSON = (data: BackupData, stats: TableStats[]): void => {
  const backup = {
    metadata: {
      generatedAt: new Date().toISOString(),
      generatedAtFormatted: format(new Date(), "dd 'de' MMMM 'de' yyyy, HH:mm", { locale: es }),
      totalRecords: stats.reduce((sum, s) => sum + s.count, 0),
      tables: stats.length,
      tableStats: stats,
    },
    data: {
      profiles: data.profiles,
      user_roles: data.userRoles,
      categories: data.categories,
      business_types: data.businessTypes,
      businesses: data.businesses,
      products: data.products,
      product_complements: data.productComplements,
      complement_templates: data.complementTemplates,
      pizza_specialties: data.pizzaSpecialties,
      orders: data.orders,
      order_messages: data.orderMessages,
      notifications: data.notifications,
      business_menu_images: data.businessMenuImages,
      business_promotions: data.businessPromotions,
    },
  };

  const jsonString = JSON.stringify(backup, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `respaldo_json_${getTimestamp()}.json`;
  link.click();
  URL.revokeObjectURL(link.href);
};

export interface BackupHistoryItem {
  date: string;
  type: 'excel' | 'sql' | 'json' | 'sql_complete';
  records: number;
  tables: number;
}

const BACKUP_HISTORY_KEY = 'backup_history';

export const saveBackupToHistory = (type: BackupHistoryItem['type'], records: number, tables: number): void => {
  const history = getBackupHistory();
  history.unshift({
    date: new Date().toISOString(),
    type,
    records,
    tables,
  });
  
  // Mantener solo los últimos 20 respaldos
  const trimmedHistory = history.slice(0, 20);
  localStorage.setItem(BACKUP_HISTORY_KEY, JSON.stringify(trimmedHistory));
};

export const getBackupHistory = (): BackupHistoryItem[] => {
  try {
    const stored = localStorage.getItem(BACKUP_HISTORY_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const clearBackupHistory = (): void => {
  localStorage.removeItem(BACKUP_HISTORY_KEY);
};
