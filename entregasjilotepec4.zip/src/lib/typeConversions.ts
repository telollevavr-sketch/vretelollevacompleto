import { Database } from '@/integrations/supabase/types';
import { Business, Product, Order, User, UserRole, OrderStatus, PaymentMethod } from '@/types';

type DbBusiness = Database['public']['Tables']['businesses']['Row'];
type DbProduct = Database['public']['Tables']['products']['Row'];
type DbOrder = Database['public']['Tables']['orders']['Row'];
type DbProfile = Database['public']['Tables']['profiles']['Row'];

export function dbBusinessToBusiness(db: DbBusiness): Business {
  return {
    id: db.id,
    userId: db.user_id,
    name: db.name,
    category: db.category,
    description: db.description || '',
    address: db.address,
    fullAddress: db.full_address || undefined,
    location: {
      lat: db.latitude,
      lng: db.longitude,
      address: db.address,
    },
    phone: db.phone || '',
    image: db.image_url || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400',
    rating: Number(db.rating) || 0,
    reviewCount: db.review_count || 0,
    isOpen: db.is_open,
    isComingSoon: (db as any).is_coming_soon || false,
    weatherUnavailable: (db as any).weather_unavailable || false,
    estimatedDeliveryTime: `${db.delivery_time_minutes || 30} min`,
    minOrderAmount: Number(db.min_order_amount) || 0,
    deliveryFee: Number(db.delivery_fee) || 0,
    deliveryTime: db.delivery_time_minutes || 30,
    deliveryRadius: Number(db.max_delivery_distance_km) || 10,
    isApproved: db.is_active,
    isSpecialBusiness: db.is_special_business || false,
    freeDelivery: (db as any).free_delivery || false,
    deliveryTrackingEnabled: (db as any).delivery_tracking_enabled || false,
    autoScheduleEnabled: (db as any).auto_schedule_enabled || false,
    businessDays: db.business_days || undefined,
    businessHours: db.business_hours || undefined,
    createdAt: db.created_at,
  };
}

export function dbProductToProduct(db: DbProduct): Product {
  return {
    id: db.id,
    businessId: db.business_id,
    name: db.name,
    description: db.description || '',
    price: Number(db.price),
    category: db.category,
    image: db.image_url || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400',
    isAvailable: db.is_available,
    isPromotionalCombo: db.is_promotional_combo || false,
    isSpecialty: db.is_specialty || false,
    isPricedCombo: (db as any).is_priced_combo || false,
    pricedItemsCount: (db as any).priced_items_count || 1,
    comboConfiguration: db.combo_configuration as any,
    createdAt: db.created_at,
  };
}

export function dbOrderToOrder(db: DbOrder): Order {
  return {
    id: db.id,
    orderNumber: db.order_number,
    clientId: db.client_id,
    businessId: db.business_id,
    deliveryPersonId: db.delivery_person_id || undefined,
    items: db.items as any,
    subtotal: Number(db.subtotal),
    deliveryFee: Number(db.delivery_fee),
    total: Number(db.total),
    totalAmount: Number(db.total),
    status: mapDbStatusToOrderStatus(db.status),
    paymentMethod: mapDbPaymentMethodToPaymentMethod(db.payment_method),
    deliveryLocation: {
      lat: db.delivery_latitude,
      lng: db.delivery_longitude,
      address: db.delivery_address,
    },
    notes: db.notes || '',
    isPickupAtCounter: db.is_pickup_at_counter || false,
    isRated: !!(db.business_rating && db.delivery_rating),
    businessRating: db.business_rating || undefined,
    deliveryRating: db.delivery_rating || undefined,
    rating: (db.business_rating && db.delivery_rating) ? {
      businessRating: Number(db.business_rating),
      deliveryRating: Number(db.delivery_rating),
    } : undefined,
    createdAt: db.created_at,
    updatedAt: db.updated_at,
  };
}

export function dbProfileToUser(db: DbProfile, role?: string): User {
  return {
    id: db.id,
    email: db.email,
    name: db.name,
    role: mapRoleStringToUserRole(role || 'client'),
    phone: db.phone || undefined,
    address: db.address || undefined,
    isActive: db.is_active,
    createdAt: db.created_at,
    vehicleType: db.vehicle_type || undefined,
    vehiclePlate: db.vehicle_plate || undefined,
    isOnline: db.is_online,
    assignedBusinessId: db.assigned_business_id || undefined,
    rating: db.rating ? Number(db.rating) : undefined,
    review_count: db.review_count || undefined,
    location: db.latitude && db.longitude ? {
      lat: db.latitude,
      lng: db.longitude,
      address: db.address || undefined
    } : undefined,
  };
}

function mapDbStatusToOrderStatus(status: string): OrderStatus {
  const statusMap: Record<string, OrderStatus> = {
    'pending': OrderStatus.PENDING,
    'accepted': OrderStatus.IN_PREPARATION,
    'preparing': OrderStatus.IN_PREPARATION,
    'ready': OrderStatus.READY_FOR_PICKUP,
    'in_delivery': OrderStatus.ON_THE_WAY,
    'delivered': OrderStatus.DELIVERED,
    'cancelled': OrderStatus.CANCELLED,
  };
  return statusMap[status] || OrderStatus.PENDING;
}

function mapDbPaymentMethodToPaymentMethod(method: string): PaymentMethod {
  return method === 'cash' ? PaymentMethod.CASH : PaymentMethod.TRANSFER;
}

function mapRoleStringToUserRole(role: string): UserRole {
  const roleMap: Record<string, UserRole> = {
    'admin': UserRole.ADMIN,
    'client': UserRole.CLIENT,
    'business': UserRole.BUSINESS,
    'delivery': UserRole.DELIVERY,
  };
  return roleMap[role] || UserRole.CLIENT;
}

export function mapOrderStatusToDbStatus(status: OrderStatus): string {
  const statusMap: Record<OrderStatus, string> = {
    [OrderStatus.PENDING]: 'pending',
    [OrderStatus.IN_PREPARATION]: 'preparing',
    [OrderStatus.READY_FOR_PICKUP]: 'ready',
    [OrderStatus.ON_THE_WAY]: 'in_delivery',
    [OrderStatus.DELIVERED]: 'delivered',
    [OrderStatus.CANCELLED]: 'cancelled',
  };
  return statusMap[status] || 'pending';
}
