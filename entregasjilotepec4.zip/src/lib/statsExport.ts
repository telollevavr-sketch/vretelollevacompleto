import jsPDF from "jspdf";
import * as XLSX from "xlsx";
import { Order, Business, User } from "@/types";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import watermarkImg from "@/assets/vrtelolleva-watermark.png";

interface ExportData {
  dateRange: { from?: Date; to?: Date } | undefined;
  selectedBusiness: string;
  selectedDelivery: string;
  businesses: Business[];
  deliveryPersons: User[];
  filteredOrders: Order[];
  revenueData: Array<{ date: string; ingresos: number; pedidos: number }>;
  businessRevenue: Array<{ name: string; ingresos: number; pedidos: number }>;
  deliveryRevenue: Array<{ name: string; ganancias: number; entregas: number }>;
  statusData: Array<{ name: string; value: number }>;
  revenueGrowth: string;
  ordersGrowth: string;
}

// Helper function to create transparent watermark
const createTransparentWatermark = (): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");

      if (ctx) {
        ctx.globalAlpha = 0.1; // 85% transparency = 15% opacity
        ctx.drawImage(img, 0, 0);
      }

      resolve(canvas.toDataURL("image/png"));
    };
    img.onerror = () => {
      console.warn("Could not load watermark image");
      resolve(watermarkImg); // Fallback to original image
    };
    img.src = watermarkImg;
  });
};

export const exportToPDF = async (data: ExportData) => {
  // Create transparent watermark
  const transparentWatermark = await createTransparentWatermark();

  const doc = new jsPDF();
  let yPos = 20;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  const maxWidth = pageWidth - 2 * margin;

  // Add watermark to every page
  const addWatermark = () => {
    try {
      const imgWidth = 150;
      const imgHeight = 120;
      const x = (pageWidth - imgWidth) / 2;
      const y = (pageHeight - imgHeight) / 2;

      doc.addImage(transparentWatermark, "PNG", x, y, imgWidth, imgHeight, undefined, "FAST");
    } catch (error) {
      console.warn("Could not add watermark to report:", error);
      // Continue without watermark if it fails
    }
  };

  // Add watermark to first page
  addWatermark();

  // Helper function to add text with automatic page breaks
  const addText = (text: string, size: number = 10, isBold: boolean = false) => {
    if (yPos > 280) {
      doc.addPage();
      addWatermark(); // Add watermark to new page
      yPos = 20;
    }
    doc.setFontSize(size);
    doc.setFont("helvetica", isBold ? "bold" : "normal");
    doc.text(text, margin, yPos);
    yPos += size * 0.5;
  };

  const addLine = () => {
    doc.setDrawColor(200);
    doc.line(margin, yPos, pageWidth - margin, yPos);
    yPos += 5;
  };

  // Title
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text("Reporte de Estadísticas - Admin", pageWidth / 2, yPos, { align: "center" });
  yPos += 10;

  // Date Range Filter
  addLine();
  addText("FILTROS APLICADOS", 14, true);
  yPos += 5;

  if (data.dateRange?.from) {
    const fromDate = format(data.dateRange.from, "dd/MM/yyyy", { locale: es });
    const toDate = data.dateRange.to ? format(data.dateRange.to, "dd/MM/yyyy", { locale: es }) : fromDate;
    addText(`Rango de Fechas: ${fromDate} - ${toDate}`);
  }

  if (data.selectedBusiness !== "all") {
    const business = data.businesses.find((b) => b.id === data.selectedBusiness);
    addText(`Negocio: ${business?.name || "N/A"}`);
  } else {
    addText("Negocio: Todos los negocios");
  }

  if (data.selectedDelivery !== "all") {
    const delivery = data.deliveryPersons.find((d) => d.id === data.selectedDelivery);
    addText(`Repartidor: ${delivery?.name || "N/A"}`);
  } else {
    addText("Repartidor: Todos los repartidores");
  }

  yPos += 5;
  addLine();

  // Growth Metrics
  addText("INDICADORES DE CRECIMIENTO", 14, true);
  yPos += 5;
  addText(`Crecimiento de Ingresos: ${data.revenueGrowth}% vs. período anterior`);
  addText(`Crecimiento de Pedidos: ${data.ordersGrowth}% vs. período anterior`);

  yPos += 5;
  addLine();

  // Revenue Data Summary
  if (data.revenueData.length > 0) {
    addText("RESUMEN DE INGRESOS POR DÍA", 14, true);
    yPos += 5;

    const totalRevenue = data.revenueData.reduce((sum, d) => sum + d.ingresos, 0);
    const totalOrders = data.revenueData.reduce((sum, d) => sum + d.pedidos, 0);

    addText(`Total de Ingresos: $${totalRevenue.toFixed(2)}`);
    addText(`Total de Pedidos: ${totalOrders}`);
    yPos += 3;

    // Show first 10 days
    data.revenueData.slice(0, 10).forEach((day) => {
      addText(`${day.date}: $${day.ingresos.toFixed(2)} (${day.pedidos} pedidos)`, 9);
    });

    yPos += 5;
    addLine();
  }

  // Top Businesses
  if (data.businessRevenue.length > 0) {
    addText("TOP NEGOCIOS POR INGRESOS", 14, true);
    yPos += 5;

    data.businessRevenue.forEach((business, index) => {
      addText(`${index + 1}. ${business.name}: $${business.ingresos.toFixed(2)} (${business.pedidos} pedidos)`, 10);
    });

    yPos += 5;
    addLine();
  }

  // Top Delivery Persons
  if (data.deliveryRevenue.length > 0) {
    addText("TOP REPARTIDORES POR GANANCIAS", 14, true);
    yPos += 5;

    data.deliveryRevenue.forEach((delivery, index) => {
      addText(`${index + 1}. ${delivery.name}: $${delivery.ganancias.toFixed(2)} (${delivery.entregas} entregas)`, 10);
    });

    yPos += 5;
    addLine();
  }

  // Order Status Distribution
  if (data.statusData.length > 0) {
    addText("DISTRIBUCIÓN DE PEDIDOS POR ESTADO", 14, true);
    yPos += 5;

    const total = data.statusData.reduce((sum, s) => sum + s.value, 0);
    data.statusData.forEach((status) => {
      const percentage = ((status.value / total) * 100).toFixed(1);
      addText(`${status.name}: ${status.value} (${percentage}%)`, 10);
    });

    yPos += 5;
    addLine();
  }

  // Orders List
  if (data.filteredOrders.length > 0) {
    addText(`LISTADO DE PEDIDOS (${data.filteredOrders.length} total)`, 14, true);
    yPos += 5;

    // Show first 20 orders
    data.filteredOrders.slice(0, 20).forEach((order) => {
      if (yPos > 260) {
        doc.addPage();
        yPos = 20;
      }

      const delivery = data.deliveryPersons.find((d) => d.id === order.deliveryPersonId);

      addText(`Pedido #${order.id.slice(0, 8)} - ${format(new Date(order.createdAt), "dd/MM/yyyy HH:mm")}`, 9, true);
      addText(`Negocio: ${order.businessName || "N/A"}`, 8);
      if (delivery) {
        addText(`Repartidor: ${delivery.name}`, 8);
      }
      addText(`Total: $${order.total.toFixed(2)} - Estado: ${order.status}`, 8);
      yPos += 2;
    });

    if (data.filteredOrders.length > 20) {
      yPos += 3;
      addText(`... y ${data.filteredOrders.length - 20} pedidos más`, 9);
    }
  }

  // Footer
  doc.setFontSize(8);
  doc.setTextColor(128);
  const totalPages = doc.internal.pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.text(
      `Generado el ${format(new Date(), "dd/MM/yyyy HH:mm")} - Página ${i} de ${totalPages}`,
      pageWidth / 2,
      doc.internal.pageSize.getHeight() - 10,
      { align: "center" },
    );
  }

  // Save PDF
  const fileName = `estadisticas-admin-${format(new Date(), "yyyy-MM-dd-HHmm")}.pdf`;
  doc.save(fileName);
};

export const exportToExcel = (data: ExportData) => {
  const workbook = XLSX.utils.book_new();

  // Sheet 1: Summary
  const summaryData = [
    ["REPORTE DE ESTADÍSTICAS - ADMIN"],
    [],
    ["Generado:", format(new Date(), "dd/MM/yyyy HH:mm")],
    [],
    ["FILTROS APLICADOS"],
    [
      "Rango de Fechas:",
      data.dateRange?.from
        ? `${format(data.dateRange.from, "dd/MM/yyyy")} - ${data.dateRange.to ? format(data.dateRange.to, "dd/MM/yyyy") : format(data.dateRange.from, "dd/MM/yyyy")}`
        : "N/A",
    ],
    [
      "Negocio:",
      data.selectedBusiness === "all"
        ? "Todos"
        : data.businesses.find((b) => b.id === data.selectedBusiness)?.name || "N/A",
    ],
    [
      "Repartidor:",
      data.selectedDelivery === "all"
        ? "Todos"
        : data.deliveryPersons.find((d) => d.id === data.selectedDelivery)?.name || "N/A",
    ],
    [],
    ["INDICADORES DE CRECIMIENTO"],
    ["Crecimiento de Ingresos:", `${data.revenueGrowth}%`],
    ["Crecimiento de Pedidos:", `${data.ordersGrowth}%`],
  ];
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, "Resumen");

  // Sheet 2: Daily Revenue
  if (data.revenueData.length > 0) {
    const revenueSheet = XLSX.utils.json_to_sheet(
      data.revenueData.map((d) => ({
        Fecha: d.date,
        Ingresos: d.ingresos,
        Pedidos: d.pedidos,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, revenueSheet, "Ingresos Diarios");
  }

  // Sheet 3: Top Businesses
  if (data.businessRevenue.length > 0) {
    const businessSheet = XLSX.utils.json_to_sheet(
      data.businessRevenue.map((b, index) => ({
        Posición: index + 1,
        Negocio: b.name,
        Ingresos: b.ingresos,
        Pedidos: b.pedidos,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, businessSheet, "Top Negocios");
  }

  // Sheet 4: Top Delivery Persons
  if (data.deliveryRevenue.length > 0) {
    const deliverySheet = XLSX.utils.json_to_sheet(
      data.deliveryRevenue.map((d, index) => ({
        Posición: index + 1,
        Repartidor: d.name,
        Ganancias: d.ganancias,
        Entregas: d.entregas,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, deliverySheet, "Top Repartidores");
  }

  // Sheet 5: Order Status Distribution
  if (data.statusData.length > 0) {
    const total = data.statusData.reduce((sum, s) => sum + s.value, 0);
    const statusSheet = XLSX.utils.json_to_sheet(
      data.statusData.map((s) => ({
        Estado: s.name,
        Cantidad: s.value,
        Porcentaje: `${((s.value / total) * 100).toFixed(1)}%`,
      })),
    );
    XLSX.utils.book_append_sheet(workbook, statusSheet, "Estados de Pedidos");
  }

  // Sheet 6: Orders List
  if (data.filteredOrders.length > 0) {
    const ordersSheet = XLSX.utils.json_to_sheet(
      data.filteredOrders.map((order) => {
        const delivery = data.deliveryPersons.find((d) => d.id === order.deliveryPersonId);

        return {
          "ID Pedido": order.id.slice(0, 8),
          Fecha: format(new Date(order.createdAt), "dd/MM/yyyy HH:mm"),
          Negocio: order.businessName || "N/A",
          Repartidor: delivery?.name || "N/A",
          Estado: order.status,
          Subtotal: order.subtotal,
          Envío: order.deliveryFee,
          Total: order.total,
          Pago: order.paymentMethod,
          Artículos: order.items.length,
          Dirección: order.deliveryLocation?.address || "N/A",
        };
      }),
    );
    XLSX.utils.book_append_sheet(workbook, ordersSheet, "Listado de Pedidos");
  }

  // Save Excel
  const fileName = `estadisticas-admin-${format(new Date(), "yyyy-MM-dd-HHmm")}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};

export const exportOrdersToExcel = (
  orders: Order[],
  businesses: Business[],
  deliveryPersons: User[],
  dateRange?: { from?: Date; to?: Date },
) => {
  if (orders.length === 0) {
    return;
  }

  const workbook = XLSX.utils.book_new();

  // Orders sheet
  const ordersSheet = XLSX.utils.json_to_sheet(
    orders.map((order) => {
      const delivery = deliveryPersons.find((d) => d.id === order.deliveryPersonId);

      return {
        "ID Pedido": order.id,
        Fecha: format(new Date(order.createdAt), "dd/MM/yyyy HH:mm", { locale: es }),
        "Nombre del Cliente": order.clientInfo?.name || "N/A",
        "Teléfono Cliente": order.clientInfo?.phone || "N/A",
        "Dirección Cliente": order.clientInfo?.address || "N/A",
        Negocio: order.businessName || "N/A",
        Repartidor: delivery?.name || "Sin asignar",
        Estado: order.status,
        Subtotal: order.subtotal,
        "Costo de Envío": order.deliveryFee,
        Total: order.total,
        "Método de Pago": order.paymentMethod === "CASH" ? "Efectivo" : "Transferencia",
        "Cantidad de Artículos": order.items.length,
        "Dirección de Entrega": order.deliveryLocation?.address || "N/A",
      };
    }),
  );

  XLSX.utils.book_append_sheet(workbook, ordersSheet, "Pedidos");

  // Summary sheet
  const totalRevenue = orders.filter((o) => o.status === "DELIVERED").reduce((sum, o) => sum + o.total, 0);
  const totalDeliveryFees = orders.filter((o) => o.status === "DELIVERED").reduce((sum, o) => sum + o.deliveryFee, 0);
  const deliveredOrders = orders.filter((o) => o.status === "DELIVERED").length;

  const summaryData = [
    ["RESUMEN DE PEDIDOS"],
    [],
    ["Generado:", format(new Date(), "dd/MM/yyyy HH:mm", { locale: es })],
    [],
    ["Total de Pedidos:", orders.length],
    ["Pedidos Entregados:", deliveredOrders],
    ["Ingresos Totales (Entregados):", `$${totalRevenue.toFixed(2)}`],
    ["Comisión por Envíos:", `$${totalDeliveryFees.toFixed(2)}`],
  ];

  if (dateRange?.from) {
    const fromDate = format(dateRange.from, "dd/MM/yyyy", { locale: es });
    const toDate = dateRange.to ? format(dateRange.to, "dd/MM/yyyy", { locale: es }) : fromDate;
    summaryData.push(["Rango de Fechas:", `${fromDate} - ${toDate}`]);
  }

  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, "Resumen");

  // Save Excel
  const fileName = `listado-pedidos-${format(new Date(), "yyyy-MM-dd-HHmm")}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};

export const exportBusinessOrdersToExcel = (orders: Order[], businessName: string) => {
  if (orders.length === 0) {
    return;
  }

  const workbook = XLSX.utils.book_new();

  // Orders sheet
  const ordersSheet = XLSX.utils.json_to_sheet(
    orders.map((order) => ({
      "ID Pedido": order.id.slice(0, 8),
      Fecha: format(new Date(order.createdAt), "dd/MM/yyyy HH:mm", { locale: es }),
      Estado: order.status,
      Tipo: order.isPickupAtCounter ? "Mostrador" : "Delivery",
      Subtotal: order.subtotal,
      "Costo de Envío": order.deliveryFee,
      Total: order.totalAmount || order.total,
      "Método de Pago": order.paymentMethod === "CASH" ? "Efectivo" : "Transferencia",
      "Cantidad de Artículos": order.items.length,
      "Dirección de Entrega": order.deliveryLocation?.address || "N/A",
      Calificación: order.rating?.businessRating || "N/A",
      Comentario: order.rating?.businessComment || "N/A",
    })),
  );

  XLSX.utils.book_append_sheet(workbook, ordersSheet, "Pedidos Completados");

  // Items Details sheet
  const itemsData: any[] = [];
  orders.forEach((order) => {
    order.items.forEach((item) => {
      itemsData.push({
        "ID Pedido": order.id.slice(0, 8),
        "Fecha Pedido": format(new Date(order.createdAt), "dd/MM/yyyy", { locale: es }),
        Producto: item.product.name,
        Cantidad: item.quantity,
        "Precio Unitario": item.product.price,
        Subtotal: item.product.price * item.quantity,
        Observaciones: item.notes || "N/A",
      });
    });
  });

  if (itemsData.length > 0) {
    const itemsSheet = XLSX.utils.json_to_sheet(itemsData);
    XLSX.utils.book_append_sheet(workbook, itemsSheet, "Detalle de Productos");
  }

  // Summary sheet
  const totalRevenue = orders.reduce((sum, o) => sum + (o.totalAmount || o.total), 0);
  const totalDeliveryFees = orders.reduce((sum, o) => sum + o.deliveryFee, 0);
  const counterOrders = orders.filter((o) => o.isPickupAtCounter).length;
  const deliveryOrders = orders.length - counterOrders;
  const avgOrderValue = orders.length > 0 ? totalRevenue / orders.length : 0;

  const summaryData = [
    ["RESUMEN DE PEDIDOS COMPLETADOS"],
    ["Negocio:", businessName],
    [],
    ["Generado:", format(new Date(), "dd/MM/yyyy HH:mm", { locale: es })],
    [],
    ["Total de Pedidos Completados:", orders.length],
    ["Pedidos en Mostrador:", counterOrders],
    ["Pedidos por Delivery:", deliveryOrders],
    ["Ingresos Totales:", `$${totalRevenue.toFixed(2)}`],
    ["Comisión por Envíos:", `$${totalDeliveryFees.toFixed(2)}`],
    ["Ticket Promedio:", `$${avgOrderValue.toFixed(2)}`],
  ];

  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, "Resumen");

  // Save Excel
  const fileName = `pedidos-completados-${businessName.replace(/\s+/g, "-")}-${format(new Date(), "yyyy-MM-dd-HHmm")}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};
