/**
 * Comprime imágenes antes de subirlas al servidor
 * Proceso de compresión iterativa con redimensionamiento automático
 */

interface ImageCompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  maxSizeKB?: number;
  initialQuality?: number;
  qualityStep?: number;
  minQuality?: number;
}

const DEFAULT_OPTIONS: Required<ImageCompressionOptions> = {
  maxWidth: 1024,
  maxHeight: 1024,
  maxSizeKB: 250,
  initialQuality: 0.9,
  qualityStep: 0.05,
  minQuality: 0.5,
};

/**
 * Carga un archivo de imagen y lo convierte en HTMLImageElement
 */
function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Error al cargar la imagen'));
    };
    img.src = objectUrl;
  });
}

/**
 * Redimensiona una imagen si excede las dimensiones máximas
 */
function resizeImage(
  img: HTMLImageElement,
  maxWidth: number,
  maxHeight: number
): { canvas: HTMLCanvasElement; width: number; height: number } {
  let { width, height } = img;

  // Calcular nuevas dimensiones manteniendo la proporción
  if (width > maxWidth || height > maxHeight) {
    const aspectRatio = width / height;

    if (width > height) {
      width = maxWidth;
      height = width / aspectRatio;
    } else {
      height = maxHeight;
      width = height * aspectRatio;
    }
  }

  // Crear canvas y dibujar la imagen redimensionada
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('No se pudo obtener el contexto 2D del canvas');
  }

  ctx.drawImage(img, 0, 0, width, height);

  return { canvas, width, height };
}

/**
 * Convierte un canvas a Blob con calidad específica
 */
function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) {
          resolve(blob);
        } else {
          reject(new Error('Error al convertir canvas a blob'));
        }
      },
      'image/jpeg',
      quality
    );
  });
}

/**
 * Compresión iterativa: reduce la calidad hasta alcanzar el tamaño objetivo
 */
async function compressIteratively(
  canvas: HTMLCanvasElement,
  maxSizeKB: number,
  initialQuality: number,
  qualityStep: number,
  minQuality: number
): Promise<Blob> {
  let quality = initialQuality;
  let blob = await canvasToBlob(canvas, quality);

  // Iterar reduciendo calidad hasta alcanzar el tamaño objetivo
  while (blob.size > maxSizeKB * 1024 && quality > minQuality) {
    quality -= qualityStep;
    blob = await canvasToBlob(canvas, quality);
  }

  return blob;
}

/**
 * Comprime una imagen con redimensionamiento y compresión iterativa
 * 
 * @param file - Archivo de imagen a comprimir
 * @param options - Opciones de compresión
 * @returns Blob de la imagen comprimida y base64 string
 */
export async function compressImage(
  file: File,
  options: ImageCompressionOptions = {}
): Promise<{ blob: Blob; base64: string; originalSize: number; compressedSize: number }> {
  const opts = { ...DEFAULT_OPTIONS, ...options };

  // Validar que sea una imagen
  if (!file.type.startsWith('image/')) {
    throw new Error('El archivo no es una imagen válida');
  }

  const originalSize = file.size;

  // Cargar imagen
  const img = await loadImageFromFile(file);

  // Redimensionar si es necesario
  const { canvas } = resizeImage(img, opts.maxWidth, opts.maxHeight);

  // Comprimir iterativamente
  const blob = await compressIteratively(
    canvas,
    opts.maxSizeKB,
    opts.initialQuality,
    opts.qualityStep,
    opts.minQuality
  );

  // Convertir a base64
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });

  return {
    blob,
    base64,
    originalSize,
    compressedSize: blob.size,
  };
}

/**
 * Utilidad para formatear tamaños de archivo
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
