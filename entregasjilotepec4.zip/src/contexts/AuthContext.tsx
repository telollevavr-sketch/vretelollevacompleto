import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';

type AppRole = Database['public']['Enums']['app_role'];

interface Profile {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  avatar_url: string | null;
  vehicle_type: string | null;
  vehicle_plate: string | null;
  is_online: boolean;
  is_active: boolean;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  userRole: AppRole | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any; isInactive: boolean }>;
  signUp: (email: string, password: string, name: string, role: AppRole, phone?: string) => Promise<{ error: any; requiresValidation: boolean }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: any }>;
  updatePassword: (newPassword: string) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [userRole, setUserRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);

        if (!session?.user) {
          setProfile(null);
          setUserRole(null);
          setLoading(false);
          return;
        }

        if (event === 'TOKEN_REFRESHED') {
          return;
        }

        if (event === 'SIGNED_IN' || event === 'USER_UPDATED') {
          setLoading(true);
          setTimeout(() => {
            fetchProfileAndRole(session.user.id);
          }, 0);
        }
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchProfileAndRole(session.user.id);
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfileAndRole = async (userId: string) => {
    try {
      // Fetch both profile and role in parallel
      const [profileResult, roleResult] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', userId).single(),
        supabase.from('user_roles')
          .select('role')
          .eq('user_id', userId)
          .order('role', { ascending: true }) // admin < business < client < delivery
          .limit(1)
          .maybeSingle()
      ]);

      if (profileResult.error) {
        console.error('Error fetching profile:', profileResult.error);
      } else {
        setProfile(profileResult.data);
      }

      if (roleResult.error) {
        console.error('Error fetching role:', roleResult.error);
        setUserRole(null);
      } else if (!roleResult.data) {
        console.error('No role found for user');
        setUserRole(null);
      } else {
        setUserRole(roleResult.data.role);
      }
    } catch (error) {
      console.error('Error fetching profile/role:', error);
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) return { error, isInactive: false };

      // Verificar si el perfil está activo
      if (data.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('is_active')
          .eq('id', data.user.id)
          .single();

        if (profile && !profile.is_active) {
          await supabase.auth.signOut();
          return { 
            error: { message: 'Tu cuenta está pendiente de validación. El administrador se pondrá en contacto contigo en breve.' },
            isInactive: true 
          };
        }
      }

      return { error: null, isInactive: false };
    } catch (error) {
      return { error, isInactive: false };
    }
  };

  const signUp = async (email: string, password: string, name: string, role: AppRole, phone?: string) => {
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            name,
          }
        }
      });

      if (error) return { error, requiresValidation: false };

      if (data.user) {
        // Esperar a que el trigger cree el perfil
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Verificar que el perfil existe
        const { data: existingProfile, error: profileCheckError } = await supabase
          .from('profiles')
          .select('id')
          .eq('id', data.user.id)
          .maybeSingle();
          
        if (!existingProfile) {
          console.log('Perfil no encontrado, creándolo manualmente...');
          const { error: profileError } = await supabase
            .from('profiles')
            .insert({
              id: data.user.id,
              email: email,
              name: name,
              phone: phone || null,
            });
          if (profileError) {
            console.error('Error creating profile manually:', profileError);
          }
        } else if (phone) {
          // Actualizar el teléfono si el perfil ya existe
          const { error: updateError } = await supabase
            .from('profiles')
            .update({ phone: phone })
            .eq('id', data.user.id);
          if (updateError) {
            console.error('Error updating phone:', updateError);
          }
        }

        // Crear el rol
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({
            user_id: data.user.id,
            role: role,
          });

        if (roleError) {
          console.error('Error creating role:', roleError);
          return { error: roleError, requiresValidation: false };
        }
      }

      // Los roles business y delivery requieren validación del admin
      const requiresValidation = role === 'business' || role === 'delivery';
      return { error: null, requiresValidation };
    } catch (error) {
      return { error, requiresValidation: false };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setProfile(null);
    setUserRole(null);
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) throw error;

      // Refresh profile
      await fetchProfileAndRole(user.id);
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  const resetPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth?mode=reset`,
      });
      return { error };
    } catch (error) {
      return { error };
    }
  };

  const updatePassword = async (newPassword: string) => {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });
      return { error };
    } catch (error) {
      return { error };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        userRole,
        loading,
        signIn,
        signUp,
        signOut,
        updateProfile,
        resetPassword,
        updatePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Hook para usar el contexto de autenticación
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
