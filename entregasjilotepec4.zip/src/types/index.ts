export enum UserRole {
  CLIENT = 'CLIENT',
  BUSINESS = 'BUSINESS',
  DELIVERY = 'DELIVERY',
  ADMIN = 'ADMIN'
}

export enum OrderStatus {
  PENDING = 'PENDING',
  IN_PREPARATION = 'IN_PREPARATION',
  READY_FOR_PICKUP = 'READY_FOR_PICKUP',
  ON_THE_WAY = 'ON_THE_WAY',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED'
}

export enum PaymentMethod {
  CASH = 'CASH',
  TRANSFER = 'TRANSFER'
}

export interface Location {
  lat: number;
  lng: number;
  address?: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  phone?: string;
  address?: string;
  location?: Location;
  profileImage?: string;
  isActive: boolean;
  createdAt: string;
  // Delivery specific
  vehicleType?: string;
  vehiclePlate?: string;
  isOnline?: boolean;
  currentEarnings?: number;
  documents?: string[];
  assignedBusinessId?: string; // Negocio al que está adscrito el repartidor
  rating?: number;
  review_count?: number;
}

export interface Business {
  id: string;
  userId: string;
  name: string;
  category: string;
  description?: string;
  phone: string;
  address: string;
  fullAddress?: string;
  location: Location;
  image: string;
  rating: number;
  reviewCount: number;
  deliveryTime: number; // minutes
  deliveryFee: number;
  deliveryRadius: number; // km
  minOrderAmount: number;
  estimatedDeliveryTime: string; // e.g. "30-45 min"
  isOpen: boolean;
  isApproved: boolean;
  isComingSoon?: boolean; // true = negocio próximamente (en proceso de integración)
  weatherUnavailable?: boolean; // true = disponibilidad sujeta a clima (verificar por teléfono)
  isSpecialBusiness?: boolean; // true = tiene creador de pizzas
  freeDelivery?: boolean; // true = envío sin costo
  deliveryTrackingEnabled?: boolean; // true = sección de seguimiento de entregas visible
  autoScheduleEnabled?: boolean; // true = apertura/cierre automático
  openingHours?: string;
  businessDays?: string; // e.g. "Lun-Dom"
  businessHours?: string; // e.g. "10:00 AM - 10:00 PM"
  documents?: string[];
  createdAt: string;
}

export interface Product {
  id: string;
  businessId: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  isAvailable: boolean;
  isConfigurable?: boolean; // For pizzas
  ingredientCount?: number; // For pizza bases
  isPromotionalCombo?: boolean; // For promotional combos
  isSpecialty?: boolean; // For individual specialty selection
  isPricedCombo?: boolean; // Si true, el precio se calcula como el máximo de las especialidades (para 2x1)
  pricedItemsCount?: number; // Cuántos items cobrar: 1=2x1, 2=3x2, 3=4x3, etc.
  comboConfiguration?: {
    itemCount?: number;              // Número de items en el combo
    itemType?: string;               // Tipo de item por defecto (pizza, torta, salsa, etc.)
    itemLabelPrefix?: string;        // Prefijo para las etiquetas (Pizza, Torta, etc.)
    items?: {                        // Nueva estructura flexible
      size: string;
      label: string;
      itemType?: string;             // Tipo específico del slot
    }[];
    pizzas?: {                       // Estructura antigua (compatibilidad)
      size: string;
      label: string;
    }[];
  };
  createdAt: string;
}

export interface ProductComplement {
  id: string;
  businessId: string;
  name: string;
  price: number;
  category: string;
  description?: string;
  isAvailable: boolean;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  subtotal: number;
  notes?: string;
  configuration?: {
    size?: string;
    ingredients?: string[];
    extraCheese?: boolean;
    stuffedCrust?: boolean;
  };
  specialtySelection?: {
    specialtyId: string;
    specialtyName: string;
    specialtyIngredients?: string;
  };
  comboSelections?: {
    unitIndex: number;
    pizzaIndex: number;
    specialtyId: string;
    specialtyName: string;
    specialtyPrice?: number; // Precio de la especialidad para combos 2x1
    size: string;
    specialtyIngredients?: string;
    itemType?: string;    // Tipo de item: "pizza", "salsa", "refresco", etc.
    itemLabel?: string;   // Etiqueta del slot: "Pizza 1", "Salsa BBQ", etc.
  }[];
  selectedComplements?: {
    complementId: string;
    complementName: string;
    complementPrice: number;
    complementCategory: string;
  }[];
}

export interface PizzaSpecialty {
  id: string;
  businessId: string;
  name: string;
  description?: string;
  price?: number; // Precio para combos 2x1 donde se paga el de mayor precio
  isActive: boolean;
  specialtyType?: string;
  createdAt: string;
}

export interface ClientInfo {
  id: string;
  name: string;
  phone?: string;
  address?: string;
}

export interface OrderMessage {
  id: string;
  senderId: string;
  senderRole: 'CLIENT' | 'DELIVERY';
  message: string;
  timestamp: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  clientId: string;
  businessName?: string;
  businessId: string;
  deliveryPersonId?: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  totalAmount: number; // Alias for total
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  deliveryLocation: Location;
  notes?: string;
  preparationTime?: string; // e.g. "25 min"
  estimatedDeliveryTime?: string;
  isPickupAtCounter?: boolean; // Se entrega en mostrador
  isRated: boolean;
  rating?: {
    businessRating: number;
    businessComment?: string;
    deliveryRating: number;
    deliveryComment?: string;
  };
  businessRating?: number; // Deprecated
  deliveryRating?: number; // Deprecated
  messages?: OrderMessage[];
  clientInfo?: ClientInfo;
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  userRole: UserRole;
  type: 'new_order' | 'success' | 'info' | 'error';
  title: string;
  message: string;
  orderId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface Promotion {
  id: string;
  title: string;
  description: string;
  image: string;
  businessId?: string;
  discount?: number;
  validUntil: string;
}

export const CATEGORIES = [
  'Mexicana',
  'Italiana',
  'China',
  'Japonesa',
  'Hamburguesas',
  'Pizza',
  'Tacos',
  'Mariscos',
  'Vegetariana',
  'Postres'
];

export const PIZZA_INGREDIENTS = {
  carnes: [
    'Atún',
    'Atún Especial',
    'Bistec',
    'Carne al Pastor',
    'Carne Molida',
    'Chorizo',
    'Jamón',
    'Pepperoni',
    'Pollo',
    'Salami',
    'Salchicha',
    'Tocino'
  ],
  vegetales: [
    'Aceitunas',
    'Aguacate',
    'Cebolla',
    'Cerezas',
    'Champiñón',
    'Champiñones',
    'Elote',
    'Espinaca',
    'Espinacas',
    'Frijoles',
    'Jalapeño',
    'Jitomate',
    'Pimiento Verde',
    'Piña'
  ],
  salsas: [
    'Mayonesa',
    'Receta Especial Salsa',
    'Salsa BBQ',
    'Salsa Chipotle',
    'Salsa Extra Picosa',
    '3 Salsas'
  ],
  quesos: [
    'Extra Queso',
    'Queso Parmesano',
    'Receta Especial de Queso'
  ]
};

export const PIZZA_SIZES = [
  { id: 'chica', name: 'Chica', maxIngredients: 4, basePrice: 120 },
  { id: 'mediana', name: 'Mediana', maxIngredients: 4, basePrice: 165 },
  { id: 'grande', name: 'Grande', maxIngredients: 4, basePrice: 210 },
  { id: 'familiar', name: 'Familiar', maxIngredients: 4, basePrice: 280 }
];
