import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useProducts } from '@/hooks/useProducts';
import { useBusinesses } from '@/hooks/useBusinesses';
import { usePizzaSpecialties } from '@/hooks/usePizzaSpecialties';
import { useMenuImages } from '@/hooks/useMenuImages';
import { dbBusinessToBusiness, dbProductToProduct } from '@/lib/typeConversions';
import { Business, Product, CartItem } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Star, Clock, Search, Pizza, ChefHat, UtensilsCrossed, Coffee, Cake, IceCream, Beef, Salad, Cookie, Wine, Sandwich, Soup, Home, BookOpen } from 'lucide-react';
import { ProductCard } from '@/components/product/ProductCard';
import { PizzaBuilder, PizzaConfiguration } from '@/components/pizza/PizzaBuilder';
import { MenuGalleryModal } from '@/components/client/MenuGalleryModal';
import { toast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface BusinessDetailPageProps {
  onAddToCart: (item: CartItem) => void;
  onBack: () => void;
  onNavigateHome: () => void;
  businessId: string;
  currentCartBusinessId?: string;
  hasItemsInCart: boolean;
}

export const BusinessDetailPage = ({ onAddToCart, onBack, onNavigateHome, businessId, currentCartBusinessId, hasItemsInCart }: BusinessDetailPageProps) => {
  const { businesses: dbBusinesses } = useBusinesses();
  const { products: dbProducts } = useProducts(businessId);
  const { specialties, isLoading: isLoadingSpecialties } = usePizzaSpecialties(businessId);
  const { menuImages } = useMenuImages(businessId);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPizzaBuilder, setShowPizzaBuilder] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showWarningDialog, setShowWarningDialog] = useState(false);
  const [showMenuGallery, setShowMenuGallery] = useState(false);
  const specialtiesRef = useRef<HTMLDivElement>(null);

  const scrollToSpecialties = () => {
    specialtiesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Category icon mapping
  const getCategoryIcon = (category: string) => {
    const categoryLower = category.toLowerCase();
    if (categoryLower.includes('pizza')) return Pizza;
    if (categoryLower.includes('postre') || categoryLower.includes('dulce')) return Cake;
    if (categoryLower.includes('bebida') || categoryLower.includes('café') || categoryLower.includes('coffee')) return Coffee;
    if (categoryLower.includes('helado')) return IceCream;
    if (categoryLower.includes('carne') || categoryLower.includes('parrilla')) return Beef;
    if (categoryLower.includes('ensalada') || categoryLower.includes('vegetal')) return Salad;
    if (categoryLower.includes('galleta') || categoryLower.includes('cookie')) return Cookie;
    if (categoryLower.includes('vino') || categoryLower.includes('licor') || categoryLower.includes('alcohol')) return Wine;
    if (categoryLower.includes('sandwich') || categoryLower.includes('hamburguesa') || categoryLower.includes('torta')) return Sandwich;
    if (categoryLower.includes('sopa') || categoryLower.includes('crema')) return Soup;
    return UtensilsCrossed; // Default icon
  };

  const business = dbBusinesses.find(b => b.id === businessId) || null;
  const products = dbProducts;

  const handleAddToCart = (product: Product) => {
    if (product.isConfigurable) {
      toast({
        title: 'Pizza Personalizable',
        description: 'Esta pizza necesita ser configurada'
      });
      return;
    }

    onAddToCart({
      product,
      quantity: 1,
      subtotal: product.price
    });

    toast({
      title: 'Agregado al Carrito',
      description: `${product.name} agregado exitosamente`
    });
  };

  const handleHomeClick = () => {
    if (hasItemsInCart && currentCartBusinessId && currentCartBusinessId !== businessId) {
      setShowWarningDialog(true);
    } else {
      onNavigateHome();
    }
  };

  const handleConfirmNavigate = () => {
    setShowWarningDialog(false);
    onNavigateHome();
  };

  const handlePizzaAddToCart = (config: PizzaConfiguration) => {
    if (!business) return;

    const customPizza: Product = {
      id: `custom-pizza-${Date.now()}`,
      businessId: business.id,
      name: `Pizza ${config.size} Personalizada`,
      description: `Ingredientes: ${config.ingredients.join(', ')}${config.stuffedCrust ? ' + Orilla Rellena' : ''}`,
      price: config.price,
      category: 'Pizza',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop',
      isAvailable: true,
      isConfigurable: true,
      createdAt: new Date().toISOString()
    };

    const cartItem: CartItem = {
      product: customPizza,
      quantity: 1,
      subtotal: config.price,
      configuration: {
        size: config.size,
        ingredients: config.ingredients,
        stuffedCrust: config.stuffedCrust
      },
      notes: config.notes
    };

    onAddToCart(cartItem);
    toast({
      title: '¡Pizza agregada!',
      description: 'Tu pizza personalizada se agregó al carrito.',
    });
  };

  // Extract unique categories from products
  const uniqueCategories = Array.from(
    new Set(products
      .filter(p => !p.name.toLowerCase().includes('arma tu pizza'))
      .map(p => p.category)
      .filter(Boolean)
    )
  ).sort();

  const filteredProducts = products
    .filter(p =>
      !p.name.toLowerCase().includes('arma tu pizza') &&
      (p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase())) &&
      (!selectedCategory || p.category === selectedCategory)
    )
    .sort((a, b) => {
      // Primero ordenar por categoría
      const categoryCompare = a.category.localeCompare(b.category);
      if (categoryCompare !== 0) return categoryCompare;
      
      // Si la categoría es la misma, ordenar por nombre
      return a.name.localeCompare(b.name);
    });

  const pizzaProducts = products.filter(p => 
    p.name.toLowerCase().includes('arma tu pizza')
  );

  if (!business) return null;

  const isPizzaBusiness = business.category.toLowerCase().includes('pizza');
  const showPizzaBuilderSection = isPizzaBusiness && business.isSpecialBusiness === true && pizzaProducts.length > 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={business.image}
          alt={business.name}
          className="w-full h-full object-cover"
          style={{ 
            imageRendering: 'auto',
            backfaceVisibility: 'hidden'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="flex items-center gap-2 mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={onBack}
              className="bg-black text-white border-black hover:bg-black/80"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Atrás
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleHomeClick}
              className="bg-black text-white border-black hover:bg-black/80"
            >
              <Home className="h-4 w-4 mr-2" />
              Ver Más Negocios
            </Button>
          </div>
          <h1 className="text-3xl font-bold mb-2">{business.name}</h1>
          <Badge variant="secondary">{business.category}</Badge>
        </div>
      </div>

      {/* Info Bar */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="font-medium">{business.rating.toFixed(1)}</span>
              <span className="text-muted-foreground">({business.reviewCount} reseñas)</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>{business.deliveryTime} min</span>
            </div>
            <Badge variant={business.isOpen ? 'default' : 'secondary'}>
              {business.isOpen ? 'Abierto' : 'Cerrado'}
            </Badge>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Menu */}
          <div className="lg:col-span-2 space-y-6">
            {/* Pizza Builder Section - Only for Special Pizza businesses */}
            {showPizzaBuilderSection && (
              <Card className="bg-gradient-to-r from-blue-50/50 to-blue-100/30 border-blue-200/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/20 p-3 rounded-full">
                        <Pizza className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">¡Arma tu Pizza!</h3>
                        <p className="text-sm text-muted-foreground">
                          Crea tu combinación perfecta a tu gusto.
                        </p>
                      </div>
                    </div>
                    <Button
                      size="lg"
                      onClick={() => setShowPizzaBuilder(true)}
                      className="bg-primary hover:bg-primary/90"
                    >
                      Empezar a Crear
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Link to Specialties - Solo para negocios especiales con especialidades */}
            {business.isSpecialBusiness && specialties.length > 0 && (
              <Card className="bg-muted/50 border-muted">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-full">
                        <ChefHat className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">¿No sabes qué elegir?</p>
                        <p className="text-xs text-muted-foreground">
                          Revisa nuestras especialidades disponibles
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={scrollToSpecialties}
                      className="shrink-0"
                    >
                      Ver Especialidades
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder="Buscar en el menú..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter Bar */}
            {uniqueCategories.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-muted-foreground mb-3">
                  Categorías
                </h3>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={selectedCategory === null ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(null)}
                    className="rounded-full"
                  >
                    <UtensilsCrossed className="h-4 w-4 mr-1.5" />
                    Todas
                  </Button>
                  {uniqueCategories.map(category => {
                    const IconComponent = getCategoryIcon(category);
                    return (
                      <Button
                        key={category}
                        variant={selectedCategory === category ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(category)}
                        className="rounded-full"
                      >
                        <IconComponent className="h-4 w-4 mr-1.5" />
                        {category}
                      </Button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Products */}
            <div>
              <h2 className="text-2xl font-bold mb-4">Menú</h2>
              {filteredProducts.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No se encontraron productos
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredProducts.map(product => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onAddToCart={handleAddToCart}
                      isSpecialBusiness={business.isSpecialBusiness}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Info Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-bold text-lg mb-4">Información de Contacto</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Teléfono:</span> {business.phone}</p>
                  <p><span className="font-medium">Dirección:</span> {business.fullAddress || business.address}</p>
                  <p><span className="font-medium">Costo de Envío:</span> ${business.deliveryFee}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-bold text-lg mb-4">Horarios de Atención</h3>
                <div className="space-y-2 text-sm">
                  {business.businessDays && (
                    <p><span className="font-medium">Días:</span> {business.businessDays}</p>
                  )}
                  {business.businessHours && (
                    <p><span className="font-medium">Horarios:</span> {business.businessHours}</p>
                  )}
                  {!business.businessDays && !business.businessHours && (
                    <p className="text-muted-foreground">Lunes a Domingo: 10:00 AM - 10:00 PM</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Menu Gallery Card */}
            {menuImages.length > 0 && (
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    Carta del Menú
                  </h3>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    {menuImages.slice(0, 3).map((img, idx) => (
                      <button
                        key={img.id}
                        onClick={() => setShowMenuGallery(true)}
                        className="aspect-square rounded-lg overflow-hidden border hover:border-primary transition-colors"
                      >
                        <img
                          src={img.imageData}
                          alt={`Menú ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowMenuGallery(true)}
                    className="w-full"
                  >
                    Ver carta completa ({menuImages.length} {menuImages.length === 1 ? 'imagen' : 'imágenes'})
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Especialidades Section - Solo para negocios especiales de pizzerías */}
            {business.isSpecialBusiness && specialties.length > 0 && (
              <Card ref={specialtiesRef}>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-4">Especialidades</h3>
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-4">
                      {specialties.map(specialty => (
                        <div key={specialty.id} className="border-b pb-3 last:border-b-0">
                          <h4 className="font-semibold text-base mb-1">
                            {specialty.name}
                          </h4>
                          {specialty.description && (
                            <p className="text-sm text-muted-foreground">
                              {specialty.description}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Pizza Builder Modal */}
      {showPizzaBuilderSection && (
        <PizzaBuilder
          open={showPizzaBuilder}
          onClose={() => setShowPizzaBuilder(false)}
          onAddToCart={handlePizzaAddToCart}
          businessId={business.id}
          pizzaProducts={pizzaProducts}
        />
      )}

      {/* Menu Gallery Modal */}
      <MenuGalleryModal
        open={showMenuGallery}
        onClose={() => setShowMenuGallery(false)}
        images={menuImages}
      />

      {/* Warning Dialog */}
      <AlertDialog open={showWarningDialog} onOpenChange={setShowWarningDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>⚠️ Cambiar de Negocio</AlertDialogTitle>
            <AlertDialogDescription>
              Tienes productos en tu carrito de otro negocio. 
              Si continúas viendo otros negocios, se vaciarán los productos actuales.
              ¿Deseas continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmNavigate}>
              Sí, continuar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
