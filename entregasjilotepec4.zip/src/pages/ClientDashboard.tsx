import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useBusinesses } from "@/hooks/useBusinesses";
import { useOrders } from "@/hooks/useOrders";
import { dbBusinessToBusiness, dbOrderToOrder } from "@/lib/typeConversions";
import { CartItem, Business, Order } from "@/types";
import { DashboardHeader } from "@/components/client/DashboardHeader";
import { ShoppingCart } from "@/components/client/ShoppingCart";
import { BusinessCard } from "@/components/business/BusinessCard";
import { BusinessFilters, FilterState } from "@/components/client/BusinessFilters";
import { BusinessDetailPage } from "@/pages/BusinessDetailPage";
import { OrderHistory } from "@/components/client/OrderHistory";
import { UserProfile } from "@/components/client/UserProfile";
import { OrderTracking } from "@/components/client/OrderTracking";
import { ClientDashboardStats } from "@/components/client/ClientDashboardStats";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Home } from "lucide-react";
import bannerAntojos from "@/assets/banner_algo_mas2.png";
import { toast } from "@/hooks/use-toast";

type ClientView = "shopping" | "businessDetail" | "tracking" | "profile" | "orders" | "stats";

const ClientDashboard = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const { businesses: dbBusinesses, isLoading: loadingBusinesses } = useBusinesses();
  const { orders: dbOrders, isLoading: loadingOrders } = useOrders(user?.id || "", "client");
  const [currentView, setCurrentView] = useState<ClientView>("shopping");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedBusinessId, setSelectedBusinessId] = useState<string>("");
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    minRating: 0,
    openOnly: false,
  });

  // Establecer búsqueda automática para usuarios específicos
  useEffect(() => {
    if (profile?.name?.toLowerCase().includes("hugos directo constituyentes")) {
      setSearchQuery("hugos pizza constituyentes");
    } else if (profile?.name?.toLowerCase().includes("hugos directo vicente guerrero")) {
      setSearchQuery("hugos pizza vicente guerrero");
    }
  }, [profile]);

  // Si aún está cargando la autenticación, mostrar loading
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[hsl(260,50%,8%)] via-[hsl(255,48%,10%)] to-[hsl(250,45%,12%)] flex items-center justify-center">
        <div className="text-white text-xl">Cargando...</div>
      </div>
    );
  }

  // Hooks now return converted types
  const businesses = dbBusinesses;
  const orders = dbOrders;

  // Check for active orders
  const activeOrder = orders.find((o) => o.status !== "DELIVERED" && o.status !== "CANCELLED") || null;

  // Manejar businessId de URL cuando los datos estén listos
  useEffect(() => {
    const urlBusinessId = searchParams.get("businessId");

    // Solo proceder si:
    // 1. Hay businessId en URL
    // 2. NO estamos cargando businesses
    // 3. Tenemos businesses cargados
    // 4. NO hemos seleccionado ya un negocio
    if (urlBusinessId && !loadingBusinesses && businesses.length > 0 && !selectedBusinessId) {
      const businessExists = businesses.find((b) => b.id === urlBusinessId);

      if (businessExists && businessExists.weatherUnavailable) {
        toast({
          title: "☔ Verifica disponibilidad",
          description: "Este negocio no está disponible por clima. Comunícate al 554895 7140.",
          variant: "destructive",
        });
        return;
      }

      if (businessExists) {
        // Esperar un tick para asegurar que el DOM esté listo
        setTimeout(() => {
          setSelectedBusinessId(urlBusinessId);
          setCurrentView("businessDetail");
        }, 100);
      }
    }
  }, [searchParams, businesses, loadingBusinesses, selectedBusinessId]);

  // Redirigir si no hay usuario
  useEffect(() => {
    if (!user && !searchParams.get("businessId")) {
      navigate("/home");
    }
  }, [user, navigate, searchParams]);

  const openBusinesses = businesses.filter((b) => b.isApproved);

  const filteredBusinesses = openBusinesses.filter((b) => {
    const matchesSearch =
      b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filters.categories.length === 0 || filters.categories.includes(b.category);
    const matchesRating = b.rating >= filters.minRating;
    const matchesOpenOnly = !filters.openOnly || b.isOpen;

    return (
      matchesSearch && matchesCategory && matchesRating && matchesOpenOnly
    );
  });

  const handleBusinessClick = (business: Business) => {
    if (business.weatherUnavailable) {
      toast({
        title: "☔ Verifica disponibilidad",
        description: "Este negocio no está disponible por clima. Comunícate al 554895 7140.",
        variant: "destructive",
      });
      return;
    }
    // Clear cart if switching to different business
    if (selectedBusinessId && selectedBusinessId !== business.id) {
      setCart([]);
    }
    setSelectedBusinessId(business.id);
    setCurrentView("businessDetail");
  };

  const handleAddToCart = (item: CartItem) => {
    // Requerir login para agregar al carrito
    if (!user) {
      toast({
        title: "Inicia sesión",
        description: "Debes iniciar sesión para agregar productos al carrito",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    const existingIndex = cart.findIndex(
      (i) => i.product.id === item.product.id && JSON.stringify(i.configuration) === JSON.stringify(item.configuration),
    );

    if (existingIndex >= 0) {
      const newCart = [...cart];
      newCart[existingIndex].quantity += item.quantity;
      setCart(newCart);
    } else {
      setCart([...cart, item]);
    }
  };

  const handleBackToShopping = () => {
    setCurrentView("shopping");
    setSelectedBusinessId("");
  };

  const handleNavigateHomeFromDetail = () => {
    setCart([]);
    setSelectedBusinessId("");
    setCurrentView("shopping");
  };

  const currentCartBusinessId = cart.length > 0 ? cart[0].product.businessId : undefined;

  // Permitir acceso anónimo si hay businessId en URL
  const hasBusinessIdParam = searchParams.get("businessId");
  const requiresAuth = !hasBusinessIdParam && (!user || !profile);

  if (requiresAuth) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(260,50%,8%)] via-[hsl(255,48%,10%)] to-[hsl(250,45%,12%)]">
      {user && profile && (
        <DashboardHeader
          user={{ ...user, ...profile, role: "CLIENT" } as any}
          cartItemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
          onCartClick={() => setCartOpen(true)}
          onProfileClick={() => setCurrentView("profile")}
          onOrdersClick={() => setCurrentView("orders")}
          onStatsClick={() => setCurrentView("stats")}
        />
      )}

      {currentView === "shopping" && (
        <div className="container mx-auto px-4 py-6">
          {/* Antojos Banner */}
          <div className="max-w-2xl mx-auto mb-4 cursor-pointer flex justify-center" onClick={() => navigate('/antojos')}>
            <img src={bannerAntojos} alt="¿Se te antoja algo más?" className="w-[75%] rounded-2xl shadow-lg transition-transform duration-300 hover:scale-[1.02]" />
          </div>
          {/* Search Bar */}
          <div className="relative max-w-2xl mx-auto mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 h-5 w-5" />
            <Input
              type="text"
              placeholder="Buscar restaurantes o categorías..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-14 text-lg bg-[hsl(260,35%,18%)]/60 border-[hsl(270,40%,35%)]/50 text-white placeholder:text-white/50 rounded-2xl focus:ring-2 focus:ring-[hsl(270,70%,60%)] focus:border-transparent"
            />
          </div>

          {/* Filters */}
          <div className="mb-6">
            <BusinessFilters onFilterChange={setFilters} />
          </div>

          {/* Businesses */}
          {filteredBusinesses.length === 0 ? (
            <div className="text-center py-12 text-white/60">
              <p>No se encontraron restaurantes</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredBusinesses.map((business) => (
                <BusinessCard key={business.id} business={business} onSelect={handleBusinessClick} />
              ))}
            </div>
          )}
        </div>
      )}

      {currentView === "businessDetail" && selectedBusinessId && (
        <BusinessDetailPage
          businessId={selectedBusinessId}
          onAddToCart={handleAddToCart}
          onBack={handleBackToShopping}
          onNavigateHome={handleNavigateHomeFromDetail}
          currentCartBusinessId={currentCartBusinessId}
          hasItemsInCart={cart.length > 0}
        />
      )}

      {currentView === "tracking" && activeOrder && user && (
        <OrderTracking
          orderId={activeOrder.id}
          onBack={() => setCurrentView("shopping")}
          userId={user.id}
          userRole="client"
        />
      )}

      {currentView === "tracking" && !activeOrder && !loadingOrders && (
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12 text-white/60">
            <p>No se encontró ningún pedido activo</p>
            <Button variant="outline" onClick={() => setCurrentView("shopping")} className="mt-4">
              Volver a Inicio
            </Button>
          </div>
        </div>
      )}

      {currentView === "profile" && profile && (
        <div className="container mx-auto px-4 py-8">
          <Button variant="outline" onClick={() => setCurrentView("shopping")} className="mb-4">
            <Home className="h-4 w-4 mr-2" />
            Volver a Inicio
          </Button>
          <UserProfile user={{ ...user, ...profile, role: "CLIENT" } as any} onUpdate={() => {}} />
        </div>
      )}

      {currentView === "orders" && user && (
        <div className="container mx-auto px-4 py-8">
          <Button variant="outline" onClick={() => setCurrentView("shopping")} className="mb-4">
            <Home className="h-4 w-4 mr-2" />
            Volver a Inicio
          </Button>
          <OrderHistory
            userId={user.id}
            onTrackOrder={(orderId) => {
              // Solo cambiar a tracking si realmente existe ese pedido
              const order = orders.find((o) => o.id === orderId);
              if (order) {
                setCurrentView("tracking");
              }
            }}
          />
        </div>
      )}

      {currentView === "stats" && user && (
        <ClientDashboardStats userId={user.id} onBack={() => setCurrentView("shopping")} />
      )}

      {/* Shopping Cart */}
      {selectedBusinessId && user && (
        <ShoppingCart
          open={cartOpen}
          onClose={() => setCartOpen(false)}
          items={cart}
          businessId={selectedBusinessId}
          onUpdateCart={setCart}
        />
      )}
    </div>
  );
};

export default ClientDashboard;
