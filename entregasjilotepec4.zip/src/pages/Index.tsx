import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserRole } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useBusinesses } from '@/hooks/useBusinesses';
import { useOrders } from '@/hooks/useOrders';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  Store, 
  ShoppingBag, 
  CheckCircle,
  XCircle,
  User as UserIcon,
  Phone
} from 'lucide-react';

export default function Index() {
  const navigate = useNavigate();
  const { user, userRole, signOut, loading } = useAuth();
  const { businesses } = useBusinesses();
  const { orders } = useOrders();

  useEffect(() => {
    if (loading) return;

    if (!user) {
      navigate('/home');
      return;
    }

    // Wait for role to be loaded
    if (!userRole) {
      return;
    }

    // Redirect based on role
    if (userRole !== 'admin') {
      switch (userRole) {
        case 'client':
          navigate('/client-dashboard');
          break;
        case 'business':
          navigate('/business-dashboard');
          break;
        case 'delivery':
          navigate('/delivery-dashboard');
          break;
      }
      return;
    }
  }, [user, userRole, loading, navigate]);

  const handleLogout = async () => {
    await signOut();
    navigate('/home');
  };

  if (!user) return null;

  const stats = {
    totalUsers: 0,
    totalBusinesses: businesses.length,
    totalOrders: orders.length,
    pendingApprovals: businesses.filter(b => !b.isApproved).length,
    activeOrders: orders.filter(o => 
      !['DELIVERED', 'CANCELLED'].includes(o.status)
    ).length,
    totalRevenue: orders.reduce((sum, o) => sum + o.total, 0)
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-primary">vrtelolleva - Admin</h1>
            <p className="text-sm text-muted-foreground">Panel de Administración</p>
          </div>
          <Button variant="logout" onClick={handleLogout}>
            Cerrar Sesión
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Usuarios Totales</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Negocios</CardTitle>
              <Store className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalBusinesses}</div>
              {stats.pendingApprovals > 0 && (
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.pendingApprovals} pendientes
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pedidos</CardTitle>
              <ShoppingBag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalOrders}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.activeOrders} activos
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="businesses" className="space-y-4">
          <TabsList>
            <TabsTrigger value="businesses">Negocios</TabsTrigger>
            <TabsTrigger value="users">Usuarios</TabsTrigger>
            <TabsTrigger value="orders">Pedidos</TabsTrigger>
          </TabsList>

          <TabsContent value="businesses" className="space-y-4">
            {businesses.map(business => (
              <Card key={business.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex gap-4">
                      <img 
                        src={business.image || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400'} 
                        alt={business.name}
                        className="w-16 h-16 rounded-lg object-cover"
                        style={{ 
                          imageRendering: 'auto',
                          backfaceVisibility: 'hidden'
                        }}
                      />
                      <div>
                        <CardTitle>{business.name}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">
                          {business.category}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {business.fullAddress || business.address}
                        </p>
                      </div>
                    </div>
                    <Badge variant={business.isApproved ? "default" : "outline"}>
                      {business.isApproved ? "Aprobado" : "Pendiente"}
                    </Badge>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <p className="text-center text-muted-foreground py-8">
              User management coming soon
            </p>
          </TabsContent>

          <TabsContent value="orders" className="space-y-4">
            {orders.map(order => (
              <Card key={order.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">
                        Pedido #{order.id.slice(0, 8)}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        ${order.total} - {order.paymentMethod}
                      </p>
                    </div>
                    <Badge>{order.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {/* Client Info */}
                    {order.clientInfo && (
                      <div className="bg-blue-50 p-2 rounded border border-blue-200">
                        <p className="text-sm flex items-center gap-1">
                          <UserIcon className="h-4 w-4 text-blue-600" />
                          <strong>Cliente:</strong> {order.clientInfo.name}
                        </p>
                        {order.clientInfo.phone && (
                          <p className="text-sm text-muted-foreground flex items-center gap-1 ml-5">
                            <Phone className="h-3 w-3" />
                            {order.clientInfo.phone}
                          </p>
                        )}
                      </div>
                    )}
                    <p className="text-sm">
                      <strong>Items:</strong> {order.items.length}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(order.createdAt).toLocaleString('es-MX')}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
