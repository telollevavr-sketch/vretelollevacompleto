import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useBusinesses } from '@/hooks/useBusinesses';
import { useOrders } from '@/hooks/useOrders';
import { useLocationTracking } from '@/hooks/useLocationTracking';
import { useNotifications } from '@/hooks/useNotifications';
import { dbBusinessToBusiness, dbOrderToOrder, mapOrderStatusToDbStatus } from '@/lib/typeConversions';
import { Order, OrderStatus, Business } from '@/types';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LogOut, Package, MapPin, DollarSign, Store, Phone, CheckCircle, User as UserIcon, History, Navigation } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { DeliveryProfile } from '@/components/delivery/DeliveryProfile';
import { OrderHistoryDelivery } from '@/components/delivery/OrderHistoryDelivery';
import { OrderDetailsModal } from '@/components/delivery/OrderDetailsModal';
import { DeliveryStats } from '@/components/delivery/DeliveryStats';
import { OrderMessages } from '@/components/shared/OrderMessages';
import { OrderItemDetails } from '@/components/shared/OrderItemDetails';
import logo from '@/assets/vrtelolleva-logo.png';

const DeliveryDashboard = () => {
  const { user, profile, signOut, updateProfile } = useAuth();
  const { businesses: dbBusinesses } = useBusinesses();
  const { orders: dbOrders, updateOrder } = useOrders(user?.id, 'delivery');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const navigate = useNavigate();

  // Hooks now return converted types
  const businesses = dbBusinesses;
  const orders = dbOrders;

  const isOnline = profile?.is_online || false;
  
  // Activar seguimiento de ubicación en tiempo real cuando el repartidor está en línea
  useLocationTracking({
    userId: user?.id || '',
    isOnline,
    enabled: !!user
  });
  
  const availableOrders = orders.filter(o => 
    o.status === OrderStatus.READY_FOR_PICKUP && !o.deliveryPersonId
  );

  const activeOrder = orders.find(o => 
    o.deliveryPersonId === user?.id && 
    o.status !== OrderStatus.DELIVERED && 
    o.status !== OrderStatus.CANCELLED
  ) || null;

  const business = activeOrder 
    ? businesses.find(b => b.id === activeOrder.businessId) || null
    : null;

  useEffect(() => {
    if (!user) {
      navigate('/home');
      return;
    }
  }, [navigate, user]);

  const handleToggleOnline = async (online: boolean) => {
    if (user && profile) {
      // Si se está activando, verificar permisos de geolocalización primero
      if (online) {
        try {
          // Solicitar permisos de geolocalización
          const permissionStatus = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
          
          if (permissionStatus.state === 'denied') {
            toast({
              title: 'Permisos de Ubicación Requeridos',
              description: 'Debes permitir el acceso a tu ubicación en la configuración del navegador para activarte',
              variant: 'destructive',
            });
            return;
          }

          // Intentar obtener ubicación inmediatamente
          await new Promise<void>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
              () => {
                console.log('✅ Permiso de geolocalización concedido');
                resolve();
              },
              (error) => {
                console.error('❌ Error al obtener ubicación inicial:', error);
                toast({
                  title: 'Error de Ubicación',
                  description: 'No se pudo obtener tu ubicación. Por favor, verifica los permisos del navegador.',
                  variant: 'destructive',
                });
                reject(error);
              },
              { enableHighAccuracy: true, timeout: 10000 }
            );
          });
        } catch (error) {
          console.error('Error verificando permisos:', error);
          return; // No activar si no hay permisos
        }
      }

      await updateProfile({ is_online: online });
      
      console.log(`${online ? '🟢' : '🔴'} [DELIVERY] Estado: ${online ? 'EN LÍNEA' : 'FUERA DE LÍNEA'}`);
      
      toast({
        title: online ? '🟢 En Línea' : '🔴 Fuera de Línea',
        description: online 
          ? '✅ Tu ubicación se está compartiendo en tiempo real. Los clientes y administradores pueden ver tu posición en el mapa.' 
          : 'Ya no estás disponible para entregas'
      });
    }
  };

  const handleAcceptDelivery = (order: Order) => {
    if (!user) return;

    updateOrder({
      id: order.id,
      status: mapOrderStatusToDbStatus(OrderStatus.ON_THE_WAY) as any,
      delivery_person_id: user.id,
      updated_at: new Date().toISOString()
    });

    toast({
      title: 'Entrega Aceptada',
      description: 'Dirígete al restaurante para recoger el pedido'
    });
  };

  const handleMarkDelivered = () => {
    if (!activeOrder) return;

    updateOrder({
      id: activeOrder.id,
      status: mapOrderStatusToDbStatus(OrderStatus.DELIVERED) as any,
      delivered_at: new Date().toISOString(),
    });

    toast({
      title: 'Entrega Completada',
      description: 'El pedido ha sido marcado como entregado'
    });
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/home');
  };

  const handleUpdateUser = async (updates: any) => {
    await updateProfile(updates);
  };

  const openGoogleMaps = (order: Order) => {
    const { lat, lng } = order.deliveryLocation;
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, '_blank');
  };

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setDetailsOpen(true);
  };

  if (!user || !profile) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(0,50%,30%)] via-[hsl(5,45%,25%)] to-[hsl(10,40%,20%)]">
      <header className="border-b border-white/10 bg-[hsl(0,50%,20%)]/80 backdrop-blur shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="animate-fade-in flex items-center gap-3">
              <img src={logo} alt="vrtelolleva" className="h-12 w-auto" />
              <div>
                <h1 className="text-3xl font-bold text-white">Panel de Repartidor</h1>
                <p className="text-sm text-white/70 mt-1">👋 {profile.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3 bg-white/10 px-4 py-2 rounded-lg border border-white/20 shadow-sm backdrop-blur">
                <Label htmlFor="online-toggle" className="font-medium text-white flex items-center gap-2">
                  {isOnline ? (
                    <>
                      <span className="relative flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                      </span>
                      En Línea
                    </>
                  ) : (
                    <>
                      🔴 Desconectado
                    </>
                  )}
                </Label>
                <Switch
                  id="online-toggle"
                  checked={isOnline}
                  onCheckedChange={handleToggleOnline}
                  disabled={!!activeOrder}
                />
              </div>
              {isOnline && (
                <div className="text-xs text-white/60 bg-white/5 px-3 py-1 rounded border border-white/10">
                  📍 Ubicación compartida
                </div>
              )}
              <Button variant="logout" onClick={handleLogout} className="hover-scale">
                <LogOut className="h-4 w-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 animate-fade-in">
        <Tabs defaultValue={activeOrder ? "active" : "available"} className="space-y-6">
          <div className="w-full overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
            <TabsList className="inline-flex bg-[hsl(0,50%,85%)]/80 backdrop-blur-sm min-w-full md:min-w-0">
              {activeOrder && (
                <TabsTrigger value="active" className="flex items-center gap-2 whitespace-nowrap">
                  <Package className="h-4 w-4" />
                  🚴 Entrega Activa
                </TabsTrigger>
              )}
              <TabsTrigger value="available" className="flex items-center gap-2 whitespace-nowrap">
                <Package className="h-4 w-4" />
                Pedidos
              </TabsTrigger>
              <TabsTrigger value="stats" className="flex items-center gap-2 whitespace-nowrap">
                📊 Stats
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center gap-2 whitespace-nowrap">
                <History className="h-4 w-4" />
                Historial
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex items-center gap-2 whitespace-nowrap">
                <UserIcon className="h-4 w-4" />
                Perfil
              </TabsTrigger>
            </TabsList>
          </div>

          {activeOrder && (
            <TabsContent value="active">
              <div className="max-w-2xl mx-auto space-y-6">
                <Card className="bg-[hsl(0,50%,85%)]/80 border-black/20 shadow-xl backdrop-blur-sm">
                  <CardHeader className="bg-[hsl(0,50%,80%)]/60">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold text-black">🚴 Entrega Activa</p>
                        <p className="text-sm text-black/60 mt-1">Pedido #{activeOrder.id.slice(0, 8)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-black">${activeOrder.deliveryFee.toFixed(2)}</p>
                        <p className="text-xs text-black/60">Tu ganancia</p>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6 pt-6">
                    <div className="space-y-3">
                      <Label className="text-base font-semibold flex items-center gap-2 text-black">
                        <Store className="h-5 w-5 text-black" />
                        Recoger en:
                      </Label>
                      <div className="flex items-start gap-4 p-4 bg-[hsl(0,50%,90%)]/60 rounded-lg border border-black/20">
                        <div className="bg-green-500 p-3 rounded-lg">
                          <Store className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-lg text-black">{business?.name || 'Restaurante'}</p>
                          <p className="text-sm text-black/60 mt-1 flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            {business?.address}
                          </p>
                          {business?.phone && (
                            <p className="text-sm text-black/60 mt-1 flex items-center gap-2">
                              <Phone className="h-4 w-4" />
                              {business.phone}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-base font-semibold flex items-center gap-2 text-black">
                        <MapPin className="h-5 w-5 text-black" />
                        Entregar en:
                      </Label>
                      <div className="space-y-3">
                        <div className="flex items-start gap-4 p-4 bg-[hsl(0,50%,90%)]/60 rounded-lg border border-black/20">
                          <div className="bg-blue-500 p-3 rounded-lg">
                            <MapPin className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold text-lg text-black">Dirección de entrega</p>
                            <p className="text-sm text-black/60 mt-1">
                            {activeOrder.deliveryLocation.address || 
                              `${activeOrder.deliveryLocation.lat.toFixed(4)}, ${activeOrder.deliveryLocation.lng.toFixed(4)}`}
                          </p>
                        </div>
                      </div>
                        <Button onClick={() => openGoogleMaps(activeOrder)} variant="outline" className="w-full">
                          <Navigation className="h-4 w-4 mr-2" />
                          Abrir en Google Maps
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-base font-semibold flex items-center gap-2 text-black">
                        <Package className="h-5 w-5 text-black" />
                        Artículos del Pedido:
                      </Label>
                      <div className="space-y-4 bg-[hsl(0,50%,90%)]/60 p-4 rounded-lg border border-black/20">
                        {activeOrder.items.map((item, index) => {
                          console.log('🔍 [DeliveryActiveOrder] Rendering item:', {
                            name: item.product.name,
                            hasComplements: !!item.selectedComplements,
                            complementsCount: item.selectedComplements?.length || 0,
                            complements: item.selectedComplements
                          });
                          return (
                            <div key={index} className="p-3 bg-white/60 rounded-lg border border-black/20">
                              <OrderItemDetails 
                                item={item} 
                                index={index} 
                                showPrice={true}
                                compact={false}
                              />
                            </div>
                          );
                        })}
                      </div>
                      <div className="bg-[hsl(0,50%,90%)]/60 p-4 rounded-lg border border-black/20 space-y-2">
                        <div className="flex justify-between items-center text-lg">
                          <span className="font-semibold text-black">Total a cobrar:</span>
                          <span className="text-2xl font-bold text-black">${activeOrder.total.toFixed(2)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-black/60 pt-2 border-t border-black/10">
                          <DollarSign className="h-4 w-4" />
                          <span>Método: {activeOrder.paymentMethod === 'CASH' ? '💵 Efectivo' : '💳 Transferencia'}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="bg-muted/30 pt-4">
                    <Button onClick={handleMarkDelivered} className="w-full bg-gradient-to-r from-primary to-primary/80 hover-scale" size="lg">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      Marcar como Entregado
                    </Button>
                  </CardFooter>
                </Card>

                {/* Messages Section */}
                {user && (activeOrder.status === OrderStatus.READY_FOR_PICKUP || activeOrder.status === OrderStatus.ON_THE_WAY) && (
                  <Card className="border-blue-500/50 shadow-2xl bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30">
                    <CardHeader className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border-b-2 border-blue-200 dark:border-blue-800">
                      <h3 className="text-xl font-bold flex items-center gap-2 text-blue-700 dark:text-blue-300">
                        💬 Mensajes con el Cliente
                      </h3>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <OrderMessages
                        order={activeOrder}
                        currentUserId={user.id}
                        currentUserRole="DELIVERY"
                        onOrderUpdate={() => {}}
                      />
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          )}

            <TabsContent value="available">
              <Card className="bg-[hsl(0,50%,85%)]/80 border-black/20 shadow-lg backdrop-blur-sm">
                <CardHeader className="bg-[hsl(0,50%,80%)]/60">
                  <h2 className="text-2xl font-bold flex items-center gap-2 text-black">
                    <span className="bg-orange-500 text-white p-2 rounded-lg">📦</span>
                    Pedidos Disponibles
                    {isOnline && availableOrders.length > 0 && (
                      <span className="ml-2 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                        {availableOrders.length}
                      </span>
                    )}
                  </h2>
                </CardHeader>
                <CardContent className="pt-6">
                  {!isOnline ? (
                    <div className="text-center py-16">
                      <div className="inline-block p-6 bg-muted/50 rounded-full mb-4">
                        <span className="text-6xl">🔴</span>
                      </div>
                      <p className="text-lg text-muted-foreground font-medium">Estás desconectado</p>
                      <p className="text-sm text-muted-foreground mt-2">Actívate en línea para ver pedidos disponibles</p>
                    </div>
                  ) : availableOrders.length === 0 ? (
                    <div className="text-center py-16">
                      <div className="inline-block p-6 bg-muted/50 rounded-full mb-4">
                        <span className="text-6xl">📭</span>
                      </div>
                      <p className="text-lg text-muted-foreground font-medium">No hay pedidos disponibles</p>
                      <p className="text-sm text-muted-foreground mt-2">Los nuevos pedidos aparecerán aquí automáticamente</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {availableOrders.map(order => {
                        const orderBusiness = businesses.find(b => b.id === order.businessId);
                        
                        return (
                          <Card key={order.id} className="bg-[hsl(0,50%,90%)]/80 border-black/20 hover:border-black/40 transition-all duration-300 hover:shadow-lg animate-fade-in backdrop-blur-sm">
                            <CardHeader className="bg-[hsl(0,50%,85%)]/60 pb-3">
                              <div className="flex items-center justify-between">
                                <p className="font-bold text-black">📦 Pedido #{order.id.slice(0, 8)}</p>
                                <div className="text-right">
                                  <p className="text-xl font-bold text-black">${order.deliveryFee.toFixed(2)}</p>
                                  <p className="text-xs text-black/60">Ganancia</p>
                                </div>
                              </div>
                            </CardHeader>

                            <CardContent className="space-y-3 pt-4">
                              <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                                <Store className="h-5 w-5 text-green-600" />
                                <span className="text-sm font-medium">{orderBusiness?.name}</span>
                              </div>
                              <div className="flex items-start gap-3 p-2 bg-white/60 rounded-lg">
                                <MapPin className="h-5 w-5 text-blue-600 mt-0.5" />
                                <span className="text-sm text-black/60">{orderBusiness?.address}</span>
                              </div>
                              <div className="flex items-center gap-2 p-2 bg-white/60 rounded-lg">
                                <Package className="h-4 w-4 text-orange-600" />
                                <span className="text-sm font-medium text-black">{order.items.length} artículo(s)</span>
                              </div>
                            </CardContent>

                            <CardFooter className="flex gap-2 pt-4">
                              <Button variant="outline" className="flex-1 bg-white text-black border-black/20 hover:bg-black/5" onClick={() => handleViewDetails(order)}>
                                Ver Detalles
                              </Button>
                              <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white" onClick={() => handleAcceptDelivery(order)}>
                                Aceptar
                              </Button>
                            </CardFooter>
                          </Card>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stats">
              <DeliveryStats orders={orders} deliveryPersonId={user.id} />
            </TabsContent>

            <TabsContent value="history">
              <OrderHistoryDelivery deliveryPersonId={user.id} />
            </TabsContent>

            <TabsContent value="profile">
              {profile && <DeliveryProfile user={{ ...user!, ...profile, role: 'DELIVERY' } as any} onUpdate={handleUpdateUser} />}
            </TabsContent>
          </Tabs>
        </div>

      <OrderDetailsModal 
        order={selectedOrder} 
        open={detailsOpen} 
        onClose={() => setDetailsOpen(false)}
        deliveryPersonId={user.id}
      />
    </div>
  );
};

export default DeliveryDashboard;
