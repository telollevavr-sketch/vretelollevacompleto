import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useBusinesses } from '@/hooks/useBusinesses';
import { useProducts } from '@/hooks/useProducts';
import { useOrders } from '@/hooks/useOrders';
import { dbBusinessToBusiness, dbProductToProduct, dbOrderToOrder } from '@/lib/typeConversions';
import { Business, Order, Product, OrderStatus } from '@/types';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BusinessOrderCard } from '@/components/business/BusinessOrderCard';
import { ProductManagement } from '@/components/business/ProductManagement';
import { SpecialtyManagement } from '@/components/business/SpecialtyManagement';
import { BusinessProfile } from '@/components/business/BusinessProfile';
import { DeliveryPersonList } from '@/components/business/DeliveryPersonList';
import { OrderHistoryBusiness } from '@/components/business/OrderHistoryBusiness';
import { NotificationCenter } from '@/components/shared/NotificationCenter';
import { BusinessStats } from '@/components/business/BusinessStats';
import { BusinessCreateForm } from '@/components/business/BusinessCreateForm';
import { ComplementManagement } from '@/components/business/ComplementManagement';
import { ActiveDeliveriesTracking } from '@/components/business/ActiveDeliveriesTracking';
import { Store, LogOut, VolumeX } from 'lucide-react';
import { useOrderSound } from '@/hooks/useOrderSound';
import { PushNotificationToggle } from '@/components/admin/PushNotificationToggle';
import { toast } from '@/hooks/use-toast';
import logo from '@/assets/vrtelolleva-logo.png';

const BusinessDashboard = () => {
  const { user, profile, signOut } = useAuth();
  const { myBusiness, updateBusiness } = useBusinesses();
  const { orders: dbOrders } = useOrders(user?.id, 'business');
  const { products: dbProducts } = useProducts(myBusiness?.id);
  const navigate = useNavigate();

  // Hooks now return converted types
  const business = myBusiness;
  const orders = dbOrders;
  const products = dbProducts;

  // Alerta sonora para nuevos pedidos (con sonido personalizado para negocios)
  const { stopAlertSound, isPlaying } = useOrderSound(
    orders, 
    !!business,
    '/sounds/business-order-alert.mp3',
    1.0 // Volumen máximo para mejor audibilidad en móviles
  );

  useEffect(() => {
    if (!user) {
      navigate('/home');
      return;
    }

    if (!myBusiness) {
      toast({
        title: 'Información',
        description: 'No se encontró el negocio asociado. Debes crear un negocio primero.',
      });
    }
  }, [navigate, user, myBusiness]);

  const handleToggleOpen = (isOpen: boolean) => {
    if (business && myBusiness) {
      updateBusiness({ 
        id: myBusiness.id, 
        updates: { is_open: isOpen } 
      });
      toast({
        title: isOpen ? 'Negocio Abierto' : 'Negocio Cerrado',
        description: `Tu negocio ahora está ${isOpen ? 'abierto' : 'cerrado'}`
      });
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/home');
  };

  const activeOrders = orders.filter(o => {
    const isActive = o.status !== OrderStatus.DELIVERED && o.status !== OrderStatus.CANCELLED;
    console.log('🔍 [DASHBOARD] Filtrando pedido:', {
      orderId: o.id.slice(0, 8),
      status: o.status,
      isPickupAtCounter: o.isPickupAtCounter,
      isActive
    });
    return isActive;
  });

  if (!user || !profile) return null;

  // Si no hay negocio, mostrar formulario de creación
  if (!business) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[hsl(270,60%,15%)] via-[hsl(200,50%,15%)] to-[hsl(180,50%,12%)]">
        <header className="border-b border-white/10 bg-[hsl(180,50%,10%)]/60 backdrop-blur shadow-lg">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 animate-fade-in">
                <Store className="h-8 w-8 text-[hsl(180,100%,60%)]" />
                <h1 className="text-3xl font-bold text-white">
                  Panel de Negocios
                </h1>
              </div>
              <Button variant="logout" onClick={handleLogout} className="hover-scale">
                <LogOut className="h-4 w-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </header>
        <div className="container mx-auto px-4 py-8">
          <BusinessCreateForm />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(270,60%,15%)] via-[hsl(200,50%,15%)] to-[hsl(180,50%,12%)]">
      {/* Header */}
      <header className="border-b border-white/10 bg-[hsl(180,50%,10%)]/60 backdrop-blur shadow-lg">
        <div className="container mx-auto px-4 py-4 md:py-6">
          {/* Contenedor principal - columna en móvil, fila en desktop */}
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            
            {/* Fila 1: Logo + Salir (en móvil) */}
            <div className="flex items-center justify-between w-full md:w-auto">
              <div className="animate-fade-in flex items-center gap-3">
                <img src={logo} alt="vrtelolleva" className="h-10 md:h-12 w-auto" />
                <div>
                  <h1 className="text-xl md:text-3xl font-bold text-white">
                    {business.name}
                  </h1>
                  <p className="text-xs md:text-sm text-white/70 mt-1">Panel de Control</p>
                </div>
              </div>
              {/* Botón Salir visible solo en móvil */}
              <Button variant="logout" onClick={handleLogout} className="md:hidden hover-scale">
                <LogOut className="h-4 w-4 mr-1" />
                Salir
              </Button>
            </div>

            {/* Fila 2: Controles - compactos en móvil */}
            <div className="flex flex-wrap items-center justify-start gap-1.5 w-full md:w-auto md:gap-4 md:justify-end">
              {/* Estado Abierto/Cerrado - compacto */}
              <div className="flex items-center gap-1.5 bg-white/10 px-2 py-1.5 rounded-lg border border-white/20 shadow-sm backdrop-blur">
                {business.autoScheduleEnabled ? (
                  <Label className="font-medium text-white text-[11px] md:text-sm">
                    {business.isOpen ? '🟢 Abierto' : '🔴 Cerrado'}
                  </Label>
                ) : (
                  <>
                    <span className="text-[11px] md:text-sm text-white">
                      {business.isOpen ? '🟢' : '🔴'}
                    </span>
                    <Switch
                      id="open-toggle"
                      checked={business.isOpen}
                      onCheckedChange={handleToggleOpen}
                      className="scale-90 md:scale-100"
                    />
                  </>
                )}
              </div>
              
              {/* Push Notifications - compacto en móvil */}
              <PushNotificationToggle userId={user?.id} compact />
              
              {/* Silenciar Alerta (condicional) */}
              {isPlaying && (
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={stopAlertSound}
                  className="animate-pulse h-7 px-2"
                >
                  <VolumeX className="h-3 w-3 md:mr-1" />
                  <span className="hidden md:inline">Silenciar</span>
                </Button>
              )}
              
              {/* Botón Salir solo en desktop */}
              <Button variant="logout" onClick={handleLogout} className="hidden md:flex hover-scale">
                <LogOut className="h-4 w-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 animate-fade-in">
        <Tabs defaultValue="orders" className="space-y-6">
          <div className="w-full overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
            <TabsList className="inline-flex bg-[hsl(180,50%,12%)]/80 border-white/10 p-1 shadow-md backdrop-blur min-w-full md:min-w-0">
              <TabsTrigger value="orders" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                📦 Pedidos
              </TabsTrigger>
              <TabsTrigger value="menu" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                🍽️ Menú
              </TabsTrigger>
              {business.isSpecialBusiness && (
                <TabsTrigger value="specialties" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                  🍕 Especialidades
                </TabsTrigger>
              )}
              <TabsTrigger value="complements" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                🧀 Complementos
              </TabsTrigger>
              {business.deliveryTrackingEnabled && (
                <TabsTrigger value="tracking" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                  📍 Entregas
                </TabsTrigger>
              )}
              <TabsTrigger value="delivery" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                🚴 Repartidores
              </TabsTrigger>
              <TabsTrigger value="history" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                📋 Historial
              </TabsTrigger>
              <TabsTrigger value="stats" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                📊 Estadísticas
              </TabsTrigger>
              <TabsTrigger value="profile" className="text-white/70 data-[state=active]:bg-[hsl(180,60%,35%)]/80 data-[state=active]:text-white whitespace-nowrap">
                ⚙️ Perfil
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="orders" className="space-y-4 animate-fade-in">
            <div className="bg-[hsl(180,50%,12%)]/60 backdrop-blur rounded-lg p-6 border border-white/10">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2 text-[hsl(180,100%,60%)]">
                <span className="bg-white/10 p-2 rounded-lg">📦</span>
                Pedidos Activos
                {activeOrders.length > 0 && (
                  <span className="ml-2 bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-bold">
                    {activeOrders.length}
                  </span>
                )}
              </h2>
              {activeOrders.length === 0 ? (
                <div className="text-center py-16">
                  <div className="inline-block p-6 bg-white/5 rounded-full mb-4">
                    <span className="text-6xl">📭</span>
                  </div>
                  <p className="text-lg text-white/70 font-medium">
                    No hay pedidos activos en este momento
                  </p>
                  <p className="text-sm text-white/50 mt-2">
                    Los nuevos pedidos aparecerán aquí automáticamente
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeOrders.map(order => (
                    <BusinessOrderCard 
                      key={order.id} 
                      order={order} 
                      businessLocation={business.location}
                      business={business}
                    />
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="menu">
            {business && <ProductManagement businessId={business.id} businessName={business.name} isSpecialBusiness={business.isSpecialBusiness} />}
          </TabsContent>

          {business.isSpecialBusiness && (
            <TabsContent value="specialties">
              <div className="bg-[hsl(180,50%,12%)]/60 backdrop-blur rounded-lg p-6 border border-white/10">
                <SpecialtyManagement businessId={business.id} businessName={business.name} />
              </div>
            </TabsContent>
          )}

          <TabsContent value="complements">
            <div className="bg-[hsl(180,50%,12%)]/60 backdrop-blur rounded-lg p-6 border border-white/10">
              <ComplementManagement businessId={business.id} businessName={business.name} />
            </div>
          </TabsContent>

          {business.deliveryTrackingEnabled && (
            <TabsContent value="tracking">
              <ActiveDeliveriesTracking 
                businessId={business.id} 
                businessLocation={business.location}
                businessName={business.name}
              />
            </TabsContent>
          )}

          <TabsContent value="delivery">
            {business && (
              <DeliveryPersonList 
                businessId={business.id} 
                businessLocation={business.location}
                businessName={business.name}
              />
            )}
          </TabsContent>

          <TabsContent value="history">
            {business && <OrderHistoryBusiness businessId={business.id} />}
          </TabsContent>

          <TabsContent value="stats">
            <BusinessStats orders={orders} products={products} />
          </TabsContent>

          <TabsContent value="profile">
            {business && <BusinessProfile business={business} onUpdate={() => {}} />}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default BusinessDashboard;
