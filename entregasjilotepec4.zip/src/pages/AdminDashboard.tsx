import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useOrders } from '@/hooks/useOrders';
import { useUsers } from '@/hooks/useUsers';
import { useOrderSound } from '@/hooks/useOrderSound';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LogOut, Users, Store, Package, DollarSign, Bike, Tags, MapPin, UserCheck, FileText, Database, VolumeX, UserCircle, Navigation, Sparkles, ClipboardPlus, AlertTriangle } from 'lucide-react';
import { StatCard } from '@/components/shared/StatCard';
import { AdminStats } from '@/components/admin/AdminStats';
import { UserManagement } from '@/components/admin/UserManagement';
import { BusinessManagement } from '@/components/admin/BusinessManagement';
import { DeliveryManagement } from '@/components/admin/DeliveryManagement';
import { CategoryManagement } from '@/components/admin/CategoryManagement';
import { AdminLiveMap } from '@/components/admin/AdminLiveMap';
import { AdminOrdersMap } from '@/components/admin/AdminOrdersMap';
import { OrdersDebugger } from '@/components/admin/OrdersDebugger';
import { PendingApproval } from '@/components/admin/PendingApproval';
import { AdminReports } from '@/components/admin/AdminReports';
import { DataBackup } from '@/components/admin/DataBackup';
import { PushNotificationToggle } from '@/components/admin/PushNotificationToggle';
import { NotificationCenter } from '@/components/shared/NotificationCenter';
import { ClientManagement } from '@/components/admin/ClientManagement';
import { AdminActiveDeliveries } from '@/components/admin/AdminActiveDeliveries';
import { AntojoBusinessManagement } from '@/components/admin/AntojoBusinessManagement';
import { ManualOrderCapture } from '@/components/admin/ManualOrderCapture';
import { DeliveryIncidents } from '@/components/admin/DeliveryIncidents';
import { UserRole } from '@/types';
import logo from '@/assets/vrtelolleva-logo.png';

const ADMIN_ACTIVE_TAB_STORAGE_KEY = 'admin-dashboard-active-tab';

const AdminDashboard = () => {
  const { user, profile, userRole, signOut } = useAuth();
  const { businesses } = useAllBusinesses();
  const { orders } = useOrders(user?.id, 'admin');
  const { users } = useUsers();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(() => {
    if (typeof window === 'undefined') return 'pending';
    return window.sessionStorage.getItem(ADMIN_ACTIVE_TAB_STORAGE_KEY) ?? 'pending';
  });

  // Sound alert for new orders
  const { stopAlertSound, isPlaying } = useOrderSound(orders, userRole === 'admin');

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    if (typeof window !== 'undefined') {
      window.sessionStorage.setItem(ADMIN_ACTIVE_TAB_STORAGE_KEY, value);
    }
  };

  useEffect(() => {
    if (!user || userRole !== 'admin') {
      navigate('/home');
      return;
    }
  }, [navigate, user, userRole]);

  const handleLogout = async () => {
    await signOut();
    navigate('/home');
  };

  const deliveredOrders = orders.filter(o => o.status === 'DELIVERED');
  const totalRevenue = deliveredOrders.reduce((sum, order) => sum + order.total, 0);
  const deliveryPersons = users
    .filter(u => u.role === 'delivery')
    .map(u => ({
      id: u.id,
      email: u.email,
      name: u.name,
      role: UserRole.DELIVERY,
      phone: u.phone || undefined,
      address: u.address || undefined,
      isActive: u.is_active || false,
      createdAt: u.created_at,
      vehicleType: u.vehicle_type || undefined,
      vehiclePlate: u.vehicle_plate || undefined,
      isOnline: u.is_online || undefined,
      assignedBusinessId: u.assigned_business_id || undefined,
      location: u.latitude && u.longitude ? {
        lat: u.latitude,
        lng: u.longitude,
        address: u.address || undefined
      } : undefined,
    }));

  if (!user || !profile) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(270,50%,20%)] via-[hsl(265,45%,25%)] to-[hsl(260,40%,30%)]">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={logo} alt="vrtelolleva" className="h-10 w-auto" />
              <div>
                <h1 className="text-2xl font-bold text-white">Panel de Administración</h1>
                <p className="text-sm text-white/70">{profile.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {isPlaying && (
                <Button 
                  variant="destructive" 
                  onClick={stopAlertSound}
                  className="animate-pulse"
                >
                  <VolumeX className="h-4 w-4 mr-2" />
                  Silenciar Alerta
                </Button>
              )}
              <PushNotificationToggle userId={user?.id} />
              <Button variant="logout" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Usuarios"
            value={users.length}
            icon={Users}
            description="Total registrados"
            variant="purple"
          />
          <StatCard
            title="Negocios"
            value={businesses.length}
            icon={Store}
            description="Restaurantes totales"
            variant="cyan"
          />
          <StatCard
            title="Repartidores"
            value={deliveryPersons.length}
            icon={Bike}
            description="En plataforma"
            variant="orange"
          />
          <StatCard
            title="Ingresos"
            value={`$${totalRevenue.toFixed(2)}`}
            icon={DollarSign}
            description="Revenue total"
            variant="green"
          />
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          <div className="w-full overflow-x-auto md:overflow-visible pb-2 scrollbar-thin scrollbar-thumb-white/30 scrollbar-track-transparent">
            <TabsList className="flex flex-nowrap md:flex-wrap gap-2 h-auto bg-[hsl(270,50%,85%)]/80 border-purple-300/30 p-2 rounded-lg min-w-max md:min-w-0">
              <TabsTrigger value="pending" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <UserCheck className="h-4 w-4 mr-2" />
                Aprobaciones
              </TabsTrigger>
              <TabsTrigger value="map" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Bike className="h-4 w-4 mr-2" />
                Seguimiento en tiempo real
              </TabsTrigger>
              <TabsTrigger value="live-deliveries" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Navigation className="h-4 w-4 mr-2" />
                Entregas en Vivo
              </TabsTrigger>
              <TabsTrigger value="users" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Users className="h-4 w-4 mr-2" />
                Usuarios
              </TabsTrigger>
              <TabsTrigger value="clients" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <UserCircle className="h-4 w-4 mr-2" />
                Clientes
              </TabsTrigger>
              <TabsTrigger value="businesses" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Store className="h-4 w-4 mr-2" />
                Negocios
              </TabsTrigger>
              <TabsTrigger value="categories" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Tags className="h-4 w-4 mr-2" />
                Categorías
              </TabsTrigger>
              <TabsTrigger value="delivery" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Bike className="h-4 w-4 mr-2" />
                Repartidores
              </TabsTrigger>
              <TabsTrigger value="stats" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Package className="h-4 w-4 mr-2" />
                Estadísticas
              </TabsTrigger>
              <TabsTrigger value="orders-map" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <MapPin className="h-4 w-4 mr-2" />
                Mapa de Pedidos
              </TabsTrigger>
              <TabsTrigger value="orders-debug" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Package className="h-4 w-4 mr-2" />
                Depurador de Pedidos
              </TabsTrigger>
              <TabsTrigger value="reports" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <FileText className="h-4 w-4 mr-2" />
                Informes
              </TabsTrigger>
              <TabsTrigger value="backup" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Database className="h-4 w-4 mr-2" />
                Respaldos
              </TabsTrigger>
              <TabsTrigger value="manual-capture" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <ClipboardPlus className="h-4 w-4 mr-2" />
                Captura Manual
              </TabsTrigger>
              <TabsTrigger value="antojos" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <Sparkles className="h-4 w-4 mr-2" />
                Antojos
              </TabsTrigger>
              <TabsTrigger value="incidents" className="text-white data-[state=active]:bg-purple-600 data-[state=active]:text-white whitespace-nowrap">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Entregas
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="pending" className="space-y-4">
            <PendingApproval />
          </TabsContent>

          <TabsContent value="map" className="space-y-4">
            <AdminLiveMap />
          </TabsContent>

          <TabsContent value="live-deliveries" className="space-y-4">
            <AdminActiveDeliveries />
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <UserManagement />
          </TabsContent>

          <TabsContent value="clients" className="space-y-4">
            <ClientManagement />
          </TabsContent>

          <TabsContent value="businesses" className="space-y-4">
            <BusinessManagement />
          </TabsContent>

          <TabsContent value="categories" className="space-y-4">
            <CategoryManagement />
          </TabsContent>

          <TabsContent value="delivery" className="space-y-4">
            <DeliveryManagement />
          </TabsContent>

          <TabsContent value="stats" className="space-y-4">
            <AdminStats orders={orders} businesses={businesses} deliveryPersons={deliveryPersons} />
          </TabsContent>

          <TabsContent value="orders-map" className="space-y-4">
            <AdminOrdersMap />
          </TabsContent>

          <TabsContent value="orders-debug" className="space-y-4">
            <OrdersDebugger />
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <AdminReports />
          </TabsContent>

          <TabsContent value="backup" className="space-y-4">
            <DataBackup />
          </TabsContent>

          <TabsContent value="manual-capture" className="space-y-4">
            <ManualOrderCapture />
          </TabsContent>

          <TabsContent value="antojos" className="space-y-4">
            <AntojoBusinessManagement />
          </TabsContent>

          <TabsContent value="incidents" className="space-y-4">
            <DeliveryIncidents />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;