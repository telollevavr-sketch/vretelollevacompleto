import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Menu, Search, ShoppingCart as ShoppingCartIcon, Download } from 'lucide-react';
import { useInstallPrompt } from '@/hooks/useInstallPrompt';
import { useBusinesses } from '@/hooks/useBusinesses';
import { BackendError } from '@/components/shared/BackendError';
import { supabase } from '@/integrations/supabase/client';
import { Business, Product, CartItem } from '@/types';
import { AuthModal } from '@/components/auth/AuthModal';
import { BusinessCard } from '@/components/business/BusinessCard';
import { BusinessFilters, FilterState } from '@/components/client/BusinessFilters';

import { BusinessMenuModal } from '@/components/business/BusinessMenuModal';
import { ShoppingCart } from '@/components/client/ShoppingCart';
import { TutorialsModal } from '@/components/client/TutorialsModal';
import { IOSInstallBanner } from '@/components/shared/IOSInstallBanner';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import logo from '@/assets/vrtelolleva-logo.png';
import facebookIcon from '@/assets/facebook-icon.png';
import instagramIcon from '@/assets/instagram-icon.png';
import bannerAntojos from '@/assets/banner_algo_mas2.png';

const INITIAL_VISIBLE = 8;

const HomePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { businesses, isLoading: isLoadingBusinesses, isError: isErrorBusinesses, refetch: refetchBusinesses } = useBusinesses({ skipMyBusiness: true });
  const { isInstallable, isInstalled, isIOS, isAndroid, promptInstall } = useInstallPrompt();

  // Single consolidated batch query for promo + menu counts
  const { data: batchCounts = { promo: {}, menu: {} } } = useQuery({
    queryKey: ['batch-counts'],
    queryFn: async () => {
      const [promoRes, menuRes] = await Promise.all([
        supabase.from('business_promotions').select('business_id').eq('is_active', true),
        supabase.from('business_menu_images').select('business_id').eq('is_active', true),
      ]);
      const promo: Record<string, number> = {};
      (promoRes.data || []).forEach(row => {
        promo[row.business_id] = (promo[row.business_id] || 0) + 1;
      });
      const menu: Record<string, number> = {};
      (menuRes.data || []).forEach(row => {
        menu[row.business_id] = (menu[row.business_id] || 0) + 1;
      });
      return { promo, menu };
    },
    staleTime: 120000,
    refetchOnWindowFocus: false,
    enabled: !isLoadingBusinesses,
  });

  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showTutorialsModal, setShowTutorialsModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [showBusinessMenu, setShowBusinessMenu] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartBusinessId, setCartBusinessId] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    minRating: 0,
    openOnly: false,
  });
  const [showAll, setShowAll] = useState(false);
  
  const activeBusinesses = useMemo(() => businesses.filter(b => b.isApproved), [businesses]);
  
  const filteredBusinesses = useMemo(() => activeBusinesses.filter(b => {
    const matchesSearch = b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         b.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filters.categories.length === 0 || filters.categories.includes(b.category);
    const matchesRating = b.rating >= filters.minRating;
    const matchesOpenOnly = !filters.openOnly || b.isOpen;
    
    return matchesSearch && matchesCategory && matchesRating && matchesOpenOnly;
  }), [activeBusinesses, searchQuery, filters]);

  const visibleBusinesses = showAll ? filteredBusinesses : filteredBusinesses.slice(0, INITIAL_VISIBLE);

  const handleBusinessSelect = (business: Business) => {
    setSelectedBusiness(business);
    setShowBusinessMenu(true);
  };

  const handleAddToCart = (product: Product, configuration?: CartItem['configuration']) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }

    if (cartBusinessId && cartBusinessId !== product.businessId) {
      toast({
        title: "Carrito de otro restaurante",
        description: "Solo puedes ordenar de un restaurante a la vez. Vacía tu carrito primero.",
        variant: "destructive"
      });
      return;
    }

    if (configuration?.ingredients) {
      const newItem: CartItem = {
        product,
        quantity: 1,
        subtotal: product.price,
        configuration
      };
      setCartItems([...cartItems, newItem]);
      setCartBusinessId(product.businessId);
      
      toast({
        title: "¡Agregado al carrito!",
        description: `${product.name} agregado a tu carrito.`,
      });
      return;
    }

    const existingIndex = cartItems.findIndex(item => item.product.id === product.id);
    
    if (existingIndex >= 0) {
      const newItems = [...cartItems];
      newItems[existingIndex].quantity += 1;
      newItems[existingIndex].subtotal = newItems[existingIndex].product.price * newItems[existingIndex].quantity;
      setCartItems(newItems);
    } else {
      const newItem: CartItem = {
        product,
        quantity: 1,
        subtotal: product.price,
        configuration
      };
      setCartItems([...cartItems, newItem]);
      setCartBusinessId(product.businessId);
    }

    toast({
      title: "¡Agregado al carrito!",
      description: `${product.name} agregado a tu carrito.`,
    });
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(260,50%,8%)] via-[hsl(255,48%,10%)] to-[hsl(250,45%,12%)]">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-[hsl(260,45%,10%)]/80 backdrop-blur-md supports-[backdrop-filter]:bg-[hsl(260,45%,10%)]/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={logo} alt="vrtelolleva" className="h-10 w-auto" />
            <h1 className="text-2xl font-bold text-white">vrtelolleva</h1>
          </div>
          <div className="flex items-center gap-2">
            <a href="https://www.facebook.com/profile.php?id=61582552715688" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
              <img src={facebookIcon} alt="Facebook" className="h-8 w-8" />
            </a>
            <a href="https://www.facebook.com/profile.php?id=61582552715688" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
              <img src={instagramIcon} alt="Instagram" className="h-8 w-8" />
            </a>
            
            {!isInstalled && (
              <Button variant="default" size="sm" onClick={isInstallable ? promptInstall : () => navigate('/install')} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Download className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Instalar App</span>
              </Button>
            )}
            
            <Button variant="ghost" size="icon" onClick={() => setShowCart(true)} className="text-white hover:bg-white/10 relative">
              <ShoppingCartIcon className="h-5 w-5" />
              {cartItems.length > 0 && (
                <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  {cartItems.length}
                </Badge>
              )}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setShowAuthModal(true)} className="text-white hover:bg-white/10">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation Links */}
      <section className="container mx-auto px-4 py-4">
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 max-w-4xl mx-auto">
          <Button variant="outline" onClick={() => setShowTutorialsModal(true)} className="flex-1 h-12 text-base font-medium bg-[hsl(260,35%,18%)]/60 border-[hsl(270,40%,35%)]/50 text-white hover:bg-[hsl(270,40%,25%)] hover:text-white hover:border-[hsl(270,70%,60%)] transition-all">
            Conoce la plataforma
          </Button>
          <a href="https://www.facebook.com/profile.php?id=61582552715688" target="_blank" rel="noopener noreferrer" className="flex-1">
            <Button variant="outline" className="w-full h-12 text-base font-medium bg-[hsl(260,35%,18%)]/60 border-[hsl(270,40%,35%)]/50 text-white hover:bg-[hsl(270,40%,25%)] hover:text-white hover:border-[hsl(270,70%,60%)] transition-all">
              Inscribir negocio...
            </Button>
          </a>
          <a href="https://www.facebook.com/profile.php?id=61582552715688" target="_blank" rel="noopener noreferrer" className="flex-1">
            <Button variant="outline" className="w-full h-12 text-base font-medium bg-[hsl(260,35%,18%)]/60 border-[hsl(270,40%,35%)]/50 text-white hover:bg-[hsl(270,40%,25%)] hover:text-white hover:border-[hsl(270,70%,60%)] transition-all">
              Quiero ser repartidor...
            </Button>
          </a>
        </div>
        {/* Banner Antojos */}
        <div className="mt-4 max-w-4xl mx-auto cursor-pointer flex justify-center" onClick={() => navigate('/antojos')}>
          <img src={bannerAntojos} alt="¿Se te antoja algo más?" className="w-[75%] rounded-2xl shadow-lg transition-transform duration-300 hover:scale-[1.02]" />
        </div>
      </section>

      {/* Search Bar */}
      <section className="container mx-auto px-4 py-6">
        <div className="relative max-w-2xl mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 h-5 w-5" />
          <Input type="text" placeholder="Buscar por restaurante o categoría" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 h-14 text-lg bg-[hsl(260,35%,18%)]/60 border-[hsl(270,40%,35%)]/50 text-white placeholder:text-white/50 rounded-2xl focus:ring-2 focus:ring-[hsl(270,70%,60%)] focus:border-transparent" />
        </div>
      </section>


      {/* Filters and Businesses */}
      <section className="container mx-auto px-4 py-6">
        <h2 className="text-2xl font-bold mb-4 text-white">Restaurantes</h2>
        
        <div className="mb-6">
          <BusinessFilters onFilterChange={setFilters} />
        </div>

        {isErrorBusinesses ? (
          <BackendError compact message="No se pudieron cargar los restaurantes." onRetry={() => refetchBusinesses()} />
        ) : isLoadingBusinesses ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <Skeleton key={i} className="h-96 rounded-xl" />
            ))}
          </div>
        ) : filteredBusinesses.length === 0 ? (
          <div className="text-center py-12 text-white/60">
            <p>No se encontraron restaurantes</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {visibleBusinesses.map(business => (
                <BusinessCard
                  key={business.id}
                  business={business}
                  onSelect={handleBusinessSelect}
                  promotionCount={batchCounts.promo[business.id] || 0}
                  menuImageCount={batchCounts.menu[business.id] || 0}
                />
              ))}
            </div>
            {!showAll && filteredBusinesses.length > INITIAL_VISIBLE && (
              <div className="text-center mt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowAll(true)}
                  className="bg-[hsl(260,35%,18%)]/60 border-[hsl(270,40%,35%)]/50 text-white hover:bg-[hsl(270,40%,25%)] hover:text-white"
                >
                  Ver más restaurantes ({filteredBusinesses.length - INITIAL_VISIBLE} más)
                </Button>
              </div>
            )}
          </>
        )}
      </section>

      <BusinessMenuModal
        open={showBusinessMenu}
        onClose={() => {
          setShowBusinessMenu(false);
          setSelectedBusiness(null);
        }}
        business={selectedBusiness}
        onAddToCart={handleAddToCart}
      />

      {cartBusinessId && (
        <ShoppingCart
          open={showCart}
          onClose={() => setShowCart(false)}
          items={cartItems}
          businessId={cartBusinessId}
          onUpdateCart={(newItems) => {
            setCartItems(newItems);
            if (newItems.length === 0) {
              setCartBusinessId(null);
            }
          }}
        />
      )}

      <TutorialsModal open={showTutorialsModal} onClose={() => setShowTutorialsModal(false)} />
      <AuthModal open={showAuthModal} onClose={() => setShowAuthModal(false)} />
      <IOSInstallBanner />
    </div>
  );
};

export default HomePage;
