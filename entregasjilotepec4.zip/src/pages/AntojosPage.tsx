import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useAntojoBusinesses, AntojoBusiness } from '@/hooks/useAntojoBusinesses';
import { useAntojoCategories } from '@/hooks/useAntojoCategories';
import { AntojoBusinessCard } from '@/components/antojo/AntojoBusinessCard';
import { AntojoOrderForm } from '@/components/antojo/AntojoOrderForm';
import { AuthModal } from '@/components/auth/AuthModal';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Sparkles, Store } from 'lucide-react';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import logo from '@/assets/vrtelolleva-logo.png';

const AntojosPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { businesses, isLoading } = useAntojoBusinesses();
  const { categories } = useAntojoCategories();
  const [selectedBusiness, setSelectedBusiness] = useState<AntojoBusiness | null>(null);
  const [isCustomBusiness, setIsCustomBusiness] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAuth, setShowAuth] = useState(false);

  const activeBusinesses = businesses
    .filter(b => b.is_active)
    .filter(b => !selectedCategory || b.category === selectedCategory);

  const handleSelectBusiness = (business: AntojoBusiness) => {
    if (!user) {
      setShowAuth(true);
      return;
    }
    setSelectedBusiness(business);
    setIsCustomBusiness(false);
  };

  const handleCustomBusiness = () => {
    if (!user) {
      setShowAuth(true);
      return;
    }
    setSelectedBusiness(null);
    setIsCustomBusiness(true);
  };

  const handleOrderSuccess = () => {
    setSelectedBusiness(null);
    setIsCustomBusiness(false);
  };

  const handleBack = () => {
    setSelectedBusiness(null);
    setIsCustomBusiness(false);
  };

  const showForm = selectedBusiness || isCustomBusiness;

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Mexican gradient */}
      <header className="sticky top-0 z-50 border-b-2 border-[hsl(var(--antojo-gold)/0.3)] bg-card/95 backdrop-blur-md"
        style={{ borderImage: 'var(--gradient-antojo) 1' }}>
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="text-[hsl(var(--antojo-terracotta))] hover:bg-[hsl(var(--antojo-cream))]"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <img src={logo} alt="vrtelolleva" className="h-8 w-auto" />
            <div>
              <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
                <span className="text-2xl">🌮</span>
                ¿Se te antoja algo más?
              </h1>
              <p className="text-xs text-muted-foreground">Pide a negocios fuera de la plataforma</p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {showForm ? (
          <AntojoOrderForm
            business={selectedBusiness}
            isCustomBusiness={isCustomBusiness}
            onBack={handleBack}
            onSuccess={handleOrderSuccess}
          />
        ) : (
          <>
            {/* Info banner with warm Mexican cream bg */}
            <div className="mb-6 rounded-xl border border-[hsl(var(--antojo-gold)/0.3)] bg-[hsl(var(--antojo-cream))] p-4 shadow-sm">
              <p className="text-sm text-foreground">
                🍽️ Aquí encontrarás negocios de comida no afiliados. Escribe tu pedido o sube una foto de tu nota y un repartidor lo recogerá por ti.
              </p>
            </div>

            {/* Category filters with Mexican colors */}
            {categories.length > 0 && (
              <div className="flex gap-2 overflow-x-auto pb-3 mb-4 scrollbar-none">
                <Badge
                  className={`cursor-pointer shrink-0 px-3 py-1.5 text-sm font-semibold transition-all ${
                    !selectedCategory
                      ? 'bg-[hsl(var(--antojo-terracotta))] text-white border-[hsl(var(--antojo-terracotta))] hover:bg-[hsl(var(--antojo-red))]'
                      : 'border-[hsl(var(--antojo-gold)/0.4)] bg-[hsl(var(--antojo-cream))] text-foreground hover:bg-[hsl(var(--antojo-gold)/0.2)]'
                  }`}
                  onClick={() => setSelectedCategory(null)}
                >
                  Todos
                </Badge>
                {categories.filter(c => c.is_active).map(cat => (
                  <Badge
                    key={cat.id}
                    className={`cursor-pointer shrink-0 px-3 py-1.5 text-sm font-semibold transition-all ${
                      selectedCategory === cat.name
                        ? 'bg-[hsl(var(--antojo-green))] text-white border-[hsl(var(--antojo-green))] hover:bg-[hsl(var(--antojo-green)/0.85)]'
                        : 'border-[hsl(var(--antojo-gold)/0.4)] bg-[hsl(var(--antojo-cream))] text-foreground hover:bg-[hsl(var(--antojo-gold)/0.2)]'
                    }`}
                    onClick={() => setSelectedCategory(selectedCategory === cat.name ? null : cat.name)}
                  >
                    {cat.icon} {cat.name}
                  </Badge>
                ))}
              </div>
            )}

            {/* Custom business button */}
            <Button
              variant="outline"
              onClick={handleCustomBusiness}
              className="mb-4 w-full border-2 border-dashed border-foreground bg-foreground text-background hover:bg-foreground/90 hover:border-foreground font-semibold"
            >
              <Store className="h-4 w-4 mr-2" />
              ¿No encuentras tu negocio? Escríbelo aquí
            </Button>

            {isLoading ? (
              <LoadingSpinner text="Cargando negocios..." />
            ) : activeBusinesses.length === 0 ? (
              <div className="py-12 text-center text-muted-foreground">
                <span className="mx-auto mb-3 block text-5xl">🌶️</span>
                <p className="text-lg text-foreground">
                  {selectedCategory ? `No hay negocios de "${selectedCategory}" aún` : 'Próximamente más negocios'}
                </p>
                <p className="text-sm mt-1">Estamos agregando opciones para ti</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {activeBusinesses.map(business => (
                  <AntojoBusinessCard
                    key={business.id}
                    business={business}
                    onSelect={handleSelectBusiness}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <AuthModal open={showAuth} onClose={() => setShowAuth(false)} />
    </div>
  );
};

export default AntojosPage;
