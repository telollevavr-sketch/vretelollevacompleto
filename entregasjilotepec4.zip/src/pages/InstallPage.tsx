import { useInstallPrompt } from '@/hooks/useInstallPrompt';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, Smartphone, CheckCircle, Share, PlusSquare, MoreVertical, AlertTriangle, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Alert, AlertDescription } from '@/components/ui/alert';

const InstallPage = () => {
  const { isInstallable, isInstalled, isIOS, isAndroid, isSafari, isChromeiOS, promptInstall } = useInstallPrompt();
  const navigate = useNavigate();

  const handleInstall = async () => {
    const success = await promptInstall();
    if (success) {
      navigate('/');
    }
  };

  if (isInstalled) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            <CardTitle className="text-2xl">¡App Instalada!</CardTitle>
            <CardDescription>
              vrtelolleva ya está instalada en tu dispositivo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Puedes acceder a la app desde tu pantalla de inicio para una experiencia más rápida y fluida.
            </p>
            <Button onClick={() => navigate('/')} className="w-full">
              Ir a la App
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 h-20 w-20 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Smartphone className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-2xl">Instalar vrtelolleva</CardTitle>
          <CardDescription>
            Instala nuestra app para una mejor experiencia
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Download className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Acceso rápido</p>
                <p className="text-sm text-muted-foreground">Abre la app directamente desde tu pantalla de inicio</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Smartphone className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Funciona sin conexión</p>
                <p className="text-sm text-muted-foreground">Accede a funciones básicas sin internet</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Notificaciones</p>
                <p className="text-sm text-muted-foreground">Recibe alertas de tus pedidos en tiempo real</p>
              </div>
            </div>
          </div>

          {isInstallable && (
            <Button onClick={handleInstall} className="w-full" size="lg">
              <Download className="mr-2 h-5 w-5" />
              Instalar App
            </Button>
          )}

          {/* Advertencia si está en Chrome/Firefox iOS */}
          {isIOS && isChromeiOS && (
            <Alert className="border-amber-500/50 bg-amber-500/10">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              <AlertDescription className="text-amber-200">
                <p className="font-medium mb-2">Estás usando Chrome en iOS</p>
                <p className="text-sm">
                  Para instalar la app, debes abrir esta página en <span className="font-bold">Safari</span>. 
                  Copia la URL y ábrela en Safari.
                </p>
              </AlertDescription>
            </Alert>
          )}

          {isIOS && !isInstallable && (
            <div className="space-y-4 p-4 bg-muted rounded-lg">
              <p className="font-medium text-center">
                {isChromeiOS ? 'Abre en Safari y luego:' : 'Cómo instalar en iPhone/iPad:'}
              </p>
              
              {/* Animación visual del botón Compartir */}
              <div className="flex justify-center py-4">
                <div className="relative">
                  <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg animate-pulse">
                    <Share className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                    <div className="animate-bounce">
                      <span className="text-2xl">👆</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <ol className="space-y-3 text-sm">
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">1</span>
                  <span className="flex items-center gap-1 flex-wrap">
                    Busca el botón <Share className="h-4 w-4 inline text-blue-400" /> <strong>Compartir</strong> en la barra inferior de Safari
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">2</span>
                  <span>Desplázate hacia abajo en el menú que aparece</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">3</span>
                  <span className="flex items-center gap-1 flex-wrap">
                    Toca <PlusSquare className="h-4 w-4 inline text-gray-400" /> <strong>"Agregar a pantalla de inicio"</strong>
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">4</span>
                  <span>Toca <strong>"Agregar"</strong> en la esquina superior derecha</span>
                </li>
              </ol>
              
              <div className="mt-4 p-3 bg-primary/10 rounded-lg text-center">
                <p className="text-xs text-muted-foreground">
                  💡 La app aparecerá en tu pantalla de inicio como un ícono normal
                </p>
              </div>
            </div>
          )}

          {isAndroid && !isInstallable && (
            <div className="space-y-4 p-4 bg-muted rounded-lg">
              <p className="font-medium text-center">Cómo instalar en Android:</p>
              <ol className="space-y-3 text-sm">
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">1</span>
                  <span className="flex items-center gap-1">
                    Toca el menú <MoreVertical className="h-4 w-4 inline" /> en Chrome
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">2</span>
                  <span>Selecciona "Instalar app" o "Agregar a pantalla de inicio"</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">3</span>
                  <span>Confirma la instalación</span>
                </li>
              </ol>
            </div>
          )}

          {!isIOS && !isAndroid && !isInstallable && (
            <div className="p-4 bg-muted rounded-lg text-center">
              <p className="text-sm text-muted-foreground">
                Abre esta página en Chrome, Edge o Safari en tu dispositivo móvil para instalar la app.
              </p>
            </div>
          )}

          <Button variant="outline" onClick={() => navigate('/')} className="w-full">
            Continuar en el navegador
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default InstallPage;
