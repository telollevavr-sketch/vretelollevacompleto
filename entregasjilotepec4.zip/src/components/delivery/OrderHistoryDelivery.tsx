import { useState } from 'react';
import { Order, OrderStatus } from '@/types';
import { useOrders } from '@/hooks/useOrders';
import { useBusinesses } from '@/hooks/useBusinesses';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Package, MapPin, DollarSign, Calendar, Navigation } from 'lucide-react';
import { OrderDetailsModal } from './OrderDetailsModal';

interface OrderHistoryDeliveryProps {
  deliveryPersonId: string;
}

export const OrderHistoryDelivery = ({ deliveryPersonId }: OrderHistoryDeliveryProps) => {
  const { orders } = useOrders(deliveryPersonId, 'delivery');
  const { businesses } = useBusinesses();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const getStatusBadge = (status: OrderStatus) => {
    const statusConfig = {
      [OrderStatus.PENDING]: { label: '⏳ Pendiente', variant: 'secondary' as const, className: 'bg-yellow-500 text-white' },
      [OrderStatus.IN_PREPARATION]: { label: '👨‍🍳 En Preparación', variant: 'default' as const, className: 'bg-blue-500 text-white' },
      [OrderStatus.READY_FOR_PICKUP]: { label: '📦 Listo', variant: 'default' as const, className: 'bg-green-500 text-white' },
      [OrderStatus.ON_THE_WAY]: { label: '🚴 En Camino', variant: 'default' as const, className: 'bg-purple-500 text-white' },
      [OrderStatus.DELIVERED]: { label: '✅ Entregado', variant: 'default' as const, className: 'bg-green-600 text-white' },
      [OrderStatus.CANCELLED]: { label: '❌ Cancelado', variant: 'destructive' as const, className: 'bg-red-600 text-white' }
    };
    const config = statusConfig[status];
    return <Badge variant={config.variant} className={config.className}>{config.label}</Badge>;
  };

  const openGoogleMaps = (order: Order) => {
    const { lat, lng } = order.deliveryLocation;
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, '_blank');
  };

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setDetailsOpen(true);
  };

  const totalEarnings = orders
    .filter(o => o.status === OrderStatus.DELIVERED)
    .reduce((sum, o) => sum + o.deliveryFee, 0);

  const deliveredCount = orders.filter(o => o.status === OrderStatus.DELIVERED).length;

  return (
    <>
      <Card className="bg-[hsl(0,50%,85%)]/80 border-black/20 shadow-lg backdrop-blur-sm">
        <CardHeader className="bg-[hsl(0,50%,80%)]/60">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-black">
              <Package className="h-5 w-5 text-orange-600" />
              Historial de Entregas
            </CardTitle>
            <div className="text-right">
              <p className="text-2xl font-bold text-black">${totalEarnings.toFixed(2)}</p>
              <p className="text-xs text-black/60">{deliveredCount} entregas completadas</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {orders.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-block p-6 bg-white/60 rounded-full mb-4 border border-black/20">
                <Package className="h-12 w-12 text-black/60" />
              </div>
              <p className="text-lg text-black font-medium">
                No tienes entregas aún
              </p>
              <p className="text-sm text-black/60 mt-2">
                Tu historial aparecerá aquí
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map(order => {
                const business = businesses.find(b => b.id === order.businessId);
                
                return (
                  <Card key={order.id} className="bg-[hsl(0,50%,90%)]/80 border-black/20 hover:border-black/40 transition-all backdrop-blur-sm">
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-bold text-black">Pedido #{order.id.slice(0, 8)}</p>
                            {getStatusBadge(order.status)}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-black/60">
                            <Calendar className="h-3 w-3" />
                            {new Date(order.createdAt).toLocaleDateString('es-MX', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-600">
                            ${order.deliveryFee.toFixed(2)}
                          </p>
                          <p className="text-xs text-black/60">Tu ganancia</p>
                        </div>
                      </div>

                      <div className="space-y-2 mb-3">
                        <div className="flex items-center gap-2 text-sm p-2 bg-white/60 rounded border border-black/10">
                          <Package className="h-4 w-4 text-green-600" />
                          <span className="font-medium text-black">{business?.name}</span>
                        </div>
                        <div className="flex items-start gap-2 text-sm p-2 bg-white/60 rounded border border-black/10">
                          <MapPin className="h-4 w-4 text-blue-600 mt-0.5" />
                          <span className="text-black/60 flex-1">
                            {order.deliveryLocation.address || 
                              `${order.deliveryLocation.lat.toFixed(4)}, ${order.deliveryLocation.lng.toFixed(4)}`}
                          </span>
                        </div>
                        <div className="p-2 bg-white/60 rounded border border-black/10 space-y-1">
                          <div className="flex justify-between text-xs text-black/60">
                            <span>Subtotal:</span>
                            <span>${order.subtotal.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-xs text-black/60">
                            <span>Costo de envío:</span>
                            <span>${order.deliveryFee.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-sm font-bold text-black pt-1 border-t border-black/10">
                            <span>Total:</span>
                            <span>${order.total.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 bg-white text-black border-black/20 hover:bg-black/5"
                          onClick={() => handleViewDetails(order)}
                        >
                          Ver Detalles
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openGoogleMaps(order)}
                          className="bg-white text-black border-black/20 hover:bg-black/5"
                        >
                          <Navigation className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <OrderDetailsModal
        order={selectedOrder}
        open={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        deliveryPersonId={deliveryPersonId}
      />
    </>
  );
};