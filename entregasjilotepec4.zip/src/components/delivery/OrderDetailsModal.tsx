import { useState, useEffect } from 'react';
import { Order } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package, MapPin, Store, DollarSign, Phone, Navigation } from 'lucide-react';
import { useBusinesses } from '@/hooks/useBusinesses';
import { Button } from '@/components/ui/button';
import { OrderMessages } from '@/components/shared/OrderMessages';
import { OrderItemDetails } from '@/components/shared/OrderItemDetails';

interface OrderDetailsModalProps {
  order: Order | null;
  open: boolean;
  onClose: () => void;
  deliveryPersonId?: string;
}

export const OrderDetailsModal = ({ order, open, onClose, deliveryPersonId }: OrderDetailsModalProps) => {
  const { businesses } = useBusinesses();
  const [currentOrder, setCurrentOrder] = useState<Order | null>(order);

  useEffect(() => {
    setCurrentOrder(order);
  }, [order]);

  if (!currentOrder) return null;

  const business = businesses.find(b => b.id === currentOrder.businessId);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      PENDING: { label: '⏳ Pendiente', variant: 'secondary' as const, className: 'bg-yellow-500 text-white' },
      IN_PREPARATION: { label: '👨‍🍳 En Preparación', variant: 'default' as const, className: 'bg-blue-500 text-white' },
      READY_FOR_PICKUP: { label: '📦 Listo para Recoger', variant: 'default' as const, className: 'bg-green-500 text-white' },
      ON_THE_WAY: { label: '🚴 En Camino', variant: 'default' as const, className: 'bg-purple-500 text-white' },
      DELIVERED: { label: '✅ Entregado', variant: 'default' as const, className: 'bg-green-600 text-white' },
      CANCELLED: { label: '❌ Cancelado', variant: 'destructive' as const, className: 'bg-red-600 text-white' }
    };
    const config = statusConfig[status as keyof typeof statusConfig];
    return <Badge variant={config.variant} className={config.className}>{config.label}</Badge>;
  };

  const openGoogleMaps = () => {
    const { lat, lng } = currentOrder.deliveryLocation;
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, '_blank');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[hsl(0,50%,85%)]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between text-black">
            <span>Detalles del Pedido #{currentOrder.id.slice(0, 8)}</span>
            {getStatusBadge(currentOrder.status)}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-4">
          {/* Business Info */}
          {business && (
            <div className="space-y-3">
              <h3 className="font-semibold flex items-center gap-2 text-black">
                <Store className="h-5 w-5 text-green-600" />
                Negocio
              </h3>
              <div className="bg-white/60 p-4 rounded-lg space-y-2 border border-black/20">
                <p className="font-semibold text-black">{business.name}</p>
                <p className="text-sm text-black/60 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  {business.fullAddress || business.address}
                </p>
                {business.phone && (
                  <p className="text-sm text-black/60 flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    {business.phone}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Delivery Location */}
          <div className="space-y-3">
            <h3 className="font-semibold flex items-center gap-2 text-black">
              <MapPin className="h-5 w-5 text-blue-600" />
              Dirección de Entrega
            </h3>
            <div className="bg-white/60 p-4 rounded-lg space-y-3 border border-black/20">
              <p className="text-sm text-black">
                {currentOrder.deliveryLocation.address || 
                  `${currentOrder.deliveryLocation.lat.toFixed(4)}, ${currentOrder.deliveryLocation.lng.toFixed(4)}`}
              </p>
              <Button
                onClick={openGoogleMaps}
                variant="outline"
                size="sm"
                className="w-full bg-white text-black border-black/20 hover:bg-black/5"
              >
                <Navigation className="h-4 w-4 mr-2" />
                Abrir en Google Maps
              </Button>
            </div>
          </div>

          {/* Order Items */}
          <div className="space-y-3">
            <h3 className="font-semibold flex items-center gap-2 text-black">
              <Package className="h-5 w-5 text-orange-600" />
              Artículos ({currentOrder.items.length})
            </h3>
            <div className="space-y-3">
              {currentOrder.items.map((item, index) => {
                console.log('🔍 [DeliveryOrderDetails] Rendering item:', {
                  name: item.product.name,
                  hasComplements: !!item.selectedComplements,
                  complementsCount: item.selectedComplements?.length || 0,
                  complements: item.selectedComplements
                });
                return (
                  <div key={index} className="bg-white/60 p-3 rounded-lg border border-black/20">
                    <OrderItemDetails
                      item={item}
                      index={index}
                      showPrice={true}
                      compact={false}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          <Separator className="bg-black/20" />

          {/* Payment Summary */}
          <div className="space-y-3">
            <h3 className="font-semibold flex items-center gap-2 text-black">
              <DollarSign className="h-5 w-5 text-purple-600" />
              Resumen de Pago
            </h3>
            <div className="bg-white/60 p-4 rounded-lg space-y-2 border border-black/20">
              <div className="flex justify-between text-sm text-black">
                <span>Subtotal:</span>
                <span>${currentOrder.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-black">
                <span>Costo de Envío:</span>
                <span className="font-semibold">${currentOrder.deliveryFee.toFixed(2)}</span>
              </div>
              <Separator className="bg-black/20" />
              <div className="flex justify-between font-bold text-lg text-black">
                <span>Total a Cobrar:</span>
                <span>${currentOrder.total.toFixed(2)}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-black/60 pt-2 border-t border-black/10">
                <span>Método de pago:</span>
                <span className="font-medium">
                  {currentOrder.paymentMethod === 'CASH' ? '💵 Efectivo' : '💳 Transferencia'}
                </span>
              </div>
            </div>
          </div>

          {/* Notes */}
          {currentOrder.notes && (
            <div className="space-y-2">
              <h3 className="font-semibold text-black">Notas Especiales</h3>
              <div className="bg-white/60 p-4 rounded-lg border border-black/20">
                <p className="text-sm text-black">{currentOrder.notes}</p>
              </div>
            </div>
          )}

          {/* Earnings */}
          {currentOrder.status === 'DELIVERED' && (
            <div className="bg-green-500/20 p-4 rounded-lg border border-green-600">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-black">Tu Ganancia:</span>
                <span className="text-2xl font-bold text-green-600">
                  ${currentOrder.deliveryFee.toFixed(2)}
                </span>
              </div>
            </div>
          )}

          {/* Messages Section - Prominently displayed */}
          {deliveryPersonId && (currentOrder.status === 'READY_FOR_PICKUP' || currentOrder.status === 'ON_THE_WAY') && (
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 p-6 rounded-xl border-2 border-blue-200 dark:border-blue-800 shadow-lg">
              <OrderMessages
                order={currentOrder}
                currentUserId={deliveryPersonId}
                currentUserRole="DELIVERY"
                onOrderUpdate={setCurrentOrder}
              />
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};