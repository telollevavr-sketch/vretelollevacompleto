import { useState, useEffect } from 'react';
import { User, Location } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User as UserIcon, Phone, MapPin, Bike, Upload, FileText, Edit2, Save, X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { LocationPicker } from '@/components/shared/LocationPicker';
import { Separator } from '@/components/ui/separator';

interface DeliveryProfileProps {
  user: User;
  onUpdate: (user: User) => void;
}

export const DeliveryProfile = ({ user, onUpdate }: DeliveryProfileProps) => {
  const { updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    phone: user.phone || '',
    address: user.address || '',
    vehicleType: user.vehicleType || '',
    vehiclePlate: user.vehiclePlate || '',
    profileImage: user.profileImage || ''
  });
  const [location, setLocation] = useState<Location>(
    user.location || { lat: 19.4326, lng: -99.1332 }
  );

  // Sync state with props when user changes (only when NOT actively editing)
  useEffect(() => {
    if (!isEditing) {
      setFormData({
        name: user.name,
        phone: user.phone || '',
        address: user.address || '',
        vehicleType: user.vehicleType || '',
        vehiclePlate: user.vehiclePlate || '',
        profileImage: user.profileImage || ''
      });
      setLocation(user.location || { lat: 19.4326, lng: -99.1332 });
    }
  }, [user, isEditing]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'Error',
          description: 'La imagen no debe superar los 5MB',
          variant: 'destructive'
        });
        return;
      }

      try {
        const { compressImage, formatFileSize } = await import('@/lib/imageCompression');
        
        toast({
          title: 'Procesando imagen...',
          description: 'Comprimiendo y optimizando la imagen'
        });

        const { base64, originalSize, compressedSize } = await compressImage(file, {
          maxWidth: 1024,
          maxHeight: 1024,
          maxSizeKB: 250
        });

        setFormData({ ...formData, profileImage: base64 });

        toast({
          title: 'Imagen Optimizada',
          description: `Tamaño original: ${formatFileSize(originalSize)} → Optimizado: ${formatFileSize(compressedSize)}`
        });
      } catch (error) {
        toast({
          title: 'Error',
          description: 'No se pudo procesar la imagen',
          variant: 'destructive'
        });
      }
    }
  };

  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: 'Error',
          description: 'El documento no debe superar los 10MB',
          variant: 'destructive'
        });
        return;
      }

      // Si es una imagen, comprimirla
      if (file.type.startsWith('image/')) {
        try {
          const { compressImage, formatFileSize } = await import('@/lib/imageCompression');
          
          toast({
            title: 'Procesando documento...',
            description: 'Comprimiendo y optimizando la imagen'
          });

          const { base64, originalSize, compressedSize } = await compressImage(file, {
            maxWidth: 1024,
            maxHeight: 1024,
            maxSizeKB: 250
          });

          toast({
            title: 'Documento Optimizado',
            description: `Tamaño original: ${formatFileSize(originalSize)} → Optimizado: ${formatFileSize(compressedSize)}`
          });
        } catch (error) {
          toast({
            title: 'Error',
            description: 'No se pudo procesar el documento',
            variant: 'destructive'
          });
        }
      } else {
        // Para PDFs y otros archivos, solo mostrar mensaje
        toast({
          title: 'Documento Subido',
          description: 'El documento ha sido guardado correctamente'
        });
      }
    }
  };

  const handleSaveProfile = async () => {
    if (!formData.name.trim()) {
      toast({
        title: 'Error',
        description: 'El nombre es obligatorio',
        variant: 'destructive'
      });
      return;
    }

    console.log('Guardando ubicación:', { lat: location.lat, lng: location.lng });

    try {
      await updateProfile({
        name: formData.name,
        phone: formData.phone,
        address: formData.address,
        vehicle_type: formData.vehicleType,
        vehicle_plate: formData.vehiclePlate,
        latitude: location.lat,
        longitude: location.lng
      });

      console.log('Perfil actualizado con coordenadas:', { lat: location.lat, lng: location.lng });

      setIsEditing(false);
      toast({
        title: 'Perfil Actualizado',
        description: 'Tu información y ubicación base han sido guardadas correctamente'
      });
    } catch (error) {
      console.error('Error al actualizar perfil:', error);
      toast({
        title: 'Error',
        description: 'No se pudo actualizar el perfil',
        variant: 'destructive'
      });
    }
  };

  const handleCancel = () => {
    setFormData({
      name: user.name,
      phone: user.phone || '',
      address: user.address || '',
      vehicleType: user.vehicleType || '',
      vehiclePlate: user.vehiclePlate || '',
      profileImage: user.profileImage || ''
    });
    setLocation(user.location || { lat: 19.4326, lng: -99.1332 });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white">Mi Perfil</h2>
          <p className="text-white/70 mt-1">Administra tu información de repartidor</p>
        </div>
      </div>

      <Card className="shadow-sm bg-[hsl(0,50%,85%)]/80 border-black/20 backdrop-blur-sm">
        <CardHeader className="bg-[hsl(0,50%,80%)]/60">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-black">
                <UserIcon className="h-5 w-5 text-black" />
                Información Personal
              </CardTitle>
              <CardDescription className="mt-2 text-black/60">
                Actualiza tus datos personales, vehículo y ubicación base
              </CardDescription>
            </div>
            {!isEditing && (
              <Button onClick={() => setIsEditing(true)} variant="outline" size="sm" className="bg-white text-black border-black/20 hover:bg-black/5">
                <Edit2 className="h-4 w-4 mr-2" />
                Editar
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Profile Image */}
          <div className="flex flex-col items-center gap-4">
            <Avatar className="h-32 w-32 border-4 border-black/20 shadow-lg">
              <AvatarImage src={formData.profileImage} />
              <AvatarFallback className="text-3xl font-semibold bg-orange-500 text-white">
                {formData.name.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            {isEditing && (
              <div className="flex flex-col items-center gap-2">
                <Label htmlFor="profile-image" className="cursor-pointer">
                  <Button variant="outline" size="sm" asChild>
                    <span>
                      <Upload className="h-4 w-4 mr-2" />
                      Cambiar Foto
                    </span>
                  </Button>
                </Label>
                <Input
                  id="profile-image"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
                <p className="text-xs text-muted-foreground">Máximo 5MB</p>
              </div>
            )}
          </div>

          <Separator />

          {/* Personal Info */}
          {!isEditing ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-black/60">
                    <UserIcon className="h-4 w-4" />
                    <span>Nombre Completo</span>
                  </div>
                  <p className="font-medium text-lg text-black">{user.name}</p>
                </div>

                {user.phone && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-black/60">
                      <Phone className="h-4 w-4" />
                      <span>Teléfono</span>
                    </div>
                    <p className="font-medium text-lg text-black">{user.phone}</p>
                  </div>
                )}

                {user.address && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-black/60">
                      <MapPin className="h-4 w-4" />
                      <span>Dirección</span>
                    </div>
                    <p className="font-medium text-lg text-black">{user.address}</p>
                  </div>
                )}

                {user.vehicleType && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-black/60">
                      <Bike className="h-4 w-4" />
                      <span>Tipo de Vehículo</span>
                    </div>
                    <p className="font-medium text-lg text-black">{user.vehicleType}</p>
                  </div>
                )}

                {user.vehiclePlate && (
                  <div className="space-y-2">
                    <Label className="text-black/60">Placas del Vehículo</Label>
                    <p className="font-medium text-lg font-mono text-black">{user.vehiclePlate}</p>
                  </div>
                )}
              </div>

              {user.location && (
                <>
                  <Separator className="bg-black/20" />
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-black/60">
                      <MapPin className="h-4 w-4" />
                      <span>Ubicación Base</span>
                    </div>
                    <div className="p-4 bg-white/60 rounded-lg space-y-1 border border-black/20">
                      <p className="text-sm font-mono text-black">
                        {user.location.lat.toFixed(6)}, {user.location.lng.toFixed(6)}
                      </p>
                      {user.location.address && (
                        <p className="text-sm text-black/60">{user.location.address}</p>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    Nombre Completo <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Tu nombre completo"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="5512345678"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Tu dirección"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vehicleType">Tipo de Vehículo</Label>
                  <Input
                    id="vehicleType"
                    value={formData.vehicleType}
                    onChange={(e) => setFormData({ ...formData, vehicleType: e.target.value })}
                    placeholder="Ej: Motocicleta, Bicicleta, Auto"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vehiclePlate">Placas del Vehículo</Label>
                  <Input
                    id="vehiclePlate"
                    value={formData.vehiclePlate}
                    onChange={(e) => setFormData({ ...formData, vehiclePlate: e.target.value })}
                    placeholder="ABC-123"
                  />
                </div>
              </div>

              <Separator className="bg-black/20" />

              <div className="space-y-3">
                <Label className="text-base font-semibold text-black">Ubicación Base</Label>
                <p className="text-sm text-black/60">
                  Selecciona tu ubicación base en el mapa o usa el botón para obtener tu ubicación actual
                </p>
                <LocationPicker
                  location={location}
                  onLocationChange={setLocation}
                />
              </div>
            </div>
          )}

          {/* Documents */}
          <Separator className="bg-black/20" />
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="flex items-center gap-2 text-base font-semibold text-black">
                  <FileText className="h-5 w-5 text-black" />
                  Documentos ({user.documents?.length || 0})
                </Label>
                <p className="text-sm text-black/60 mt-1">
                  Sube documentos como licencia, INE, etc.
                </p>
              </div>
              <Label htmlFor="document-upload" className="cursor-pointer">
                <Button variant="outline" size="sm" asChild className="bg-white text-black border-black/20 hover:bg-black/5">
                  <span>
                    <Upload className="h-4 w-4 mr-2" />
                    Subir Documento
                  </span>
                </Button>
              </Label>
              <Input
                id="document-upload"
                type="file"
                accept="image/*,.pdf"
                className="hidden"
                onChange={handleDocumentUpload}
              />
            </div>
            {user.documents && user.documents.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {user.documents.map((doc, index) => (
                  <div key={index} className="relative aspect-video bg-white/60 rounded-lg overflow-hidden border border-black/20 shadow-sm">
                    {doc.startsWith('data:image') ? (
                      <img src={doc} alt={`Documento ${index + 1}`} className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <FileText className="h-12 w-12 text-black/60" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center border-2 border-dashed rounded-lg border-black/20">
                <FileText className="h-12 w-12 text-black/60 mx-auto mb-3" />
                <p className="text-sm text-black/60">No hay documentos subidos</p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          {isEditing && (
            <>
              <Separator className="bg-black/20" />
              <div className="flex gap-3 justify-end">
                <Button type="button" variant="outline" onClick={handleCancel} className="bg-white text-black border-black/20 hover:bg-black/5">
                  <X className="h-4 w-4 mr-2" />
                  Cancelar
                </Button>
                <Button onClick={handleSaveProfile} className="bg-green-600 hover:bg-green-700 text-white">
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Cambios
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};