import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Order } from '@/types';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { StatCard } from '@/components/shared/StatCard';
import { DollarSign, Package, Clock, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { DateRange } from 'react-day-picker';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { isSameDay, isWithinInterval, startOfDay, endOfDay } from 'date-fns';

interface DeliveryStatsProps {
  orders: Order[];
  deliveryPersonId: string;
}

export const DeliveryStats = ({ orders, deliveryPersonId }: DeliveryStatsProps) => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>(() => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 7);
    return { from, to };
  });

  // Quick date filters
  const setQuickRange = (days: number) => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - days);
    setDateRange({ from, to });
  };

  // Filter orders by date range and delivery person
  const filterByDateRange = (order: Order) => {
    if (order.deliveryPersonId !== deliveryPersonId || order.status !== 'DELIVERED') return false;
    if (!dateRange?.from) return true;
    
    const orderDate = new Date(order.createdAt);
    const from = startOfDay(dateRange.from);
    const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
    
    return isWithinInterval(orderDate, { start: from, end: to });
  };

  const myOrders = orders.filter(filterByDateRange);
  const totalEarnings = myOrders.reduce((sum, o) => sum + (o.deliveryFee || 0), 0);
  const totalDeliveries = myOrders.length;

  // Calculate acceptance rate
  const allMyOrders = orders.filter(o => o.deliveryPersonId === deliveryPersonId);
  const acceptedOrders = allMyOrders.length;
  const completedOrders = allMyOrders.filter(o => o.status === 'DELIVERED').length;
  const acceptanceRate = acceptedOrders > 0 ? (completedOrders / acceptedOrders * 100) : 0;

  // Average delivery time (simulated - in real app would calculate from timestamps)
  const avgDeliveryTime = 28; // minutes

  // Earnings trend
  const earningsData = (() => {
    if (!dateRange?.from) return [];
    
    const from = startOfDay(dateRange.from);
    const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
    const diffTime = Math.abs(to.getTime() - from.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return Array.from({ length: Math.min(diffDays + 1, 30) }, (_, i) => {
      const date = new Date(from);
      date.setDate(date.getDate() + i);
      const dayOrders = myOrders.filter(o => isSameDay(new Date(o.createdAt), date));
      const earnings = dayOrders.reduce((sum, o) => sum + (o.deliveryFee || 0), 0);
      return {
        time: date.toLocaleDateString('es-MX', { day: '2-digit', month: 'short' }),
        ganancias: parseFloat(earnings.toFixed(2)),
        entregas: dayOrders.length
      };
    });
  })();

  // Peak hours
  const hourlyDeliveries = Array.from({ length: 24 }, (_, hour) => {
    const hourOrders = allMyOrders.filter(o => new Date(o.createdAt).getHours() === hour);
    return {
      hora: `${hour}:00`,
      entregas: hourOrders.length
    };
  }).filter(h => h.entregas > 0);

  return (
    <div className="space-y-6">
      {/* Date Range Selector */}
      <Card className="border-gray-200 bg-white">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setQuickRange(0)}>
                Hoy
              </Button>
              <Button variant="outline" size="sm" onClick={() => setQuickRange(7)}>
                7 días
              </Button>
              <Button variant="outline" size="sm" onClick={() => setQuickRange(30)}>
                30 días
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Ganancias"
          value={`$${totalEarnings.toFixed(2)}`}
          icon={DollarSign}
          description="Total generado"
          variant="green"
        />
        <StatCard
          title="Entregas"
          value={totalDeliveries}
          icon={Package}
          description="Completadas"
          variant="blue"
        />
        <StatCard
          title="Ganancia Promedio"
          value={`$${totalDeliveries > 0 ? (totalEarnings / totalDeliveries).toFixed(2) : '0.00'}`}
          icon={TrendingUp}
          description="Por entrega"
          variant="orange"
        />
        <StatCard
          title="Tiempo Promedio"
          value={`${avgDeliveryTime} min`}
          icon={Clock}
          description="Por entrega"
          variant="cyan"
        />
      </div>

      {/* Performance Card */}
      <Card className="border-gray-200 bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900">
            🎯 Rendimiento
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Tasa de Finalización</span>
              <span className="text-sm font-bold text-primary">{acceptanceRate.toFixed(1)}%</span>
            </div>
            <Progress value={acceptanceRate} className="h-3" />
            <p className="text-xs text-gray-600 mt-1">
              {completedOrders} de {acceptedOrders} entregas completadas
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-900">{completedOrders}</p>
              <p className="text-xs text-gray-600 mt-1">Entregas Totales</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-900">{allMyOrders.filter(o => o.status === 'CANCELLED').length}</p>
              <p className="text-xs text-gray-600 mt-1">Canceladas</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Earnings Trend */}
      <Card className="border-gray-200 bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900">
            💰 Tendencia de Ganancias
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={earningsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="time" 
                stroke="hsl(var(--muted-foreground))"
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="ganancias" 
                stroke="hsl(var(--icon-green))" 
                strokeWidth={3}
                dot={false}
                name="Ganancias ($)"
              />
              <Line 
                type="monotone" 
                dataKey="entregas" 
                stroke="hsl(var(--icon-blue))" 
                strokeWidth={3}
                dot={false}
                name="Entregas (#)"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Peak Hours */}
      {hourlyDeliveries.length > 0 && (
        <Card className="border-gray-200 bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900">
              🕐 Horas Pico de Entregas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={hourlyDeliveries}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="hora" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar 
                  dataKey="entregas" 
                  fill="hsl(var(--icon-cyan))" 
                  radius={[8, 8, 0, 0]}
                  name="Entregas"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
