import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserRole } from "@/types";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { User, Store, Bike, CheckCircle, ArrowLeft, MessageCircle, Copy, Check, Loader2 } from "lucide-react";

const PENDING_MODAL_KEY = 'showPendingApprovalModal';

type ModalView = "login" | "register" | "forgot" | "whatsapp-recovery";

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  redirectTo?: string;
}

export const AuthModal = ({ open, onClose, redirectTo }: AuthModalProps) => {
  const { signIn, signUp, signOut, resetPassword } = useAuth();
  const navigate = useNavigate();
  const [view, setView] = useState<ModalView>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [recoveryPhone, setRecoveryPhone] = useState("");
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  // Verificar si hay un modal pendiente de mostrar - usa estado inicial
  const [showPendingModal, setShowPendingModal] = useState(() => {
    const shouldShow = sessionStorage.getItem(PENDING_MODAL_KEY) === 'true';
    if (shouldShow) {
      sessionStorage.removeItem(PENDING_MODAL_KEY);
    }
    return shouldShow;
  });

  // También verificar en cada render cuando el modal está abierto
  useEffect(() => {
    if (open) {
      const shouldShowModal = sessionStorage.getItem(PENDING_MODAL_KEY);
      if (shouldShowModal === 'true') {
        sessionStorage.removeItem(PENDING_MODAL_KEY);
        setShowPendingModal(true);
      }
    }
  }, [open]);

  const roles = [
    { value: UserRole.CLIENT, label: "Cliente", icon: User },
    { value: UserRole.BUSINESS, label: "Negocio", icon: Store },
    { value: UserRole.DELIVERY, label: "Repartidor", icon: Bike },
  ];

  const handleLogin = async () => {
    if (!email || !password) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error, isInactive } = await signIn(email, password);

      if (error) {
        toast({
          title: isInactive ? "Cuenta pendiente de validación" : "Error al iniciar sesión",
          description: error.message || "Credenciales inválidas",
          variant: isInactive ? "default" : "destructive",
        });
        return;
      }

      toast({
        title: "Bienvenido",
        description: "Has iniciado sesión correctamente",
      });
      onClose();
      // Dar tiempo para que el contexto cargue el rol del usuario
      setTimeout(() => navigate(redirectTo || "/"), 500);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!email || !password || !name || !selectedRole || !phone.trim()) {
      toast({
        title: "Error",
        description: !phone.trim() 
          ? "El número de teléfono es obligatorio para recuperar tu cuenta"
          : "Por favor completa todos los campos y selecciona un rol",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const role = selectedRole.toLowerCase() as "client" | "business" | "delivery" | "admin";
      const { error, requiresValidation } = await signUp(email, password, name, role, phone || undefined);

      if (error) {
        toast({
          title: "Error al registrarse",
          description: error.message || "No se pudo crear la cuenta",
          variant: "destructive",
        });
        return;
      }

      // Si es business o delivery, mostrar modal de éxito y hacer signOut
      if (requiresValidation) {
        // Primero cerrar el dialog principal
        onClose();
        // Hacer signOut
        await signOut();
        // Mostrar el modal de éxito inmediatamente
        setShowPendingModal(true);
        return;
      }

      toast({
        title: "¡Cuenta creada!",
        description: "Tu cuenta ha sido creada exitosamente. Iniciando sesión...",
      });

      // Auto login after successful registration (solo para clientes)
      const { error: loginError } = await signIn(email, password);
      if (!loginError) {
        onClose();
        setTimeout(() => navigate(redirectTo || "/"), 500);
      } else {
        // If auto-login fails, switch to login mode
        setView("login");
        resetForm();
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      toast({
        title: "Error",
        description: "Por favor ingresa tu correo electrónico",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await resetPassword(email);

      if (error) {
        toast({
          title: "Error",
          description: error.message || "No se pudo enviar el correo de recuperación",
          variant: "destructive",
        });
        return;
      }

      setEmailSent(true);
      toast({
        title: "Correo enviado",
        description: "Se ha enviado un enlace de recuperación a tu correo electrónico.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEmail("");
    setPassword("");
    setName("");
    setPhone("");
    setRecoveryPhone("");
    setTempPassword(null);
    setCopied(false);
    setSelectedRole(null);
    setEmailSent(false);
  };

  const switchToLogin = () => {
    setView("login");
    resetForm();
  };

  const switchToRegister = () => {
    setView("register");
    resetForm();
  };

  const switchToForgot = () => {
    setView("forgot");
    setPassword("");
    setEmailSent(false);
  };

  const switchToWhatsAppRecovery = () => {
    setView("whatsapp-recovery");
    setRecoveryPhone("");
    setTempPassword(null);
    setCopied(false);
  };

  const handleWhatsAppRecovery = async () => {
    if (!recoveryPhone) {
      toast({
        title: "Error",
        description: "Por favor ingresa tu número de teléfono",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-temp-password', {
        body: { phone: recoveryPhone },
      });

      if (error) {
        toast({
          title: "Error",
          description: error.message || "No se pudo generar la contraseña temporal",
          variant: "destructive",
        });
        return;
      }

      if (data.error) {
        toast({
          title: "Error",
          description: data.error,
          variant: "destructive",
        });
        return;
      }

      setTempPassword(data.tempPassword);
      toast({
        title: "¡Contraseña generada!",
        description: "Tu nueva contraseña temporal ha sido creada",
      });
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "Error inesperado";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCopyPassword = async () => {
    if (!tempPassword) return;
    
    try {
      await navigator.clipboard.writeText(tempPassword);
      setCopied(true);
      toast({
        title: "Copiado",
        description: "Contraseña copiada al portapapeles",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({
        title: "Error",
        description: "No se pudo copiar al portapapeles",
        variant: "destructive",
      });
    }
  };

  const handleSendWhatsApp = () => {
    if (!tempPassword) return;
    
    const message = encodeURIComponent(
      `¡Hola! Tu nueva contraseña temporal para VRTELoLleva es: ${tempPassword}\n\nPor tu seguridad, te recomendamos cambiar esta contraseña después de iniciar sesión.\n\n- Equipo VRTELoLleva`
    );
    
    // Clean phone number
    const cleanPhone = recoveryPhone.replace(/[\s\-\(\)+]/g, '');
    const phoneWithCountry = cleanPhone.startsWith('52') ? cleanPhone : `52${cleanPhone}`;
    
    window.open(`https://wa.me/${phoneWithCountry}?text=${message}`, '_blank');
  };

  const handleClosePendingModal = () => {
    sessionStorage.removeItem(PENDING_MODAL_KEY);
    setShowPendingModal(false);
    resetForm();
    onClose();
    navigate("/home");
  };

  const getTitle = () => {
    switch (view) {
      case "login":
        return "Iniciar Sesión";
      case "register":
        return "Crear Cuenta";
      case "forgot":
        return "Recuperar Contraseña";
      case "whatsapp-recovery":
        return "Recuperar por WhatsApp";
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md bg-[hsl(270,50%,25%)] border-[hsl(270,60%,40%)]">
          <DialogHeader>
            <DialogTitle className="text-2xl text-white text-center">
              {getTitle()}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            {/* Vista de recuperación de contraseña */}
            {view === "forgot" && (
              <>
                {emailSent ? (
                  <div className="space-y-4">
                    <div className="p-4 bg-green-500/20 rounded-xl text-center">
                      <p className="text-green-300">
                        ¡Correo enviado! Revisa tu bandeja de entrada y sigue las instrucciones para restablecer tu contraseña.
                      </p>
                    </div>
                    <Button
                      onClick={switchToLogin}
                      variant="ghost"
                      className="w-full text-white hover:text-[hsl(270,70%,70%)] hover:bg-[hsl(270,50%,30%)]"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Volver al inicio de sesión
                    </Button>
                  </div>
                ) : (
                  <>
                    <p className="text-white/70 text-sm text-center">
                      Ingresa tu correo electrónico y te enviaremos un enlace para restablecer tu contraseña.
                    </p>
                    <div className="space-y-2">
                      <Input
                        id="forgot-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Correo Electrónico"
                        className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                      />
                    </div>
                    <Button
                      onClick={handleForgotPassword}
                      disabled={loading}
                      className="w-full h-14 bg-gradient-to-r from-[hsl(270,70%,60%)] to-[hsl(280,75%,65%)] hover:from-[hsl(270,70%,55%)] hover:to-[hsl(280,75%,60%)] text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                    >
                      {loading ? "Enviando..." : "Enviar enlace de recuperación"}
                    </Button>
                    <Button
                      onClick={switchToLogin}
                      variant="ghost"
                      className="w-full text-white hover:text-[hsl(270,70%,70%)] hover:bg-[hsl(270,50%,30%)]"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Volver al inicio de sesión
                    </Button>
                  </>
                )}
              </>
            )}

            {/* Vista de login */}
            {view === "login" && (
              <>
                <div className="space-y-2">
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Correo Electrónico"
                    className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Contraseña"
                    className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                  />
                </div>

                <Button
                  onClick={handleLogin}
                  disabled={loading}
                  className="w-full h-14 bg-gradient-to-r from-[hsl(270,70%,60%)] to-[hsl(280,75%,65%)] hover:from-[hsl(270,70%,55%)] hover:to-[hsl(280,75%,60%)] text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                  size="lg"
                >
                  {loading ? "Procesando..." : "Ingresar"}
                </Button>

                <div className="text-center text-sm">
                  <button onClick={switchToRegister} className="text-white hover:text-[hsl(270,70%,70%)] transition-colors">
                    ¿No tienes una cuenta? Regístrate
                  </button>
                </div>

                <div className="text-center text-sm">
                  <button 
                    onClick={switchToWhatsAppRecovery} 
                    className="text-green-400 hover:text-green-300 transition-colors flex items-center justify-center gap-2 w-full"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Recuperar por WhatsApp
                  </button>
                </div>
              </>
            )}

            {/* Vista de recuperación por WhatsApp */}
            {view === "whatsapp-recovery" && (
              <>
                {!tempPassword ? (
                  <>
                    <p className="text-white/70 text-sm text-center">
                      Ingresa el número de teléfono registrado en tu cuenta para generar una nueva contraseña temporal.
                    </p>
                    <p className="text-yellow-400/80 text-xs text-center">
                      ⚠️ Solo disponible para usuarios con rol de Cliente, Negocio o Repartidor
                    </p>
                    <div className="space-y-2">
                      <Input
                        id="recovery-phone"
                        type="tel"
                        value={recoveryPhone}
                        onChange={(e) => setRecoveryPhone(e.target.value)}
                        placeholder="Número de teléfono (ej: 5551234567)"
                        className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                      />
                    </div>
                    <Button
                      onClick={handleWhatsAppRecovery}
                      disabled={loading}
                      className="w-full h-14 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Generando...
                        </>
                      ) : (
                        "Generar Contraseña Temporal"
                      )}
                    </Button>
                  </>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 bg-green-500/20 border border-green-500/30 rounded-xl">
                      <p className="text-white/70 text-sm mb-2 text-center">Tu nueva contraseña temporal:</p>
                      <div className="flex items-center justify-between bg-[hsl(270,40%,18%)]/60 p-3 rounded-lg border border-[hsl(270,50%,35%)]">
                        <code className="text-lg font-mono font-bold tracking-wider text-white">
                          {tempPassword}
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={handleCopyPassword}
                          className="text-white hover:bg-white/10"
                        >
                          {copied ? (
                            <Check className="h-4 w-4 text-green-400" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={handleCopyPassword}
                        className="flex-1 border-[hsl(270,50%,35%)] text-white hover:bg-[hsl(270,50%,30%)]"
                      >
                        <Copy className="h-4 w-4 mr-2" />
                        Copiar
                      </Button>
                      
                      <Button
                        onClick={handleSendWhatsApp}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        <MessageCircle className="h-4 w-4 mr-2" />
                        WhatsApp
                      </Button>
                    </div>

                    <p className="text-white/60 text-xs text-center">
                      Recuerda cambiar tu contraseña después de iniciar sesión.
                    </p>
                  </div>
                )}

                <Button
                  onClick={switchToLogin}
                  variant="ghost"
                  className="w-full text-white hover:text-[hsl(270,70%,70%)] hover:bg-[hsl(270,50%,30%)]"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Volver al inicio de sesión
                </Button>
              </>
            )}

            {/* Vista de registro */}
            {view === "register" && (
              <>
                <div className="space-y-2">
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Nombre Completo"
                    className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Correo Electrónico"
                    className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Contraseña"
                    className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                  />
                </div>

                <div className="space-y-1">
                  <Input
                    id="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Teléfono (Obligatorio) *"
                    required
                    className="h-14 bg-[hsl(270,40%,18%)]/60 border-[hsl(270,50%,35%)] text-white placeholder:text-white/50 rounded-xl"
                  />
                  <p className="text-white/50 text-xs pl-1">
                    * Requerido para recuperar tu cuenta
                  </p>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Selecciona tu Rol</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {roles.map((role) => {
                      const Icon = role.icon;
                      return (
                        <button
                          key={role.value}
                          onClick={() => setSelectedRole(role.value)}
                          className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                            selectedRole === role.value
                              ? "border-[hsl(270,70%,60%)] bg-[hsl(270,70%,60%)]/20 text-white"
                              : "border-[hsl(270,50%,35%)] text-white/70 hover:border-[hsl(270,70%,60%)]/50"
                          }`}
                        >
                          <Icon className="h-6 w-6" />
                          <span className="text-sm font-medium">{role.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <Button
                  onClick={handleRegister}
                  disabled={loading}
                  className="w-full h-14 bg-gradient-to-r from-[hsl(270,70%,60%)] to-[hsl(280,75%,65%)] hover:from-[hsl(270,70%,55%)] hover:to-[hsl(280,75%,60%)] text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                  size="lg"
                >
                  {loading ? "Procesando..." : "Registrarse"}
                </Button>

                <div className="text-center text-sm">
                  <button onClick={switchToLogin} className="text-white hover:text-[hsl(270,70%,70%)] transition-colors">
                    ¿Ya tienes cuenta? Inicia sesión
                  </button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de alerta para cuenta pendiente de aprobación */}
      <AlertDialog open={showPendingModal} onOpenChange={setShowPendingModal}>
        <AlertDialogContent className="bg-[hsl(270,50%,25%)] border-[hsl(270,60%,40%)]">
          <AlertDialogHeader>
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-[hsl(270,70%,60%)]/20 flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-[hsl(270,70%,60%)]" />
              </div>
            </div>
            <AlertDialogTitle className="text-white text-center text-xl">
              ¡Registro Exitoso!
            </AlertDialogTitle>
            <AlertDialogDescription className="text-white/80 text-center text-base space-y-3 pt-2">
              <p>Tu cuenta ha sido creada correctamente.</p>
              <p className="font-semibold text-white bg-[hsl(270,70%,60%)]/20 py-2 px-4 rounded-lg">
                ⚠️ Tu cuenta está pendiente de aprobación
              </p>
              <p>
                El administrador se pondrá en contacto contigo en breve para continuar con el proceso de validación.
              </p>
              <p className="text-[hsl(270,70%,70%)] text-sm">
                Recibirás una notificación cuando tu cuenta sea activada.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center pt-4">
            <AlertDialogAction 
              onClick={handleClosePendingModal}
              className="w-full sm:w-auto bg-gradient-to-r from-[hsl(270,70%,60%)] to-[hsl(280,75%,65%)] hover:from-[hsl(270,70%,55%)] hover:to-[hsl(280,75%,60%)] text-white font-semibold rounded-xl"
            >
              Entendido
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
