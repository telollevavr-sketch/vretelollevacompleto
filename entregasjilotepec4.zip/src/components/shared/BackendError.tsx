import { WifiOff, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface BackendErrorProps {
  title?: string;
  message?: string;
  onRetry?: () => void;
  compact?: boolean;
}

export const BackendError = ({
  title = 'Sin conexión al servidor',
  message = 'No pudimos conectar con el servidor. Revisa tu conexión a internet e intenta de nuevo.',
  onRetry,
  compact = false,
}: BackendErrorProps) => {
  if (compact) {
    return (
      <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
        <WifiOff className="h-10 w-10 text-destructive/70 mb-3" />
        <p className="text-sm text-muted-foreground mb-3">{message}</p>
        {onRetry && (
          <Button variant="outline" size="sm" onClick={onRetry}>
            <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
            Reintentar
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-destructive/10">
          <WifiOff className="h-10 w-10 text-destructive" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white">{title}</h2>
          <p className="text-white/60 text-base leading-relaxed">{message}</p>
        </div>
        {onRetry && (
          <Button 
            onClick={onRetry} 
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Reintentar conexión
          </Button>
        )}
        <p className="text-xs text-white/40">
          Si el problema persiste, intenta de nuevo en unos minutos.
        </p>
      </div>
    </div>
  );
};
