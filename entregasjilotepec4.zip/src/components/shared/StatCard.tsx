import { Card, CardContent } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: 'green' | 'blue' | 'orange' | 'purple' | 'cyan';
}

export const StatCard = ({ 
  title, 
  value, 
  icon: Icon, 
  description,
  trend,
  variant = 'green'
}: StatCardProps) => {
  const iconColors = {
    green: 'bg-[hsl(var(--icon-green))]',
    blue: 'bg-[hsl(var(--icon-blue))]',
    orange: 'bg-[hsl(var(--icon-orange))]',
    purple: 'bg-[hsl(var(--icon-purple))]',
    cyan: 'bg-[hsl(var(--icon-cyan))]'
  };

  return (
    <Card className="hover-scale bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-700 mb-1">
              {title}
            </p>
          </div>
          <div className={cn("rounded-lg p-2.5", iconColors[variant])}>
            <Icon className="h-5 w-5 text-white" />
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-baseline gap-2">
            <h3 className="text-3xl font-bold tracking-tight text-gray-900">
              {value}
            </h3>
            {trend && (
              <span className={cn(
                "text-sm font-medium",
                trend.isPositive ? "text-green-400" : "text-red-400"
              )}>
                {trend.isPositive ? '+' : ''}{trend.value}%
              </span>
            )}
          </div>
          
          {description && (
            <p className="text-sm text-gray-600">
              {description}
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
