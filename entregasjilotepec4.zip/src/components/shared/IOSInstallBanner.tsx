import { useState, useEffect } from 'react';
import { X, Share, PlusSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { detectDevice, needsSafariForInstall } from '@/lib/deviceUtils';
import { useNavigate } from 'react-router-dom';

const BANNER_DISMISSED_KEY = 'ios-install-banner-dismissed';
const BANNER_DISMISS_DURATION = 24 * 60 * 60 * 1000; // 24 horas

export const IOSInstallBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    const device = detectDevice();
    
    // Solo mostrar en iOS, no instalado, y Safari
    if (!device.isIOS || device.isStandalone) {
      return;
    }
    
    // Verificar si el usuario ya cerró el banner recientemente
    const dismissedTime = localStorage.getItem(BANNER_DISMISSED_KEY);
    if (dismissedTime) {
      const elapsed = Date.now() - parseInt(dismissedTime, 10);
      if (elapsed < BANNER_DISMISS_DURATION) {
        return;
      }
    }
    
    // Mostrar el banner después de un pequeño delay para mejor UX
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleDismiss = () => {
    localStorage.setItem(BANNER_DISMISSED_KEY, Date.now().toString());
    setIsVisible(false);
  };
  
  const handleLearnMore = () => {
    navigate('/install');
    handleDismiss();
  };
  
  if (!isVisible) return null;
  
  const device = detectDevice();
  const needsSafari = needsSafariForInstall();
  
  return (
    <div className="fixed bottom-0 left-0 right-0 z-[100] animate-in slide-in-from-bottom duration-500">
      <div className="bg-gradient-to-r from-primary/95 to-primary-foreground/10 backdrop-blur-md border-t border-white/20 shadow-2xl">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-start gap-3">
            {/* Icono animado */}
            <div className="flex-shrink-0 mt-1">
              <div className="relative">
                <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center">
                  <Share className="h-5 w-5 text-white animate-bounce" />
                </div>
                <div className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 flex items-center justify-center">
                  <span className="text-[10px] font-bold text-white">!</span>
                </div>
              </div>
            </div>
            
            {/* Contenido */}
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-white text-sm">
                📲 Instala vrtelolleva
              </p>
              
              {needsSafari ? (
                <p className="text-white/80 text-xs mt-1">
                  Abre esta página en <span className="font-bold">Safari</span> para instalar la app
                </p>
              ) : (
                <p className="text-white/80 text-xs mt-1 flex items-center flex-wrap gap-1">
                  <span>Toca</span>
                  <Share className="h-3 w-3 inline" />
                  <span>Compartir →</span>
                  <PlusSquare className="h-3 w-3 inline" />
                  <span className="font-medium">Agregar a inicio</span>
                </p>
              )}
              
              <Button 
                variant="secondary" 
                size="sm" 
                onClick={handleLearnMore}
                className="mt-2 h-7 text-xs bg-white/20 hover:bg-white/30 text-white border-0"
              >
                Ver instrucciones
              </Button>
            </div>
            
            {/* Botón cerrar */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleDismiss}
              className="flex-shrink-0 h-8 w-8 text-white/80 hover:text-white hover:bg-white/20"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
