import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Store, Bike, Home } from 'lucide-react';
import { renderToString } from 'react-dom/server';
import { Button } from '@/components/ui/button';

// Fix for default marker icons in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface MapLocation {
  lat: number;
  lng: number;
  name?: string;
  address?: string;
  icon?: 'business' | 'delivery' | 'client';
}

interface RouteData {
  orderId: string;
  orderNumber?: string;
  coordinates: { lat: number; lng: number }[];
  color: string;
  weight?: number;
  dashArray?: string;
}

interface MapViewProps {
  location?: { lat: number; lng: number };
  locations?: MapLocation[];
  routes?: RouteData[];
  onLocationChange?: (location: { lat: number; lng: number }) => void;
  height?: string;
  zoom?: number;
  interactive?: boolean;
  requireActivation?: boolean;
}

export const MapView = ({ 
  location, 
  locations,
  routes = [],
  onLocationChange, 
  height = '300px',
  zoom = 13,
  interactive = true,
  requireActivation = false
}: MapViewProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const routesRef = useRef<L.Polyline[]>([]);
  const [isMapActive, setIsMapActive] = useState(!requireActivation);

  // Create custom icons with Lucide icons
  const createIcon = (type: 'business' | 'delivery' | 'client') => {
    const configs = {
      business: {
        icon: Store,
        bgColor: '#10b981',
        iconColor: '#ffffff'
      },
      delivery: {
        icon: Bike,
        bgColor: '#f97316',
        iconColor: '#ffffff'
      },
      client: {
        icon: Home,
        bgColor: '#3b82f6',
        iconColor: '#ffffff'
      }
    };
    
    const config = configs[type];
    const IconComponent = config.icon;
    
    const iconHtml = renderToString(
      <div style={{
        backgroundColor: config.bgColor,
        width: '40px',
        height: '40px',
        borderRadius: '50%',
        border: '3px solid white',
        boxShadow: '0 3px 10px rgba(0,0,0,0.3)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <IconComponent size={20} color={config.iconColor} strokeWidth={2.5} />
      </div>
    );
    
    return L.divIcon({
      className: 'custom-marker',
      html: iconHtml,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
      popupAnchor: [0, -20]
    });
  };

  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return;

    const locs = locations || (location ? [{ ...location, icon: 'client' as const }] : []);
    console.log('🗺️ MapView - Inicializando mapa con', locs.length, 'ubicaciones', locs);
    
    // Default center if no locations provided
    const defaultCenter: [number, number] = [19.95, -99.53];
    const center: [number, number] = locs.length > 0 ? [locs[0].lat, locs[0].lng] : defaultCenter;

    // Initialize map
    const map = L.map(mapContainer.current, {
      dragging: interactive && isMapActive,
      zoomControl: false, // Desactivar control por defecto para agregarlo manualmente
      scrollWheelZoom: interactive && isMapActive,
      doubleClickZoom: interactive && isMapActive,
      touchZoom: interactive && isMapActive,
    }).setView(center, zoom);

    // Agregar control de zoom en la parte derecha
    L.control.zoom({
      position: 'topright'
    }).addTo(map);

    // Add OpenStreetMap tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);

    // Forzar recalculación del tamaño del mapa después de inicializar
    setTimeout(() => {
      map.invalidateSize();
      console.log('🗺️ MapView - Mapa inicializado y tamaño recalculado');
    }, 100);

    // Add markers for each location
    const markers: L.Marker[] = [];
    locs.forEach((loc) => {
      const icon = createIcon(loc.icon || 'client');
      const marker = L.marker([loc.lat, loc.lng], {
        icon,
        draggable: interactive && !!onLocationChange && locs.length === 1,
      }).addTo(map);

      // Create popup content with name, address and coordinates
      if (loc.name || loc.address) {
        const isDelivery = loc.icon === 'delivery';
        const isBusiness = loc.icon === 'business';
        const popupContent = `
          <div style="padding: 12px; min-width: 250px; max-width: 350px;">
            ${isDelivery ? '<div style="font-size: 11px; text-transform: uppercase; color: #f97316; font-weight: 600; margin-bottom: 6px; letter-spacing: 0.5px;">📍 Ubicación en Tiempo Real</div>' : ''}
            ${isBusiness ? '<div style="font-size: 11px; text-transform: uppercase; color: #10b981; font-weight: 600; margin-bottom: 6px; letter-spacing: 0.5px;">🏪 Negocio</div>' : ''}
            ${loc.name ? `<div style="font-weight: 600; font-size: 15px; margin-bottom: 8px; color: #1f2937;">${loc.name}</div>` : ''}
            ${loc.address ? `
              <div style="font-size: 13px; color: #4b5563; line-height: 1.5; padding: 8px; background-color: #f9fafb; border-radius: 6px; border-left: 3px solid ${isDelivery ? '#f97316' : isBusiness ? '#10b981' : '#3b82f6'}; margin-bottom: 8px;">
                ${loc.address}
              </div>
            ` : ''}
            <div style="font-size: 12px; color: #6b7280; background-color: #f3f4f6; padding: 8px; border-radius: 6px; margin-top: 8px;">
              <div style="font-weight: 600; margin-bottom: 4px; color: #374151;">📍 Coordenadas:</div>
              <a 
                href="https://www.google.com/maps?q=${loc.lat},${loc.lng}" 
                target="_blank" 
                rel="noopener noreferrer"
                style="font-family: monospace; font-size: 11px; color: #3b82f6; text-decoration: none; display: block; padding: 4px; border-radius: 4px; background-color: #ffffff; margin-top: 4px; transition: background-color 0.2s;"
                onmouseover="this.style.backgroundColor='#eff6ff'"
                onmouseout="this.style.backgroundColor='#ffffff'"
              >
                <div style="display: flex; align-items: center; gap: 4px;">
                  <span>🗺️</span>
                  <div>
                    <div>Lat: ${loc.lat.toFixed(6)}</div>
                    <div>Lng: ${loc.lng.toFixed(6)}</div>
                  </div>
                  <span style="margin-left: auto;">→</span>
                </div>
              </a>
            </div>
          </div>
        `;
        marker.bindPopup(popupContent, {
          maxWidth: 350,
          className: 'custom-popup',
          closeButton: true,
          autoClose: false,
          closeOnClick: false
        });
        
        // Abrir popup automáticamente al hacer clic
        marker.on('click', function() {
          this.openPopup();
        });
      }

      markers.push(marker);
    });

    // Handle marker drag for single location
    if (interactive && onLocationChange && locs.length === 1) {
      markers[0].on('dragend', () => {
        if (isMapActive) {
          const position = markers[0].getLatLng();
          onLocationChange({ lat: position.lat, lng: position.lng });
        }
      });

      map.on('click', (e: L.LeafletMouseEvent) => {
        if (isMapActive) {
          const { lat, lng } = e.latlng;
          markers[0].setLatLng([lat, lng]);
          onLocationChange({ lat, lng });
        }
      });
    }

    // Fit bounds if multiple locations
    if (locs.length > 1) {
      const bounds = L.latLngBounds(locs.map(loc => [loc.lat, loc.lng]));
      map.fitBounds(bounds, { padding: [50, 50] });
    }

    // Add routes (polylines)
    const polylines: L.Polyline[] = [];
    routes.forEach((route) => {
      const latLngs: [number, number][] = route.coordinates.map(coord => [coord.lat, coord.lng]);
      
      const polyline = L.polyline(latLngs, {
        color: route.color,
        weight: route.weight || 3,
        opacity: 0.7,
        dashArray: route.dashArray,
      }).addTo(map);

      // Add popup with order info
      if (route.orderNumber) {
        polyline.bindPopup(`
          <div style="padding: 8px; min-width: 200px;">
            <div style="font-weight: 600; font-size: 14px; margin-bottom: 6px; color: #1f2937;">
              🚚 Ruta de Entrega
            </div>
            <div style="font-size: 13px; color: #4b5563; margin-bottom: 4px;">
              Pedido: #${route.orderNumber}
            </div>
            <div style="font-size: 12px; color: #6b7280;">
              ${route.coordinates.length === 3 ? 'Negocio → Repartidor → Cliente' : 'Negocio → Cliente'}
            </div>
          </div>
        `, {
          className: 'custom-popup',
        });
      }

      polylines.push(polyline);
    });

    mapRef.current = map;
    markersRef.current = markers;
    routesRef.current = polylines;

    return () => {
      map.remove();
      mapRef.current = null;
      markersRef.current = [];
      routesRef.current = [];
    };
  }, [isMapActive]);

  // Update markers and routes when locations or routes change
  useEffect(() => {
    if (!mapRef.current) return;

    const locs = locations || (location ? [{ ...location, icon: 'client' as const }] : []);
    console.log('🔄 MapView - Actualizando marcadores con', locs.length, 'ubicaciones', locs);
    
    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Clear existing routes
    routesRef.current.forEach(polyline => polyline.remove());
    routesRef.current = [];

    // Add new markers
    const markers: L.Marker[] = [];
    locs.forEach((loc) => {
      const icon = createIcon(loc.icon || 'client');
      const marker = L.marker([loc.lat, loc.lng], {
        icon,
      }).addTo(mapRef.current!);

      // Create popup content with name, address and coordinates
      if (loc.name || loc.address) {
        const isDelivery = loc.icon === 'delivery';
        const isBusiness = loc.icon === 'business';
        const popupContent = `
          <div style="padding: 12px; min-width: 250px; max-width: 350px;">
            ${isDelivery ? '<div style="font-size: 11px; text-transform: uppercase; color: #f97316; font-weight: 600; margin-bottom: 6px; letter-spacing: 0.5px;">📍 Ubicación en Tiempo Real</div>' : ''}
            ${isBusiness ? '<div style="font-size: 11px; text-transform: uppercase; color: #10b981; font-weight: 600; margin-bottom: 6px; letter-spacing: 0.5px;">🏪 Negocio</div>' : ''}
            ${loc.name ? `<div style="font-weight: 600; font-size: 15px; margin-bottom: 8px; color: #1f2937;">${loc.name}</div>` : ''}
            ${loc.address ? `
              <div style="font-size: 13px; color: #4b5563; line-height: 1.5; padding: 8px; background-color: #f9fafb; border-radius: 6px; border-left: 3px solid ${isDelivery ? '#f97316' : isBusiness ? '#10b981' : '#3b82f6'}; margin-bottom: 8px;">
                ${loc.address}
              </div>
            ` : ''}
            <div style="font-size: 12px; color: #6b7280; background-color: #f3f4f6; padding: 8px; border-radius: 6px; margin-top: 8px;">
              <div style="font-weight: 600; margin-bottom: 4px; color: #374151;">📍 Coordenadas:</div>
              <a 
                href="https://www.google.com/maps?q=${loc.lat},${loc.lng}" 
                target="_blank" 
                rel="noopener noreferrer"
                style="font-family: monospace; font-size: 11px; color: #3b82f6; text-decoration: none; display: block; padding: 4px; border-radius: 4px; background-color: #ffffff; margin-top: 4px; transition: background-color 0.2s;"
                onmouseover="this.style.backgroundColor='#eff6ff'"
                onmouseout="this.style.backgroundColor='#ffffff'"
              >
                <div style="display: flex; align-items: center; gap: 4px;">
                  <span>🗺️</span>
                  <div>
                    <div>Lat: ${loc.lat.toFixed(6)}</div>
                    <div>Lng: ${loc.lng.toFixed(6)}</div>
                  </div>
                  <span style="margin-left: auto;">→</span>
                </div>
              </a>
            </div>
          </div>
        `;
        marker.bindPopup(popupContent, {
          maxWidth: 350,
          className: 'custom-popup',
          closeButton: true,
          autoClose: false,
          closeOnClick: false
        });
        
        // Abrir popup automáticamente al hacer clic
        marker.on('click', function() {
          this.openPopup();
        });
      }

      markers.push(marker);
    });

    markersRef.current = markers;

    // Add routes (polylines)
    const polylines: L.Polyline[] = [];
    routes.forEach((route) => {
      const latLngs: [number, number][] = route.coordinates.map(coord => [coord.lat, coord.lng]);
      
      const polyline = L.polyline(latLngs, {
        color: route.color,
        weight: route.weight || 3,
        opacity: 0.7,
        dashArray: route.dashArray,
      }).addTo(mapRef.current!);

      // Add popup with order info
      if (route.orderNumber) {
        polyline.bindPopup(`
          <div style="padding: 8px; min-width: 200px;">
            <div style="font-weight: 600; font-size: 14px; margin-bottom: 6px; color: #1f2937;">
              🚚 Ruta de Entrega
            </div>
            <div style="font-size: 13px; color: #4b5563; margin-bottom: 4px;">
              Pedido: #${route.orderNumber}
            </div>
            <div style="font-size: 12px; color: #6b7280;">
              ${route.coordinates.length === 3 ? 'Negocio → Repartidor → Cliente' : 'Negocio → Cliente'}
            </div>
          </div>
        `, {
          className: 'custom-popup',
        });
      }

      polylines.push(polyline);
    });

    routesRef.current = polylines;

    // Update view
    if (locs.length === 1) {
      mapRef.current.setView([locs[0].lat, locs[0].lng], zoom);
    } else if (locs.length > 1) {
      const bounds = L.latLngBounds(locs.map(loc => [loc.lat, loc.lng]));
      mapRef.current.fitBounds(bounds, { padding: [50, 50] });
    }
    
    // Forzar recalculación del tamaño después de actualizar
    setTimeout(() => {
      mapRef.current?.invalidateSize();
      console.log('🔄 MapView - Tamaño del mapa recalculado después de actualizar');
    }, 100);
  }, [locations, location?.lat, location?.lng, routes, zoom]);

  // Actualizar interactividad del mapa cuando cambia isMapActive
  useEffect(() => {
    if (!mapRef.current) return;
    
    if (isMapActive) {
      mapRef.current.dragging?.enable();
      mapRef.current.scrollWheelZoom?.enable();
      mapRef.current.doubleClickZoom?.enable();
      mapRef.current.touchZoom?.enable();
    } else {
      mapRef.current.dragging?.disable();
      mapRef.current.scrollWheelZoom?.disable();
      mapRef.current.doubleClickZoom?.disable();
      mapRef.current.touchZoom?.disable();
    }
  }, [isMapActive]);

  return (
    <div className="relative">
      <div 
        ref={mapContainer} 
        style={{ height, width: '100%' }}
        className="rounded-lg overflow-hidden border border-border shadow-lg sm:pr-0 pr-4"
      />
      
      {requireActivation && !isMapActive && (
        <div 
          className="absolute inset-0 bg-background/60 backdrop-blur-[2px] flex items-center justify-center cursor-pointer transition-opacity hover:bg-background/70 rounded-lg"
          onClick={() => setIsMapActive(true)}
        >
          <div className="bg-card border-2 border-primary px-6 py-4 rounded-xl shadow-2xl text-center">
            <div className="text-4xl mb-2">👆</div>
            <p className="text-sm font-semibold text-foreground">Toca para editar ubicación</p>
          </div>
        </div>
      )}
      
      {requireActivation && isMapActive && (
        <Button
          size="sm"
          className="absolute top-2 left-2 shadow-lg z-[1000]"
          onClick={() => setIsMapActive(false)}
        >
          ✓ Confirmar
        </Button>
      )}
    </div>
  );
};
