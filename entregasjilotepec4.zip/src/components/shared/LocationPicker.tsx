import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { MapPin, Loader2 } from 'lucide-react';
import { locationService } from '@/services/locationService';
import { MapView } from './MapView';
import { toast } from '@/hooks/use-toast';

interface LocationPickerProps {
  location: { lat: number; lng: number };
  onLocationChange: (location: { lat: number; lng: number }) => void;
  onAddressChange?: (address: string) => void;
}

export const LocationPicker = ({ location, onLocationChange, onAddressChange }: LocationPickerProps) => {
  const [address, setAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    locationService.getAddressFromCoordinates(location.lat, location.lng)
      .then((addr) => {
        setAddress(addr);
        onAddressChange?.(addr);
      })
      .catch(() => setAddress(''));
  }, [location.lat, location.lng]);

  const handleUseCurrentLocation = async () => {
    setIsLoading(true);
    try {
      const currentLocation = await locationService.getCurrentPosition();
      onLocationChange(currentLocation);
      toast({
        title: "Ubicación actualizada",
        description: "Tu ubicación actual ha sido establecida",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo obtener tu ubicación",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-3 sm:pr-0 pr-2">
      <MapView 
        location={location}
        onLocationChange={onLocationChange}
        height="240px"
        zoom={15}
        interactive={true}
        requireActivation={true}
      />
      
      {address && (
        <div className="flex items-start gap-2 p-3 bg-muted/50 rounded-lg">
          <MapPin className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
          <p className="text-sm text-foreground flex-1">{address}</p>
        </div>
      )}
      
      <Button 
        variant="outline" 
        className="w-full" 
        onClick={handleUseCurrentLocation}
        disabled={isLoading}
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Obteniendo ubicación...
          </>
        ) : (
          <>
            <MapPin className="h-4 w-4 mr-2" />
            Usar Mi Ubicación Actual
          </>
        )}
      </Button>
    </div>
  );
};
