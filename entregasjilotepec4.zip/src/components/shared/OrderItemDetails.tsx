import { useEffect, useState } from 'react';
import { CartItem } from '@/types';
import { supabase } from '@/integrations/supabase/client';

interface OrderItemDetailsProps {
  item: CartItem;
  index: number;
  showPrice?: boolean;
  compact?: boolean;
}

interface SpecialtyDetails {
  id: string;
  name: string;
  description: string | null;
}

export const OrderItemDetails = ({ 
  item, 
  index, 
  showPrice = true, 
  compact = false 
}: OrderItemDetailsProps) => {
  const [specialtiesDetails, setSpecialtiesDetails] = useState<Map<string, string>>(new Map());
  const [loading, setLoading] = useState(false);

  // Debug: Log item data to verify complement information
  useEffect(() => {
    console.log('🔍 [OrderItemDetails] Item data:', {
      productName: item.product.name,
      hasComplements: !!item.selectedComplements,
      complementsCount: item.selectedComplements?.length || 0,
      complements: item.selectedComplements,
      subtotal: item.subtotal
    });
  }, [item]);

  useEffect(() => {
    const fetchSpecialtiesDetails = async () => {
      // Solo consultar si es combo promocional y no tiene ingredientes guardados
      if (item.product.isPromotionalCombo && item.comboSelections) {
        const selectionsWithoutIngredients = item.comboSelections.filter(
          sel => !sel.specialtyIngredients
        );

        if (selectionsWithoutIngredients.length > 0) {
          setLoading(true);
          const specialtyIds = selectionsWithoutIngredients.map(sel => sel.specialtyId);
          
          const { data, error } = await supabase
            .from('pizza_specialties')
            .select('id, name, description')
            .in('id', specialtyIds);

          if (!error && data) {
            const detailsMap = new Map<string, string>();
            data.forEach((specialty: SpecialtyDetails) => {
              if (specialty.description) {
                detailsMap.set(specialty.id, specialty.description);
              }
            });
            setSpecialtiesDetails(detailsMap);
          }
          setLoading(false);
        }
      }
    };

    fetchSpecialtiesDetails();
  }, [item]);

  return (
    <div className={compact ? "text-sm" : "text-sm"}>
      <div className="flex justify-between items-start">
        <span className="font-medium">
          {item.quantity}x {item.product.name}
        </span>
        {showPrice && (
          <span className="font-semibold">${item.subtotal.toFixed(2)}</span>
        )}
      </div>

      {/* Combo Promotional Details */}
      {item.product.isPromotionalCombo && item.comboSelections && item.comboSelections.length > 0 && (
        <div className={`ml-4 mt-2 space-y-2 ${compact ? 'text-xs' : 'text-sm'}`}>
          {item.comboSelections.map((selection, idx) => {
            const ingredients = selection.specialtyIngredients || specialtiesDetails.get(selection.specialtyId);
            
            // Usar itemType e itemLabel guardados en la selección
            const itemType = selection.itemType || 'pizza';
            const itemLabel = selection.itemLabel || `Producto ${idx + 1}`;
            
            // Función para obtener icono según tipo
            const getIcon = (type: string) => {
              const icons: { [key: string]: string } = {
                pizza: '🍕', torta: '🥖', salsa: '🧂', queso: '🧀',
                bebida: '🥤', refresco: '🥤', postre: '🍰',
                hamburguesa: '🍔', taco: '🌮', burrito: '🌯',
                hot: '🌭', hotdog: '🌭',
              };
              return icons[type.toLowerCase()] || '🎁';
            };
            
            return (
              <div key={idx} className="bg-primary/5 dark:bg-primary/10 p-2 rounded border border-primary/10">
                <p className="font-medium text-foreground">
                  {getIcon(itemType)} {itemLabel}: {selection.specialtyName}
                  {selection.specialtyPrice && selection.specialtyPrice > 0 && (
                    <span className="ml-2 text-primary font-semibold">
                      ${selection.specialtyPrice.toFixed(0)}
                    </span>
                  )}
                </p>
                {loading && !ingredients ? (
                  <p className="text-xs text-muted-foreground animate-pulse">
                    Cargando ingredientes...
                  </p>
                ) : ingredients ? (
                  <p className="text-xs text-muted-foreground mt-1">
                    Ingredientes: {ingredients}
                  </p>
                ) : (
                  <p className="text-xs text-muted-foreground/50 mt-1">
                    (Ingredientes no disponibles)
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Individual Specialty Details */}
      {item.product.isSpecialty && item.specialtySelection && (
        <div className={`ml-4 mt-2 ${compact ? 'text-xs' : 'text-sm'}`}>
          <div className="bg-primary/5 dark:bg-primary/10 p-2 rounded border border-primary/10">
            <p className="font-medium text-foreground">
              ✨ Especialidad: {item.specialtySelection.specialtyName}
            </p>
            {item.specialtySelection.specialtyIngredients && (
              <p className="text-xs text-muted-foreground mt-1">
                Ingredientes: {item.specialtySelection.specialtyIngredients}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Pizza Configuration (custom pizzas) */}
      {item.configuration && (
        <div className={`ml-4 mt-1 space-y-0.5 ${compact ? 'text-xs' : 'text-xs'} text-muted-foreground`}>
          {item.configuration.ingredients && item.configuration.ingredients.length > 0 && (
            <p>• Ingredientes: {item.configuration.ingredients.join(', ')}</p>
          )}
          {item.configuration.extraCheese && <p>• Extra queso</p>}
          {item.configuration.stuffedCrust && <p>• Orilla rellena de queso</p>}
        </div>
      )}

      {/* Complements */}
      {item.selectedComplements && Array.isArray(item.selectedComplements) && item.selectedComplements.length > 0 && (
        <div className={`ml-4 mt-2 ${compact ? 'text-xs' : 'text-sm'} bg-primary/5 dark:bg-primary/10 p-2 rounded border border-primary/10`}>
          <p className="text-xs font-semibold text-primary">Complementos:</p>
          <ul className="space-y-0.5 mt-1">
            {item.selectedComplements.map((comp, idx) => (
              <li key={idx} className="text-xs text-foreground">
                • {comp.complementName}
                {comp.complementPrice > 0 && ` (+$${comp.complementPrice.toFixed(2)})`}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Notes */}
      {item.notes && (
        <p className={`ml-4 mt-1 ${compact ? 'text-xs' : 'text-xs'} text-muted-foreground`}>
          📝 Nota: {item.notes}
        </p>
      )}
    </div>
  );
};