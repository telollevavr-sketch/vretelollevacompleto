import { useState, useEffect } from 'react';
import { Order, OrderMessage } from '@/types';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { MessageSquare, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';

interface OrderMessagesProps {
  order: Order;
  currentUserId: string;
  currentUserRole: 'CLIENT' | 'DELIVERY';
  onOrderUpdate?: (updatedOrder: Order) => void;
}

const DELIVERY_MESSAGES = [
  'Llego en 15 mins',
  'Llego en 10 mins',
  'Llego en 5 mins',
  'Estar pendiente al cláxon',
  'Estoy afuera'
];

const CLIENT_MESSAGES = [
  'Llamar al llegar',
  'Salgo en seguida',
  'Tocar el timbre',
  'Dejar en recepción'
];

export const OrderMessages = ({ order, currentUserId, currentUserRole, onOrderUpdate }: OrderMessagesProps) => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<OrderMessage[]>([]);
  const [selectedMessage, setSelectedMessage] = useState<string>('');
  const [customMessage, setCustomMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  const availableMessages = currentUserRole === 'DELIVERY' ? DELIVERY_MESSAGES : CLIENT_MESSAGES;

  // Cargar mensajes existentes y suscribirse a cambios en tiempo real
  useEffect(() => {
    const loadMessages = async () => {
      try {
        const { data, error } = await supabase
          .from('order_messages')
          .select('*')
          .eq('order_id', order.id)
          .order('created_at', { ascending: true });

        if (error) throw error;

        if (data) {
          const formattedMessages: OrderMessage[] = data.map(msg => ({
            id: msg.id,
            senderId: msg.sender_id,
            senderRole: msg.sender_role.toUpperCase() as 'CLIENT' | 'DELIVERY',
            message: msg.message,
            timestamp: msg.created_at
          }));
          setMessages(formattedMessages);
        }
      } catch (error) {
        console.error('Error loading messages:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadMessages();

    // Suscribirse a mensajes nuevos en tiempo real
    const channel = supabase
      .channel(`order-messages-${order.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'order_messages',
          filter: `order_id=eq.${order.id}`
        },
        (payload) => {
          const newMsg = payload.new as any;
          const formattedMsg: OrderMessage = {
            id: newMsg.id,
            senderId: newMsg.sender_id,
            senderRole: newMsg.sender_role.toUpperCase() as 'CLIENT' | 'DELIVERY',
            message: newMsg.message,
            timestamp: newMsg.created_at
          };
          setMessages(prev => [...prev, formattedMsg]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [order.id]);

  const handleSendMessage = async () => {
    // Priorizar mensaje personalizado si existe, sino usar seleccionado
    const messageToSend = customMessage.trim() || selectedMessage;
    
    if (!messageToSend) {
      toast({
        title: "Mensaje vacío",
        description: "Por favor escribe o selecciona un mensaje",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('order_messages')
        .insert([{
          order_id: order.id,
          sender_id: currentUserId,
          sender_role: currentUserRole.toLowerCase() as 'client' | 'delivery',
          message: messageToSend
        }]);

      if (error) throw error;

      // Limpiar ambos campos después de enviar
      setSelectedMessage('');
      setCustomMessage('');
      
      toast({
        title: "Mensaje enviado",
        description: "El mensaje ha sido enviado correctamente"
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3 pb-2 border-b-2 border-blue-300 dark:border-blue-700">
        <div className="bg-blue-500 p-2 rounded-full">
          <MessageSquare className="h-5 w-5 text-white" />
        </div>
        <div>
          <h3 className="font-bold text-lg text-blue-900 dark:text-blue-100">
            💬 Chat Rápido
          </h3>
          <p className="text-xs text-blue-700 dark:text-blue-300">
            {currentUserRole === 'DELIVERY' ? 'Comunícate con el cliente' : 'Comunícate con el repartidor'}
          </p>
        </div>
      </div>

      {/* Messages Display */}
      <div className="space-y-3 max-h-72 overflow-y-auto p-4 bg-white dark:bg-gray-900 rounded-lg border-2 border-blue-100 dark:border-blue-900">
        {isLoading ? (
          <div className="p-6 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-3"></div>
            <p className="text-blue-600 dark:text-blue-400 text-sm">Cargando mensajes...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="p-6 text-center">
            <MessageSquare className="h-12 w-12 mx-auto mb-3 text-blue-300 dark:text-blue-700" />
            <p className="text-blue-600 dark:text-blue-400 font-medium">No hay mensajes aún</p>
            <p className="text-xs text-blue-500 dark:text-blue-500 mt-1">Selecciona un mensaje rápido o escribe uno personalizado</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isOwnMessage = msg.senderId === currentUserId;
            return (
              <div
                key={msg.id}
                className={cn(
                  "flex",
                  isOwnMessage ? "justify-end" : "justify-start"
                )}
              >
                <div
                  className={cn(
                    "max-w-[80%] rounded-lg p-3 space-y-1",
                    isOwnMessage
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  )}
                >
                  <div className="flex items-center gap-2 text-xs opacity-80">
                    <span className="font-semibold">
                      {msg.senderRole === 'DELIVERY' ? '🚴 Repartidor' : '👤 Cliente'}
                    </span>
                    <span>•</span>
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString('es-MX', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  <p className="text-sm font-medium">{msg.message}</p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Quick Messages */}
      <div className="space-y-3 bg-gradient-to-br from-blue-50/50 to-indigo-50/50 dark:from-blue-950/20 dark:to-indigo-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
        <p className="text-sm font-bold text-blue-900 dark:text-blue-100 flex items-center gap-2">
          ⚡ Mensajes rápidos:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {availableMessages.map((msg) => (
            <Button
              key={msg}
              variant={selectedMessage === msg ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedMessage(msg)}
              className="justify-start text-left h-auto py-2 whitespace-normal"
            >
              {msg}
            </Button>
          ))}
        </div>
      </div>

      {/* Custom Message Input */}
      <div className="space-y-2 bg-gradient-to-br from-purple-50/50 to-pink-50/50 dark:from-purple-950/20 dark:to-pink-950/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
        <p className="text-sm font-bold text-purple-900 dark:text-purple-100 flex items-center gap-2">
          ✍️ Escribe tu propio mensaje:
        </p>
        <Textarea
          placeholder="Escribe un mensaje personalizado..."
          value={customMessage}
          onChange={(e) => setCustomMessage(e.target.value)}
          maxLength={200}
          className="resize-none min-h-[80px]"
          rows={3}
        />
        <div className="flex justify-between items-center text-xs">
          <span className="text-muted-foreground">
            {customMessage.length > 0 ? '✓ Mensaje listo para enviar' : 'Escribe hasta 200 caracteres'}
          </span>
          <span className={cn(
            "font-medium",
            customMessage.length > 180 ? "text-orange-600" : "text-muted-foreground"
          )}>
            {customMessage.length}/200
          </span>
        </div>
      </div>

      {/* Send Button */}
      <Button
        onClick={handleSendMessage}
        disabled={!selectedMessage && !customMessage.trim()}
        className="w-full h-12 text-base font-bold shadow-lg hover:shadow-xl transition-all"
        size="lg"
      >
        <Send className="h-5 w-5 mr-2" />
        {customMessage.trim() 
          ? 'Enviar Mensaje Personalizado' 
          : 'Enviar Mensaje Rápido'}
      </Button>
    </div>
  );
};
