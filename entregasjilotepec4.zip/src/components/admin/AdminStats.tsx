import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Order, Business, User, OrderStatus } from '@/types';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Filter, Package, MapPin, FileDown, FileSpreadsheet, User as UserIcon, Phone } from 'lucide-react';
import { useState } from 'react';
import { DateRange } from 'react-day-picker';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { isWithinInterval, startOfDay, endOfDay, format } from 'date-fns';
import { es } from 'date-fns/locale';
import { BusinessOrderDetailsModal } from '@/components/business/BusinessOrderDetailsModal';
import { cn } from '@/lib/utils';
import { exportToPDF, exportToExcel, exportOrdersToExcel } from '@/lib/statsExport';
import { toast } from 'sonner';

interface AdminStatsProps {
  orders: Order[];
  businesses: Business[];
  deliveryPersons: User[];
}

export const AdminStats = ({ orders, businesses, deliveryPersons }: AdminStatsProps) => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>(() => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 7);
    return { from, to };
  });
  const [selectedBusiness, setSelectedBusiness] = useState<string>('all');
  const [selectedDelivery, setSelectedDelivery] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  const handleOrderClick = (order: Order) => {
    setSelectedOrder(order);
    setIsOrderModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsOrderModalOpen(false);
    setSelectedOrder(null);
  };

  // Quick date filters
  const setQuickRange = (days: number) => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - days);
    setDateRange({ from, to });
  };

  // Apply all filters
  const filteredOrders = orders.filter(order => {
    // Date filter
    if (dateRange?.from) {
      const orderDate = new Date(order.createdAt);
      const from = startOfDay(dateRange.from);
      const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
      if (!isWithinInterval(orderDate, { start: from, end: to })) return false;
    }
    
    // Business filter
    if (selectedBusiness !== 'all' && order.businessId !== selectedBusiness) return false;
    
    // Delivery person filter
    if (selectedDelivery !== 'all' && order.deliveryPersonId !== selectedDelivery) return false;
    
    return true;
  });

  // Calculate daily revenue for filtered date range
  const revenueData = (() => {
    if (!dateRange?.from) return [];
    
    const from = startOfDay(dateRange.from);
    const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
    const diffTime = Math.abs(to.getTime() - from.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return Array.from({ length: Math.min(diffDays + 1, 30) }, (_, i) => {
      const date = new Date(from);
      date.setDate(date.getDate() + i);
      const dayOrders = filteredOrders.filter(o => {
        const orderDate = new Date(o.createdAt);
        return orderDate.toDateString() === date.toDateString() && o.status === 'DELIVERED';
      });
      const revenue = dayOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
      return {
        date: date.toLocaleDateString('es-MX', { day: '2-digit', month: 'short' }),
        ingresos: parseFloat(revenue.toFixed(2)),
        pedidos: dayOrders.length
      };
    });
  })();

  // Revenue by business (filtered)
  const businessRevenue = businesses
    .map(b => {
      const businessOrders = filteredOrders.filter(o => o.businessId === b.id && o.status === 'DELIVERED');
      const revenue = businessOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
      return {
        name: b.name.length > 15 ? b.name.substring(0, 15) + '...' : b.name,
        ingresos: parseFloat(revenue.toFixed(2)),
        pedidos: businessOrders.length
      };
    })
    .filter(b => b.ingresos > 0)
    .sort((a, b) => b.ingresos - a.ingresos)
    .slice(0, 5);

  // Revenue by delivery person (filtered)
  const deliveryRevenue = deliveryPersons
    .map(d => {
      const personOrders = filteredOrders.filter(o => o.deliveryPersonId === d.id && o.status === 'DELIVERED');
      const earnings = personOrders.reduce((sum, o) => sum + (o.deliveryFee || 0), 0);
      return {
        name: d.name.length > 15 ? d.name.substring(0, 15) + '...' : d.name,
        ganancias: parseFloat(earnings.toFixed(2)),
        entregas: personOrders.length
      };
    })
    .filter(d => d.ganancias > 0)
    .sort((a, b) => b.ganancias - a.ganancias)
    .slice(0, 5);

  // Order status distribution (filtered)
  const statusData = [
    { name: 'Entregados', value: filteredOrders.filter(o => o.status === 'DELIVERED').length, color: 'hsl(var(--icon-green))' },
    { name: 'En Camino', value: filteredOrders.filter(o => o.status === 'ON_THE_WAY').length, color: 'hsl(var(--icon-blue))' },
    { name: 'Preparando', value: filteredOrders.filter(o => o.status === 'IN_PREPARATION').length, color: 'hsl(var(--icon-orange))' },
    { name: 'Cancelados', value: filteredOrders.filter(o => o.status === 'CANCELLED').length, color: 'hsl(var(--icon-purple))' }
  ].filter(item => item.value > 0);

  // Calculate growth metrics (comparing with previous period)
  const calculateGrowthMetrics = () => {
    if (!dateRange?.from || !dateRange.to) return { revenueGrowth: '0', ordersGrowth: '0' };
    
    const from = startOfDay(dateRange.from);
    const to = endOfDay(dateRange.to);
    const diffTime = Math.abs(to.getTime() - from.getTime());
    const periodDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    
    const currentPeriodOrders = filteredOrders.filter(o => o.status === 'DELIVERED');
    const currentRevenue = currentPeriodOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
    
    // Previous period
    const prevFrom = new Date(from);
    prevFrom.setDate(prevFrom.getDate() - periodDays);
    const prevTo = new Date(from);
    prevTo.setDate(prevTo.getDate() - 1);
    
    const previousPeriodOrders = orders.filter(o => {
      if (o.status !== 'DELIVERED') return false;
      const orderDate = new Date(o.createdAt);
      return isWithinInterval(orderDate, { start: prevFrom, end: prevTo });
    });
    const previousRevenue = previousPeriodOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
    
    const revenueGrowth = previousRevenue > 0 ? ((currentRevenue - previousRevenue) / previousRevenue * 100).toFixed(1) : '0';
    const ordersGrowth = previousPeriodOrders.length > 0 ? ((currentPeriodOrders.length - previousPeriodOrders.length) / previousPeriodOrders.length * 100).toFixed(1) : '0';
    
    return { revenueGrowth, ordersGrowth };
  };
  
  const { revenueGrowth, ordersGrowth } = calculateGrowthMetrics();

  const handleExportPDF = async () => {
    try {
      await exportToPDF({
        dateRange,
        selectedBusiness,
        selectedDelivery,
        businesses,
        deliveryPersons,
        filteredOrders,
        revenueData,
        businessRevenue,
        deliveryRevenue,
        statusData,
        revenueGrowth,
        ordersGrowth
      });
      toast.success('Reporte PDF generado exitosamente');
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Error al generar el reporte PDF');
    }
  };

  const handleExportExcel = () => {
    try {
      exportToExcel({
        dateRange,
        selectedBusiness,
        selectedDelivery,
        businesses,
        deliveryPersons,
        filteredOrders,
        revenueData,
        businessRevenue,
        deliveryRevenue,
        statusData,
        revenueGrowth,
        ordersGrowth
      });
      toast.success('Reporte Excel generado exitosamente');
    } catch (error) {
      console.error('Error generating Excel:', error);
      toast.error('Error al generar el reporte Excel');
    }
  };

  const handleExportOrdersExcel = () => {
    try {
      if (filteredOrders.length === 0) {
        toast.error('No hay pedidos para exportar');
        return;
      }
      exportOrdersToExcel(filteredOrders, businesses, deliveryPersons, dateRange);
      toast.success('Listado de pedidos exportado exitosamente');
    } catch (error) {
      console.error('Error exporting orders:', error);
      toast.error('Error al exportar el listado de pedidos');
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.PENDING:
        return <Badge className="bg-yellow-500 text-white">Pendiente</Badge>;
      case OrderStatus.IN_PREPARATION:
        return <Badge className="bg-blue-500 text-white">En Preparación</Badge>;
      case OrderStatus.READY_FOR_PICKUP:
        return <Badge className="bg-purple-500 text-white">Listo</Badge>;
      case OrderStatus.ON_THE_WAY:
        return <Badge className="bg-orange-500 text-white">En Camino</Badge>;
      case OrderStatus.DELIVERED:
        return <Badge className="bg-green-500 text-white">Entregado</Badge>;
      case OrderStatus.CANCELLED:
        return <Badge variant="destructive">Cancelado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <BusinessOrderDetailsModal 
        order={selectedOrder}
        open={isOrderModalOpen}
        onClose={handleCloseModal}
      />
      {/* Filters Section */}
      <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filtros
            </CardTitle>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleExportPDF}
                className="gap-2"
              >
                <FileDown className="h-4 w-4" />
                Exportar PDF
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleExportExcel}
                className="gap-2"
              >
                <FileSpreadsheet className="h-4 w-4" />
                Exportar Excel
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Date Range Filter */}
            <div className="space-y-2">
              <Label>Rango de Fechas</Label>
              <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} />
              <div className="flex gap-2 mt-2">
                <Button variant="outline" size="sm" onClick={() => setQuickRange(7)}>
                  7 días
                </Button>
                <Button variant="outline" size="sm" onClick={() => setQuickRange(30)}>
                  30 días
                </Button>
              </div>
            </div>

            {/* Business Filter */}
            <div className="space-y-2">
              <Label>Negocio</Label>
              <Select value={selectedBusiness} onValueChange={setSelectedBusiness}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los negocios</SelectItem>
                  {businesses.map((business) => (
                    <SelectItem key={business.id} value={business.id}>
                      {business.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Delivery Person Filter */}
            <div className="space-y-2">
              <Label>Repartidor</Label>
              <Select value={selectedDelivery} onValueChange={setSelectedDelivery}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los repartidores</SelectItem>
                  {deliveryPersons.map((person) => (
                    <SelectItem key={person.id} value={person.id}>
                      {person.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* Growth Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30 bg-gradient-to-br from-[hsl(var(--icon-green))]/10 via-transparent to-transparent">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-700">Crecimiento de Ingresos</p>
                <p className="text-3xl font-bold mt-2 text-gray-900">{revenueGrowth}%</p>
                <p className="text-xs text-gray-600 mt-1">vs. semana anterior</p>
              </div>
              {parseFloat(revenueGrowth) >= 0 ? (
                <TrendingUp className="h-12 w-12 text-[hsl(var(--icon-green))]" />
              ) : (
                <TrendingDown className="h-12 w-12 text-red-500" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30 bg-gradient-to-br from-[hsl(var(--icon-blue))]/10 via-transparent to-transparent">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-700">Crecimiento de Pedidos</p>
                <p className="text-3xl font-bold mt-2 text-gray-900">{ordersGrowth}%</p>
                <p className="text-xs text-gray-600 mt-1">vs. semana anterior</p>
              </div>
              {parseFloat(ordersGrowth) >= 0 ? (
                <TrendingUp className="h-12 w-12 text-[hsl(var(--icon-blue))]" />
              ) : (
                <TrendingDown className="h-12 w-12 text-red-500" />
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Trend */}
      <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900">
            📈 Tendencia de Ingresos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="date" 
                stroke="hsl(var(--muted-foreground))"
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="ingresos" 
                stroke="hsl(var(--icon-green))" 
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--icon-green))', r: 5 }}
                activeDot={{ r: 8 }}
                name="Ingresos ($)"
              />
              <Line 
                type="monotone" 
                dataKey="pedidos" 
                stroke="hsl(var(--icon-blue))" 
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--icon-blue))', r: 5 }}
                name="Pedidos (#)"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Businesses */}
        {businessRevenue.length > 0 && (
          <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
            <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900">
              🏆 Top Negocios por Ingresos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={businessRevenue}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    stroke="hsl(var(--muted-foreground))"
                    angle={-45}
                    textAnchor="end"
                    height={100}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar 
                    dataKey="ingresos" 
                    fill="hsl(var(--icon-cyan))" 
                    radius={[8, 8, 0, 0]}
                    name="Ingresos ($)"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Top Delivery Persons */}
        {deliveryRevenue.length > 0 && (
          <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                🚚 Top Repartidores por Ganancias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={deliveryRevenue}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    stroke="hsl(var(--muted-foreground))"
                    angle={-45}
                    textAnchor="end"
                    height={100}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar 
                    dataKey="ganancias" 
                    fill="hsl(var(--icon-orange))" 
                    radius={[8, 8, 0, 0]}
                    name="Ganancias ($)"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Order Status Distribution */}
      {statusData.length > 0 && (
        <div className="grid grid-cols-1 gap-6">
          <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                📊 Distribución de Pedidos
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Orders List Section */}
      <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Listado de Pedidos ({filteredOrders.length})
            </CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleExportOrdersExcel}
              disabled={filteredOrders.length === 0}
              className="gap-2"
            >
              <FileSpreadsheet className="h-4 w-4" />
              Exportar Lista
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {filteredOrders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No hay pedidos que coincidan con los filtros seleccionados
            </div>
          ) : (
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-3">
                {filteredOrders
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((order) => {
                    const deliveryPerson = deliveryPersons.find(d => d.id === order.deliveryPersonId);
                    
                    return (
                      <Card 
                        key={order.id}
                        className={cn(
                          "cursor-pointer transition-all hover:shadow-lg hover:scale-[1.01] border-2",
                          "hover:border-purple-400"
                        )}
                        onClick={() => handleOrderClick(order)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            {/* Left Section - Order Info */}
                            <div className="flex-1 space-y-2">
                              <div className="flex items-center gap-2">
                                <h4 className="font-bold text-base">
                                  Pedido #{order.id.slice(0, 8)}
                                </h4>
                                {getStatusBadge(order.status)}
                              </div>
                              
                              <div className="space-y-1 text-sm">
                                {/* Client Info */}
                                {order.clientInfo && (
                                  <div className="bg-blue-50 rounded p-2 mb-2 border border-blue-200">
                                    <p className="text-foreground flex items-center gap-1">
                                      <UserIcon className="h-4 w-4 text-blue-600" />
                                      <span className="font-medium">Cliente:</span> {order.clientInfo.name}
                                    </p>
                                    {order.clientInfo.phone && (
                                      <p className="text-muted-foreground flex items-center gap-1 ml-5">
                                        <Phone className="h-3 w-3" />
                                        {order.clientInfo.phone}
                                      </p>
                                    )}
                                  </div>
                                )}
                                <p className="text-foreground">
                                  <span className="font-medium">🏪 Negocio:</span> {order.businessName || 'N/A'}
                                </p>
                                {deliveryPerson && (
                                  <p className="text-muted-foreground">
                                    <span className="font-medium">🚚 Repartidor:</span> {deliveryPerson.name}
                                  </p>
                                )}
                                <p className="text-muted-foreground">
                                  <span className="font-medium">📅 Fecha:</span>{' '}
                                  {format(new Date(order.createdAt), "dd/MM/yyyy HH:mm", { locale: es })}
                                </p>
                                <p className="text-muted-foreground flex items-start gap-1">
                                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                                  <span className="line-clamp-1">{order.deliveryLocation?.address || 'Sin dirección'}</span>
                                </p>
                              </div>
                            </div>
                            
                            {/* Right Section - Pricing */}
                            <div className="text-right space-y-2">
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Subtotal</p>
                                <p className="font-medium">${order.subtotal.toFixed(2)}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Envío</p>
                                <p className="font-medium text-orange-600">${order.deliveryFee.toFixed(2)}</p>
                              </div>
                              <div className="pt-2 border-t">
                                <p className="text-sm text-muted-foreground">Total</p>
                                <p className="text-xl font-bold text-primary">${order.total.toFixed(2)}</p>
                              </div>
                              <Badge variant="outline" className="mt-2">
                                {order.paymentMethod === 'CASH' ? '💵 Efectivo' : '💳 Transferencia'}
                              </Badge>
                            </div>
                          </div>
                          
                          {/* Items Count */}
                          <div className="mt-3 pt-3 border-t">
                            <p className="text-xs text-muted-foreground">
                              📦 {order.items.length} artículo{order.items.length !== 1 ? 's' : ''} en el pedido
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
