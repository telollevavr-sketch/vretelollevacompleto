import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { MapView } from '@/components/shared/MapView';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, MapPin, Phone, Navigation, Star, Package, Clock, AlertCircle, Store, X } from 'lucide-react';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { EmptyState } from '@/components/shared/EmptyState';
import { toast } from '@/hooks/use-toast';

interface DeliveryPerson {
  id: string;
  name: string;
  phone: string | null;
  avatar_url: string | null;
  latitude: number | null;
  longitude: number | null;
  vehicle_type: string | null;
  vehicle_plate: string | null;
  rating: number | null;
  review_count: number | null;
}

interface AdminActiveDelivery {
  id: string;
  orderNumber: string;
  total: number;
  deliveryAddress: string;
  deliveryLatitude: number;
  deliveryLongitude: number;
  createdAt: string;
  businessId: string;
  businessName: string;
  businessLocation: { lat: number; lng: number };
  deliveryPerson: DeliveryPerson | null;
}

interface BusinessOption {
  id: string;
  name: string;
}

interface DeliveryPersonOption {
  id: string;
  name: string;
}

export const AdminActiveDeliveries = () => {
  const [activeDeliveries, setActiveDeliveries] = useState<AdminActiveDelivery[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDeliveryId, setSelectedDeliveryId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  
  // Filter states
  const [selectedBusinessId, setSelectedBusinessId] = useState<string>('all');
  const [selectedDeliveryPersonId, setSelectedDeliveryPersonId] = useState<string>('all');

  // Extract unique businesses and delivery persons for filters
  const { businessOptions, deliveryPersonOptions } = useMemo(() => {
    const businesses = new Map<string, BusinessOption>();
    const deliveryPersons = new Map<string, DeliveryPersonOption>();

    activeDeliveries.forEach(delivery => {
      if (!businesses.has(delivery.businessId)) {
        businesses.set(delivery.businessId, {
          id: delivery.businessId,
          name: delivery.businessName
        });
      }
      if (delivery.deliveryPerson && !deliveryPersons.has(delivery.deliveryPerson.id)) {
        deliveryPersons.set(delivery.deliveryPerson.id, {
          id: delivery.deliveryPerson.id,
          name: delivery.deliveryPerson.name
        });
      }
    });

    return {
      businessOptions: Array.from(businesses.values()),
      deliveryPersonOptions: Array.from(deliveryPersons.values())
    };
  }, [activeDeliveries]);

  // Filter deliveries based on selected filters
  const filteredDeliveries = useMemo(() => {
    return activeDeliveries.filter(delivery => {
      const matchesBusiness = selectedBusinessId === 'all' || delivery.businessId === selectedBusinessId;
      const matchesDeliveryPerson = selectedDeliveryPersonId === 'all' || 
        delivery.deliveryPerson?.id === selectedDeliveryPersonId;
      return matchesBusiness && matchesDeliveryPerson;
    });
  }, [activeDeliveries, selectedBusinessId, selectedDeliveryPersonId]);

  // Fetch all active deliveries from all businesses
  const fetchActiveDeliveries = async () => {
    try {
      console.log('📍 [AdminActiveDeliveries] Fetching all active deliveries');
      
      const { data, error } = await supabase
        .from('orders')
        .select(`
          id,
          order_number,
          total,
          delivery_address,
          delivery_latitude,
          delivery_longitude,
          created_at,
          delivery_person_id,
          business_id,
          businesses!inner (
            id,
            name,
            latitude,
            longitude
          )
        `)
        .eq('status', 'in_delivery')
        .not('delivery_person_id', 'is', null);

      if (error) throw error;

      // OPTIMIZACIÓN: Batch query para perfiles de repartidores (elimina N+1)
      const personIds = [...new Set((data || []).map(o => o.delivery_person_id).filter((id): id is string => !!id))];
      
      let personMap = new Map<string, DeliveryPerson>();
      if (personIds.length > 0) {
        const { data: persons } = await supabase
          .from('profiles')
          .select('id, name, phone, avatar_url, latitude, longitude, vehicle_type, vehicle_plate, rating, review_count')
          .in('id', personIds);
        
        personMap = new Map((persons || []).map(p => [p.id, p as DeliveryPerson]));
      }

      const deliveriesWithPersons: AdminActiveDelivery[] = (data || []).map((order) => {
        const business = order.businesses as unknown as { id: string; name: string; latitude: number; longitude: number };

        return {
          id: order.id,
          orderNumber: order.order_number,
          total: order.total,
          deliveryAddress: order.delivery_address,
          deliveryLatitude: order.delivery_latitude,
          deliveryLongitude: order.delivery_longitude,
          createdAt: order.created_at,
          businessId: business.id,
          businessName: business.name,
          businessLocation: {
            lat: business.latitude,
            lng: business.longitude
          },
          deliveryPerson: order.delivery_person_id ? personMap.get(order.delivery_person_id) || null : null
        };
      });

      console.log('📍 [AdminActiveDeliveries] Found deliveries:', deliveriesWithPersons.length);
      setActiveDeliveries(deliveriesWithPersons);
      
      // Auto-select first delivery if none selected
      if (deliveriesWithPersons.length > 0 && !selectedDeliveryId) {
        setSelectedDeliveryId(deliveriesWithPersons[0].id);
      }
    } catch (error) {
      console.error('Error fetching active deliveries:', error);
      toast({
        title: 'Error',
        description: 'No se pudieron cargar las entregas activas',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchActiveDeliveries();
  }, []);

  // Subscribe to all order changes
  useEffect(() => {
    const channel = supabase
      .channel('admin-all-deliveries')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        (payload) => {
          console.log('📦 [AdminActiveDeliveries] Order change detected:', payload);
          fetchActiveDeliveries();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Realtime subscription to profiles removed - locations update only on manual refresh

  // Calculate map locations and routes based on filtered deliveries
  const { mapLocations, mapRoutes } = useMemo(() => {
    const locations: { lat: number; lng: number; name?: string; address?: string; icon: 'business' | 'delivery' | 'client' }[] = [];
    const routes: { orderId: string; orderNumber: string; coordinates: { lat: number; lng: number }[]; color: string }[] = [];

    // If a delivery is selected, show only that one
    const deliveriesToShow = selectedDeliveryId 
      ? filteredDeliveries.filter(d => d.id === selectedDeliveryId)
      : filteredDeliveries;

    // Track unique businesses to add to map
    const addedBusinesses = new Set<string>();

    deliveriesToShow.forEach(delivery => {
      // Add business location (unique per business)
      if (!addedBusinesses.has(delivery.businessId)) {
        locations.push({
          lat: delivery.businessLocation.lat,
          lng: delivery.businessLocation.lng,
          name: delivery.businessName,
          address: 'Ubicación del negocio',
          icon: 'business'
        });
        addedBusinesses.add(delivery.businessId);
      }

      // Add client location
      locations.push({
        lat: delivery.deliveryLatitude,
        lng: delivery.deliveryLongitude,
        name: `Pedido #${delivery.orderNumber}`,
        address: delivery.deliveryAddress,
        icon: 'client'
      });

      // Add delivery person location if available
      if (delivery.deliveryPerson?.latitude && delivery.deliveryPerson?.longitude) {
        locations.push({
          lat: delivery.deliveryPerson.latitude,
          lng: delivery.deliveryPerson.longitude,
          name: delivery.deliveryPerson.name,
          address: `Repartidor - ${delivery.deliveryPerson.vehicle_type || 'Vehículo'}`,
          icon: 'delivery'
        });

        // Create route: Business -> Delivery Person -> Client
        routes.push({
          orderId: delivery.id,
          orderNumber: delivery.orderNumber,
          coordinates: [
            { lat: delivery.businessLocation.lat, lng: delivery.businessLocation.lng },
            { lat: delivery.deliveryPerson.latitude, lng: delivery.deliveryPerson.longitude },
            { lat: delivery.deliveryLatitude, lng: delivery.deliveryLongitude }
          ],
          color: '#f97316'
        });
      } else {
        // Route without delivery person position: Business -> Client
        routes.push({
          orderId: delivery.id,
          orderNumber: delivery.orderNumber,
          coordinates: [
            { lat: delivery.businessLocation.lat, lng: delivery.businessLocation.lng },
            { lat: delivery.deliveryLatitude, lng: delivery.deliveryLongitude }
          ],
          color: '#3b82f6'
        });
      }
    });

    return { mapLocations: locations, mapRoutes: routes };
  }, [filteredDeliveries, selectedDeliveryId]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchActiveDeliveries();
  };

  const handleClearFilters = () => {
    setSelectedBusinessId('all');
    setSelectedDeliveryPersonId('all');
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) return `${diffMins} min`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ${diffMins % 60}min`;
  };

  const hasActiveFilters = selectedBusinessId !== 'all' || selectedDeliveryPersonId !== 'all';

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="bg-[hsl(270,50%,85%)]/90 backdrop-blur rounded-lg p-6 border border-purple-300/30">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2 text-gray-900">
          <span className="bg-purple-100 p-2 rounded-lg">📍</span>
          Entregas en Vivo
          {filteredDeliveries.length > 0 && (
            <Badge className="ml-2 bg-orange-500 text-white">
              {filteredDeliveries.length}
            </Badge>
          )}
        </h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          disabled={refreshing}
          className="border-gray-300 text-gray-900 bg-white hover:bg-gray-100"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Actualizar
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4 mb-6 p-4 bg-white/50 rounded-lg border border-purple-200">
        <span className="text-sm font-medium text-gray-700">Filtros:</span>
        
        <Select value={selectedBusinessId} onValueChange={setSelectedBusinessId}>
          <SelectTrigger className="w-[200px] bg-white border-gray-300 text-gray-900">
            <Store className="h-4 w-4 mr-2 text-gray-500" />
            <SelectValue placeholder="Todos los negocios" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los negocios</SelectItem>
            {businessOptions.map(business => (
              <SelectItem key={business.id} value={business.id}>
                {business.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedDeliveryPersonId} onValueChange={setSelectedDeliveryPersonId}>
          <SelectTrigger className="w-[200px] bg-white border-gray-300 text-gray-900">
            <Navigation className="h-4 w-4 mr-2 text-gray-500" />
            <SelectValue placeholder="Todos los repartidores" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los repartidores</SelectItem>
            {deliveryPersonOptions.map(person => (
              <SelectItem key={person.id} value={person.id}>
                {person.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleClearFilters}
            className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
          >
            <X className="h-4 w-4 mr-1" />
            Limpiar Filtros
          </Button>
        )}
      </div>

      {filteredDeliveries.length === 0 ? (
        <EmptyState
          icon={Navigation}
          title="Sin entregas activas"
          description={hasActiveFilters 
            ? "No hay entregas que coincidan con los filtros seleccionados." 
            : "No hay pedidos en camino en este momento. Los pedidos aparecerán aquí cuando un repartidor los tome."
          }
        />
      ) : (
        <div className="space-y-6">
          {/* Map Section */}
          <Card className="bg-white border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-gray-900 flex items-center gap-2">
                <MapPin className="h-5 w-5 text-orange-500" />
                Mapa de Entregas
                {selectedDeliveryId && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedDeliveryId(null)}
                    className="ml-auto text-xs text-gray-600 hover:text-gray-900"
                  >
                    Ver todas
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <MapView
                locations={mapLocations}
                routes={mapRoutes}
                height="400px"
                zoom={13}
              />
            </CardContent>
          </Card>

          {/* Delivery Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDeliveries.map((delivery) => (
              <Card 
                key={delivery.id}
                className={`bg-white border-purple-200 cursor-pointer transition-all hover:border-orange-400 ${
                  selectedDeliveryId === delivery.id ? 'ring-2 ring-orange-400' : ''
                }`}
                onClick={() => setSelectedDeliveryId(delivery.id)}
              >
                <CardContent className="p-4">
                  {/* Order Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-orange-500" />
                      <span className="font-semibold text-gray-900">#{delivery.orderNumber}</span>
                    </div>
                    <Badge variant="secondary" className="bg-orange-100 text-orange-700 border-orange-200">
                      En camino
                    </Badge>
                  </div>

                  {/* Business Info */}
                  <div className="flex items-center gap-2 mb-3 p-2 bg-purple-50 rounded-lg">
                    <Store className="h-4 w-4 text-purple-600" />
                    <span className="text-sm font-medium text-purple-700">{delivery.businessName}</span>
                  </div>

                  {/* Delivery Person Info */}
                  {delivery.deliveryPerson ? (
                    <div className="flex items-center gap-3 mb-3 p-2 bg-gray-50 rounded-lg">
                      <Avatar className="h-10 w-10 border-2 border-orange-400">
                        <AvatarImage src={delivery.deliveryPerson.avatar_url || undefined} />
                        <AvatarFallback className="bg-orange-500 text-white">
                          {delivery.deliveryPerson.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 truncate">{delivery.deliveryPerson.name}</p>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          {delivery.deliveryPerson.vehicle_type && (
                            <span>{delivery.deliveryPerson.vehicle_type}</span>
                          )}
                          {delivery.deliveryPerson.rating && (
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              {delivery.deliveryPerson.rating.toFixed(1)}
                            </span>
                          )}
                        </div>
                      </div>
                      {delivery.deliveryPerson.phone && (
                        <a 
                          href={`tel:${delivery.deliveryPerson.phone}`}
                          onClick={(e) => e.stopPropagation()}
                          className="p-2 bg-green-100 rounded-full hover:bg-green-200 transition-colors"
                        >
                          <Phone className="h-4 w-4 text-green-600" />
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 mb-3 p-2 bg-yellow-50 rounded-lg text-yellow-700 text-sm">
                      <AlertCircle className="h-4 w-4" />
                      Sin ubicación del repartidor
                    </div>
                  )}

                  {/* Delivery Info */}
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start gap-2 text-gray-600">
                      <MapPin className="h-4 w-4 mt-0.5 text-blue-500 shrink-0" />
                      <span className="line-clamp-2">{delivery.deliveryAddress}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-gray-500">
                        <Clock className="h-4 w-4" />
                        <span>Hace {formatTime(delivery.createdAt)}</span>
                      </div>
                      <span className="font-semibold text-gray-900">
                        ${delivery.total.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* View on Map Button */}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full mt-3 border-orange-300 text-orange-600 hover:bg-orange-50"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedDeliveryId(delivery.id);
                    }}
                  >
                    <Navigation className="h-4 w-4 mr-2" />
                    Ver en Mapa
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
