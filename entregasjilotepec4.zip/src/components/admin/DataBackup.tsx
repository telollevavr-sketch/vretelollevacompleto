import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { useDataBackup, TableStats } from '@/hooks/useDataBackup';
import { 
  exportAllTablesToExcel, 
  generateSQLInsertScripts,
  generateDeleteAndInsertSQL,
  exportToJSON,
  saveBackupToHistory,
  getBackupHistory,
  clearBackupHistory,
  BackupHistoryItem
} from '@/lib/backupExport';
import { 
  Database, 
  Download, 
  FileSpreadsheet, 
  FileCode, 
  FileJson, 
  RefreshCw, 
  Users, 
  Store, 
  Package, 
  ShoppingCart,
  Trash2,
  AlertCircle,
  CheckCircle2,
  Clock,
  HardDrive
} from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { toast } from 'sonner';

export const DataBackup = () => {
  const { data, stats, isLoading, progress, error, fetchAllData } = useDataBackup();
  const [includeImages, setIncludeImages] = useState(false);
  const [selectedTables, setSelectedTables] = useState<Set<string>>(new Set());
  const [backupHistory, setBackupHistory] = useState<BackupHistoryItem[]>([]);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    setBackupHistory(getBackupHistory());
  }, []);

  useEffect(() => {
    if (stats.length > 0) {
      setSelectedTables(new Set(stats.map(s => s.name)));
    }
  }, [stats]);

  const handleLoadData = async () => {
    await fetchAllData(includeImages);
    toast.success('Datos cargados correctamente');
  };

  const handleExportExcel = async () => {
    if (stats.length === 0) {
      toast.error('Primero debes cargar los datos');
      return;
    }
    setIsExporting(true);
    try {
      exportAllTablesToExcel(data, stats);
      const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
      saveBackupToHistory('excel', totalRecords, stats.length);
      setBackupHistory(getBackupHistory());
      toast.success('Archivo Excel generado correctamente');
    } catch (err) {
      toast.error('Error al generar el archivo Excel');
      console.error(err);
    }
    setIsExporting(false);
  };

  const handleExportSQL = async () => {
    if (stats.length === 0) {
      toast.error('Primero debes cargar los datos');
      return;
    }
    setIsExporting(true);
    try {
      generateSQLInsertScripts(data, stats);
      const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
      saveBackupToHistory('sql', totalRecords, stats.length);
      setBackupHistory(getBackupHistory());
      toast.success('Script SQL generado correctamente');
    } catch (err) {
      toast.error('Error al generar el script SQL');
      console.error(err);
    }
    setIsExporting(false);
  };

  const handleExportSQLComplete = async () => {
    if (stats.length === 0) {
      toast.error('Primero debes cargar los datos');
      return;
    }
    setIsExporting(true);
    try {
      generateDeleteAndInsertSQL(data, stats);
      const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
      saveBackupToHistory('sql_complete', totalRecords, stats.length);
      setBackupHistory(getBackupHistory());
      toast.success('Script SQL completo generado correctamente');
    } catch (err) {
      toast.error('Error al generar el script SQL');
      console.error(err);
    }
    setIsExporting(false);
  };

  const handleExportJSON = async () => {
    if (stats.length === 0) {
      toast.error('Primero debes cargar los datos');
      return;
    }
    setIsExporting(true);
    try {
      exportToJSON(data, stats);
      const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
      saveBackupToHistory('json', totalRecords, stats.length);
      setBackupHistory(getBackupHistory());
      toast.success('Archivo JSON generado correctamente');
    } catch (err) {
      toast.error('Error al generar el archivo JSON');
      console.error(err);
    }
    setIsExporting(false);
  };

  const handleClearHistory = () => {
    clearBackupHistory();
    setBackupHistory([]);
    toast.success('Historial limpiado');
  };

  const toggleTable = (tableName: string) => {
    const newSelected = new Set(selectedTables);
    if (newSelected.has(tableName)) {
      newSelected.delete(tableName);
    } else {
      newSelected.add(tableName);
    }
    setSelectedTables(newSelected);
  };

  const toggleAllTables = () => {
    if (selectedTables.size === stats.length) {
      setSelectedTables(new Set());
    } else {
      setSelectedTables(new Set(stats.map(s => s.name)));
    }
  };

  const getImportanceBadge = (importance: string) => {
    switch (importance) {
      case 'alta':
        return <Badge variant="destructive">Alta</Badge>;
      case 'media':
        return <Badge variant="default">Media</Badge>;
      case 'baja':
        return <Badge variant="secondary">Baja</Badge>;
      default:
        return <Badge variant="outline">{importance}</Badge>;
    }
  };

  const getTypeLabel = (type: BackupHistoryItem['type']) => {
    switch (type) {
      case 'excel':
        return 'Excel';
      case 'sql':
        return 'SQL (INSERT)';
      case 'sql_complete':
        return 'SQL (DELETE+INSERT)';
      case 'json':
        return 'JSON';
      default:
        return type;
    }
  };

  const totalRecords = stats.reduce((sum, s) => sum + s.count, 0);
  const lastBackup = backupHistory[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-900/50 to-indigo-900/50 border-purple-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Database className="h-8 w-8 text-purple-400" />
              <div>
                <CardTitle className="text-2xl text-white">Sistema de Respaldo de Datos</CardTitle>
                <CardDescription className="text-purple-200">
                  Exporta todos los datos de tu aplicación para respaldo
                </CardDescription>
              </div>
            </div>
            <Button 
              onClick={handleLoadData} 
              disabled={isLoading}
              variant="secondary"
              size="lg"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              {stats.length === 0 ? 'Cargar Datos' : 'Actualizar Datos'}
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Progress */}
      {isLoading && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Cargando datos...</span>
                <span className="font-medium">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error */}
      {error && (
        <Card className="border-destructive">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              <span>{error}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      {stats.length > 0 && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-card border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-black">Usuarios</p>
                    <p className="text-3xl font-bold text-black">{data.profiles.length}</p>
                  </div>
                  <Users className="h-10 w-10 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-black">Negocios</p>
                    <p className="text-3xl font-bold text-black">{data.businesses.length}</p>
                  </div>
                  <Store className="h-10 w-10 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-black">Productos</p>
                    <p className="text-3xl font-bold text-black">{data.products.length}</p>
                  </div>
                  <Package className="h-10 w-10 text-orange-500" />
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-black">Pedidos</p>
                    <p className="text-3xl font-bold text-black">{data.orders.length}</p>
                  </div>
                  <ShoppingCart className="h-10 w-10 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Summary info */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap items-center gap-6">
                <div className="flex items-center gap-2">
                  <HardDrive className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Total de registros:</span>
                  <span className="font-bold text-lg">{totalRecords.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Tablas:</span>
                  <span className="font-bold text-lg">{stats.length}</span>
                </div>
                {lastBackup && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Último respaldo:</span>
                    <span className="font-medium">
                      {format(new Date(lastBackup.date), "dd/MM/yyyy HH:mm", { locale: es })}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Table list */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Tablas para Respaldar</CardTitle>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 text-sm">
                    <Checkbox 
                      checked={includeImages} 
                      onCheckedChange={(checked) => setIncludeImages(checked === true)}
                    />
                    <span>Incluir imágenes (aumenta tamaño)</span>
                  </label>
                  <Button variant="outline" size="sm" onClick={toggleAllTables}>
                    {selectedTables.size === stats.length ? 'Deseleccionar todo' : 'Seleccionar todo'}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox 
                        checked={selectedTables.size === stats.length}
                        onCheckedChange={toggleAllTables}
                      />
                    </TableHead>
                    <TableHead>Tabla</TableHead>
                    <TableHead className="text-right">Registros</TableHead>
                    <TableHead className="text-right">Tamaño Est.</TableHead>
                    <TableHead className="text-center">Importancia</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.map((stat) => (
                    <TableRow key={stat.name}>
                      <TableCell>
                        <Checkbox 
                          checked={selectedTables.has(stat.name)}
                          onCheckedChange={() => toggleTable(stat.name)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{stat.displayName}</TableCell>
                      <TableCell className="text-right">{stat.count.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{stat.estimatedSize}</TableCell>
                      <TableCell className="text-center">{getImportanceBadge(stat.importance)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Export buttons */}
          <Card>
            <CardHeader>
              <CardTitle>Opciones de Exportación</CardTitle>
              <CardDescription>
                Selecciona el formato de respaldo que prefieras
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button 
                  onClick={handleExportExcel} 
                  disabled={isExporting || stats.length === 0}
                  className="h-auto py-4 flex flex-col items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <FileSpreadsheet className="h-8 w-8" />
                  <span className="font-medium">Exportar a Excel</span>
                  <span className="text-xs opacity-80">Recomendado</span>
                </Button>

                <Button 
                  onClick={handleExportSQL} 
                  disabled={isExporting || stats.length === 0}
                  className="h-auto py-4 flex flex-col items-center gap-2 bg-blue-600 hover:bg-blue-700"
                >
                  <FileCode className="h-8 w-8" />
                  <span className="font-medium">SQL (INSERT)</span>
                  <span className="text-xs opacity-80">Para agregar datos</span>
                </Button>

                <Button 
                  onClick={handleExportSQLComplete} 
                  disabled={isExporting || stats.length === 0}
                  className="h-auto py-4 flex flex-col items-center gap-2 bg-red-600 hover:bg-red-700"
                >
                  <FileCode className="h-8 w-8" />
                  <span className="font-medium">SQL Completo</span>
                  <span className="text-xs opacity-80">DELETE + INSERT</span>
                </Button>

                <Button 
                  onClick={handleExportJSON} 
                  disabled={isExporting || stats.length === 0}
                  className="h-auto py-4 flex flex-col items-center gap-2 bg-purple-600 hover:bg-purple-700"
                >
                  <FileJson className="h-8 w-8" />
                  <span className="font-medium">Exportar JSON</span>
                  <span className="text-xs opacity-80">Programático</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Empty state */}
      {!isLoading && stats.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <Database className="h-16 w-16 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium mb-2">No hay datos cargados</h3>
              <p className="text-muted-foreground mb-4">
                Haz clic en "Cargar Datos" para obtener la información de todas las tablas
              </p>
              <Button onClick={handleLoadData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Cargar Datos
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Backup history */}
      {backupHistory.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Historial de Respaldos</CardTitle>
              <Button variant="ghost" size="sm" onClick={handleClearHistory}>
                <Trash2 className="h-4 w-4 mr-2" />
                Limpiar historial
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {backupHistory.slice(0, 10).map((item, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                >
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <div>
                      <p className="font-medium">
                        {format(new Date(item.date), "dd 'de' MMMM 'de' yyyy, HH:mm", { locale: es })}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {getTypeLabel(item.type)} - {item.records.toLocaleString()} registros en {item.tables} tablas
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
