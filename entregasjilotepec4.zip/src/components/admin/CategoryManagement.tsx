import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useCategories } from '@/hooks/useCategories';
import { useToast } from '@/hooks/use-toast';
import { Tags, Plus, Edit2, Trash2, Search, Download } from 'lucide-react';
import * as XLSX from 'xlsx';

export function CategoryManagement() {
  const { allCategories, createCategory, updateCategory, deleteCategory } = useCategories();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<any>(null);
  
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    icon: '',
  });

  const filteredCategories = allCategories.filter(cat =>
    cat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreate = () => {
    if (!newCategory.name.trim()) return;
    
    createCategory({
      name: newCategory.name,
      description: newCategory.description || null,
      icon: newCategory.icon || null,
      is_active: true,
    });
    
    setNewCategory({ name: '', description: '', icon: '' });
    setIsCreateOpen(false);
  };

  const handleUpdate = () => {
    if (!editingCategory) return;
    
    updateCategory({
      id: editingCategory.id,
      updates: {
        name: editingCategory.name,
        description: editingCategory.description || null,
        icon: editingCategory.icon || null,
      }
    });
    
    setEditingCategory(null);
  };

  const handleToggleActive = (categoryId: string, currentStatus: boolean) => {
    updateCategory({
      id: categoryId,
      updates: { is_active: !currentStatus }
    });
  };

  const handleExportToExcel = () => {
    if (filteredCategories.length === 0) {
      toast({
        title: "Sin datos",
        description: "No hay categorías para exportar",
        variant: "destructive"
      });
      return;
    }

    const dataToExport = filteredCategories.map(category => ({
      'Nombre': category.name,
      'Descripción': category.description || '',
      'Icono': category.icon || '',
      'Estado': category.is_active ? 'Activa' : 'Inactiva',
      'Fecha Creación': new Date(category.created_at).toLocaleDateString('es-ES'),
      'Última Actualización': new Date(category.updated_at).toLocaleDateString('es-ES')
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Categorías');

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `categorias_${date}.xlsx`);

    toast({
      title: "Exportación exitosa",
      description: `Se exportaron ${filteredCategories.length} categorías`
    });
  };

  return (
    <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="flex items-center gap-2">
            <Tags className="h-5 w-5" />
            Gestión de Categorías
            <Badge variant="secondary" className="ml-2">
              {filteredCategories.length}
            </Badge>
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button onClick={handleExportToExcel} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Exportar a Excel
            </Button>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nueva Categoría
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Crear Nueva Categoría</DialogTitle>
                <DialogDescription>
                  Agrega una nueva categoría para los negocios
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Nombre *</Label>
                  <Input
                    id="name"
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    placeholder="Ej: Italiana"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    value={newCategory.description}
                    onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                    placeholder="Descripción de la categoría"
                  />
                </div>
                <div>
                  <Label htmlFor="icon">Icono (emoji)</Label>
                  <Input
                    id="icon"
                    value={newCategory.icon}
                    onChange={(e) => setNewCategory({ ...newCategory, icon: e.target.value })}
                    placeholder="🍕"
                    maxLength={2}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleCreate}>Crear</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar categorías..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-4">
          {filteredCategories.map(category => (
            <div key={category.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-3 flex-wrap">
                  {category.icon && <span className="text-2xl">{category.icon}</span>}
                  <h3 className="font-semibold">{category.name}</h3>
                  <Badge variant={category.is_active ? 'default' : 'secondary'}>
                    {category.is_active ? 'Activa' : 'Inactiva'}
                  </Badge>
                </div>
                {category.description && (
                  <p className="text-sm text-muted-foreground">
                    {category.description}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-3 ml-4">
                <div className="flex items-center gap-2">
                  <Label htmlFor={`active-${category.id}`} className="text-sm whitespace-nowrap">
                    Activa
                  </Label>
                  <Switch
                    id={`active-${category.id}`}
                    checked={category.is_active}
                    onCheckedChange={() => handleToggleActive(category.id, category.is_active)}
                  />
                </div>

                <Dialog open={editingCategory?.id === category.id} onOpenChange={(open) => !open && setEditingCategory(null)}>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingCategory(category)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Editar Categoría</DialogTitle>
                      <DialogDescription>
                        Modifica los datos de la categoría
                      </DialogDescription>
                    </DialogHeader>
                    {editingCategory && (
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="edit-name">Nombre *</Label>
                          <Input
                            id="edit-name"
                            value={editingCategory.name}
                            onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="edit-description">Descripción</Label>
                          <Textarea
                            id="edit-description"
                            value={editingCategory.description || ''}
                            onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="edit-icon">Icono (emoji)</Label>
                          <Input
                            id="edit-icon"
                            value={editingCategory.icon || ''}
                            onChange={(e) => setEditingCategory({ ...editingCategory, icon: e.target.value })}
                            maxLength={2}
                          />
                        </div>
                      </div>
                    )}
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEditingCategory(null)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleUpdate}>Guardar</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Eliminar categoría?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta acción no se puede deshacer. Los negocios que usan esta categoría deberán actualizarse manualmente.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => deleteCategory(category.id)}>
                        Eliminar
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}

          {filteredCategories.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No se encontraron categorías
            </div>
          )}
        </div>

        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <h4 className="font-semibold mb-2">Estadísticas</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Total:</span>
              <span className="ml-2 font-semibold">{allCategories.length}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Activas:</span>
              <span className="ml-2 font-semibold">
                {allCategories.filter(c => c.is_active).length}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
