import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Copy, MessageCircle, Check, Loader2, Key, Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PasswordResetModalProps {
  open: boolean;
  onClose: () => void;
  userName: string;
  userPhone?: string | null;
  tempPassword: string | null;
  isLoading: boolean;
  onReset: (customPassword?: string) => void;
}

export function PasswordResetModal({
  open,
  onClose,
  userName,
  userPhone,
  tempPassword,
  isLoading,
  onReset,
}: PasswordResetModalProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [passwordMode, setPasswordMode] = useState<'auto' | 'custom'>('auto');
  const [customPassword, setCustomPassword] = useState('');
  const [showCustomPassword, setShowCustomPassword] = useState(false);

  const isCustomPasswordValid = customPassword.length >= 6;
  const canSubmit = passwordMode === 'auto' || isCustomPasswordValid;

  const handleCopyPassword = async () => {
    const passwordToCopy = tempPassword || (passwordMode === 'custom' ? customPassword : null);
    if (!passwordToCopy) return;
    
    try {
      await navigator.clipboard.writeText(passwordToCopy);
      setCopied(true);
      toast({
        title: 'Copiado',
        description: 'Contraseña copiada al portapapeles',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({
        title: 'Error',
        description: 'No se pudo copiar al portapapeles',
        variant: 'destructive',
      });
    }
  };

  const handleSendWhatsApp = () => {
    if (!tempPassword || !userPhone) return;
    
    const message = encodeURIComponent(
      `¡Hola! Tu nueva contraseña temporal para VRTELoLleva es: ${tempPassword}\n\nPor tu seguridad, te recomendamos cambiar esta contraseña después de iniciar sesión.\n\n- Equipo VRTELoLleva`
    );
    
    // Clean phone number
    const cleanPhone = userPhone.replace(/[\s\-\(\)+]/g, '');
    const phoneWithCountry = cleanPhone.startsWith('52') ? cleanPhone : `52${cleanPhone}`;
    
    window.open(`https://wa.me/${phoneWithCountry}?text=${message}`, '_blank');
  };

  const handleSubmit = () => {
    if (passwordMode === 'custom') {
      onReset(customPassword);
    } else {
      onReset(undefined);
    }
  };

  const handleClose = () => {
    setCopied(false);
    setPasswordMode('auto');
    setCustomPassword('');
    setShowCustomPassword(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Resetear Contraseña
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <p className="text-sm text-muted-foreground">
            Usuario: <span className="font-medium text-foreground">{userName}</span>
          </p>

          {!tempPassword ? (
            <div className="space-y-4">
              <RadioGroup
                value={passwordMode}
                onValueChange={(value) => setPasswordMode(value as 'auto' | 'custom')}
                className="space-y-3"
              >
                <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                  <RadioGroupItem value="auto" id="auto" />
                  <Label htmlFor="auto" className="flex-1 cursor-pointer">
                    <span className="font-medium">Generar contraseña automática</span>
                    <p className="text-sm text-muted-foreground">
                      Se generará una contraseña aleatoria de 8 caracteres
                    </p>
                  </Label>
                </div>
                
                <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                  <RadioGroupItem value="custom" id="custom" />
                  <Label htmlFor="custom" className="flex-1 cursor-pointer">
                    <span className="font-medium">Escribir contraseña personalizada</span>
                    <p className="text-sm text-muted-foreground">
                      Ingresa manualmente la nueva contraseña
                    </p>
                  </Label>
                </div>
              </RadioGroup>

              {passwordMode === 'custom' && (
                <div className="space-y-2 pl-1">
                  <Label htmlFor="customPassword">Nueva contraseña</Label>
                  <div className="relative">
                    <Input
                      id="customPassword"
                      type={showCustomPassword ? 'text' : 'password'}
                      value={customPassword}
                      onChange={(e) => setCustomPassword(e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      onClick={() => setShowCustomPassword(!showCustomPassword)}
                    >
                      {showCustomPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                  {customPassword.length > 0 && !isCustomPasswordValid && (
                    <p className="text-sm text-destructive">
                      La contraseña debe tener al menos 6 caracteres
                    </p>
                  )}
                </div>
              )}

              <Button 
                onClick={handleSubmit} 
                disabled={isLoading || !canSubmit}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    {passwordMode === 'custom' ? 'Cambiando...' : 'Generando...'}
                  </>
                ) : (
                  passwordMode === 'custom' ? 'Cambiar Contraseña' : 'Generar Contraseña Temporal'
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Nueva contraseña:</p>
                <div className="flex items-center justify-between bg-background p-3 rounded-lg border">
                  <code className="text-lg font-mono font-bold tracking-wider">
                    {tempPassword}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleCopyPassword}
                  >
                    {copied ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleCopyPassword}
                  className="flex-1"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copiar
                </Button>
                
                {userPhone && (
                  <Button
                    onClick={handleSendWhatsApp}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Enviar por WhatsApp
                  </Button>
                )}
              </div>

              <p className="text-xs text-muted-foreground text-center">
                Esta contraseña solo se muestra una vez. Asegúrate de compartirla con el usuario.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
