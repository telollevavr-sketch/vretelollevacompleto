import { useState } from 'react';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useOrders } from '@/hooks/useOrders';
import { useAuth } from '@/contexts/AuthContext';
import { MapView } from '@/components/shared/MapView';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { OrderStatus } from '@/types';
import { startOfDay, endOfDay, format } from 'date-fns';
import { es } from 'date-fns/locale';
import { MapPin, Filter, X, Store, Home, User as UserIcon, Phone } from 'lucide-react';
import { DateRange } from 'react-day-picker';

interface MapLocation {
  lat: number;
  lng: number;
  name?: string;
  address?: string;
  icon?: 'business' | 'client';
}

export const AdminOrdersMap = () => {
  const { user } = useAuth();
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [selectedBusinessId, setSelectedBusinessId] = useState<string>('all');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const { orders } = useOrders(user?.id, 'admin');
  const { businesses } = useAllBusinesses();

  const filteredOrders = orders.filter(order => {
    if (dateRange?.from) {
      const orderDate = new Date(order.createdAt);
      if (dateRange.to) {
        if (orderDate < startOfDay(dateRange.from) || orderDate > endOfDay(dateRange.to)) return false;
      } else {
        if (orderDate < startOfDay(dateRange.from)) return false;
      }
    }
    
    if (selectedBusinessId !== 'all' && order.businessId !== selectedBusinessId) {
      return false;
    }
    
    return true;
  });

  const mapLocations: MapLocation[] = [];
  const addedBusinesses = new Set<string>();
  
  filteredOrders.forEach(order => {
    const business = businesses.find(b => b.id === order.businessId);
    if (business && business.location && !addedBusinesses.has(business.id)) {
      mapLocations.push({
        lat: business.location.lat,
        lng: business.location.lng,
        name: business.name,
        address: business.fullAddress || business.address,
        icon: 'business'
      });
      addedBusinesses.add(business.id);
    }
    
    if (order.deliveryLocation) {
      mapLocations.push({
        lat: order.deliveryLocation.lat,
        lng: order.deliveryLocation.lng,
        name: `Entrega - Orden #${order.id.slice(0, 8)}`,
        address: order.deliveryLocation.address,
        icon: 'client'
      });
    }
  });

  const handleClearFilters = () => {
    setDateRange(undefined);
    setSelectedBusinessId('all');
    setSelectedOrderId(null);
  };

  const hasActiveFilters = dateRange?.from || selectedBusinessId !== 'all';

  return (
    <div className="space-y-6">
      <Card className="bg-white/95 backdrop-blur border-purple-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-purple-900 flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filtros
            </h3>
            {hasActiveFilters && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleClearFilters}
                className="text-purple-600 hover:text-purple-700"
              >
                <X className="h-4 w-4 mr-1" />
                Limpiar filtros
              </Button>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-purple-900">
                Rango de Fechas
              </label>
              <DateRangePicker 
                dateRange={dateRange}
                onDateRangeChange={setDateRange}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-purple-900">
                Negocio
              </label>
              <Select value={selectedBusinessId} onValueChange={setSelectedBusinessId}>
                <SelectTrigger className="bg-white border-purple-200">
                  <SelectValue placeholder="Todos los negocios" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los negocios</SelectItem>
                  {businesses.map(business => (
                    <SelectItem key={business.id} value={business.id}>
                      {business.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mt-4 flex items-center gap-2 text-sm text-purple-700">
            <MapPin className="h-4 w-4" />
            Mostrando {filteredOrders.length} pedido(s)
            {dateRange?.from && (
              <span>
                desde {format(dateRange.from, 'dd/MMM/yyyy', { locale: es })}
                {dateRange.to && ` hasta ${format(dateRange.to, 'dd/MMM/yyyy', { locale: es })}`}
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-white/95 backdrop-blur border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-purple-900">
                Mapa de Ubicaciones
              </h3>
              <div className="flex items-center gap-2 text-sm">
                <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-300">
                  <Store className="h-3 w-3 mr-1" />
                  Negocios
                </Badge>
                <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-300">
                  <Home className="h-3 w-3 mr-1" />
                  Entregas
                </Badge>
              </div>
            </div>
            
            <div className="rounded-lg overflow-hidden border-2 border-purple-200">
              <MapView 
                locations={mapLocations}
                interactive={true}
                height="600px"
              />
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-800">
                💡 <strong>Mapa Estático:</strong> Las ubicaciones se actualizan solo cuando refrescas la pantalla o cambias los filtros.
                Los íconos naranjas representan negocios y los azules las ubicaciones de entrega.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/95 backdrop-blur border-purple-200">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-purple-900 mb-4">
              Pedidos ({filteredOrders.length})
            </h3>
            
            <ScrollArea className="h-[650px] pr-4">
              {filteredOrders.length === 0 ? (
                <div className="text-center py-8 text-purple-400">
                  No hay pedidos que coincidan con los filtros
                </div>
              ) : (
                <div className="space-y-3">
                {filteredOrders.map(order => {
                    return (
                      <Card 
                        key={order.id}
                        className={`cursor-pointer transition-all hover:shadow-md ${
                          selectedOrderId === order.id 
                            ? 'border-2 border-purple-500 bg-purple-50' 
                            : 'border border-purple-200'
                        }`}
                        onClick={() => setSelectedOrderId(selectedOrderId === order.id ? null : order.id)}
                      >
                        <CardContent className="p-4">
                          <div className="space-y-2">
                          <div className="flex items-center gap-2">
                              <Store className="h-4 w-4 text-orange-600" />
                              <span className="font-semibold text-sm">{order.businessName || 'N/A'}</span>
                            </div>
                            
                            {/* Client Info */}
                            {order.clientInfo && (
                              <div className="bg-blue-50 rounded p-2 border border-blue-200">
                                <div className="flex items-center gap-1 text-sm">
                                  <UserIcon className="h-3 w-3 text-blue-600" />
                                  <span className="font-medium">{order.clientInfo.name}</span>
                                </div>
                                {order.clientInfo.phone && (
                                  <div className="flex items-center gap-1 text-xs text-gray-600 mt-1">
                                    <Phone className="h-3 w-3" />
                                    <span>{order.clientInfo.phone}</span>
                                  </div>
                                )}
                              </div>
                            )}
                            
                            <div className="flex items-center justify-between">
                              <Badge variant={
                                order.status === OrderStatus.DELIVERED ? 'default' :
                                order.status === OrderStatus.CANCELLED ? 'destructive' :
                                'secondary'
                              }>
                                {order.status}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {format(new Date(order.createdAt), 'dd/MMM HH:mm', { locale: es })}
                              </span>
                            </div>
                            
                            <div className="flex items-start gap-2 text-xs text-gray-600">
                              <Home className="h-3 w-3 mt-0.5 flex-shrink-0 text-blue-600" />
                              <span className="line-clamp-2">{order.deliveryLocation.address || 'Sin dirección'}</span>
                            </div>
                            
                            <div className="pt-2 border-t border-gray-200 flex justify-between items-center">
                              <span className="text-xs text-gray-500">Total:</span>
                              <span className="font-bold text-purple-700">${order.total.toFixed(2)}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
