import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Search, Pencil, ChevronLeft, ChevronRight } from 'lucide-react';
import {
  useManualOrders,
  MANUAL_ORDERS_PAGE_SIZE,
  type ManualOrderRow,
} from '@/hooks/useManualOrders';

export const ManualOrdersEditor = () => {
  const { toast } = useToast();
  const [input, setInput] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<ManualOrderRow | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(input);
      setPage(0);
    }, 400);
    return () => clearTimeout(t);
  }, [input]);

  const { orders, isLoading, isFetching, updateClient, isUpdating } = useManualOrders(search, page);

  const openEdit = (o: ManualOrderRow) => {
    setEditing(o);
    setName(o.manual_client_name || '');
    setPhone(o.manual_client_phone || '');
  };

  const save = async () => {
    if (!editing) return;
    const nameClean = name.trim();
    const phoneClean = phone.trim();
    if (!nameClean) {
      toast({ title: 'Falta cliente', description: 'Escribe el nombre del cliente', variant: 'destructive' });
      return;
    }
    if (nameClean.length > 100) {
      toast({ title: 'Nombre muy largo', description: 'Máximo 100 caracteres', variant: 'destructive' });
      return;
    }
    if (phoneClean.length > 20) {
      toast({ title: 'Teléfono inválido', description: 'Máximo 20 caracteres', variant: 'destructive' });
      return;
    }
    await updateClient({ id: editing.id, name: nameClean, phone: phoneClean || null });
    setEditing(null);
  };

  return (
    <Card className="bg-[hsl(270,50%,15%)]/60 border-purple-300/20 text-white">
      <CardHeader>
        <CardTitle>Pedidos capturados manualmente</CardTitle>
        <CardDescription className="text-white/70">
          Busca un pedido manual y corrige el nombre o teléfono del cliente. No se modifican productos, totales ni fechas.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-black/50" />
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Buscar por número de pedido, cliente o teléfono"
            className="bg-white text-black pl-9"
          />
        </div>

        <div className="rounded-lg overflow-hidden border border-white/10 bg-white">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-black">
              <thead className="bg-purple-100 text-black">
                <tr>
                  <th className="text-left p-2">Pedido</th>
                  <th className="text-left p-2">Fecha</th>
                  <th className="text-left p-2">Negocio</th>
                  <th className="text-left p-2">Cliente</th>
                  <th className="text-left p-2">Teléfono</th>
                  <th className="text-right p-2">Total</th>
                  <th className="text-right p-2">Acción</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-4 text-center text-black/60">Cargando...</td>
                  </tr>
                ) : orders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-4 text-center text-black/60">
                      No se encontraron pedidos manuales.
                    </td>
                  </tr>
                ) : (
                  orders.map((o) => (
                    <tr key={o.id} className="border-t border-black/10">
                      <td className="p-2 font-medium">{o.order_number}</td>
                      <td className="p-2">{new Date(o.created_at).toLocaleString('es-MX')}</td>
                      <td className="p-2">{o.businessName || '—'}</td>
                      <td className="p-2">{o.manual_client_name || '—'}</td>
                      <td className="p-2">{o.manual_client_phone || '—'}</td>
                      <td className="p-2 text-right">${o.total.toFixed(2)}</td>
                      <td className="p-2 text-right">
                        <Button size="sm" variant="outline" onClick={() => openEdit(o)}>
                          <Pencil className="h-3.5 w-3.5 mr-1" /> Editar
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-white/70">
            Página {page + 1}{isFetching ? ' · actualizando...' : ''}
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-white text-black"
              disabled={page === 0 || isFetching}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
            >
              <ChevronLeft className="h-4 w-4" /> Anterior
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="bg-white text-black"
              disabled={orders.length < MANUAL_ORDERS_PAGE_SIZE || isFetching}
              onClick={() => setPage((p) => p + 1)}
            >
              Siguiente <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="bg-white text-black">
          <DialogHeader>
            <DialogTitle>Editar cliente del pedido {editing?.order_number}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Nombre del cliente</Label>
              <Input value={name} maxLength={100} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Teléfono del cliente (opcional)</Label>
              <Input value={phone} maxLength={20} inputMode="tel" onChange={(e) => setPhone(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)} disabled={isUpdating}>
              Cancelar
            </Button>
            <Button
              onClick={save}
              disabled={isUpdating}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {isUpdating ? 'Guardando...' : 'Guardar cambios'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};
