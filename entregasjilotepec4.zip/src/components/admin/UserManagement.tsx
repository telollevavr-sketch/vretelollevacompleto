import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { useUsers } from '@/hooks/useUsers';
import { Trash2, Search, UserCog, Download, Key } from 'lucide-react';
import * as XLSX from 'xlsx';
import { useToast } from '@/hooks/use-toast';
import { PasswordResetModal } from './PasswordResetModal';

export function UserManagement() {
  const { users, updateUser, deleteUser, updateUserRole, resetUserPassword } = useUsers();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<{ id: string; name: string; phone?: string | null } | null>(null);
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleToggleActive = (userId: string, currentStatus: boolean) => {
    updateUser({
      id: userId,
      updates: { is_active: !currentStatus }
    });
  };

  const handleRoleChange = (userId: string, newRole: string) => {
    updateUserRole({ userId, newRole: newRole as any });
  };

  const handleOpenResetModal = (user: { id: string; name: string; phone?: string | null }) => {
    setSelectedUser(user);
    setTempPassword(null);
    setResetModalOpen(true);
  };

  const handleResetPassword = async (customPassword?: string) => {
    if (!selectedUser) return;
    
    setIsResetting(true);
    const result = await resetUserPassword(selectedUser.id, customPassword);
    setIsResetting(false);

    if (result.success) {
      setTempPassword(result.tempPassword || null);
      toast({
        title: 'Contraseña reseteada',
        description: 'La contraseña temporal ha sido generada',
      });
    } else {
      toast({
        title: 'Error',
        description: result.error || 'No se pudo resetear la contraseña',
        variant: 'destructive',
      });
    }
  };

  const handleCloseResetModal = () => {
    setResetModalOpen(false);
    setSelectedUser(null);
    setTempPassword(null);
  };

  const handleExportToExcel = () => {
    try {
      const dataToExport = filteredUsers.map(user => ({
        'Nombre': user.name,
        'Email': user.email,
        'Teléfono': user.phone || 'N/A',
        'Rol': user.role || 'Sin rol',
        'Estado': user.is_active ? 'Activo' : 'Inactivo',
        'Dirección': user.address || 'N/A',
      }));

      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Usuarios');

      const date = new Date().toISOString().split('T')[0];
      XLSX.writeFile(workbook, `usuarios_${date}.xlsx`);

      toast({
        title: 'Exportación exitosa',
        description: `Se exportaron ${filteredUsers.length} usuarios a Excel`,
      });
    } catch (error) {
      toast({
        title: 'Error al exportar',
        description: 'No se pudo exportar el archivo',
        variant: 'destructive',
      });
    }
  };

  return (
    <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="flex items-center gap-2">
            <UserCog className="h-5 w-5" />
            Gestión de Usuarios
          </CardTitle>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="text-sm px-3 py-1">
              {filteredUsers.length} usuario{filteredUsers.length !== 1 ? 's' : ''} filtrado{filteredUsers.length !== 1 ? 's' : ''}
            </Badge>
            <Button 
              onClick={handleExportToExcel}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Exportar a Excel
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar usuarios..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por rol" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los roles</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
              <SelectItem value="client">Cliente</SelectItem>
              <SelectItem value="business">Negocio</SelectItem>
              <SelectItem value="delivery">Repartidor</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {filteredUsers.map(user => (
            <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <h3 className="font-semibold">{user.name}</h3>
                  <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                    {user.role || 'Sin rol'}
                  </Badge>
                  <Badge variant={user.is_active ? 'default' : 'secondary'}>
                    {user.is_active ? 'Activo' : 'Inactivo'}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {user.email}
                </p>
                {user.phone && (
                  <p className="text-sm text-muted-foreground">
                    Tel: {user.phone}
                  </p>
                )}
              </div>

              <div className="flex gap-4 items-center flex-wrap">
                <div className="flex items-center gap-2">
                  <Label htmlFor={`active-${user.id}`} className="text-sm">
                    Activo
                  </Label>
                  <Switch
                    id={`active-${user.id}`}
                    checked={user.is_active}
                    onCheckedChange={() => handleToggleActive(user.id, user.is_active || false)}
                  />
                </div>

                <Select
                  value={user.role || 'client'}
                  onValueChange={(value) => handleRoleChange(user.id, value)}
                >
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Rol" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="client">Cliente</SelectItem>
                    <SelectItem value="business">Negocio</SelectItem>
                    <SelectItem value="delivery">Repartidor</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>

                {/* Reset Password button - for client, business and delivery roles */}
                {(user.role === 'client' || user.role === 'business' || user.role === 'delivery') && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleOpenResetModal({ id: user.id, name: user.name, phone: user.phone })}
                    title="Resetear contraseña"
                  >
                    <Key className="h-4 w-4" />
                  </Button>
                )}

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Eliminar usuario?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta acción no se puede deshacer. Se eliminará permanentemente el usuario y todos sus datos.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => deleteUser(user.id)}>
                        Eliminar
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}

          {filteredUsers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No se encontraron usuarios
            </div>
          )}
        </div>
      </CardContent>

      {/* Password Reset Modal */}
      <PasswordResetModal
        open={resetModalOpen}
        onClose={handleCloseResetModal}
        userName={selectedUser?.name || ''}
        userPhone={selectedUser?.phone}
        tempPassword={tempPassword}
        isLoading={isResetting}
        onReset={handleResetPassword}
      />
    </Card>
  );
}
