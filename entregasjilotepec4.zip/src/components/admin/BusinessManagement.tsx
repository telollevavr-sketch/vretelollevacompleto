import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useToast } from '@/hooks/use-toast';
import { Store, Search, Trash2, Pizza, Download, MapPin, CloudRain } from 'lucide-react';
import * as XLSX from 'xlsx';

export function BusinessManagement() {
  const { businesses, updateBusiness, deleteBusiness } = useAllBusinesses();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredBusinesses = businesses.filter(business =>
    business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleToggleActive = (businessId: string, currentStatus: boolean) => {
    updateBusiness({
      id: businessId,
      updates: { is_active: !currentStatus }
    });
  };

const handleToggleOpen = (businessId: string, currentStatus: boolean) => {
    updateBusiness({
      id: businessId,
      updates: { is_open: !currentStatus }
    });
  };

  const handleToggleComingSoon = (businessId: string, currentStatus: boolean) => {
    updateBusiness({
      id: businessId,
      updates: { is_coming_soon: !currentStatus }
    });
  };

  const handleToggleWeather = (businessId: string, currentStatus: boolean) => {
    updateBusiness({
      id: businessId,
      updates: { weather_unavailable: !currentStatus } as any
    });
  };

  const handleBusinessTypeChange = (businessId: string, isSpecial: boolean) => {
    updateBusiness({
      id: businessId,
      updates: { is_special_business: isSpecial }
    });
  };

  const handleToggleDeliveryTracking = (businessId: string, currentStatus: boolean) => {
    updateBusiness({
      id: businessId,
      updates: { delivery_tracking_enabled: !currentStatus }
    });
  };

  const handleExportToExcel = () => {
    if (filteredBusinesses.length === 0) {
      toast({
        title: "Sin datos",
        description: "No hay negocios para exportar",
        variant: "destructive"
      });
      return;
    }

    const dataToExport = filteredBusinesses.map(business => ({
      'Nombre': business.name,
      'Categoría': business.category,
      'Descripción': business.description || '',
      'Teléfono': business.phone,
      'Dirección': business.fullAddress || business.address,
      'Rating': business.rating.toFixed(1),
      'Reseñas': business.reviewCount,
      'Tarifa Envío': business.freeDelivery ? 'Gratis' : `$${business.deliveryFee}`,
      'Envío Gratis': business.freeDelivery ? 'Sí' : 'No',
      'Pedido Mínimo': `$${business.minOrderAmount}`,
      'Tiempo Entrega (min)': business.deliveryTime,
      'Radio Entrega (km)': business.deliveryRadius,
      'Aprobado': business.isApproved ? 'Sí' : 'No',
      'Abierto': business.isOpen ? 'Sí' : 'No',
      'Próximamente': (business as any).isComingSoon ? 'Sí' : 'No',
      'Verifica Disponibilidad (Clima)': (business as any).weatherUnavailable ? 'Sí' : 'No',
      'Tipo Especial': business.isSpecialBusiness ? 'Sí' : 'No',
      'Seguimiento Entregas': (business as any).deliveryTrackingEnabled ? 'Sí' : 'No',
      'Días de Servicio': business.businessDays || '',
      'Horario': business.businessHours || '',
      'Fecha Creación': business.createdAt
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Negocios');

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `negocios_${date}.xlsx`);

    toast({
      title: "Exportación exitosa",
      description: `Se exportaron ${filteredBusinesses.length} negocios`
    });
  };

  return (
    <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            Gestión de Negocios
            <Badge variant="secondary" className="ml-2">
              {filteredBusinesses.length}
            </Badge>
          </CardTitle>
          <Button onClick={handleExportToExcel} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar negocios..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-4">
          {filteredBusinesses.map(business => (
            <div key={business.id} className="flex items-start justify-between p-4 border rounded-lg">
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <h3 className="font-semibold">{business.name}</h3>
                  <Badge variant={business.isApproved ? 'default' : 'secondary'}>
                    {business.isApproved ? 'Aprobado' : 'Pendiente'}
                  </Badge>
                  <Badge variant={business.isOpen ? 'default' : 'secondary'}>
                    {business.isOpen ? 'Abierto' : 'Cerrado'}
                  </Badge>
                  {(business as any).isComingSoon && (
                    <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-300">
                      🚧 Próximamente
                    </Badge>
                  )}
                  {(business as any).weatherUnavailable && (
                    <Badge variant="outline" className="bg-sky-100 text-sky-800 border-sky-300">
                      ☔ Verifica disponibilidad
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {business.category} • {business.phone}
                </p>
                <p className="text-sm text-muted-foreground">
                  {business.fullAddress || business.address}
                </p>
                <div className="flex gap-4 text-sm text-muted-foreground">
                  <span>⭐ {business.rating.toFixed(1)}</span>
                  <span>🚚 ${business.deliveryFee}</span>
                  <span>📦 Min: ${business.minOrderAmount}</span>
                </div>
                
                {/* Tipo de Negocio */}
                <div className="flex items-center gap-2 pt-2 border-t mt-2">
                  <Pizza className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Tipo:</span>
                  <Select
                    value={business.isSpecialBusiness ? 'special' : 'standard'}
                    onValueChange={(value) => handleBusinessTypeChange(business.id, value === 'special')}
                  >
                    <SelectTrigger className="h-8 w-[140px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Estándar</SelectItem>
                      <SelectItem value="special">Especial 🍕</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex flex-col gap-3 ml-4">
                <div className="flex items-center gap-2">
                  <Label htmlFor={`active-${business.id}`} className="text-sm whitespace-nowrap">
                    Activo
                  </Label>
                  <Switch
                    id={`active-${business.id}`}
                    checked={business.isApproved}
                    onCheckedChange={() => handleToggleActive(business.id, business.isApproved)}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Label htmlFor={`open-${business.id}`} className="text-sm whitespace-nowrap">
                    Abierto
                  </Label>
                  <Switch
                    id={`open-${business.id}`}
                    checked={business.isOpen}
                    onCheckedChange={() => handleToggleOpen(business.id, business.isOpen)}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Label htmlFor={`coming-soon-${business.id}`} className="text-sm whitespace-nowrap">
                    Próximamente
                  </Label>
                  <Switch
                    id={`coming-soon-${business.id}`}
                    checked={(business as any).isComingSoon || false}
                    onCheckedChange={() => handleToggleComingSoon(business.id, (business as any).isComingSoon || false)}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <CloudRain className="h-4 w-4 text-sky-600" />
                  <Label htmlFor={`weather-${business.id}`} className="text-sm whitespace-nowrap">
                    Disponible
                  </Label>
                  <Switch
                    id={`weather-${business.id}`}
                    checked={(business as any).weatherUnavailable || false}
                    onCheckedChange={() => handleToggleWeather(business.id, (business as any).weatherUnavailable || false)}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <Label htmlFor={`tracking-${business.id}`} className="text-sm whitespace-nowrap">
                    Seguimiento
                  </Label>
                  <Switch
                    id={`tracking-${business.id}`}
                    checked={(business as any).deliveryTrackingEnabled || false}
                    onCheckedChange={() => handleToggleDeliveryTracking(business.id, (business as any).deliveryTrackingEnabled || false)}
                  />
                </div>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Eliminar
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Eliminar negocio?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta acción no se puede deshacer. Se eliminará permanentemente el negocio y todos sus productos.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => deleteBusiness(business.id)}>
                        Eliminar
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}

          {filteredBusinesses.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No se encontraron negocios
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
