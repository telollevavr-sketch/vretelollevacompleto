import { useMemo, useState } from 'react';
import { DateRange } from 'react-day-picker';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Plus, Hash, DollarSign, Pencil, Trash2, Bike } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { StatCard } from '@/components/shared/StatCard';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { cn } from '@/lib/utils';
import { useUsers } from '@/hooks/useUsers';
import { useDeliveryIncidents, DeliveryIncident } from '@/hooks/useDeliveryIncidents';

const AMOUNTS = [5, 10];

export const DeliveryIncidents = () => {
  const { users } = useUsers();
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [filterPerson, setFilterPerson] = useState<string>('all');

  const {
    incidents,
    total,
    count,
    isLoading,
    createIncident,
    isCreating,
    updateIncident,
    isUpdating,
    deleteIncident,
  } = useDeliveryIncidents({
    from: dateRange?.from,
    to: dateRange?.to ?? dateRange?.from,
    deliveryPersonId: filterPerson,
  });

  const deliveryPersons = useMemo(
    () => users.filter((u) => u.role === 'delivery'),
    [users]
  );

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<DeliveryIncident | null>(null);
  const [personId, setPersonId] = useState('');
  const [amount, setAmount] = useState<number>(5);
  const [notes, setNotes] = useState('');

  const openNew = () => {
    setEditing(null);
    setPersonId('');
    setAmount(5);
    setNotes('');
    setOpen(true);
  };

  const openEdit = (inc: DeliveryIncident) => {
    setEditing(inc);
    setPersonId(inc.delivery_person_id);
    setAmount(inc.amount);
    setNotes(inc.notes || '');
    setOpen(true);
  };

  const handleSave = async () => {
    if (!personId) return;
    if (editing) {
      await updateIncident({
        id: editing.id,
        delivery_person_id: personId,
        amount,
        notes: notes.trim() || null,
      });
    } else {
      await createIncident({
        delivery_person_id: personId,
        amount,
        notes: notes.trim() || null,
      });
    }
    setOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <StatCard
          title="Registros filtrados"
          value={count}
          icon={Hash}
          description="Entregas en el periodo"
          variant="purple"
        />
        <StatCard
          title="Suma total"
          value={`$${total.toFixed(2)}`}
          icon={DollarSign}
          description="Monto acumulado"
          variant="green"
        />
      </div>

      <Card className="bg-[hsl(270,50%,85%)]/90 border-purple-300/30">
        <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
          <CardTitle className="text-gray-900 flex items-center gap-2">
            <Bike className="h-5 w-5" />
            Entregas de Repartidor
          </CardTitle>
          <Button onClick={openNew} className="bg-purple-600 hover:bg-purple-700 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Nueva entrega
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            <DateRangePicker
              dateRange={dateRange}
              onDateRangeChange={setDateRange}
              className="md:w-auto"
            />
            <Select value={filterPerson} onValueChange={setFilterPerson}>
              <SelectTrigger className="md:w-64 bg-white">
                <SelectValue placeholder="Repartidor" />
              </SelectTrigger>
              <SelectContent className="bg-white z-50">
                <SelectItem value="all">Todos los repartidores</SelectItem>
                {deliveryPersons.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {(dateRange || filterPerson !== 'all') && (
              <Button
                variant="outline"
                onClick={() => {
                  setDateRange(undefined);
                  setFilterPerson('all');
                }}
              >
                Limpiar filtros
              </Button>
            )}
          </div>

          <div className="rounded-lg bg-white overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-gray-900">Fecha y hora</TableHead>
                  <TableHead className="text-gray-900">Repartidor</TableHead>
                  <TableHead className="text-gray-900">Monto</TableHead>
                  <TableHead className="text-gray-900">Comentarios</TableHead>
                  <TableHead className="text-gray-900 text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-gray-600 py-6">
                      Cargando...
                    </TableCell>
                  </TableRow>
                )}
                {!isLoading && incidents.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-gray-600 py-6">
                      Sin registros en el filtro seleccionado
                    </TableCell>
                  </TableRow>
                )}
                {incidents.map((inc) => (
                  <TableRow key={inc.id}>
                    <TableCell className="text-gray-900 whitespace-nowrap">
                      {format(new Date(inc.occurred_at), "dd/MM/yyyy HH:mm", { locale: es })}
                    </TableCell>
                    <TableCell className="text-gray-900">{inc.deliveryName || '—'}</TableCell>
                    <TableCell className="text-gray-900 font-semibold">
                      ${inc.amount.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-gray-700 max-w-[280px]">
                      {inc.notes || '—'}
                    </TableCell>
                    <TableCell className="text-right whitespace-nowrap">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(inc)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (window.confirm('¿Eliminar esta entrega?')) deleteIncident(inc.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-gray-900">
              {editing ? 'Editar entrega' : 'Nueva entrega'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-900">Repartidor</Label>
              <Select value={personId} onValueChange={setPersonId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un repartidor" />
                </SelectTrigger>
                <SelectContent className="bg-white z-50">
                  {deliveryPersons.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-900">Monto del envío</Label>
              <div className="flex gap-3">
                {AMOUNTS.map((a) => (
                  <Button
                    key={a}
                    type="button"
                    variant={amount === a ? 'default' : 'outline'}
                    className={cn(
                      'flex-1 h-14 text-lg font-bold',
                      amount === a && 'bg-purple-600 hover:bg-purple-700 text-white'
                    )}
                    onClick={() => setAmount(a)}
                  >
                    ${a}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-900">Comentarios (opcional)</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Detalle de la entrega"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleSave}
              disabled={!personId || isCreating || isUpdating}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {editing ? 'Guardar cambios' : 'Registrar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
