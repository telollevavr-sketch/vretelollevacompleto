import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useUsers } from '@/hooks/useUsers';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useToast } from '@/hooks/use-toast';
import { Bike, Search, Building2, Download } from 'lucide-react';
import * as XLSX from 'xlsx';

export function DeliveryManagement() {
  const { users, updateUser } = useUsers();
  const { businesses } = useAllBusinesses();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const deliveryPersons = users.filter(user => user.role === 'delivery');

  const filteredDeliveryPersons = deliveryPersons.filter(person =>
    person.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    person.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    person.vehicle_type?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleToggleActive = (userId: string, currentStatus: boolean) => {
    updateUser({
      id: userId,
      updates: { is_active: !currentStatus }
    });
  };

  const handleToggleOnline = (userId: string, currentStatus: boolean) => {
    updateUser({
      id: userId,
      updates: { is_online: !currentStatus }
    });
  };

  const handleBusinessAssignment = (userId: string, businessId: string | null) => {
    updateUser({
      id: userId,
      updates: { assigned_business_id: businessId }
    });
  };

  const handleExportToExcel = () => {
    if (filteredDeliveryPersons.length === 0) {
      toast({
        title: "Sin datos",
        description: "No hay repartidores para exportar",
        variant: "destructive"
      });
      return;
    }

    const dataToExport = filteredDeliveryPersons.map(person => {
      const assignedBusiness = businesses.find(b => b.id === person.assigned_business_id);
      
      return {
        'Nombre': person.name,
        'Email': person.email,
        'Teléfono': person.phone || '',
        'Tipo Vehículo': person.vehicle_type || '',
        'Placa': person.vehicle_plate || '',
        'Rating': person.rating?.toFixed(1) || 'Sin calificar',
        'Reseñas': person.review_count || 0,
        'En Línea': person.is_online ? 'Sí' : 'No',
        'Activo': person.is_active ? 'Sí' : 'No',
        'Negocio Asignado': assignedBusiness?.name || 'Independiente'
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Repartidores');

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `repartidores_${date}.xlsx`);

    toast({
      title: "Exportación exitosa",
      description: `Se exportaron ${filteredDeliveryPersons.length} repartidores`
    });
  };

  return (
    <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="flex items-center gap-2">
            <Bike className="h-5 w-5" />
            Gestión de Repartidores
            <Badge variant="secondary" className="ml-2">
              {filteredDeliveryPersons.length}
            </Badge>
          </CardTitle>
          <Button onClick={handleExportToExcel} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar repartidores..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-4">
          {filteredDeliveryPersons.map(person => (
            <div key={person.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <h3 className="font-semibold">{person.name}</h3>
                  <Badge variant={person.is_online ? 'default' : 'secondary'}>
                    {person.is_online ? 'En línea' : 'Desconectado'}
                  </Badge>
                  <Badge variant={person.is_active ? 'default' : 'secondary'}>
                    {person.is_active ? 'Activo' : 'Inactivo'}
                  </Badge>
                  {person.rating !== undefined && person.rating > 0 && (
                    <div className="flex items-center gap-1 bg-yellow-100 px-2 py-1 rounded">
                      <span className="text-yellow-600 font-medium">{person.rating.toFixed(1)}</span>
                      <span className="text-yellow-500">★</span>
                      <span className="text-xs text-gray-600">({person.review_count || 0})</span>
                    </div>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {person.email}
                </p>
                {person.phone && (
                  <p className="text-sm text-muted-foreground">
                    Tel: {person.phone}
                  </p>
                )}
                {person.vehicle_type && (
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <span>🚗 {person.vehicle_type}</span>
                    {person.vehicle_plate && <span>Placa: {person.vehicle_plate}</span>}
                  </div>
                )}
                
                {/* Asignación a Negocio */}
                <div className="flex items-center gap-2 pt-2 border-t mt-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Adscripción:</span>
                  <Select
                    value={person.assigned_business_id || 'independent'}
                    onValueChange={(value) => handleBusinessAssignment(
                      person.id, 
                      value === 'independent' ? null : value
                    )}
                  >
                    <SelectTrigger className="h-8 w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="independent">Independiente</SelectItem>
                      {businesses.map((business) => (
                        <SelectItem key={business.id} value={business.id}>
                          {business.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex flex-col gap-3 ml-4">
                <div className="flex items-center gap-2">
                  <Label htmlFor={`active-${person.id}`} className="text-sm whitespace-nowrap">
                    Activo
                  </Label>
                  <Switch
                    id={`active-${person.id}`}
                    checked={person.is_active}
                    onCheckedChange={() => handleToggleActive(person.id, person.is_active || false)}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Label htmlFor={`online-${person.id}`} className="text-sm whitespace-nowrap">
                    En línea
                  </Label>
                  <Switch
                    id={`online-${person.id}`}
                    checked={person.is_online}
                    onCheckedChange={() => handleToggleOnline(person.id, person.is_online || false)}
                  />
                </div>
              </div>
            </div>
          ))}

          {filteredDeliveryPersons.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No se encontraron repartidores
            </div>
          )}
        </div>

        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <h4 className="font-semibold mb-2">Estadísticas</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Total:</span>
              <span className="ml-2 font-semibold">{deliveryPersons.length}</span>
            </div>
            <div>
              <span className="text-muted-foreground">En línea:</span>
              <span className="ml-2 font-semibold">
                {deliveryPersons.filter(p => p.is_online).length}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Activos:</span>
              <span className="ml-2 font-semibold">
                {deliveryPersons.filter(p => p.is_active).length}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Inactivos:</span>
              <span className="ml-2 font-semibold">
                {deliveryPersons.filter(p => !p.is_active).length}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
