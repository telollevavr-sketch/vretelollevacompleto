import { useState } from 'react';
import { Bell, BellOff, Loader2, Send } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';

interface PushNotificationToggleProps {
  userId?: string;
  className?: string;
  compact?: boolean;
}

export const PushNotificationToggle = ({ userId, className, compact }: PushNotificationToggleProps) => {
  const isMobile = useIsMobile();
  const showCompact = compact && isMobile;
  const { toast } = useToast();
  const { isSubscribed, isLoading, isSupported, permission, toggle } = usePushNotifications(userId);
  const [isTesting, setIsTesting] = useState(false);

  if (!isSupported) {
    return (
      <div className={cn("flex items-center gap-2 text-white/50 text-sm", className)}>
        <BellOff className="h-4 w-4" />
        <span>Push no soportado</span>
      </div>
    );
  }

  const handleToggle = async () => {
    await toggle();
  };

  const handleTest = async () => {
    setIsTesting(true);
    try {
      const { data, error } = await supabase.functions.invoke('send-push-notification', {
        body: {
          orderId: 'test-' + Date.now(),
          orderNumber: 'TEST-' + Math.floor(Math.random() * 1000),
          businessName: 'Prueba de Notificación'
        }
      });

      if (error) {
        console.error('[PushTest] Error:', error);
        toast({
          title: 'Error al enviar',
          description: error.message || 'No se pudo enviar la notificación de prueba',
          variant: 'destructive',
        });
      } else {
        console.log('[PushTest] Response:', data);
        toast({
          title: 'Notificación enviada',
          description: `Resultado: ${data?.successful || 0} exitosa(s), ${data?.failed || 0} fallida(s)`,
        });
      }
    } catch (err: any) {
      console.error('[PushTest] Exception:', err);
      toast({
        title: 'Error',
        description: err.message || 'Error inesperado',
        variant: 'destructive',
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className={cn("flex items-center gap-1.5 md:gap-3", className)}>
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin text-white/70" />
      ) : isSubscribed ? (
        <Bell className="h-4 w-4 text-green-400" />
      ) : (
        <BellOff className="h-4 w-4 text-white/50" />
      )}
      
      <div className="flex items-center gap-1 md:gap-2">
        <Switch
          id="push-toggle"
          checked={isSubscribed}
          onCheckedChange={handleToggle}
          disabled={isLoading || permission === 'denied'}
          className={showCompact ? "scale-90" : ""}
        />
        {!showCompact && (
          <Label 
            htmlFor="push-toggle" 
            className={cn(
              "text-sm cursor-pointer",
              isSubscribed ? "text-green-400" : "text-white/70"
            )}
          >
            {isSubscribed ? 'Notificaciones activas' : 'Notificaciones'}
          </Label>
        )}
      </div>

      {isSubscribed && !showCompact && (
        <Button
          variant="outline"
          size="sm"
          onClick={handleTest}
          disabled={isTesting}
          className="ml-2 h-7 px-2 text-xs bg-white/10 border-white/20 text-white hover:bg-white/20"
        >
          {isTesting ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <>
              <Send className="h-3 w-3 mr-1" />
              Probar
            </>
          )}
        </Button>
      )}

      {permission === 'denied' && (
        <span className="text-xs text-red-400">
          {showCompact ? '!' : '(bloqueadas)'}
        </span>
      )}
    </div>
  );
};
