import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { DateRange } from 'react-day-picker';
import { Search, Download, Users, Phone, MapPin, Calendar, Package, ChevronDown, ChevronRight } from 'lucide-react';
import * as XLSX from 'xlsx';

import { useClients, ClientWithStats } from '@/hooks/useClients';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { toast } from 'sonner';

const getStatusBadge = (status: string) => {
  const statusConfig: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
    pending: { label: 'Pendiente', variant: 'outline' },
    accepted: { label: 'Aceptado', variant: 'secondary' },
    preparing: { label: 'Preparando', variant: 'secondary' },
    ready: { label: 'Listo', variant: 'default' },
    in_delivery: { label: 'En camino', variant: 'default' },
    delivered: { label: 'Entregado', variant: 'default' },
    cancelled: { label: 'Cancelado', variant: 'destructive' },
  };

  const config = statusConfig[status] || { label: status, variant: 'outline' as const };
  return <Badge variant={config.variant}>{config.label}</Badge>;
};

interface ClientCardProps {
  client: ClientWithStats;
}

const ClientCard = ({ client }: ClientCardProps) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card className="bg-white border-gray-200">
        <CollapsibleTrigger asChild>
          <CardContent className="p-4 cursor-pointer hover:bg-gray-50 transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  {isOpen ? (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronRight className="h-5 w-5 text-gray-500" />
                  )}
                  <h3 className="text-lg font-semibold text-gray-900">{client.name}</h3>
                </div>
                
                <div className="ml-7 space-y-1">
                  <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Phone className="h-3.5 w-3.5" />
                      {client.phone || 'Sin teléfono'}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" />
                      {client.address || 'Sin domicilio'}
                    </span>
                  </div>
                  
                  <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      Alta: {format(new Date(client.createdAt), 'dd/MM/yyyy', { locale: es })}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      Último pedido: {client.lastOrderDate 
                        ? format(new Date(client.lastOrderDate), 'dd/MM/yyyy', { locale: es })
                        : 'Sin pedidos'}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="secondary" className="flex items-center gap-1">
                      <Package className="h-3 w-3" />
                      {client.orderCount} pedidos
                    </Badge>
                    <Badge variant="outline" className="text-gray-700 border-gray-300">
                      Total: ${client.totalSpent.toFixed(2)}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="pt-0 pb-4 px-4">
            <div className="ml-7 mt-2">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Historial de Pedidos</h4>
              {client.orders.length > 0 ? (
                <ScrollArea className="h-[200px] rounded-md border border-gray-200">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-200 hover:bg-transparent">
                        <TableHead className="text-gray-600">Pedido</TableHead>
                        <TableHead className="text-gray-600">Negocio</TableHead>
                        <TableHead className="text-gray-600">Fecha</TableHead>
                        <TableHead className="text-gray-600">Total</TableHead>
                        <TableHead className="text-gray-600">Estado</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {client.orders.map((order) => (
                        <TableRow key={order.id} className="border-gray-100 hover:bg-gray-50">
                          <TableCell className="text-gray-900 font-mono text-xs">
                            #{order.order_number}
                          </TableCell>
                          <TableCell className="text-gray-700 text-sm">
                            {order.business_name}
                          </TableCell>
                          <TableCell className="text-gray-700">
                            {format(new Date(order.created_at), 'dd/MM/yyyy HH:mm', { locale: es })}
                          </TableCell>
                          <TableCell className="text-gray-900 font-medium">
                            ${order.total.toFixed(2)}
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(order.status)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              ) : (
                <p className="text-sm text-gray-500 italic">Este cliente no tiene pedidos registrados.</p>
              )}
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const ClientManagement = () => {
  const { data: clients, isLoading, error } = useClients();
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [dateFilterType, setDateFilterType] = useState<'created' | 'lastOrder'>('created');

  const filteredClients = useMemo(() => {
    if (!clients) return [];

    return clients.filter(client => {
      // Search filter
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = !searchTerm || 
        client.name.toLowerCase().includes(searchLower) ||
        (client.phone?.toLowerCase().includes(searchLower)) ||
        (client.address?.toLowerCase().includes(searchLower));

      if (!matchesSearch) return false;

      // Date range filter
      if (dateRange?.from) {
        const dateToCheck = dateFilterType === 'created' 
          ? new Date(client.createdAt)
          : client.lastOrderDate ? new Date(client.lastOrderDate) : null;

        if (!dateToCheck) return false;

        const fromDate = new Date(dateRange.from);
        fromDate.setHours(0, 0, 0, 0);

        const toDate = dateRange.to ? new Date(dateRange.to) : new Date(dateRange.from);
        toDate.setHours(23, 59, 59, 999);

        if (dateToCheck < fromDate || dateToCheck > toDate) return false;
      }

      return true;
    });
  }, [clients, searchTerm, dateRange, dateFilterType]);

  const exportToExcel = () => {
    if (!filteredClients.length) {
      toast.error('No hay clientes para exportar');
      return;
    }

    const exportData = filteredClients.map(client => ({
      'Nombre': client.name,
      'Email': client.email,
      'Teléfono': client.phone || 'N/A',
      'Domicilio': client.address || 'N/A',
      'Fecha de Alta': format(new Date(client.createdAt), 'dd/MM/yyyy', { locale: es }),
      'Último Pedido': client.lastOrderDate 
        ? format(new Date(client.lastOrderDate), 'dd/MM/yyyy', { locale: es })
        : 'Sin pedidos',
      'Total de Pedidos': client.orderCount,
      'Total Gastado': `$${client.totalSpent.toFixed(2)}`,
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Clientes');
    
    const filename = `clientes_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
    XLSX.writeFile(wb, filename);
    
    toast.success('Archivo exportado correctamente');
  };

  if (error) {
    return (
      <Card className="bg-white border-gray-200">
        <CardContent className="p-6">
          <p className="text-red-500">Error al cargar los clientes: {(error as Error).message}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white border-gray-200">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Users className="h-6 w-6" />
            Gestión de Clientes
          </CardTitle>
          <Button onClick={exportToExcel} variant="outline" className="text-gray-700 border-gray-300 hover:bg-gray-50">
            <Download className="h-4 w-4 mr-2" />
            Exportar Excel
          </Button>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por nombre, teléfono o domicilio..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white border-gray-200 text-gray-900 placeholder:text-gray-400"
              />
            </div>
            <DateRangePicker
              dateRange={dateRange}
              onDateRangeChange={setDateRange}
              className="w-full md:w-auto"
            />
          </div>

          {/* Date Filter Type */}
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">Filtrar por:</span>
            <RadioGroup
              value={dateFilterType}
              onValueChange={(value) => setDateFilterType(value as 'created' | 'lastOrder')}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="created" id="created" className="border-gray-400 text-purple-600" />
                <Label htmlFor="created" className="text-gray-700 cursor-pointer">Fecha de alta</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="lastOrder" id="lastOrder" className="border-gray-400 text-purple-600" />
                <Label htmlFor="lastOrder" className="text-gray-700 cursor-pointer">Último pedido</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Stats Summary */}
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Users className="h-4 w-4" />
            <span>
              Mostrando {filteredClients.length} de {clients?.length || 0} clientes
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Client List */}
      <div className="space-y-3">
        {isLoading ? (
          // Loading skeletons
          Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="bg-white border-gray-200">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <Skeleton className="h-6 w-48 bg-gray-200" />
                  <Skeleton className="h-4 w-72 bg-gray-200" />
                  <Skeleton className="h-4 w-64 bg-gray-200" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : filteredClients.length > 0 ? (
          filteredClients.map((client) => (
            <ClientCard key={client.id} client={client} />
          ))
        ) : (
          <Card className="bg-white border-gray-200">
            <CardContent className="p-8 text-center">
              <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">
                {searchTerm || dateRange ? 'No se encontraron clientes con los filtros aplicados' : 'No hay clientes registrados'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};
