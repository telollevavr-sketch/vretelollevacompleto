import { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useProducts } from '@/hooks/useProducts';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Trash2, Plus, ClipboardPlus } from 'lucide-react';
import { ManualOrdersEditor } from '@/components/admin/ManualOrdersEditor';

type Row = { productId: string; name: string; price: number; quantity: number };

export const ManualOrderCapture = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { businesses } = useAllBusinesses();
  const [businessId, setBusinessId] = useState<string>('');
  const { products } = useProducts(businessId || undefined);

  const nowLocal = () => {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  };

  const [orderDate, setOrderDate] = useState<string>(nowLocal());
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [deliveryFee, setDeliveryFee] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer'>('cash');
  const [notes, setNotes] = useState('');
  const [rows, setRows] = useState<Row[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const activeBusinesses = useMemo(
    () => businesses.filter((b) => b.isApproved !== false),
    [businesses]
  );

  const subtotal = rows.reduce((s, r) => s + r.price * r.quantity, 0);
  const total = subtotal + Number(deliveryFee || 0);

  const addRow = () => {
    setRows((r) => [...r, { productId: '', name: '', price: 0, quantity: 1 }]);
  };

  const removeRow = (i: number) => setRows((r) => r.filter((_, idx) => idx !== i));

  const updateRow = (i: number, patch: Partial<Row>) => {
    setRows((r) => r.map((row, idx) => (idx === i ? { ...row, ...patch } : row)));
  };

  const onSelectProduct = (i: number, productId: string) => {
    const p = products.find((pp) => pp.id === productId);
    if (!p) return;
    updateRow(i, { productId: p.id, name: p.name, price: p.price });
  };

  const reset = () => {
    setBusinessId('');
    setOrderDate(nowLocal());
    setClientName('');
    setClientPhone('');
    setDeliveryFee(0);
    setPaymentMethod('cash');
    setNotes('');
    setRows([]);
  };

  const handleSubmit = async () => {
    if (!user) return;
    if (!businessId) {
      toast({ title: 'Falta negocio', description: 'Selecciona un negocio', variant: 'destructive' });
      return;
    }
    if (!orderDate) {
      toast({ title: 'Falta fecha', description: 'Selecciona la fecha del pedido', variant: 'destructive' });
      return;
    }
    const nameClean = clientName.trim();
    const phoneClean = clientPhone.trim();
    if (!nameClean) {
      toast({ title: 'Falta cliente', description: 'Escribe el nombre del cliente', variant: 'destructive' });
      return;
    }
    if (nameClean.length > 100) {
      toast({ title: 'Nombre muy largo', description: 'Máximo 100 caracteres', variant: 'destructive' });
      return;
    }
    if (phoneClean && phoneClean.length > 20) {
      toast({ title: 'Teléfono inválido', description: 'Máximo 20 caracteres', variant: 'destructive' });
      return;
    }
    const validRows = rows.filter((r) => r.productId && r.quantity > 0);
    if (validRows.length === 0) {
      toast({
        title: 'Faltan productos',
        description: 'Agrega al menos un producto con cantidad mayor a 0',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    try {
      const business = businesses.find((b) => b.id === businessId);
      const iso = new Date(orderDate).toISOString();
      const items = validRows.map((r) => ({
        product: {
          id: r.productId,
          name: r.name,
          price: r.price,
          businessId,
        },
        quantity: r.quantity,
        subtotal: r.price * r.quantity,
        selectedComplements: [],
      }));

      const orderNumber = `MAN-${Date.now()}`;
      const noteFinal = `[CAPTURA MANUAL ADMIN]${notes.trim() ? ' ' + notes.trim() : ''}`;

      const { error } = await supabase.from('orders').insert({
        order_number: orderNumber,
        client_id: user.id,
        business_id: businessId,
        delivery_person_id: null,
        items: items as any,
        subtotal,
        delivery_fee: Number(deliveryFee || 0),
        total,
        status: 'delivered' as any,
        payment_method: paymentMethod as any,
        delivery_address: 'Venta de mostrador (captura manual)',
        delivery_latitude: business?.location.lat ?? 0,
        delivery_longitude: business?.location.lng ?? 0,
        notes: noteFinal,
        manual_client_name: nameClean,
        manual_client_phone: phoneClean || null,
        is_pickup_at_counter: true,
        created_at: iso,
        updated_at: iso,
        accepted_at: iso,
        ready_at: iso,
        delivered_at: iso,
      } as any);

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast({
        title: 'Pedido registrado',
        description: `Se capturó el pedido ${orderNumber} con fecha ${new Date(iso).toLocaleString('es-MX')}`,
      });
      reset();
    } catch (e: any) {
      toast({ title: 'Error al guardar', description: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
    <Card className="bg-[hsl(270,50%,15%)]/60 border-purple-300/20 text-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ClipboardPlus className="h-5 w-5" />
          Captura manual de pedidos
        </CardTitle>
        <CardDescription className="text-white/70">
          Registra ventas de mostrador que no se capturaron en la plataforma. El pedido se guarda como{' '}
          <strong>ENTREGADO</strong> con la fecha que elijas y aparecerá en informes e ingresos.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-white">Negocio</Label>
            <Select value={businessId} onValueChange={(v) => { setBusinessId(v); setRows([]); }}>
              <SelectTrigger className="bg-white text-black">
                <SelectValue placeholder="Selecciona un negocio" />
              </SelectTrigger>
              <SelectContent className="bg-white">
                {activeBusinesses.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {b.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-white">Fecha y hora del pedido</Label>
            <Input
              type="datetime-local"
              value={orderDate}
              onChange={(e) => setOrderDate(e.target.value)}
              className="bg-white text-black"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-white">Nombre del cliente</Label>
            <Input
              value={clientName}
              maxLength={100}
              placeholder="Nombre de quien realizó la compra"
              onChange={(e) => setClientName(e.target.value)}
              className="bg-white text-black"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-white">Teléfono del cliente (opcional)</Label>
            <Input
              value={clientPhone}
              maxLength={20}
              inputMode="tel"
              placeholder="Ej. 5548957140"
              onChange={(e) => setClientPhone(e.target.value)}
              className="bg-white text-black"
            />
          </div>



          <div className="space-y-2">
            <Label className="text-white">Método de pago</Label>
            <Select value={paymentMethod} onValueChange={(v: 'cash' | 'transfer') => setPaymentMethod(v)}>
              <SelectTrigger className="bg-white text-black">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-white">
                <SelectItem value="cash">Efectivo</SelectItem>
                <SelectItem value="transfer">Transferencia</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-white">Costo de envío</Label>
            <Input
              type="number"
              min={0}
              step="0.01"
              value={deliveryFee}
              onChange={(e) => setDeliveryFee(Number(e.target.value))}
              className="bg-white text-black"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-white text-base">Productos</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addRow}
              disabled={!businessId}
              className="bg-white text-black"
            >
              <Plus className="h-4 w-4 mr-1" /> Agregar producto
            </Button>
          </div>

          {!businessId && (
            <p className="text-sm text-white/60">Selecciona un negocio para cargar sus productos.</p>
          )}

          {rows.length === 0 && businessId && (
            <p className="text-sm text-white/60">Aún no hay productos. Agrega uno para comenzar.</p>
          )}

          <div className="space-y-2">
            {rows.map((row, i) => (
              <div
                key={i}
                className="grid grid-cols-12 gap-2 items-end bg-white/5 p-3 rounded-lg border border-white/10"
              >
                <div className="col-span-12 md:col-span-6 space-y-1">
                  <Label className="text-white text-xs">Producto</Label>
                  <Select value={row.productId} onValueChange={(v) => onSelectProduct(i, v)}>
                    <SelectTrigger className="bg-white text-black">
                      <SelectValue placeholder="Selecciona producto" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {products.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name} — ${p.price.toFixed(2)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-4 md:col-span-2 space-y-1">
                  <Label className="text-white text-xs">Cantidad</Label>
                  <Input
                    type="number"
                    min={1}
                    value={row.quantity}
                    onChange={(e) => updateRow(i, { quantity: Number(e.target.value) })}
                    className="bg-white text-black"
                  />
                </div>
                <div className="col-span-5 md:col-span-2 space-y-1">
                  <Label className="text-white text-xs">Precio unit.</Label>
                  <Input
                    type="number"
                    min={0}
                    step="0.01"
                    value={row.price}
                    onChange={(e) => updateRow(i, { price: Number(e.target.value) })}
                    className="bg-white text-black"
                  />
                </div>
                <div className="col-span-2 md:col-span-1 text-right text-white font-semibold">
                  ${(row.price * row.quantity).toFixed(2)}
                </div>
                <div className="col-span-1 md:col-span-1 flex justify-end">
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    onClick={() => removeRow(i)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-white">Notas (opcional)</Label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Observaciones internas del pedido"
            className="bg-white text-black"
          />
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-white/10 rounded-lg p-4 border border-white/10">
          <div className="space-y-1 text-white">
            <p className="text-sm text-white/70">Subtotal: <span className="font-semibold text-white">${subtotal.toFixed(2)}</span></p>
            <p className="text-sm text-white/70">Envío: <span className="font-semibold text-white">${Number(deliveryFee || 0).toFixed(2)}</span></p>
            <p className="text-lg font-bold">Total: ${total.toFixed(2)}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={reset} disabled={submitting} className="bg-white text-black">
              Limpiar
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {submitting ? 'Guardando...' : 'Registrar pedido'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>

    <ManualOrdersEditor />
    </div>
  );
};
