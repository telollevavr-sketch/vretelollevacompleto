import { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders } from '@/hooks/useOrders';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { EmptyState } from '@/components/shared/EmptyState';
import { Search, Trash2, Package, Calendar, DollarSign, Store, AlertTriangle, ChevronLeft, ChevronRight, User as UserIcon, Phone } from 'lucide-react';
import { OrderStatus } from '@/types';
import { format } from 'date-fns';

const ITEMS_PER_PAGE = 10;

export const OrdersDebugger = () => {
  const { user } = useAuth();
  const { orders, isLoading, deleteOrder } = useOrders(user?.id, 'admin');
  const { businesses } = useAllBusinesses();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [businessFilter, setBusinessFilter] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [deletingOrderId, setDeletingOrderId] = useState<string | null>(null);

  const getStatusBadge = (status: OrderStatus) => {
    const configs: Record<OrderStatus, { label: string; className: string }> = {
      PENDING: { label: 'Pendiente', className: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' },
      IN_PREPARATION: { label: 'En Preparación', className: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
      READY_FOR_PICKUP: { label: 'Listo', className: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
      ON_THE_WAY: { label: 'En Camino', className: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
      DELIVERED: { label: 'Entregado', className: 'bg-green-500/20 text-green-300 border-green-500/30' },
      CANCELLED: { label: 'Cancelado', className: 'bg-red-500/20 text-red-300 border-red-500/30' },
    };
    const config = configs[status];
    return (
      <Badge variant="outline" className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      const matchesSearch = searchTerm === '' || 
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
      
      const matchesBusiness = businessFilter === 'all' || order.businessId === businessFilter;
      
      return matchesSearch && matchesStatus && matchesBusiness;
    });
  }, [orders, searchTerm, statusFilter, businessFilter]);

  const totalPages = Math.ceil(filteredOrders.length / ITEMS_PER_PAGE);
  const paginatedOrders = filteredOrders.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleClearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setBusinessFilter('all');
    setCurrentPage(1);
  };

  const handleDeleteOrder = async (orderId: string) => {
    setDeletingOrderId(orderId);
    try {
      await deleteOrder(orderId);
      setCurrentPage(1);
    } finally {
      setDeletingOrderId(null);
    }
  };

  const getBusinessName = (order: typeof orders[0]) => {
    return order.businessName || 'Desconocido';
  };

  if (isLoading) {
    return <LoadingSpinner text="Cargando pedidos..." />;
  }

  return (
    <Card className="bg-white border-gray-200 shadow-lg">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Package className="h-6 w-6 text-blue-600" />
          <div>
            <CardTitle className="text-blue-700">Depurador de Pedidos</CardTitle>
            <CardDescription className="text-gray-600">
              Gestiona y elimina pedidos históricos de todos los negocios
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por # orden..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="pl-10 bg-white border-gray-300 text-black placeholder:text-gray-400"
            />
          </div>

          <Select value={statusFilter} onValueChange={(value) => {
            setStatusFilter(value);
            setCurrentPage(1);
          }}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="PENDING">Pendiente</SelectItem>
              <SelectItem value="IN_PREPARATION">En Preparación</SelectItem>
              <SelectItem value="READY_FOR_PICKUP">Listo</SelectItem>
              <SelectItem value="ON_THE_WAY">En Camino</SelectItem>
              <SelectItem value="DELIVERED">Entregado</SelectItem>
              <SelectItem value="CANCELLED">Cancelado</SelectItem>
            </SelectContent>
          </Select>

          <Select value={businessFilter} onValueChange={(value) => {
            setBusinessFilter(value);
            setCurrentPage(1);
          }}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Negocio" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los negocios</SelectItem>
              {businesses.map(business => (
                <SelectItem key={business.id} value={business.id}>
                  {business.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button 
            variant="outline" 
            onClick={handleClearFilters}
            className="bg-white border-gray-300 text-black hover:bg-gray-50"
          >
            Limpiar filtros
          </Button>
        </div>

        {/* Estadísticas rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="flex items-center gap-2 text-gray-600 text-sm mb-1">
              <Package className="h-4 w-4" />
              Total de pedidos
            </div>
            <div className="text-2xl font-bold text-black">{filteredOrders.length}</div>
          </div>
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <div className="flex items-center gap-2 text-gray-600 text-sm mb-1">
              <DollarSign className="h-4 w-4" />
              Ingresos totales
            </div>
            <div className="text-2xl font-bold text-black">
              ${filteredOrders.reduce((sum, order) => sum + order.total, 0).toFixed(2)}
            </div>
          </div>
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <div className="flex items-center gap-2 text-gray-600 text-sm mb-1">
              <Store className="h-4 w-4" />
              Negocios activos
            </div>
            <div className="text-2xl font-bold text-black">
              {new Set(filteredOrders.map(o => o.businessId)).size}
            </div>
          </div>
        </div>

        {/* Tabla */}
        {paginatedOrders.length === 0 ? (
          <EmptyState
            icon={Package}
            title="No hay pedidos"
            description={searchTerm || statusFilter !== 'all' || businessFilter !== 'all' 
              ? "No se encontraron pedidos con los filtros aplicados" 
              : "Aún no hay pedidos en el sistema"}
            actionLabel={searchTerm || statusFilter !== 'all' || businessFilter !== 'all' ? "Limpiar filtros" : undefined}
            onAction={searchTerm || statusFilter !== 'all' || businessFilter !== 'all' ? handleClearFilters : undefined}
          />
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block rounded-lg border border-gray-300 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-blue-50 hover:bg-blue-50 border-gray-300">
                    <TableHead className="text-blue-700 font-semibold">Orden</TableHead>
                    <TableHead className="text-blue-700 font-semibold">Cliente</TableHead>
                    <TableHead className="text-blue-700 font-semibold">Negocio</TableHead>
                    <TableHead className="text-blue-700 font-semibold">Estado</TableHead>
                    <TableHead className="text-blue-700 font-semibold">Pago</TableHead>
                    <TableHead className="text-blue-700 font-semibold">Total</TableHead>
                    <TableHead className="text-blue-700 font-semibold">Fecha</TableHead>
                    <TableHead className="text-blue-700 font-semibold text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedOrders.map((order) => (
                    <TableRow key={order.id} className="border-gray-200 hover:bg-gray-50">
                      <TableCell className="text-black font-mono font-semibold">
                        #{order.orderNumber}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 text-black">
                            <UserIcon className="h-3 w-3 text-blue-600" />
                            <span className="font-medium">{order.clientInfo?.name || 'N/A'}</span>
                          </div>
                          {order.clientInfo?.phone && (
                            <div className="flex items-center gap-1 text-gray-500 text-xs">
                              <Phone className="h-3 w-3" />
                              <span>{order.clientInfo.phone}</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-black">
                        {getBusinessName(order)}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(order.status)}
                      </TableCell>
                      <TableCell className="text-black">
                        {order.paymentMethod === 'CASH' ? '💵 Efectivo' : '💳 Transferencia'}
                      </TableCell>
                      <TableCell className="text-black font-semibold">
                        ${order.total.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-gray-600 text-sm">
                        {format(new Date(order.createdAt), 'dd/MM/yyyy HH:mm')}
                      </TableCell>
                      <TableCell className="text-right">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                              disabled={deletingOrderId === order.id}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="bg-white border-gray-300">
                            <AlertDialogHeader>
                              <div className="flex items-center gap-2 mb-2">
                                <div className="p-2 rounded-full bg-red-100">
                                  <AlertTriangle className="h-6 w-6 text-red-600" />
                                </div>
                                <AlertDialogTitle className="text-blue-700">
                                  ¿Eliminar pedido?
                                </AlertDialogTitle>
                              </div>
                              <AlertDialogDescription className="text-gray-700 space-y-3">
                                <div className="bg-gray-50 rounded-lg p-4 space-y-2 border border-gray-200">
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">Pedido:</span>
                                    <span className="text-black font-semibold">#{order.orderNumber}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">Negocio:</span>
                                    <span className="text-black">{getBusinessName(order)}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">Total:</span>
                                    <span className="text-black font-semibold">${order.total.toFixed(2)}</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                    <span className="text-gray-600">Estado:</span>
                                    {getStatusBadge(order.status)}
                                  </div>
                                </div>
                                <p className="text-red-600 font-medium">
                                  Esta acción no se puede deshacer. El pedido será eliminado permanentemente.
                                </p>
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="bg-gray-200 border-gray-300 text-black hover:bg-gray-300">
                                Cancelar
                              </AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteOrder(order.id)}
                                className="bg-red-500 hover:bg-red-600 text-white"
                              >
                                Eliminar pedido
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {paginatedOrders.map((order) => (
                <Card key={order.id} className="bg-white border-gray-300">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-black font-mono font-bold text-lg">
                          #{order.orderNumber}
                        </div>
                        <div className="text-gray-600 text-sm">
                          {getBusinessName(order)}
                        </div>
                        {order.clientInfo && (
                          <div className="mt-1 bg-blue-50 rounded p-2 border border-blue-200">
                            <div className="flex items-center gap-1 text-black text-sm">
                              <UserIcon className="h-3 w-3 text-blue-600" />
                              <span className="font-medium">{order.clientInfo.name}</span>
                            </div>
                            {order.clientInfo.phone && (
                              <div className="flex items-center gap-1 text-gray-600 text-xs">
                                <Phone className="h-3 w-3" />
                                <span>{order.clientInfo.phone}</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      {getStatusBadge(order.status)}
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between text-gray-600">
                        <span>Pago:</span>
                        <span className="text-black">
                          {order.paymentMethod === 'CASH' ? '💵 Efectivo' : '💳 Transferencia'}
                        </span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                        <span>Total:</span>
                        <span className="text-black font-semibold">${order.total.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                        <span>Fecha:</span>
                        <span className="text-black">{format(new Date(order.createdAt), 'dd/MM/yyyy HH:mm')}</span>
                      </div>
                    </div>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="destructive"
                          size="sm"
                          className="w-full"
                          disabled={deletingOrderId === order.id}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Eliminar pedido
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-white border-gray-300">
                        <AlertDialogHeader>
                          <div className="flex items-center gap-2 mb-2">
                            <div className="p-2 rounded-full bg-red-100">
                              <AlertTriangle className="h-6 w-6 text-red-600" />
                            </div>
                            <AlertDialogTitle className="text-blue-700">
                              ¿Eliminar pedido?
                            </AlertDialogTitle>
                          </div>
                          <AlertDialogDescription className="text-gray-700 space-y-3">
                            <div className="bg-gray-50 rounded-lg p-4 space-y-2 border border-gray-200">
                              <div className="flex justify-between">
                                <span className="text-gray-600">Pedido:</span>
                                <span className="text-black font-semibold">#{order.orderNumber}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Total:</span>
                                <span className="text-black font-semibold">${order.total.toFixed(2)}</span>
                              </div>
                            </div>
                            <p className="text-red-600 font-medium">
                              Esta acción no se puede deshacer.
                            </p>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-gray-200 border-gray-300 text-black hover:bg-gray-300">
                            Cancelar
                          </AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeleteOrder(order.id)}
                            className="bg-red-500 hover:bg-red-600 text-white"
                          >
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Paginación */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between pt-4 border-t border-gray-300">
                <div className="text-sm text-gray-600">
                  Mostrando {((currentPage - 1) * ITEMS_PER_PAGE) + 1} - {Math.min(currentPage * ITEMS_PER_PAGE, filteredOrders.length)} de {filteredOrders.length} pedidos
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="bg-white border-gray-300 text-black hover:bg-gray-50 disabled:opacity-50"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNum;
                      if (totalPages <= 5) {
                        pageNum = i + 1;
                      } else if (currentPage <= 3) {
                        pageNum = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNum = totalPages - 4 + i;
                      } else {
                        pageNum = currentPage - 2 + i;
                      }
                      
                      return (
                        <Button
                          key={pageNum}
                          variant={currentPage === pageNum ? "default" : "outline"}
                          size="sm"
                          onClick={() => setCurrentPage(pageNum)}
                          className={currentPage === pageNum 
                            ? "bg-blue-600 text-white hover:bg-blue-700" 
                            : "bg-white border-gray-300 text-black hover:bg-gray-50"
                          }
                        >
                          {pageNum}
                        </Button>
                      );
                    })}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className="bg-white border-gray-300 text-black hover:bg-gray-50 disabled:opacity-50"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};
