import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useUsers } from '@/hooks/useUsers';
import { useToast } from '@/hooks/use-toast';
import { UserCheck, UserX, Store, Bike, Clock, Mail, Phone, Calendar, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export function PendingApproval() {
  const { users, updateUser } = useUsers();
  const { toast } = useToast();
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Filtrar usuarios business/delivery que estén inactivos (pendientes de aprobación)
  const pendingUsers = users.filter(
    user => (user.role === 'business' || user.role === 'delivery') && !user.is_active
  );

  const handleApprove = async (userId: string, userName: string) => {
    setProcessingId(userId);
    try {
      await updateUser({
        id: userId,
        updates: { is_active: true }
      });
      toast({
        title: 'Usuario aprobado',
        description: `${userName} ahora puede acceder a la plataforma.`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudo aprobar el usuario.',
        variant: 'destructive',
      });
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (userId: string, userName: string) => {
    setProcessingId(userId);
    try {
      // Mantener inactivo pero podríamos agregar un campo "rejected" en el futuro
      toast({
        title: 'Usuario rechazado',
        description: `${userName} permanecerá inactivo.`,
        variant: 'destructive',
      });
    } finally {
      setProcessingId(null);
    }
  };

  const getRoleIcon = (role: string) => {
    return role === 'business' ? Store : Bike;
  };

  const getRoleLabel = (role: string) => {
    return role === 'business' ? 'Negocio' : 'Repartidor';
  };

  const getRoleBadgeVariant = (role: string) => {
    return role === 'business' ? 'default' : 'secondary';
  };

  return (
    <Card className="bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-amber-600" />
            Aprobación de Usuarios Pendientes
          </CardTitle>
          <Badge 
            variant={pendingUsers.length > 0 ? "destructive" : "secondary"} 
            className="text-sm px-3 py-1"
          >
            {pendingUsers.length} pendiente{pendingUsers.length !== 1 ? 's' : ''}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {pendingUsers.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <UserCheck className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No hay usuarios pendientes de aprobación</p>
            <p className="text-sm mt-1">Todos los usuarios de tipo Negocio y Repartidor han sido revisados.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {pendingUsers.map(user => {
              const RoleIcon = getRoleIcon(user.role || '');
              const isProcessing = processingId === user.id;
              
              return (
                <div 
                  key={user.id} 
                  className="flex flex-col md:flex-row md:items-center justify-between p-4 border border-amber-300/50 rounded-lg bg-amber-50/50 gap-4"
                >
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-3 flex-wrap">
                      <RoleIcon className="h-5 w-5 text-purple-600" />
                      <h3 className="font-semibold text-lg">{user.name}</h3>
                      <Badge variant={getRoleBadgeVariant(user.role || '')}>
                        {getRoleLabel(user.role || '')}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        <span>{user.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4" />
                        <span>{user.phone || 'Sin teléfono'}</span>
                        {user.phone && (
                          <a
                            href={`https://wa.me/${user.phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Hola ${user.name}, nos comunicamos de VRTELolleva respecto a tu solicitud de registro como ${getRoleLabel(user.role || '')}.`)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-green-500 text-white text-xs hover:bg-green-600 transition-colors"
                          >
                            <MessageCircle className="h-3 w-3" />
                            WhatsApp
                          </a>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>
                          Registrado: {format(new Date(user.created_at), "d 'de' MMMM, yyyy", { locale: es })}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 flex-shrink-0">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleReject(user.id, user.name)}
                      disabled={isProcessing}
                      className="gap-2 border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700"
                    >
                      <UserX className="h-4 w-4" />
                      Rechazar
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleApprove(user.id, user.name)}
                      disabled={isProcessing}
                      className="gap-2 bg-green-600 hover:bg-green-700"
                    >
                      <UserCheck className="h-4 w-4" />
                      {isProcessing ? 'Aprobando...' : 'Aprobar'}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}