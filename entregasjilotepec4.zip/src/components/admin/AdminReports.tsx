import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Calendar, Users, Store } from 'lucide-react';
import { ProductsByBusinessReport } from './reports/ProductsByBusinessReport';
import { SalesByPeriodReport } from './reports/SalesByPeriodReport';
import { DeliveryPerformanceReport } from './reports/DeliveryPerformanceReport';
import { SalesByBusinessReport } from './reports/SalesByBusinessReport';

export const AdminReports = () => {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="sales-by-period" className="space-y-4">
        <TabsList className="bg-white/10 border-white/20 flex-wrap h-auto">
          <TabsTrigger 
            value="sales-by-period" 
            className="text-white/70 data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Ventas por Período
          </TabsTrigger>
          <TabsTrigger 
            value="delivery-performance" 
            className="text-white/70 data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            <Users className="h-4 w-4 mr-2" />
            Desempeño Repartidores
          </TabsTrigger>
          <TabsTrigger 
            value="sales-by-business" 
            className="text-white/70 data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            <Store className="h-4 w-4 mr-2" />
            Ventas por Negocio
          </TabsTrigger>
          <TabsTrigger 
            value="products-by-business" 
            className="text-white/70 data-[state=active]:bg-purple-600 data-[state=active]:text-white"
          >
            <Package className="h-4 w-4 mr-2" />
            Productos por Negocio
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sales-by-period">
          <SalesByPeriodReport />
        </TabsContent>

        <TabsContent value="delivery-performance">
          <DeliveryPerformanceReport />
        </TabsContent>

        <TabsContent value="sales-by-business">
          <SalesByBusinessReport />
        </TabsContent>

        <TabsContent value="products-by-business">
          <ProductsByBusinessReport />
        </TabsContent>
      </Tabs>
    </div>
  );
};
