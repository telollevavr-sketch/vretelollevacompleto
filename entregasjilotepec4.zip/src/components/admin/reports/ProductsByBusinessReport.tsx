import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Download, Package } from 'lucide-react';
import { useProductsReport } from '@/hooks/useProductsReport';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import * as XLSX from 'xlsx';

export const ProductsByBusinessReport = () => {
  const { reportData, isLoading } = useProductsReport();
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [businessFilter, setBusinessFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [availabilityFilter, setAvailabilityFilter] = useState<string>('all');

  // Get unique businesses and categories for filters
  const businesses = useMemo(() => {
    const uniqueBusinesses = new Map<string, string>();
    reportData.forEach(item => {
      uniqueBusinesses.set(item.businessId, item.businessName);
    });
    return Array.from(uniqueBusinesses.entries()).sort((a, b) => a[1].localeCompare(b[1]));
  }, [reportData]);

  const categories = useMemo(() => {
    const uniqueCategories = new Set<string>();
    reportData.forEach(item => {
      if (item.productCategory && item.productCategory.trim() !== '') {
        uniqueCategories.add(item.productCategory);
      }
    });
    return Array.from(uniqueCategories).sort();
  }, [reportData]);

  // Filter data
  const filteredData = useMemo(() => {
    return reportData.filter(item => {
      const matchesSearch = 
        item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.productCategory.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.productDescription?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false);

      const matchesBusiness = businessFilter === 'all' || item.businessId === businessFilter;
      const matchesCategory = categoryFilter === 'all' || item.productCategory === categoryFilter;
      const matchesAvailability = 
        availabilityFilter === 'all' ||
        (availabilityFilter === 'available' && item.isAvailable) ||
        (availabilityFilter === 'unavailable' && !item.isAvailable);

      return matchesSearch && matchesBusiness && matchesCategory && matchesAvailability;
    });
  }, [reportData, searchTerm, businessFilter, categoryFilter, availabilityFilter]);

  const handleExportToExcel = () => {
    if (filteredData.length === 0) {
      toast({
        title: 'Sin datos',
        description: 'No hay productos para exportar',
        variant: 'destructive',
      });
      return;
    }

    const dataToExport = filteredData.map(item => ({
      'Negocio': item.businessName,
      'Cat. Negocio': item.businessCategory,
      'Negocio Activo': item.businessIsActive ? 'Sí' : 'No',
      'Producto': item.productName,
      'Cat. Producto': item.productCategory,
      'Precio': `$${item.productPrice.toFixed(2)}`,
      'Descripción': item.productDescription || '',
      'Disponible': item.isAvailable ? 'Sí' : 'No',
      'Es Combo': item.isPromotionalCombo ? 'Sí' : 'No',
      'Es Especialidad': item.isSpecialty ? 'Sí' : 'No',
      '# Complementos': item.complementsCount,
      'Complementos': item.complementsList,
      'Especialidades Negocio': item.specialtiesList,
      'Fecha Creación': new Date(item.productCreatedAt).toLocaleDateString('es-ES'),
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Productos por Negocio');

    // Auto-size columns
    const colWidths = Object.keys(dataToExport[0] || {}).map(key => ({
      wch: Math.max(key.length, 15),
    }));
    worksheet['!cols'] = colWidths;

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `productos_por_negocio_${date}.xlsx`);

    toast({
      title: 'Exportación exitosa',
      description: `Se exportaron ${filteredData.length} productos`,
    });
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <Card className="bg-white border-gray-200">
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <CardTitle className="text-black flex items-center gap-2">
              <Package className="h-5 w-5" />
              Productos por Negocio
            </CardTitle>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {filteredData.length} registros
            </Badge>
          </div>
          <Button onClick={handleExportToExcel} variant="outline" className="border-gray-300 text-black hover:bg-gray-100">
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar producto, negocio..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-300 text-black placeholder:text-gray-400"
            />
          </div>

          <Select value={businessFilter} onValueChange={setBusinessFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Filtrar por negocio" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos los negocios</SelectItem>
              {businesses.map(([id, name]) => (
                <SelectItem key={id} value={id}>{name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Filtrar por categoría" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todas las categorías</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={availabilityFilter} onValueChange={setAvailabilityFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Filtrar por disponibilidad" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="available">Disponibles</SelectItem>
              <SelectItem value="unavailable">No disponibles</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        <div className="rounded-md border border-gray-200 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-200 hover:bg-gray-50">
                <TableHead className="text-black font-semibold">Negocio</TableHead>
                <TableHead className="text-black font-semibold">Cat. Negocio</TableHead>
                <TableHead className="text-black font-semibold">Producto</TableHead>
                <TableHead className="text-black font-semibold">Cat. Producto</TableHead>
                <TableHead className="text-black font-semibold text-right">Precio</TableHead>
                <TableHead className="text-black font-semibold">Descripción</TableHead>
                <TableHead className="text-black font-semibold text-center">Disponible</TableHead>
                <TableHead className="text-black font-semibold text-center"># Compl.</TableHead>
                <TableHead className="text-black font-semibold">Complementos</TableHead>
                <TableHead className="text-black font-semibold">Especialidades</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center text-gray-500 py-8">
                    No se encontraron productos con los filtros aplicados
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((item) => (
                  <TableRow key={item.productId} className="border-gray-100 hover:bg-gray-50">
                    <TableCell className="text-black font-medium">{item.businessName}</TableCell>
                    <TableCell className="text-gray-700">{item.businessCategory}</TableCell>
                    <TableCell className="text-black">{item.productName}</TableCell>
                    <TableCell className="text-gray-700">{item.productCategory}</TableCell>
                    <TableCell className="text-black text-right">${item.productPrice.toFixed(2)}</TableCell>
                    <TableCell className="text-gray-600 max-w-[200px] truncate" title={item.productDescription || ''}>
                      {item.productDescription || '-'}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={item.isAvailable ? 'default' : 'destructive'} className={item.isAvailable ? 'bg-green-100 text-green-800' : ''}>
                        {item.isAvailable ? 'Sí' : 'No'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-black text-center">{item.complementsCount}</TableCell>
                    <TableCell className="text-gray-600 max-w-[150px] truncate" title={item.complementsList}>
                      {item.complementsList || '-'}
                    </TableCell>
                    <TableCell className="text-gray-600 max-w-[150px] truncate" title={item.specialtiesList}>
                      {item.specialtiesList || '-'}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
