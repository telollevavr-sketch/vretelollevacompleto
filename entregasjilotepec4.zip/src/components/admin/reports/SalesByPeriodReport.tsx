import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, Calendar, TrendingUp, PieChart as PieChartIcon } from 'lucide-react';
import { useSalesByPeriodReport, GroupBy } from '@/hooks/useSalesByPeriodReport';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend
} from 'recharts';
import * as XLSX from 'xlsx';
import { subDays } from 'date-fns';

const COLORS = ['#22c55e', '#ef4444', '#f59e0b', '#8b5cf6'];

export const SalesByPeriodReport = () => {
  const { toast } = useToast();
  const { businesses } = useAllBusinesses();
  
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });
  const [groupBy, setGroupBy] = useState<GroupBy>('day');
  const [businessFilter, setBusinessFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const { reportData, isLoading, totals } = useSalesByPeriodReport({
    startDate: dateRange.from,
    endDate: dateRange.to,
    groupBy,
    businessId: businessFilter !== 'all' ? businessFilter : undefined,
    status: statusFilter !== 'all' ? statusFilter : undefined,
  });

  const handleExportToExcel = () => {
    if (reportData.length === 0) {
      toast({
        title: 'Sin datos',
        description: 'No hay datos para exportar',
        variant: 'destructive',
      });
      return;
    }

    const dataToExport = reportData.map(item => ({
      'Período': item.periodLabel,
      '# Pedidos': item.totalOrders,
      '# Entregados': item.deliveredOrders,
      '# Cancelados': item.cancelledOrders,
      '# Pendientes': item.pendingOrders,
      'Venta Bruta': `$${item.grossSales.toFixed(2)}`,
      'Delivery': `$${item.deliveryFees.toFixed(2)}`,
      'Venta Neta': `$${item.netSales.toFixed(2)}`,
      'Ticket Promedio': `$${item.averageTicket.toFixed(2)}`,
    }));

    // Add totals row
    dataToExport.push({
      'Período': 'TOTALES',
      '# Pedidos': totals.totalOrders,
      '# Entregados': totals.deliveredOrders,
      '# Cancelados': totals.cancelledOrders,
      '# Pendientes': totals.pendingOrders,
      'Venta Bruta': `$${totals.grossSales.toFixed(2)}`,
      'Delivery': `$${totals.deliveryFees.toFixed(2)}`,
      'Venta Neta': `$${totals.netSales.toFixed(2)}`,
      'Ticket Promedio': `$${totals.averageTicket.toFixed(2)}`,
    });

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Ventas por Período');

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `ventas_por_periodo_${date}.xlsx`);

    toast({
      title: 'Exportación exitosa',
      description: `Se exportaron ${reportData.length} períodos`,
    });
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <Card className="bg-white border-gray-200">
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <CardTitle className="text-black flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Ventas por Período
            </CardTitle>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {reportData.length} períodos
            </Badge>
          </div>
          <Button onClick={handleExportToExcel} variant="outline" className="border-gray-300 text-black hover:bg-gray-100">
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <DateRangePicker
            dateRange={dateRange.from && dateRange.to ? { from: dateRange.from, to: dateRange.to } : undefined}
            onDateRangeChange={(range) => setDateRange(range ? { from: range.from, to: range.to } : {})}
          />

          <Select value={groupBy} onValueChange={(v) => setGroupBy(v as GroupBy)}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Agrupar por" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="day">Diario</SelectItem>
              <SelectItem value="week">Semanal</SelectItem>
              <SelectItem value="month">Mensual</SelectItem>
            </SelectContent>
          </Select>

          <Select value={businessFilter} onValueChange={setBusinessFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Filtrar por negocio" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos los negocios</SelectItem>
              {businesses.map((b) => (
                <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Filtrar por estado" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="delivered">Solo entregados</SelectItem>
              <SelectItem value="cancelled">Solo cancelados</SelectItem>
              <SelectItem value="pending">Solo pendientes</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-blue-600 text-sm font-medium">Total Pedidos</p>
            <p className="text-2xl font-bold text-blue-900">{totals.totalOrders}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-green-600 text-sm font-medium">Entregados</p>
            <p className="text-2xl font-bold text-green-900">{totals.deliveredOrders}</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-purple-600 text-sm font-medium">Venta Neta</p>
            <p className="text-2xl font-bold text-purple-900">${totals.netSales.toFixed(2)}</p>
          </div>
          <div className="bg-orange-50 p-4 rounded-lg">
            <p className="text-orange-600 text-sm font-medium">Ticket Promedio</p>
            <p className="text-2xl font-bold text-orange-900">${totals.averageTicket.toFixed(2)}</p>
          </div>
        </div>

        {/* Charts */}
        {reportData.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Bar Chart - Sales Trend */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Tendencia de Ventas</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={reportData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="periodLabel" 
                    tick={{ fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={80}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'Venta Neta']}
                    labelStyle={{ color: '#000' }}
                  />
                  <Bar dataKey="netSales" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Pie Chart - Orders Distribution */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <PieChartIcon className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Distribución de Pedidos</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Entregados', value: totals.deliveredOrders, color: '#22c55e' },
                      { name: 'Cancelados', value: totals.cancelledOrders, color: '#ef4444' },
                      { name: 'Pendientes', value: totals.pendingOrders, color: '#f59e0b' },
                    ].filter(d => d.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {[
                      { name: 'Entregados', value: totals.deliveredOrders, color: '#22c55e' },
                      { name: 'Cancelados', value: totals.cancelledOrders, color: '#ef4444' },
                      { name: 'Pendientes', value: totals.pendingOrders, color: '#f59e0b' },
                    ].filter(d => d.value > 0).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => [value, 'Pedidos']} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Line Chart - Orders Trend */}
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Tendencia de Pedidos</h3>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={reportData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="periodLabel" 
                    tick={{ fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="deliveredOrders" stroke="#22c55e" name="Entregados" strokeWidth={2} />
                  <Line type="monotone" dataKey="cancelledOrders" stroke="#ef4444" name="Cancelados" strokeWidth={2} />
                  <Line type="monotone" dataKey="totalOrders" stroke="#8b5cf6" name="Total" strokeWidth={2} strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="rounded-md border border-gray-200 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-200 hover:bg-gray-50">
                <TableHead className="text-black font-semibold">Período</TableHead>
                <TableHead className="text-black font-semibold text-right"># Pedidos</TableHead>
                <TableHead className="text-black font-semibold text-right"># Entregados</TableHead>
                <TableHead className="text-black font-semibold text-right"># Cancelados</TableHead>
                <TableHead className="text-black font-semibold text-right"># Pendientes</TableHead>
                <TableHead className="text-black font-semibold text-right">Venta Bruta</TableHead>
                <TableHead className="text-black font-semibold text-right">Delivery</TableHead>
                <TableHead className="text-black font-semibold text-right">Venta Neta</TableHead>
                <TableHead className="text-black font-semibold text-right">Ticket Prom.</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center text-gray-500 py-8">
                    No se encontraron datos para el período seleccionado
                  </TableCell>
                </TableRow>
              ) : (
                <>
                  {reportData.map((item) => (
                    <TableRow key={item.period} className="border-gray-100 hover:bg-gray-50">
                      <TableCell className="text-black font-medium">{item.periodLabel}</TableCell>
                      <TableCell className="text-black text-right">{item.totalOrders}</TableCell>
                      <TableCell className="text-green-700 text-right">{item.deliveredOrders}</TableCell>
                      <TableCell className="text-red-700 text-right">{item.cancelledOrders}</TableCell>
                      <TableCell className="text-yellow-700 text-right">{item.pendingOrders}</TableCell>
                      <TableCell className="text-black text-right">${item.grossSales.toFixed(2)}</TableCell>
                      <TableCell className="text-gray-600 text-right">${item.deliveryFees.toFixed(2)}</TableCell>
                      <TableCell className="text-black font-medium text-right">${item.netSales.toFixed(2)}</TableCell>
                      <TableCell className="text-black text-right">${item.averageTicket.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                  {/* Totals Row */}
                  <TableRow className="bg-gray-100 font-bold border-t-2 border-gray-300">
                    <TableCell className="text-black">TOTALES</TableCell>
                    <TableCell className="text-black text-right">{totals.totalOrders}</TableCell>
                    <TableCell className="text-green-700 text-right">{totals.deliveredOrders}</TableCell>
                    <TableCell className="text-red-700 text-right">{totals.cancelledOrders}</TableCell>
                    <TableCell className="text-yellow-700 text-right">{totals.pendingOrders}</TableCell>
                    <TableCell className="text-black text-right">${totals.grossSales.toFixed(2)}</TableCell>
                    <TableCell className="text-gray-600 text-right">${totals.deliveryFees.toFixed(2)}</TableCell>
                    <TableCell className="text-black text-right">${totals.netSales.toFixed(2)}</TableCell>
                    <TableCell className="text-black text-right">${totals.averageTicket.toFixed(2)}</TableCell>
                  </TableRow>
                </>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
