import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Download, Store, Star, BarChart3, PieChart as PieChartIcon } from 'lucide-react';
import { useSalesByBusinessReport } from '@/hooks/useSalesByBusinessReport';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import * as XLSX from 'xlsx';

const COLORS = ['#8b5cf6', '#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#ec4899', '#06b6d4', '#84cc16'];

export const SalesByBusinessReport = () => {
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});

  const { reportData, isLoading, categories } = useSalesByBusinessReport({
    searchTerm,
    category: categoryFilter !== 'all' ? categoryFilter : undefined,
    isActive: activeFilter === 'all' ? null : activeFilter === 'active',
    startDate: dateRange.from,
    endDate: dateRange.to,
  });

  const handleExportToExcel = () => {
    if (reportData.length === 0) {
      toast({
        title: 'Sin datos',
        description: 'No hay negocios para exportar',
        variant: 'destructive',
      });
      return;
    }

    const dataToExport = reportData.map(item => ({
      'Negocio': item.businessName,
      'Categoría': item.category,
      'Estado': item.isActive ? 'Activo' : 'Inactivo',
      '# Productos': item.productCount,
      '# Total Pedidos': item.totalOrders,
      '# Entregados': item.deliveredOrders,
      '# Cancelados': item.cancelledOrders,
      '# Pendientes': item.pendingOrders,
      'Venta Total': `$${item.totalSales.toFixed(2)}`,
      'Ticket Promedio': `$${item.averageTicket.toFixed(2)}`,
      'Calificación': item.rating.toFixed(1),
      '# Reseñas': item.reviewCount,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Ventas por Negocio');

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `ventas_por_negocio_${date}.xlsx`);

    toast({
      title: 'Exportación exitosa',
      description: `Se exportaron ${reportData.length} negocios`,
    });
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  // Calculate summary stats
  const totalSales = reportData.reduce((sum, b) => sum + b.totalSales, 0);
  const totalOrders = reportData.reduce((sum, b) => sum + b.totalOrders, 0);
  const totalDelivered = reportData.reduce((sum, b) => sum + b.deliveredOrders, 0);
  const avgRating = reportData.length > 0 
    ? reportData.reduce((sum, b) => sum + b.rating, 0) / reportData.length 
    : 0;

  return (
    <Card className="bg-white border-gray-200">
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <CardTitle className="text-black flex items-center gap-2">
              <Store className="h-5 w-5" />
              Ventas por Negocio
            </CardTitle>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {reportData.length} negocios
            </Badge>
          </div>
          <Button onClick={handleExportToExcel} variant="outline" className="border-gray-300 text-black hover:bg-gray-100">
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar negocio..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-300 text-black placeholder:text-gray-400"
            />
          </div>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Filtrar por categoría" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todas las categorías</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={activeFilter} onValueChange={setActiveFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Estado del negocio" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="active">Activos</SelectItem>
              <SelectItem value="inactive">Inactivos</SelectItem>
            </SelectContent>
          </Select>

          <DateRangePicker
            dateRange={dateRange.from && dateRange.to ? { from: dateRange.from, to: dateRange.to } : undefined}
            onDateRangeChange={(range) => setDateRange(range ? { from: range.from, to: range.to } : {})}
          />
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-blue-600 text-sm font-medium">Total Negocios</p>
            <p className="text-2xl font-bold text-blue-900">{reportData.length}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-green-600 text-sm font-medium">Pedidos Entregados</p>
            <p className="text-2xl font-bold text-green-900">{totalDelivered}</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-purple-600 text-sm font-medium">Venta Total</p>
            <p className="text-2xl font-bold text-purple-900">${totalSales.toFixed(2)}</p>
          </div>
          <div className="bg-orange-50 p-4 rounded-lg flex items-center gap-2">
            <div>
              <p className="text-orange-600 text-sm font-medium">Calif. Promedio</p>
              <p className="text-2xl font-bold text-orange-900">{avgRating.toFixed(1)}</p>
            </div>
            <Star className="h-6 w-6 text-orange-500 fill-orange-500" />
          </div>
        </div>

        {/* Charts */}
        {reportData.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Bar Chart - Top Sales */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Top 10 Negocios por Ventas</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart 
                  data={reportData.slice(0, 10)} 
                  layout="vertical"
                  margin={{ left: 100 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 12 }} tickFormatter={(v) => `$${v}`} />
                  <YAxis 
                    dataKey="businessName" 
                    type="category" 
                    tick={{ fontSize: 10 }}
                    width={95}
                  />
                  <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Ventas']} />
                  <Bar dataKey="totalSales" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Pie Chart - Sales by Category */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <PieChartIcon className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Ventas por Categoría</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={(() => {
                      const categoryData = reportData.reduce((acc, item) => {
                        const existing = acc.find(a => a.name === item.category);
                        if (existing) {
                          existing.value += item.totalSales;
                        } else {
                          acc.push({ name: item.category, value: item.totalSales });
                        }
                        return acc;
                      }, [] as { name: string; value: number }[]);
                      return categoryData.filter(d => d.value > 0).sort((a, b) => b.value - a.value);
                    })()}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name.slice(0, 10)}... ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {(() => {
                      const categoryData = reportData.reduce((acc, item) => {
                        const existing = acc.find(a => a.name === item.category);
                        if (existing) {
                          existing.value += item.totalSales;
                        } else {
                          acc.push({ name: item.category, value: item.totalSales });
                        }
                        return acc;
                      }, [] as { name: string; value: number }[]);
                      return categoryData.filter(d => d.value > 0).sort((a, b) => b.value - a.value);
                    })().map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Ventas']} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Bar Chart - Ratings Comparison */}
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <Star className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Calificaciones por Negocio (Top 15)</h3>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={reportData.filter(d => d.rating > 0).slice(0, 15)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="businessName" 
                    tick={{ fontSize: 9 }}
                    angle={-45}
                    textAnchor="end"
                    height={70}
                  />
                  <YAxis tick={{ fontSize: 12 }} domain={[0, 5]} />
                  <Tooltip formatter={(value: number) => [value.toFixed(1), 'Rating']} />
                  <Bar dataKey="rating" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="rounded-md border border-gray-200 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-200 hover:bg-gray-50">
                <TableHead className="text-black font-semibold">Negocio</TableHead>
                <TableHead className="text-black font-semibold">Categoría</TableHead>
                <TableHead className="text-black font-semibold text-center">Estado</TableHead>
                <TableHead className="text-black font-semibold text-right"># Productos</TableHead>
                <TableHead className="text-black font-semibold text-right"># Total</TableHead>
                <TableHead className="text-black font-semibold text-right"># Entregados</TableHead>
                <TableHead className="text-black font-semibold text-right"># Cancelados</TableHead>
                <TableHead className="text-black font-semibold text-right"># Pendientes</TableHead>
                <TableHead className="text-black font-semibold text-right">Venta Total</TableHead>
                <TableHead className="text-black font-semibold text-right">Ticket Prom.</TableHead>
                <TableHead className="text-black font-semibold text-right">Calificación</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={11} className="text-center text-gray-500 py-8">
                    No se encontraron negocios con los filtros aplicados
                  </TableCell>
                </TableRow>
              ) : (
                reportData.map((item) => (
                  <TableRow key={item.businessId} className="border-gray-100 hover:bg-gray-50">
                    <TableCell className="text-black font-medium">{item.businessName}</TableCell>
                    <TableCell className="text-gray-700">{item.category}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant={item.isActive ? 'default' : 'destructive'} className={item.isActive ? 'bg-green-100 text-green-800' : ''}>
                        {item.isActive ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-black text-right">{item.productCount}</TableCell>
                    <TableCell className="text-black text-right">{item.totalOrders}</TableCell>
                    <TableCell className="text-green-700 text-right">{item.deliveredOrders}</TableCell>
                    <TableCell className="text-red-700 text-right">{item.cancelledOrders}</TableCell>
                    <TableCell className="text-yellow-700 text-right">{item.pendingOrders}</TableCell>
                    <TableCell className="text-black font-medium text-right">${item.totalSales.toFixed(2)}</TableCell>
                    <TableCell className="text-black text-right">${item.averageTicket.toFixed(2)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <span className="text-black">{item.rating.toFixed(1)}</span>
                        <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                        <span className="text-gray-400 text-xs">({item.reviewCount})</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
