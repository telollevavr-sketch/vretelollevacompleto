import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Download, Users, Star, Wifi, WifiOff, BarChart3, PieChart as PieChartIcon } from 'lucide-react';
import { useDeliveryPerformanceReport } from '@/hooks/useDeliveryPerformanceReport';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useToast } from '@/hooks/use-toast';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import * as XLSX from 'xlsx';

const COLORS = ['#22c55e', '#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6'];

export const DeliveryPerformanceReport = () => {
  const { toast } = useToast();
  const { businesses } = useAllBusinesses();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [businessFilter, setBusinessFilter] = useState<string>('all');
  const [onlineFilter, setOnlineFilter] = useState<string>('all');

  const { reportData, isLoading } = useDeliveryPerformanceReport({
    searchTerm,
    isActive: activeFilter === 'all' ? null : activeFilter === 'active',
    businessId: businessFilter !== 'all' ? businessFilter : undefined,
    isOnline: onlineFilter === 'all' ? null : onlineFilter === 'online',
  });

  const handleExportToExcel = () => {
    if (reportData.length === 0) {
      toast({
        title: 'Sin datos',
        description: 'No hay repartidores para exportar',
        variant: 'destructive',
      });
      return;
    }

    const dataToExport = reportData.map(item => ({
      'Repartidor': item.name,
      'Email': item.email,
      'Teléfono': item.phone || '-',
      'Vehículo': item.vehicleType || '-',
      'Placa': item.vehiclePlate || '-',
      'Estado': item.isActive ? 'Activo' : 'Inactivo',
      'En Línea': item.isOnline ? 'Sí' : 'No',
      'Negocio Asignado': item.assignedBusinessName || 'Sin asignar',
      '# Total Pedidos': item.totalOrders,
      '# Entregados': item.deliveredOrders,
      '# Cancelados': item.cancelledOrders,
      'Tasa de Éxito': `${item.successRate.toFixed(1)}%`,
      'Calificación': item.rating.toFixed(1),
      '# Reseñas': item.reviewCount,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Desempeño Repartidores');

    const date = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `desempeno_repartidores_${date}.xlsx`);

    toast({
      title: 'Exportación exitosa',
      description: `Se exportaron ${reportData.length} repartidores`,
    });
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  // Calculate summary stats
  const totalDeliveries = reportData.reduce((sum, d) => sum + d.deliveredOrders, 0);
  const avgRating = reportData.length > 0 
    ? reportData.reduce((sum, d) => sum + d.rating, 0) / reportData.length 
    : 0;
  const avgSuccessRate = reportData.length > 0 
    ? reportData.reduce((sum, d) => sum + d.successRate, 0) / reportData.length 
    : 0;
  const onlineCount = reportData.filter(d => d.isOnline).length;

  return (
    <Card className="bg-white border-gray-200">
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <CardTitle className="text-black flex items-center gap-2">
              <Users className="h-5 w-5" />
              Desempeño de Repartidores
            </CardTitle>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {reportData.length} repartidores
            </Badge>
          </div>
          <Button onClick={handleExportToExcel} variant="outline" className="border-gray-300 text-black hover:bg-gray-100">
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por nombre o email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-300 text-black placeholder:text-gray-400"
            />
          </div>

          <Select value={activeFilter} onValueChange={setActiveFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Estado del repartidor" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="active">Activos</SelectItem>
              <SelectItem value="inactive">Inactivos</SelectItem>
            </SelectContent>
          </Select>

          <Select value={businessFilter} onValueChange={setBusinessFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Negocio asignado" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos los negocios</SelectItem>
              {businesses.map((b) => (
                <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={onlineFilter} onValueChange={setOnlineFilter}>
            <SelectTrigger className="bg-white border-gray-300 text-black">
              <SelectValue placeholder="Estado de conexión" />
            </SelectTrigger>
            <SelectContent className="bg-white">
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="online">En línea</SelectItem>
              <SelectItem value="offline">Desconectados</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-blue-600 text-sm font-medium">Total Repartidores</p>
            <p className="text-2xl font-bold text-blue-900">{reportData.length}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-green-600 text-sm font-medium">En Línea</p>
            <p className="text-2xl font-bold text-green-900">{onlineCount}</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-purple-600 text-sm font-medium">Total Entregas</p>
            <p className="text-2xl font-bold text-purple-900">{totalDeliveries}</p>
          </div>
          <div className="bg-orange-50 p-4 rounded-lg flex items-center gap-2">
            <div>
              <p className="text-orange-600 text-sm font-medium">Calif. Promedio</p>
              <p className="text-2xl font-bold text-orange-900">{avgRating.toFixed(1)}</p>
            </div>
            <Star className="h-6 w-6 text-orange-500 fill-orange-500" />
          </div>
        </div>

        {/* Charts */}
        {reportData.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Bar Chart - Top Deliveries */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Top 10 Repartidores por Entregas</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart 
                  data={reportData.slice(0, 10)} 
                  layout="vertical"
                  margin={{ left: 80 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    tick={{ fontSize: 11 }}
                    width={75}
                  />
                  <Tooltip />
                  <Bar dataKey="deliveredOrders" fill="#22c55e" name="Entregados" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Pie Chart - Status Distribution */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <PieChartIcon className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Estado de Repartidores</h3>
              </div>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'En Línea', value: onlineCount, color: '#22c55e' },
                      { name: 'Desconectados', value: reportData.length - onlineCount, color: '#94a3b8' },
                    ].filter(d => d.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {[
                      { name: 'En Línea', value: onlineCount, color: '#22c55e' },
                      { name: 'Desconectados', value: reportData.length - onlineCount, color: '#94a3b8' },
                    ].filter(d => d.value > 0).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => [value, 'Repartidores']} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Bar Chart - Ratings */}
            <div className="bg-gray-50 p-4 rounded-lg lg:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <Star className="h-5 w-5 text-gray-600" />
                <h3 className="font-semibold text-gray-800">Calificaciones por Repartidor</h3>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={reportData.filter(d => d.rating > 0).slice(0, 15)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12 }} domain={[0, 5]} />
                  <Tooltip formatter={(value: number) => [value.toFixed(1), 'Rating']} />
                  <Bar dataKey="rating" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="rounded-md border border-gray-200 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-200 hover:bg-gray-50">
                <TableHead className="text-black font-semibold">Repartidor</TableHead>
                <TableHead className="text-black font-semibold">Contacto</TableHead>
                <TableHead className="text-black font-semibold">Vehículo</TableHead>
                <TableHead className="text-black font-semibold text-center">Estado</TableHead>
                <TableHead className="text-black font-semibold">Negocio Asignado</TableHead>
                <TableHead className="text-black font-semibold text-right"># Total</TableHead>
                <TableHead className="text-black font-semibold text-right"># Entregados</TableHead>
                <TableHead className="text-black font-semibold text-right"># Cancelados</TableHead>
                <TableHead className="text-black font-semibold text-right">Tasa Éxito</TableHead>
                <TableHead className="text-black font-semibold text-right">Calificación</TableHead>
                <TableHead className="text-black font-semibold text-center">En Línea</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={11} className="text-center text-gray-500 py-8">
                    No se encontraron repartidores con los filtros aplicados
                  </TableCell>
                </TableRow>
              ) : (
                reportData.map((item) => (
                  <TableRow key={item.id} className="border-gray-100 hover:bg-gray-50">
                    <TableCell className="text-black font-medium">{item.name}</TableCell>
                    <TableCell>
                      <div className="text-gray-700 text-sm">{item.email}</div>
                      <div className="text-gray-500 text-xs">{item.phone || '-'}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-gray-700">{item.vehicleType || '-'}</div>
                      <div className="text-gray-500 text-xs">{item.vehiclePlate || ''}</div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={item.isActive ? 'default' : 'destructive'} className={item.isActive ? 'bg-green-100 text-green-800' : ''}>
                        {item.isActive ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-700">{item.assignedBusinessName || 'Sin asignar'}</TableCell>
                    <TableCell className="text-black text-right">{item.totalOrders}</TableCell>
                    <TableCell className="text-green-700 text-right">{item.deliveredOrders}</TableCell>
                    <TableCell className="text-red-700 text-right">{item.cancelledOrders}</TableCell>
                    <TableCell className="text-right">
                      <span className={item.successRate >= 80 ? 'text-green-700' : item.successRate >= 50 ? 'text-yellow-700' : 'text-red-700'}>
                        {item.successRate.toFixed(1)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <span className="text-black">{item.rating.toFixed(1)}</span>
                        <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                        <span className="text-gray-400 text-xs">({item.reviewCount})</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {item.isOnline ? (
                        <Wifi className="h-5 w-5 text-green-500 mx-auto" />
                      ) : (
                        <WifiOff className="h-5 w-5 text-gray-400 mx-auto" />
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
