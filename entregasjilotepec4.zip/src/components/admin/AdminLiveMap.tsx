import { useEffect, useState } from 'react';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { useOrders } from '@/hooks/useOrders';
import { MapView } from '@/components/shared/MapView';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { supabase } from '@/integrations/supabase/client';
import { Order, OrderStatus } from '@/types';
import { startOfDay, endOfDay, format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Phone, Bike, MapPin, Filter, X } from 'lucide-react';
import { DateRange } from 'react-day-picker';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface MapLocation {
  lat: number;
  lng: number;
  name?: string;
  address?: string;
  icon?: 'business' | 'delivery' | 'client';
  phone?: string | null;
  avatarUrl?: string | null;
  vehicleType?: string | null;
  vehiclePlate?: string | null;
  isOnline?: boolean | null;
}

export const AdminLiveMap = () => {
  const { toast } = useToast();
  const { orders } = useOrders();
  const { businesses } = useAllBusinesses();
  const [deliveryLocations, setDeliveryLocations] = useState<MapLocation[]>([]);
  
  // Filter states
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [selectedBusinessId, setSelectedBusinessId] = useState<string>('all');
  const [selectedDeliveryPersonId, setSelectedDeliveryPersonId] = useState<string>('all');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [deliveryPersons, setDeliveryPersons] = useState<Array<{id: string, name: string}>>([]);

  // Fetch delivery persons for filter
  useEffect(() => {
    const fetchDeliveryPersons = async () => {
      const { data: roles } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'delivery');
      
      if (roles && roles.length > 0) {
        const userIds = roles.map(r => r.user_id);
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, name')
          .in('id', userIds);
        
        if (profiles) {
          setDeliveryPersons(profiles);
        }
      }
    };
    
    fetchDeliveryPersons();
  }, []);

  // Filter orders based on all criteria
  const filteredOrders = orders.filter(order => {
    // Don't show cancelled orders
    if (order.status === OrderStatus.CANCELLED) return false;
    
    // Date range filter
    if (dateRange?.from) {
      const orderDate = new Date(order.createdAt);
      if (dateRange.to) {
        if (orderDate < dateRange.from || orderDate > endOfDay(dateRange.to)) return false;
      } else {
        if (orderDate < dateRange.from) return false;
      }
    }
    
    // Business filter
    if (selectedBusinessId !== 'all' && order.businessId !== selectedBusinessId) {
      return false;
    }
    
    // Delivery person filter
    if (selectedDeliveryPersonId !== 'all' && order.deliveryPersonId !== selectedDeliveryPersonId) {
      return false;
    }
    
    return true;
  });

  // Clear all filters
  const handleClearFilters = () => {
    setDateRange(undefined);
    setSelectedBusinessId('all');
    setSelectedDeliveryPersonId('all');
    setSelectedOrderId(null);
  };

  // Manual refresh function - query DB directly without broadcast pulses
  const handleRefreshMap = async () => {
    console.log('🔄 [ADMIN MAP] Refresco manual solicitado');
    
    const { data: allDeliveryRoles } = await supabase
      .from('user_roles')
      .select('user_id')
      .eq('role', 'delivery');
    
    if (!allDeliveryRoles || allDeliveryRoles.length === 0) {
      toast({
        title: 'Sin repartidores',
        description: 'No hay repartidores registrados en el sistema',
      });
      return;
    }

    const allDeliveryPersonIds = allDeliveryRoles.map(r => r.user_id);

    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, name, latitude, longitude, address, phone, avatar_url, vehicle_type, vehicle_plate, is_online, assigned_business_id')
      .in('id', allDeliveryPersonIds)
      .not('latitude', 'is', null)
      .not('longitude', 'is', null);

    if (profiles) {
      const locationsWithAddresses = await Promise.all(
        profiles.map(async (profile) => {
          let currentAddress = profile.address || 'Ubicación actual';
          
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${profile.latitude}&lon=${profile.longitude}&zoom=18&addressdetails=1`,
              { headers: { 'Accept-Language': 'es' } }
            );
            
            if (response.ok) {
              const data = await response.json();
              const addr = data.address;
              const street = addr.road || addr.pedestrian || addr.footway || '';
              const number = addr.house_number || '';
              const suburb = addr.suburb || addr.neighbourhood || addr.quarter || '';
              const city = addr.city || addr.town || addr.village || '';
              
              const parts = [];
              if (street) parts.push(`${street}${number ? ' ' + number : ''}`);
              if (suburb) parts.push(suburb);
              if (city) parts.push(city);
              
              currentAddress = parts.length > 0 ? parts.join(', ') : data.display_name;
            }
          } catch (error) {
            console.error('Error en geocoding inverso:', error);
          }
          
          return {
            lat: profile.latitude!,
            lng: profile.longitude!,
            name: profile.name,
            address: currentAddress,
            icon: 'delivery' as const,
            phone: profile.phone,
            avatarUrl: profile.avatar_url,
            vehicleType: profile.vehicle_type,
            vehiclePlate: profile.vehicle_plate,
            isOnline: profile.is_online
          };
        })
      );
      
      setDeliveryLocations(locationsWithAddresses);
      
      toast({
        title: 'Ubicaciones actualizadas',
        description: `${locationsWithAddresses.length} repartidor(es) actualizados`,
      });
    }
  };

  // Initial fetch - query DB directly without broadcast pulses
  useEffect(() => {
    const fetchDeliveryPersonsLocations = async () => {
      console.log('🔄 [ADMIN MAP] Cargando ubicaciones de TODOS los repartidores');
      
      const { data: allDeliveryRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'delivery');
      
      if (rolesError) {
        console.error('❌ [ADMIN MAP] Error obteniendo roles de repartidores:', rolesError);
        return;
      }

      if (!allDeliveryRoles || allDeliveryRoles.length === 0) {
        console.log('📭 [ADMIN MAP] No hay repartidores registrados en el sistema');
        setDeliveryLocations([]);
        return;
      }

      const deliveryPersonIds = allDeliveryRoles.map(r => r.user_id);

      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('id, name, latitude, longitude, address, phone, avatar_url, vehicle_type, vehicle_plate, is_online, assigned_business_id')
        .in('id', deliveryPersonIds)
        .not('latitude', 'is', null)
        .not('longitude', 'is', null);

      if (error) {
        console.error('❌ [ADMIN MAP] Error obteniendo perfiles:', error);
        return;
      }

      if (!profiles || profiles.length === 0) {
        console.warn('⚠️ [ADMIN MAP] No se encontraron ubicaciones activas.');
        setDeliveryLocations([]);
        return;
      }

      const locationsWithAddresses = await Promise.all(
        profiles.map(async (profile) => {
          let currentAddress = profile.address || 'Ubicación actual';
          
          try {
            const response = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${profile.latitude}&lon=${profile.longitude}&zoom=18&addressdetails=1`,
              { headers: { 'Accept-Language': 'es' } }
            );
            
            if (response.ok) {
              const data = await response.json();
              const addr = data.address;
              const street = addr.road || addr.pedestrian || addr.footway || '';
              const number = addr.house_number || '';
              const suburb = addr.suburb || addr.neighbourhood || addr.quarter || '';
              const city = addr.city || addr.town || addr.village || '';
              
              const parts = [];
              if (street) parts.push(`${street}${number ? ' ' + number : ''}`);
              if (suburb) parts.push(suburb);
              if (city) parts.push(city);
              
              currentAddress = parts.length > 0 ? parts.join(', ') : data.display_name;
            }
          } catch (error) {
            console.error('Error en geocoding inverso:', error);
          }
          
          return {
            lat: profile.latitude!,
            lng: profile.longitude!,
            name: profile.name,
            address: currentAddress,
            icon: 'delivery' as const,
            phone: profile.phone,
            avatarUrl: profile.avatar_url,
            vehicleType: profile.vehicle_type,
            vehiclePlate: profile.vehicle_plate,
            isOnline: profile.is_online
          };
        })
      );
      
      console.log(`✅ [ADMIN MAP] ${locationsWithAddresses.length} ubicaciones de repartidores cargadas`);
      setDeliveryLocations(locationsWithAddresses);
    };

    fetchDeliveryPersonsLocations();
  }, []);

  // Orders realtime subscription removed - locations update only on manual refresh

  // Build all map locations - show only selected order if one is selected
  const allLocations: MapLocation[] = [];
  
  const ordersToShow = selectedOrderId 
    ? filteredOrders.filter(o => o.id === selectedOrderId)
    : filteredOrders;

  console.log(`🗺️ [ADMIN MAP] Construyendo ubicaciones para ${ordersToShow.length} pedidos`);
  
  let clientsCount = 0;
  let businessesCount = 0;

  ordersToShow.forEach((order, idx) => {
    console.log(`   📋 Procesando Orden #${order.id.slice(0, 8)}:`);
    
    // Add client location - verificar que exista y tenga coordenadas válidas
    if (order.deliveryLocation && order.deliveryLocation.lat && order.deliveryLocation.lng) {
      allLocations.push({
        lat: order.deliveryLocation.lat,
        lng: order.deliveryLocation.lng,
        name: `Cliente - Orden #${order.id.slice(0, 8)}`,
        address: order.deliveryLocation.address || 'Dirección de entrega',
        icon: 'client'
      });
      clientsCount++;
      console.log(`      ✅ Cliente agregado: ${order.deliveryLocation.lat.toFixed(6)}, ${order.deliveryLocation.lng.toFixed(6)}`);
    } else {
      console.warn(`      ⚠️ Cliente SIN coordenadas - deliveryLocation:`, order.deliveryLocation);
    }

    // Add business location - verificar que exista y tenga coordenadas válidas
    const business = businesses.find(b => b.id === order.businessId);
    if (business) {
      if (business.location && business.location.lat && business.location.lng) {
        // Check if business location already exists to avoid duplicates
        const existingBusiness = allLocations.find(
          loc => loc.icon === 'business' && 
          loc.lat === business.location.lat && 
          loc.lng === business.location.lng
        );
        
        if (!existingBusiness) {
          allLocations.push({
            lat: business.location.lat,
            lng: business.location.lng,
            name: business.name,
            address: business.fullAddress || business.address,
            icon: 'business'
          });
          businessesCount++;
          console.log(`      ✅ Negocio agregado: ${business.name} - ${business.location.lat.toFixed(6)}, ${business.location.lng.toFixed(6)}`);
        } else {
          console.log(`      ℹ️ Negocio ya existe en el mapa: ${business.name}`);
        }
      } else {
        console.warn(`      ⚠️ Negocio SIN coordenadas - ${business.name} - location:`, business.location);
      }
    } else {
      console.warn(`      ⚠️ Negocio NO encontrado para businessId: ${order.businessId}`);
    }
  });

  console.log(`📊 [ADMIN MAP] Ubicaciones agregadas: ${clientsCount} clientes, ${businessesCount} negocios`);

  // Add delivery persons locations (avoid duplicates)
  deliveryLocations.forEach(deliveryLoc => {
    const existing = allLocations.find(
      loc => loc.icon === 'delivery' && 
      loc.lat === deliveryLoc.lat && 
      loc.lng === deliveryLoc.lng
    );
    if (!existing) {
      allLocations.push(deliveryLoc);
    }
  });
  
  console.log(`📍 [ADMIN MAP] Total ubicaciones en mapa: ${allLocations.length} (${allLocations.filter(l => l.icon === 'client').length} clientes, ${allLocations.filter(l => l.icon === 'business').length} negocios, ${allLocations.filter(l => l.icon === 'delivery').length} repartidores)`);

  // Build routes for active orders with delivery persons
  const routes: Array<{
    orderId: string;
    orderNumber: string;
    coordinates: { lat: number; lng: number }[];
    color: string;
    weight?: number;
    dashArray?: string;
  }> = [];

  ordersToShow.forEach((order) => {
    // Only create routes for orders that are in active delivery states
    const activeDeliveryStates = [
      OrderStatus.IN_PREPARATION,
      OrderStatus.READY_FOR_PICKUP,
      OrderStatus.ON_THE_WAY
    ];

    if (!activeDeliveryStates.includes(order.status)) {
      return;
    }

    const business = businesses.find(b => b.id === order.businessId);
    const deliveryPerson = deliveryLocations.find(d => 
      d.name && order.deliveryPersonId && 
      deliveryPersons.find(dp => dp.id === order.deliveryPersonId && dp.name === d.name)
    );

    // Determine route color based on order status
    let routeColor = '#9333ea'; // purple default
    let dashArray: string | undefined;

    switch (order.status) {
      case OrderStatus.IN_PREPARATION:
        routeColor = '#eab308'; // yellow
        dashArray = '10, 10'; // dashed
        break;
      case OrderStatus.READY_FOR_PICKUP:
        routeColor = '#f97316'; // orange
        dashArray = '5, 5'; // dashed
        break;
      case OrderStatus.ON_THE_WAY:
        routeColor = '#10b981'; // green
        dashArray = undefined; // solid
        break;
    }

    // Build route: Business → Delivery Person → Client
    if (business?.location?.lat && business?.location?.lng && 
        order.deliveryLocation?.lat && order.deliveryLocation?.lng) {
      
      const routeCoordinates: { lat: number; lng: number }[] = [];

      // Start: Business location
      routeCoordinates.push({
        lat: business.location.lat,
        lng: business.location.lng
      });

      // Middle: Delivery person location (if exists and order has repartidor)
      if (deliveryPerson && order.deliveryPersonId) {
        routeCoordinates.push({
          lat: deliveryPerson.lat,
          lng: deliveryPerson.lng
        });
      }

      // End: Client location
      routeCoordinates.push({
        lat: order.deliveryLocation.lat,
        lng: order.deliveryLocation.lng
      });

      // Only add route if we have at least 2 points
      if (routeCoordinates.length >= 2) {
        routes.push({
          orderId: order.id,
          orderNumber: order.id.slice(0, 8),
          coordinates: routeCoordinates,
          color: routeColor,
          weight: 4,
          dashArray
        });

        console.log(`   🛣️ Ruta creada para orden #${order.id.slice(0, 8)}: ${routeCoordinates.length} puntos - Color: ${routeColor} - Estado: ${order.status}`);
      }
    }
  });

  console.log(`🛣️ [ADMIN MAP] Total de rutas creadas: ${routes.length}`);

  const activeOrdersCount = filteredOrders.filter(
    o => o.status !== OrderStatus.DELIVERED && o.status !== OrderStatus.CANCELLED
  ).length;
  const deliveredOrdersCount = filteredOrders.filter(
    o => o.status === OrderStatus.DELIVERED
  ).length;
  
  const hasActiveFilters = dateRange?.from || selectedBusinessId !== 'all' || selectedDeliveryPersonId !== 'all';

  return (
    <div className="space-y-4">
      <Card className="p-6 bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-purple-900">
              Seguimiento de Entregas en Tiempo Real
            </h2>
            <p className="text-sm text-purple-700 mt-1">
              Mostrando {filteredOrders.length} pedidos: {activeOrdersCount} activos, {deliveredOrdersCount} completados
              {hasActiveFilters && <Badge variant="secondary" className="ml-2">Filtros activos</Badge>}
            </p>
            <p className="text-xs text-purple-600 mt-1">
              📍 Ubicaciones en mapa: {allLocations.filter(l => l.icon === 'client').length} clientes, {allLocations.filter(l => l.icon === 'business').length} negocios, {allLocations.filter(l => l.icon === 'delivery').length} repartidores
            </p>
          </div>
          <div className="flex flex-col gap-3">
            <div className="flex gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <span className="text-purple-900">Clientes</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="text-purple-900">Negocios</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span className="text-purple-900">Repartidores</span>
              </div>
            </div>
            <div className="flex gap-3 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-8 h-0.5 bg-yellow-500 border-dashed border-t-2 border-yellow-500"></div>
                <span className="text-purple-800">En Preparación</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-0.5 bg-orange-500 border-dashed border-t-2 border-orange-500"></div>
                <span className="text-purple-800">Listo para Recoger</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-1 bg-green-500"></div>
                <span className="text-purple-800">En Camino</span>
              </div>
            </div>
          </div>
        </div>

        {/* Filters Panel */}
        <div className="mb-4 p-4 bg-white/50 backdrop-blur border border-purple-200 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-purple-900 flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </h3>
            {hasActiveFilters && (
              <Button onClick={handleClearFilters} variant="outline" size="sm" className="h-8">
                <X className="h-4 w-4 mr-1" />
                Limpiar Filtros
              </Button>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <DateRangePicker 
              dateRange={dateRange} 
              onDateRangeChange={setDateRange} 
            />
            <Select value={selectedBusinessId} onValueChange={setSelectedBusinessId}>
              <SelectTrigger>
                <SelectValue placeholder="Todos los negocios" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los negocios</SelectItem>
                {businesses.map(business => (
                  <SelectItem key={business.id} value={business.id}>
                    {business.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedDeliveryPersonId} onValueChange={setSelectedDeliveryPersonId}>
              <SelectTrigger>
                <SelectValue placeholder="Todos los repartidores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los repartidores</SelectItem>
                {deliveryPersons.map(person => (
                  <SelectItem key={person.id} value={person.id}>
                    {person.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Información sobre el sistema de pulsos */}
        <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg flex items-start justify-between gap-3">
          <div className="flex-1">
            <p className="text-xs text-blue-800 dark:text-blue-200">
              💡 <strong>Sistema de Pulsos en Tiempo Real:</strong> Las ubicaciones se actualizan automáticamente cuando:
              <br />
              • Un negocio acepta un pedido (muestra ubicación del negocio y cliente)
              <br />
              • Un repartidor se asigna a un pedido (muestra su ubicación actual)
              <br />
              • El estado de un pedido cambia (actualiza ubicaciones)
              <br />
              • Cada 30 segundos (tracking automático)
            </p>
          </div>
          <Button 
            onClick={handleRefreshMap} 
            variant="outline" 
            size="sm"
            className="whitespace-nowrap"
          >
            🔄 Refrescar Ahora
          </Button>
        </div>

        {/* Información sobre el sistema de tracking */}
        {selectedOrderId && (
          <div className="mb-4 p-4 bg-blue-100/50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-blue-900">
                📍 Vista de pedido seleccionado: #{selectedOrderId.slice(0, 8)}
              </p>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setSelectedOrderId(null)}
                className="h-7"
              >
                Ver todos
              </Button>
            </div>
          </div>
        )}

        <div className="relative">
          <MapView
            locations={allLocations}
            routes={routes}
            height="600px"
            zoom={12}
            interactive={true}
          />
          {allLocations.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="bg-white/90 backdrop-blur px-6 py-4 rounded-lg shadow-lg">
                <p className="text-purple-700 font-semibold">
                  {filteredOrders.length === 0 ? 'No hay pedidos que coincidan con los filtros' : 'No hay ubicaciones disponibles'}
                </p>
              </div>
            </div>
          )}
          
          {/* Badge de repartidores en línea */}
          {deliveryLocations.length > 0 && (
            <div className="absolute top-4 right-4 bg-white/95 backdrop-blur px-4 py-2 rounded-lg border-2 border-orange-500 shadow-lg z-[1000]">
              <div className="flex flex-col gap-1">
                <p className="text-sm font-semibold text-orange-600 flex items-center gap-2">
                  <Bike className="h-4 w-4" />
                  {deliveryLocations.filter(d => d.isOnline).length} repartidor{deliveryLocations.filter(d => d.isOnline).length !== 1 ? 'es' : ''} en línea
                </p>
                <p className="text-xs text-orange-500">
                  Total: {deliveryLocations.length} repartidores
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Orders List */}
      {filteredOrders.length > 0 && (
        <Card className="p-6 bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold text-purple-900">
                Pedidos ({filteredOrders.length})
              </h3>
              <div className="flex items-center gap-1 px-2 py-1 bg-green-100 dark:bg-green-900/20 rounded-full">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-xs text-green-700 dark:text-green-300 font-medium">En vivo</span>
              </div>
            </div>
            {selectedOrderId && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setSelectedOrderId(null)}
              >
                Deseleccionar
              </Button>
            )}
          </div>
          
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {filteredOrders.map(order => {
                const business = businesses.find(b => b.id === order.businessId);
                const isSelected = selectedOrderId === order.id;
                
                const getStatusColor = (status: OrderStatus) => {
                  switch (status) {
                    case OrderStatus.PENDING: return 'bg-yellow-500';
                    case OrderStatus.IN_PREPARATION: return 'bg-blue-500';
                    case OrderStatus.READY_FOR_PICKUP: return 'bg-purple-500';
                    case OrderStatus.ON_THE_WAY: return 'bg-orange-500';
                    case OrderStatus.DELIVERED: return 'bg-green-500';
                    default: return 'bg-gray-500';
                  }
                };
                
                const getStatusText = (status: OrderStatus) => {
                  switch (status) {
                    case OrderStatus.PENDING: return 'Pendiente';
                    case OrderStatus.IN_PREPARATION: return 'En Preparación';
                    case OrderStatus.READY_FOR_PICKUP: return 'Listo';
                    case OrderStatus.ON_THE_WAY: return 'En Camino';
                    case OrderStatus.DELIVERED: return 'Entregado';
                    default: return status;
                  }
                };
                
                return (
                  <Card 
                    key={order.id}
                    className={cn(
                      "cursor-pointer transition-all hover:shadow-md hover:scale-[1.01]",
                      isSelected && "border-2 border-purple-500 bg-purple-50/50 shadow-lg"
                    )}
                    onClick={() => setSelectedOrderId(isSelected ? null : order.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-semibold text-base">
                              Pedido #{order.id.slice(0, 8)}
                            </h4>
                            <Badge className={cn("text-white", getStatusColor(order.status))}>
                              {getStatusText(order.status)}
                            </Badge>
                          </div>
                          
                          <div className="space-y-1 text-sm">
                            <p className="text-purple-900">
                              <span className="font-medium">Negocio:</span> {business?.name || 'N/A'}
                            </p>
                            <p className="text-purple-700">
                              <span className="font-medium">Fecha:</span> {format(new Date(order.createdAt), "dd/MM/yyyy HH:mm", { locale: es })}
                            </p>
                            <p className="text-purple-900 font-semibold">
                              Total: ${order.total.toFixed(2)}
                            </p>
                            <p className="text-purple-700 text-xs">
                              <MapPin className="h-3 w-3 inline mr-1" />
                              {order.deliveryLocation?.address || 'Dirección no disponible'}
                            </p>
                          </div>
                        </div>
                        
                        {isSelected && (
                          <div className="ml-4">
                            <Badge variant="secondary" className="bg-purple-500 text-white">
                              Seleccionado
                            </Badge>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </ScrollArea>
        </Card>
      )}

      {/* Fichas de repartidores con información del perfil */}
      {deliveryLocations.length > 0 && (
        <Card className="p-6 bg-[hsl(270,50%,85%)]/90 backdrop-blur-sm border-purple-300/30">
          <h3 className="text-xl font-bold text-purple-900 mb-4 flex items-center gap-2">
            <Bike className="h-5 w-5" />
            Repartidores Activos
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {deliveryLocations.map((delivery, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-16 w-16 border-2 border-orange-500">
                      <AvatarImage src={delivery.avatarUrl || undefined} alt={delivery.name} />
                      <AvatarFallback className="bg-orange-100 text-orange-700 font-semibold text-lg">
                        {delivery.name?.charAt(0) || 'R'}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-base truncate">{delivery.name}</h4>
                        <Badge variant={delivery.isOnline ? 'default' : 'secondary'} className="text-xs">
                          {delivery.isOnline ? 'En línea' : 'Desconectado'}
                        </Badge>
                      </div>
                      
                      {delivery.phone && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <Phone className="h-3.5 w-3.5" />
                          <span className="truncate">{delivery.phone}</span>
                        </div>
                      )}
                      
                      {delivery.vehicleType && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <Bike className="h-3.5 w-3.5" />
                          <span className="truncate">
                            {delivery.vehicleType}
                            {delivery.vehiclePlate && ` - ${delivery.vehiclePlate}`}
                          </span>
                        </div>
                      )}
                      
                      {delivery.address && (
                        <div className="flex items-start gap-2 text-xs text-muted-foreground mt-2 p-2 bg-orange-50 rounded border-l-2 border-orange-500">
                          <MapPin className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-2">{delivery.address}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};
