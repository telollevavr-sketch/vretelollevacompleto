import { useState } from 'react';
import { useAntojoBusinesses, AntojoBusiness } from '@/hooks/useAntojoBusinesses';
import { useAntojoOrders } from '@/hooks/useAntojoOrders';
import { useAntojoCategories } from '@/hooks/useAntojoCategories';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Pencil, Trash2, Store, Package, DollarSign, Tag, XCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { compressImage, formatFileSize } from '@/lib/imageCompression';

const ANTOJO_ACTIVE_TAB_STORAGE_KEY = 'admin-antojos-active-tab';

export const AntojoBusinessManagement = () => {
  const { user } = useAuth();
  const { businesses, createBusiness, updateBusiness, deleteBusiness } = useAntojoBusinesses();
  const { orders, updateOrder, deleteOrder } = useAntojoOrders(user?.id, 'admin');
  const { categories, createCategory, updateCategory, deleteCategory } = useAntojoCategories();
  const [showForm, setShowForm] = useState(false);
  const [editingBusiness, setEditingBusiness] = useState<AntojoBusiness | null>(null);
  const [form, setForm] = useState({
    name: '', address: '', phone: '', latitude: 20.0796, longitude: -99.6538,
    menu_image: null as string | null, menu_text: '', is_active: true,
    image_url: null as string | null, category: '' as string,
  });

  const [showCatForm, setShowCatForm] = useState(false);
  const [catForm, setCatForm] = useState({ name: '', icon: '' });
  const [activeTab, setActiveTab] = useState(() => {
    if (typeof window === 'undefined') return 'businesses';
    return window.sessionStorage.getItem(ANTOJO_ACTIVE_TAB_STORAGE_KEY) ?? 'businesses';
  });

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    if (typeof window !== 'undefined') {
      window.sessionStorage.setItem(ANTOJO_ACTIVE_TAB_STORAGE_KEY, value);
    }
  };

  const resetForm = () => {
    setForm({ name: '', address: '', phone: '', latitude: 20.0796, longitude: -99.6538, menu_image: null, menu_text: '', is_active: true, image_url: null, category: '' });
    setEditingBusiness(null);
    setShowForm(false);
  };

  const handleEdit = (b: AntojoBusiness) => {
    setForm({
      name: b.name, address: b.address, phone: b.phone || '', latitude: b.latitude, longitude: b.longitude,
      menu_image: b.menu_image, menu_text: b.menu_text || '', is_active: b.is_active,
      image_url: b.image_url, category: b.category || '',
    });
    setEditingBusiness(b);
    setShowForm(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: 'image_url' | 'menu_image') => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImage(file, { maxWidth: 1024, maxHeight: 1024, maxSizeKB: 250 });
      setForm(prev => ({ ...prev, [field]: compressed.base64 }));
      toast({
        title: 'Imagen optimizada',
        description: `${formatFileSize(compressed.originalSize)} → ${formatFileSize(compressed.compressedSize)}`,
      });
    } catch {
      toast({ title: 'Error al comprimir imagen', description: 'No se pudo optimizar la imagen', variant: 'destructive' });
    }
  };

  const handleSubmit = () => {
    if (!form.name || !form.address) {
      toast({ title: 'Campos requeridos', description: 'Nombre y dirección son obligatorios', variant: 'destructive' });
      return;
    }
    const payload = {
      ...form,
      phone: form.phone || null,
      menu_text: form.menu_text || null,
      category: form.category || null,
      image_url: form.image_url || null,
    };
    if (editingBusiness) {
      updateBusiness({ id: editingBusiness.id, ...payload });
    } else {
      createBusiness(payload);
    }
    resetForm();
  };

  const handleSetSaleTotal = (orderId: string, saleTotal: string) => {
    const amount = parseFloat(saleTotal);
    if (isNaN(amount) || amount <= 0) {
      toast({ title: 'Monto inválido', variant: 'destructive' });
      return;
    }
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    updateOrder({ id: orderId, sale_total: amount, total: amount + order.delivery_fee });
    toast({ title: 'Total actualizado' });
  };

  const handleSetDeliveryFee = (orderId: string, fee: string) => {
    const amount = parseFloat(fee);
    if (isNaN(amount) || amount < 0) {
      toast({ title: 'Monto inválido', variant: 'destructive' });
      return;
    }
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    const newTotal = order.sale_total != null ? order.sale_total + amount : null;
    updateOrder({ id: orderId, delivery_fee: amount, ...(newTotal != null ? { total: newTotal } : {}) });
    toast({ title: 'Costo de envío actualizado' });
  };

  const statusLabels: Record<string, string> = {
    pending: '⏳ Pendiente', accepted: '✅ Aceptado', preparing: '🍳 Preparando',
    ready: '📦 Listo', in_delivery: '🚴 En camino', delivered: '✅ Entregado', cancelled: '❌ Cancelado',
  };

  return (
    <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
      <TabsList>
        <TabsTrigger value="businesses" className="flex items-center gap-2">
          <Store className="h-4 w-4" /> Negocios
        </TabsTrigger>
        <TabsTrigger value="categories" className="flex items-center gap-2">
          <Tag className="h-4 w-4" /> Categorías
        </TabsTrigger>
        <TabsTrigger value="orders" className="flex items-center gap-2">
          <Package className="h-4 w-4" /> Pedidos
        </TabsTrigger>
      </TabsList>

      {/* ===== BUSINESSES TAB ===== */}
      <TabsContent value="businesses" className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-900">Negocios No Afiliados</h3>
          <Button onClick={() => setShowForm(true)}>
            <Plus className="h-4 w-4 mr-2" /> Agregar
          </Button>
        </div>

        {showForm && (
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">{editingBusiness ? 'Editar' : 'Nuevo'} Negocio Antojo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div><Label className="text-gray-900">Nombre *</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
                <div><Label className="text-gray-900">Teléfono</Label><Input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
                <div className="md:col-span-2"><Label className="text-gray-900">Dirección *</Label><Input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} /></div>
                <div><Label className="text-gray-900">Latitud</Label><Input type="number" step="any" value={form.latitude} onChange={e => setForm(p => ({ ...p, latitude: parseFloat(e.target.value) || 0 }))} /></div>
                <div><Label className="text-gray-900">Longitud</Label><Input type="number" step="any" value={form.longitude} onChange={e => setForm(p => ({ ...p, longitude: parseFloat(e.target.value) || 0 }))} /></div>
                <div className="md:col-span-2">
                  <Label className="text-gray-900">Categoría</Label>
                  <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                    <SelectTrigger><SelectValue placeholder="Seleccionar categoría" /></SelectTrigger>
                    <SelectContent>
                      {categories.filter(c => c.is_active).map(c => (
                        <SelectItem key={c.id} value={c.name}>{c.icon} {c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label className="text-gray-900">Imagen del negocio</Label><Input type="file" accept="image/jpeg,image/png" onChange={e => handleImageUpload(e, 'image_url')} /></div>
              {form.image_url && <img src={form.image_url} alt="Negocio" className="max-h-32 rounded" />}
              <div>
                <Label className="text-gray-900">Menú / Carta (solo imagen JPG o PNG)</Label>
                <Input type="file" accept="image/jpeg,image/png" onChange={e => handleImageUpload(e, 'menu_image')} />
              </div>
              {form.menu_image && (
                <img src={form.menu_image} alt="Menú" className="max-h-32 rounded" />
              )}
              <div><Label className="text-gray-900">Pizarra de productos (texto)</Label><Textarea value={form.menu_text} onChange={e => setForm(p => ({ ...p, menu_text: e.target.value }))} placeholder="Tacos de bistec - $20&#10;Quesadilla - $15&#10;Refresco - $18" className="min-h-[100px]" /></div>
              <div className="flex gap-2">
                <Button onClick={handleSubmit}>{editingBusiness ? 'Guardar' : 'Crear'}</Button>
                <Button variant="outline" onClick={resetForm}>Cancelar</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {businesses.map(b => (
            <Card key={b.id} className="bg-white border-gray-200">
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex gap-3 items-start">
                    {b.image_url && <img src={b.image_url} alt={b.name} className="w-12 h-12 rounded object-cover" />}
                    <div>
                      <h4 className="font-semibold text-gray-900">{b.name}</h4>
                      <p className="text-sm text-gray-600">{b.address}</p>
                      {b.phone && <p className="text-sm text-gray-500">{b.phone}</p>}
                      <div className="flex gap-1 mt-1">
                        <Badge variant={b.is_active ? 'default' : 'secondary'}>
                          {b.is_active ? 'Activo' : 'Inactivo'}
                        </Badge>
                        {b.category && <Badge variant="outline" className="text-gray-700">{b.category}</Badge>}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(b)}><Pencil className="h-4 w-4 text-gray-700" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => deleteBusiness(b.id)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>

      {/* ===== CATEGORIES TAB ===== */}
      <TabsContent value="categories" className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-900">Categorías de Antojos</h3>
          <Button onClick={() => setShowCatForm(true)}>
            <Plus className="h-4 w-4 mr-2" /> Agregar
          </Button>
        </div>

        {showCatForm && (
          <Card className="bg-white border-gray-200">
            <CardContent className="p-4 flex gap-3 items-end">
              <div className="flex-1"><Label className="text-gray-900">Nombre</Label><Input value={catForm.name} onChange={e => setCatForm(p => ({ ...p, name: e.target.value }))} /></div>
              <div className="w-24"><Label className="text-gray-900">Emoji</Label><Input value={catForm.icon} onChange={e => setCatForm(p => ({ ...p, icon: e.target.value }))} placeholder="🍽️" /></div>
              <Button onClick={() => {
                if (!catForm.name) return;
                createCategory({ name: catForm.name, icon: catForm.icon || undefined });
                setCatForm({ name: '', icon: '' });
                setShowCatForm(false);
              }}>Crear</Button>
              <Button variant="outline" onClick={() => setShowCatForm(false)}>Cancelar</Button>
            </CardContent>
          </Card>
        )}

        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <Badge key={cat.id} variant={cat.is_active ? 'default' : 'secondary'} className="text-sm px-3 py-1.5 gap-2">
              {cat.icon} {cat.name}
              <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => deleteCategory(cat.id)}>
                <Trash2 className="h-3 w-3" />
              </Button>
            </Badge>
          ))}
        </div>
      </TabsContent>

      {/* ===== ORDERS TAB ===== */}
      <TabsContent value="orders" className="space-y-4">
        <h3 className="text-xl font-bold text-gray-900">Pedidos de Antojos</h3>
        {orders.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Sin pedidos de antojos aún</p>
        ) : (
          <div className="space-y-3">
            {orders.map(order => (
              <Card key={order.id} className="bg-white border-gray-200">
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold text-gray-900">#{order.order_number}</p>
                      <p className="text-sm text-gray-600">
                        {order.antojo_businesses?.name || order.custom_business_name || 'Negocio personalizado'}
                      </p>
                      {order.custom_business_name && !order.antojo_business_id && (
                        <p className="text-xs text-yellow-600">📍 Negocio escrito por el cliente</p>
                      )}
                      <Badge className="mt-1">{statusLabels[order.status] || order.status}</Badge>
                    </div>
                    <div className="text-right space-y-1">
                      <p className="text-sm text-gray-600">Envío: ${order.delivery_fee.toFixed(2)}</p>
                      {order.sale_total != null ? (
                        <p className="font-bold text-gray-900">Total: ${order.total?.toFixed(2)}</p>
                      ) : (
                        <p className="text-yellow-600 text-sm">Sin total de venta</p>
                      )}
                      <div className="flex gap-1 justify-end">
                        {order.status !== 'cancelled' && order.status !== 'delivered' && (
                          <Button size="sm" variant="outline" className="text-yellow-600 border-yellow-300 hover:bg-yellow-50" onClick={() => {
                            updateOrder({ id: order.id, status: 'cancelled' });
                            toast({ title: 'Pedido cancelado' });
                          }}>
                            <XCircle className="h-3 w-3 mr-1" /> Cancelar
                          </Button>
                        )}
                        <Button size="sm" variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={() => {
                          if (window.confirm('¿Eliminar este pedido permanentemente?')) {
                            deleteOrder(order.id);
                          }
                        }}>
                          <Trash2 className="h-3 w-3 mr-1" /> Eliminar
                        </Button>
                      </div>
                    </div>
                  </div>
                  {order.order_description && (
                    <div className="bg-gray-100 rounded p-2">
                      <p className="text-sm text-gray-800 whitespace-pre-line">{order.order_description}</p>
                    </div>
                  )}
                  {order.order_image && (
                    <img src={order.order_image} alt="Nota" className="max-h-32 rounded" />
                  )}
                  {/* Delivery fee field for custom businesses */}
                  {order.custom_business_name && !order.antojo_business_id && (
                    <div className="flex gap-2 items-end">
                      <div className="flex-1">
                        <Label className="text-gray-900 text-xs">Costo de envío ($)</Label>
                        <Input type="number" step="0.01" placeholder="0.00" defaultValue={order.delivery_fee > 0 ? order.delivery_fee : ''} id={`fee-${order.id}`} className="mt-1" />
                      </div>
                      <Button size="sm" onClick={() => {
                        const input = document.getElementById(`fee-${order.id}`) as HTMLInputElement;
                        handleSetDeliveryFee(order.id, input?.value || '');
                      }}>
                        🚴 Asignar envío
                      </Button>
                    </div>
                  )}
                  {order.sale_total == null && (
                    <div className="flex gap-2 items-end">
                      <div className="flex-1">
                        <Label className="text-gray-900 text-xs">Total de venta ($)</Label>
                        <Input type="number" step="0.01" placeholder="0.00" id={`sale-${order.id}`} className="mt-1" />
                      </div>
                      <Button size="sm" onClick={() => {
                        const input = document.getElementById(`sale-${order.id}`) as HTMLInputElement;
                        handleSetSaleTotal(order.id, input?.value || '');
                      }}>
                        <DollarSign className="h-4 w-4 mr-1" /> Asignar
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
};
