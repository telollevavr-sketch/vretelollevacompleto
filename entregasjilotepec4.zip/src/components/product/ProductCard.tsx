import { Product } from '@/types';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  isSpecialBusiness?: boolean;
}

export const ProductCard = ({ product, onAddToCart, isSpecialBusiness = false }: ProductCardProps) => {
  const handleAddToCart = () => {
    // Si es un combo promocional, inicializar con comboSelections vacío
    if (product.isPromotionalCombo) {
      // El carrito se encargará de mostrar los selectores
      onAddToCart(product);
    } else {
      onAddToCart(product);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-[0_0_30px_rgba(160,100,220,0.5)] transition-all bg-[hsl(270,55%,30%)] border-2 border-[hsl(270,70%,50%)]">
      <CardHeader className="p-0">
        <div className="relative h-48">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover"
          />
          {!product.isAvailable && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <Badge variant="secondary" className="text-lg bg-[hsl(260,50%,25%)] text-white border-[hsl(270,60%,40%)]">
                No Disponible
              </Badge>
            </div>
          )}
          {product.isConfigurable && (
            <Badge className="absolute top-2 right-2 bg-gradient-to-r from-[hsl(270,70%,60%)] to-[hsl(280,75%,65%)] text-white border-0">
              Personalizable
            </Badge>
          )}
          {isSpecialBusiness && product.isPromotionalCombo && (
            <Badge className="absolute top-2 left-2 bg-gradient-to-r from-[hsl(0,70%,60%)] to-[hsl(20,75%,65%)] text-white border-0">
              🔥 Promoción
            </Badge>
          )}
          {isSpecialBusiness && product.isSpecialty && (
            <Badge className="absolute top-2 left-2 bg-gradient-to-r from-[hsl(280,70%,60%)] to-[hsl(290,75%,65%)] text-white border-0">
              ✨ Especialidad
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="p-4">
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <h3 className="font-semibold text-lg line-clamp-1 text-gray-800">
              {product.name}
            </h3>
            <p className="text-lg font-bold text-gray-800 ml-2">
              ${product.price}
            </p>
          </div>
          
          {product.description && (
            <p className="text-sm text-gray-600 line-clamp-2">
              {product.description}
            </p>
          )}

          {isSpecialBusiness && (product.isPromotionalCombo || product.isSpecialty) && (
            <div className="bg-orange-500 text-white px-3 py-2 rounded-lg text-sm font-semibold text-center">
              🛒 Elige especialidad en el carrito de compra
            </div>
          )}

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs bg-[hsl(270,40%,20%)] text-white border-[hsl(270,60%,40%)]">
              {product.category}
            </Badge>
            {product.ingredientCount && (
              <Badge variant="secondary" className="text-xs bg-[hsl(260,50%,25%)] text-white border-0">
                {product.ingredientCount} ingredientes
              </Badge>
            )}
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full bg-gradient-to-r from-[hsl(270,70%,55%)] to-[hsl(280,75%,62%)] hover:from-[hsl(270,70%,50%)] hover:to-[hsl(280,75%,57%)] text-white border-0 font-semibold text-base h-12 rounded-xl shadow-lg"
          onClick={handleAddToCart}
          disabled={!product.isAvailable}
        >
          <Plus className="h-4 w-4 mr-2" />
          Agregar al carrito
        </Button>
      </CardFooter>
    </Card>
  );
};
