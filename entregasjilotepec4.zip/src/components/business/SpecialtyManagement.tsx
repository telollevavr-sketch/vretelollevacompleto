import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, Pizza, Download, FileSpreadsheet, Search } from "lucide-react";
import { usePizzaSpecialties } from "@/hooks/usePizzaSpecialties";
import { exportSpecialtiesToExcel, exportToTSV } from "@/lib/businessExport";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface SpecialtyManagementProps {
  businessId: string;
  businessName: string;
}

export const SpecialtyManagement = ({ businessId, businessName }: SpecialtyManagementProps) => {
  const { specialties, isLoading, createSpecialty, updateSpecialty, deleteSpecialty } = usePizzaSpecialties(businessId);
  const { toast } = useToast();
  const [showModal, setShowModal] = useState(false);
  const [editingSpecialty, setEditingSpecialty] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    specialtyType: "pizza",
    isActive: true,
  });
  const [searchQuery, setSearchQuery] = useState<string>("");

  const filteredSpecialties = specialties.filter((s) => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    const matchesName = s.name.toLowerCase().includes(query);
    const matchesType = (s.specialtyType || "pizza").toLowerCase().includes(query);
    return matchesName || matchesType;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const specialtyData: any = {
      business_id: businessId,
      name: formData.name,
      description: formData.description || undefined,
      price: formData.price ? parseFloat(formData.price) : 0,
      specialty_type: formData.specialtyType,
      is_active: formData.isActive,
    };

    if (editingSpecialty) {
      updateSpecialty({
        id: editingSpecialty,
        updates: {
          name: formData.name,
          description: formData.description || undefined,
          price: formData.price ? parseFloat(formData.price) : 0,
          specialty_type: formData.specialtyType,
          is_active: formData.isActive,
        } as any,
      });
    } else {
      createSpecialty(specialtyData);
    }

    handleCloseModal();
  };

  const handleEdit = (specialty: any) => {
    setEditingSpecialty(specialty.id);
    setFormData({
      name: specialty.name,
      description: specialty.description || "",
      price: specialty.price ? specialty.price.toString() : "",
      specialtyType: specialty.specialtyType || "pizza",
      isActive: specialty.isActive,
    });
    setShowModal(true);
  };

  const handleDelete = (specialtyId: string) => {
    if (confirm("¿Estás seguro de eliminar esta especialidad?")) {
      deleteSpecialty(specialtyId);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingSpecialty(null);
    setFormData({
      name: "",
      description: "",
      price: "",
      specialtyType: "pizza",
      isActive: true,
    });
  };

  const toggleAvailability = (specialtyId: string, currentStatus: boolean) => {
    updateSpecialty({
      id: specialtyId,
      updates: { is_active: !currentStatus },
    });
  };

  const handleExportExcel = () => {
    exportSpecialtiesToExcel(specialties, businessName);
    toast({
      title: "Exportación exitosa",
      description: "Las especialidades se han exportado a Excel correctamente",
    });
  };

  const handleExportTSV = () => {
    const tsvData = specialties.map((specialty, index) => ({
      "#": index + 1,
      Nombre: specialty.name,
      Tipo: specialty.specialtyType || "pizza",
      Precio: specialty.price || 0,
      Descripción: specialty.description || "",
      Activa: specialty.isActive ? "Sí" : "No",
    }));
    exportToTSV(tsvData, `especialidades-${businessName.replace(/\s+/g, "_")}`);
    toast({
      title: "Exportación exitosa",
      description: "Las especialidades se han exportado a TSV correctamente",
    });
  };

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Pizza className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold text-white">ESPECIALIDADES</h2>
          </div>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={handleExportExcel}>
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Exportar a Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportTSV}>
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Exportar a TSV
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={() => setShowModal(true)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Agregar Especialidad
            </Button>
          </div>
        </div>

        <p className="text-sm text-muted-foreground">
          Gestiona las especialidades que tus clientes podrán seleccionar en las promociones (2x1, combos, etc.)
        </p>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nombre o tipo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {isLoading ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-muted-foreground">Cargando especialidades...</p>
            </CardContent>
          </Card>
        ) : filteredSpecialties.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center">
              <Pizza className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">
                {searchQuery.trim()
                  ? `No se encontraron especialidades para "${searchQuery}".`
                  : "No hay especialidades. Agrega tu primera especialidad."}
              </p>
              <Button onClick={() => setShowModal(true)} variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Agregar Primera Especialidad
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {filteredSpecialties.map((specialty) => (
              <Card key={specialty.id} className={!specialty.isActive ? "opacity-60" : ""}>
                <CardContent className="py-4">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Pizza className="h-4 w-4 text-primary" />
                          <h3 className="font-semibold">{specialty.name}</h3>
                          {specialty.price && specialty.price > 0 && (
                            <span className="text-sm font-bold text-primary">${specialty.price}</span>
                          )}
                        </div>
                        <span className="inline-block px-2 py-0.5 text-xs rounded-full bg-primary/20 text-primary mb-1 capitalize">
                          {specialty.specialtyType || "pizza"}
                        </span>
                        {specialty.description && (
                          <p className="text-sm text-muted-foreground">{specialty.description}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={specialty.isActive}
                          onCheckedChange={() => toggleAvailability(specialty.id, specialty.isActive)}
                        />
                        <span className="text-xs text-muted-foreground">
                          {specialty.isActive ? "Activa" : "Inactiva"}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(specialty)} className="flex-1">
                        <Edit className="h-4 w-4 mr-1" />
                        Editar
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(specialty.id)} className="flex-1">
                        <Trash2 className="h-4 w-4 mr-1" />
                        Eliminar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={showModal} onOpenChange={handleCloseModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingSpecialty ? "Editar Especialidad" : "Nueva Especialidad"}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre de la Especialidad *</Label>
              <Input
                id="name"
                placeholder="Ej: Hawaiana, Pepperoni, Mexicana..."
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción (opcional)</Label>
              <Textarea
                id="description"
                placeholder="Describe los ingredientes de esta especialidad..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
              <p className="text-xs text-muted-foreground">Ej: Jamón, piña, queso mozzarella</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Precio (opcional, para combos 2x1)</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                min="0"
                placeholder="Ej: 139"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">Solo para promociones donde se paga el de mayor precio</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="specialtyType">Tipo de Especialidad</Label>
              <Select
                value={formData.specialtyType}
                onValueChange={(value) => setFormData({ ...formData, specialtyType: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona el tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pizza">🍕 Pizza</SelectItem>
                  <SelectItem value="hamburguesa">🍔 Hamburguesa</SelectItem>
                  <SelectItem value="hotdog">🌭 Hot Dog</SelectItem>
                  <SelectItem value="torta">🥖 Torta</SelectItem>
                  <SelectItem value="taco">🌮 Taco</SelectItem>
                  <SelectItem value="burrito">🌯 Burrito</SelectItem>
                  <SelectItem value="salsa">🧂 Salsa</SelectItem>
                  <SelectItem value="queso">🧀 Queso</SelectItem>
                  <SelectItem value="bebida">🥤 Bebida</SelectItem>
                  <SelectItem value="refresco">🥤 Refresco</SelectItem>
                  <SelectItem value="refresco 2l">🥤 Refresco 2L</SelectItem>
                  <SelectItem value="refresco 3l">🥤 Refresco 3L</SelectItem>
                  <SelectItem value="frappé">🥤 Frappé</SelectItem>
                  <SelectItem value="café">🥤 Café</SelectItem>
                  <SelectItem value="esquimo">🥤 Esquimo</SelectItem>
                  <SelectItem value="cerveza">Cerveza</SelectItem>
                  <SelectItem value="aderezo">Aderezo</SelectItem>
                  <SelectItem value="agua">Agua</SelectItem>
                  <SelectItem value="botana">Botana</SelectItem>
                  <SelectItem value="carne">Carne</SelectItem>
                  <SelectItem value="para acompañar">Para acompañar</SelectItem>
                  <SelectItem value="sabores">Sabores</SelectItem>
                  <SelectItem value="chocolatería">Chocolatería</SelectItem>
                  <SelectItem value="tés">Tés</SelectItem>
                  <SelectItem value="tisanas">Tisanas</SelectItem>
                  <SelectItem value="frutales">Frutales</SelectItem>
                  <SelectItem value="extra">Extra</SelectItem>
                  <SelectItem value="postre">🍰 Postre</SelectItem>
                  <SelectItem value="base">Base</SelectItem>
                  <SelectItem value="topping">Topping</SelectItem>
                  <SelectItem value="empanadas">Empanadas</SelectItem>
                  <SelectItem value="pastas">Pastas</SelectItem>
                  <SelectItem value="jugos">Jugos</SelectItem>
                  <SelectItem value="quesadilla">Quesadillas</SelectItem>
                  <SelectItem value="waffles">Waffles</SelectItem>
                  <SelectItem value="creppas">Creppas</SelectItem>
                  <SelectItem value="hotcakes">Hotcakes</SelectItem>
                  <SelectItem value="moka">Moka</SelectItem>
                  <SelectItem value="moka blanco">Moka blanco</SelectItem>
                  <SelectItem value="latte de sabor">Latte de sabor</SelectItem>
                  <SelectItem value="frappé clásico">Frappé clásico</SelectItem>
                  <SelectItem value="frappé clásico 20oz">Frappé clásico 20oz</SelectItem>
                  <SelectItem value="frappesaurio">Frappesaurio</SelectItem>
                  <SelectItem value="rollo sushi">Rollo sushi</SelectItem>
                  <SelectItem value="proteina">Proteina</SelectItem>
                  <SelectItem value="complemento">Complemento</SelectItem>
                  <SelectItem value="tu gusto (frio/caliente)">Tu gusto (frio/caliente)</SelectItem>
                  <SelectItem value="agua mineral">Agua mineral</SelectItem>
                  <SelectItem value="leche">Leche</SelectItem>
                  <SelectItem value="decorado">Decorado</SelectItem>
                  <SelectItem value="chocolatería 12oz">Chocolatería 12oz</SelectItem>
                  <SelectItem value="chocolatería 16oz">Chocolatería 16oz</SelectItem>
                  <SelectItem value="frappé bebida 12oz">Frappé bebida 12oz</SelectItem>
                  <SelectItem value="frappé bebida 16oz">Frappé bebida 16oz</SelectItem>
                  <SelectItem value="frappé bebida 20oz">Frappé bebida 20oz</SelectItem>
                  <SelectItem value="smoothie 12oz">Smoothie 12oz</SelectItem>
                  <SelectItem value="smoothie 16oz">Smoothie 16oz</SelectItem>
                  <SelectItem value="soda italiana 12oz">Soda italiana 12oz</SelectItem>
                  <SelectItem value="soda italiana 16oz">Soda italiana 16oz</SelectItem>
                  <SelectItem value="soda italiana 20oz">Soda italiana 20oz</SelectItem>
                  <SelectItem value="frappesaurio 12oz">Frappesaurio 12oz</SelectItem>
                  <SelectItem value="frappesaurio 16oz">Frappesaurio 16oz</SelectItem>
                  <SelectItem value="frappesaurio 20oz">Frappesaurio 20oz</SelectItem>
                  <SelectItem value="latte 12oz">Latte 12oz</SelectItem>
                  <SelectItem value="latte 16oz">Latte 16oz</SelectItem>
                  <SelectItem value="latte 20oz">Latte 20oz</SelectItem>
                  <SelectItem value="tisana 12oz">Tisana 12oz</SelectItem>
                  <SelectItem value="tisana 16oz">Tisana 16oz</SelectItem>
                  <SelectItem value="tisana 20oz">Tisana 20oz</SelectItem>
                  <SelectItem value="chai latte 12oz">Chai latte 12oz</SelectItem>
                  <SelectItem value="chai latte 16oz">Chai latte 16oz</SelectItem>
                  <SelectItem value="chai latte 20oz">Chai latte 20oz</SelectItem>
                  <SelectItem value="masala chai 12oz">Masala chai 12oz</SelectItem>
                  <SelectItem value="masala chai 16oz">Masala chai 16oz</SelectItem>
                  <SelectItem value="masala chai 20oz">Masala chai 20oz</SelectItem>
                  <SelectItem value="infusiones frutales 20oz">Infusiones frutales 20oz</SelectItem>
                  <SelectItem value="chamoyada 20oz">Chamoyada 20oz</SelectItem>
                  <SelectItem value="chai sucio 12oz">Chai sucio 12oz</SelectItem>
                  <SelectItem value="chai sucio 16oz">Chai sucio 16oz</SelectItem>
                  <SelectItem value="otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
              <Label>Especialidad activa</Label>
            </div>

            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={handleCloseModal} className="flex-1">
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                {editingSpecialty ? "Actualizar" : "Crear"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};
