import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useProductComplements } from '@/hooks/useProductComplements';
import { useComplementTemplates } from '@/hooks/useComplementTemplates';
import { useProductComplementCounts } from '@/hooks/useProductComplementCounts';
import { useProducts } from '@/hooks/useProducts';
import { Plus, Pencil, Trash2, Package, ChefHat, Sparkles, Download, FileSpreadsheet } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { exportComplementsToExcel, exportToTSV } from '@/lib/businessExport';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const COMPLEMENT_CATEGORIES = [
  { value: 'quesos', label: 'Quesos', icon: '🧀' },
  { value: 'salsas', label: 'Salsas', icon: '🍯' },
  { value: 'vegetales', label: 'Vegetales', icon: '🥬' },
  { value: 'carnes', label: 'Carnes', icon: '🥓' },
  { value: 'otros', label: 'Otros', icon: '✨' },
];

interface ComplementManagementProps {
  businessId: string;
  businessName: string;
}

export function ComplementManagement({ businessId, businessName }: ComplementManagementProps) {
  const { products } = useProducts(businessId);
  const { toast } = useToast();
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const { complements, createComplement, updateComplement, deleteComplement } = useProductComplements(selectedProductId);
  const { templates, applyMultipleTemplates } = useComplementTemplates();
  const { counts: complementCounts } = useProductComplementCounts(businessId);
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [templatesDialogOpen, setTemplatesDialogOpen] = useState(false);
  const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: 0,
    category: 'otros',
    description: '',
    is_available: true,
  });


  const handleOpenDialog = (productId: string, complementId?: string) => {
    setSelectedProductId(productId);
    
    if (complementId) {
      const complement = complements.find(c => c.id === complementId);
      if (complement) {
        setEditingId(complementId);
        setFormData({
          name: complement.name,
          price: complement.price,
          category: complement.category,
          description: complement.description || '',
          is_available: complement.isAvailable,
        });
      }
    } else {
      setEditingId(null);
      setFormData({
        name: '',
        price: 0,
        category: 'otros',
        description: '',
        is_available: true,
      });
    }
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!selectedProductId) return;

    if (editingId) {
      await updateComplement.mutateAsync({
        id: editingId,
        updates: {
          ...formData,
          product_id: selectedProductId,
        },
      });
    } else {
      await createComplement.mutateAsync({
        ...formData,
        product_id: selectedProductId,
      });
    }
    
    setDialogOpen(false);
  };

  const handleToggleAvailability = async (productId: string, complementId: string, currentStatus: boolean) => {
    setSelectedProductId(productId);
    await updateComplement.mutateAsync({
      id: complementId,
      updates: {
        is_available: !currentStatus,
      },
    });
  };

  const handleDelete = async (productId: string, complementId: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar este complemento?')) {
      setSelectedProductId(productId);
      await deleteComplement.mutateAsync(complementId);
    }
  };

  const handleOpenTemplatesDialog = (productId: string) => {
    setSelectedProductId(productId);
    setSelectedTemplates([]);
    setTemplatesDialogOpen(true);
  };

  const handleApplyTemplates = async () => {
    if (selectedTemplates.length === 0 || !selectedProductId) return;

    await applyMultipleTemplates.mutateAsync({
      templateIds: selectedTemplates,
      productId: selectedProductId,
    });

    setTemplatesDialogOpen(false);
    setSelectedTemplates([]);
  };

  const toggleTemplateSelection = (templateId: string) => {
    setSelectedTemplates((prev) =>
      prev.includes(templateId)
        ? prev.filter((id) => id !== templateId)
        : [...prev, templateId]
    );
  };

  const getComplementsByProduct = (productId: string) => {
    if (selectedProductId === productId) {
      return complements;
    }
    return [];
  };

  const getComplementCount = (productId: string) => {
    return complementCounts[productId] || 0;
  };

  const getProductsWithComplements = () => {
    return products.map(product => {
      const productComplements = getComplementsByProduct(product.id);
      return {
        ...product,
        complements: productComplements
      };
    });
  };

  const handleExportExcel = () => {
    const productsWithComplements = getProductsWithComplements();
    exportComplementsToExcel(productsWithComplements, businessName);
    toast({
      title: "Exportación exitosa",
      description: "Los complementos se han exportado a Excel correctamente",
    });
  };

  const handleExportTSV = () => {
    const productsWithComplements = getProductsWithComplements();
    const tsvData: any[] = [];
    
    productsWithComplements.forEach(product => {
      if (product.complements && product.complements.length > 0) {
        product.complements.forEach((complement: any, index: number) => {
          tsvData.push({
            'Producto': product.name,
            '#': index + 1,
            'Complemento': complement.name,
            'Precio': complement.price,
            'Disponible': complement.isAvailable ? 'Sí' : 'No'
          });
        });
      }
    });
    
    exportToTSV(tsvData, `complementos-${businessName.replace(/\s+/g, '_')}`);
    toast({
      title: "Exportación exitosa",
      description: "Los complementos se han exportado a TSV correctamente",
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <ChefHat className="h-5 w-5" />
              Gestión de Complementos por Producto
            </CardTitle>
            <CardDescription>
              Administra los complementos específicos de cada producto en tu menú
            </CardDescription>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={handleExportExcel}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Exportar a Excel (.xlsx)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleExportTSV}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Exportar a TSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {products.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No hay productos en tu menú</p>
            <p className="text-sm">Agrega productos primero para gestionar sus complementos</p>
          </div>
        ) : (
          <Accordion type="single" collapsible className="w-full">
            {products.map((product) => {
              const productComplements = getComplementsByProduct(product.id);
              const groupedComplements = productComplements.reduce((acc, comp) => {
                if (!acc[comp.category]) acc[comp.category] = [];
                acc[comp.category].push(comp);
                return acc;
              }, {} as Record<string, typeof productComplements>);

              return (
                <AccordionItem key={product.id} value={product.id}>
                  <AccordionTrigger 
                    className="hover:no-underline"
                    onClick={() => setSelectedProductId(product.id)}
                  >
                    <div className="flex items-center justify-between w-full pr-4">
                      <div className="flex items-center gap-3">
                        <Package className="h-4 w-4" />
                        <span className="font-medium">{product.name}</span>
                        <Badge variant="secondary" className="ml-2">
                          {getComplementCount(product.id)} complementos
                        </Badge>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pt-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <Button 
                          onClick={() => handleOpenDialog(product.id)}
                          className="w-full"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Crear Complemento
                        </Button>
                        <Button 
                          onClick={() => handleOpenTemplatesDialog(product.id)}
                          variant="secondary"
                          className="w-full"
                        >
                          <Sparkles className="h-4 w-4 mr-2" />
                          Usar Plantillas
                        </Button>
                      </div>

                      {productComplements.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                          <p>No hay complementos para este producto</p>
                          <p className="text-sm">Agrega complementos personalizados</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {Object.entries(groupedComplements).map(([category, items]) => {
                            const categoryInfo = COMPLEMENT_CATEGORIES.find(c => c.value === category);
                            return (
                              <div key={category} className="space-y-2">
                                <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                                  <span>{categoryInfo?.icon}</span>
                                  <span>{categoryInfo?.label || category}</span>
                                </div>
                                <div className="space-y-2">
                                  {items.map((complement) => (
                                    <div
                                      key={complement.id}
                                      className="flex items-center justify-between p-3 rounded-lg border bg-card"
                                    >
                                      <div className="flex-1">
                                        <div className="flex items-center gap-2">
                                          <p className="font-medium">{complement.name}</p>
                                          {!complement.isAvailable && (
                                            <Badge variant="outline" className="text-xs">
                                              No disponible
                                            </Badge>
                                          )}
                                        </div>
                                        {complement.description && (
                                          <p className="text-sm text-muted-foreground mt-1">
                                            {complement.description}
                                          </p>
                                        )}
                                        <p className="text-sm font-medium text-primary mt-1">
                                          ${complement.price.toFixed(2)}
                                        </p>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <Switch
                                          checked={complement.isAvailable}
                                          onCheckedChange={() =>
                                            handleToggleAvailability(product.id, complement.id, complement.isAvailable)
                                          }
                                        />
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          onClick={() => handleOpenDialog(product.id, complement.id)}
                                        >
                                          <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          onClick={() => handleDelete(product.id, complement.id)}
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        )}

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingId ? 'Editar Complemento' : 'Agregar Complemento'}
              </DialogTitle>
              <DialogDescription>
                {editingId
                  ? 'Modifica los detalles del complemento'
                  : 'Agrega un nuevo complemento para este producto'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ej: Queso Mozzarella Extra"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {COMPLEMENT_CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        <span className="flex items-center gap-2">
                          <span>{cat.icon}</span>
                          <span>{cat.label}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Precio</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descripción (opcional)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Breve descripción del complemento"
                  rows={3}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="available">Disponible</Label>
                <Switch
                  id="available"
                  checked={formData.is_available}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, is_available: checked })
                  }
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSubmit}>
                {editingId ? 'Actualizar' : 'Crear'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Diálogo de Plantillas */}
        <Dialog open={templatesDialogOpen} onOpenChange={setTemplatesDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                Usar Plantillas de Complementos
              </DialogTitle>
              <DialogDescription>
                Selecciona plantillas predefinidas para agregar complementos rápidamente
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="max-h-[50vh] pr-4">
              <div className="space-y-6">
                {COMPLEMENT_CATEGORIES.map((category) => {
                  const categoryTemplates = templates.filter(
                    (t) => t.category === category.value
                  );

                  if (categoryTemplates.length === 0) return null;

                  return (
                    <div key={category.value} className="space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{category.icon}</span>
                        <h3 className="font-semibold text-lg">{category.label}</h3>
                        <Badge variant="outline">{categoryTemplates.length}</Badge>
                      </div>
                      <Separator />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {categoryTemplates.map((template) => {
                          const isSelected = selectedTemplates.includes(template.id);
                          return (
                            <div
                              key={template.id}
                              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                isSelected
                                  ? 'border-primary bg-primary/5'
                                  : 'border-border hover:border-primary/50'
                              }`}
                              onClick={() => toggleTemplateSelection(template.id)}
                            >
                              <div className="flex items-start gap-3">
                                <Checkbox
                                  checked={isSelected}
                                  onCheckedChange={() => toggleTemplateSelection(template.id)}
                                  onClick={(e) => e.stopPropagation()}
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between gap-2">
                                    <p className="font-medium text-sm truncate">
                                      {template.name}
                                    </p>
                                    <Badge variant="secondary" className="shrink-0">
                                      ${template.price.toFixed(2)}
                                    </Badge>
                                  </div>
                                  {template.description && (
                                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                      {template.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
            <DialogFooter className="flex items-center justify-between sm:justify-between">
              <div className="text-sm text-muted-foreground">
                {selectedTemplates.length > 0 && (
                  <span>{selectedTemplates.length} plantilla(s) seleccionada(s)</span>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setTemplatesDialogOpen(false);
                    setSelectedTemplates([]);
                  }}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleApplyTemplates}
                  disabled={selectedTemplates.length === 0 || applyMultipleTemplates.isPending}
                >
                  Agregar {selectedTemplates.length > 0 && `(${selectedTemplates.length})`}
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
