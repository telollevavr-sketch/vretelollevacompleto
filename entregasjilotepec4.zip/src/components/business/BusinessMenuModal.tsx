import { useState, useEffect } from 'react';
import { Business, Product, CartItem } from '@/types';
import { useProducts } from '@/hooks/useProducts';
import { useAuth } from '@/contexts/AuthContext';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, Clock, Search, MapPin, Phone, Pizza, UtensilsCrossed, Coffee, Cake, IceCream, Beef, Salad, Cookie, Wine, Sandwich, Soup, CloudRain } from 'lucide-react';
import { ProductCard } from '@/components/product/ProductCard';
import { PizzaBuilder, PizzaConfiguration } from '@/components/pizza/PizzaBuilder';
import { AuthModal } from '@/components/auth/AuthModal';
import { toast } from '@/hooks/use-toast';

interface BusinessMenuModalProps {
  open: boolean;
  onClose: () => void;
  business: Business | null;
  onAddToCart: (product: Product, configuration?: CartItem['configuration']) => void;
}

export const BusinessMenuModal = ({ open, onClose, business, onAddToCart }: BusinessMenuModalProps) => {
  const { user } = useAuth();
  const { products } = useProducts(business?.id);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPizzaBuilder, setShowPizzaBuilder] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Category icon mapping
  const getCategoryIcon = (category: string) => {
    const categoryLower = category.toLowerCase();
    if (categoryLower.includes('pizza')) return Pizza;
    if (categoryLower.includes('postre') || categoryLower.includes('dulce')) return Cake;
    if (categoryLower.includes('bebida') || categoryLower.includes('café') || categoryLower.includes('coffee')) return Coffee;
    if (categoryLower.includes('helado')) return IceCream;
    if (categoryLower.includes('carne') || categoryLower.includes('parrilla')) return Beef;
    if (categoryLower.includes('ensalada') || categoryLower.includes('vegetal')) return Salad;
    if (categoryLower.includes('galleta') || categoryLower.includes('cookie')) return Cookie;
    if (categoryLower.includes('vino') || categoryLower.includes('licor') || categoryLower.includes('alcohol')) return Wine;
    if (categoryLower.includes('sandwich') || categoryLower.includes('hamburguesa') || categoryLower.includes('torta')) return Sandwich;
    if (categoryLower.includes('sopa') || categoryLower.includes('crema')) return Soup;
    return UtensilsCrossed; // Default icon
  };

  // Extract unique categories from products
  const uniqueCategories = Array.from(
    new Set(products
      .filter(p => !p.name.toLowerCase().includes('arma tu pizza'))
      .map(p => p.category)
      .filter(Boolean)
    )
  ).sort();

  const filteredProducts = products
    .filter(p =>
      !p.name.toLowerCase().includes('arma tu pizza') &&
      (p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.description && p.description.toLowerCase().includes(searchQuery.toLowerCase()))) &&
      (!selectedCategory || p.category === selectedCategory)
    )
    .sort((a, b) => {
      // Primero ordenar por categoría
      const categoryCompare = a.category.localeCompare(b.category);
      if (categoryCompare !== 0) return categoryCompare;
      
      // Si la categoría es la misma, ordenar por nombre
      return a.name.localeCompare(b.name);
    });

  const pizzaProducts = products.filter(p => 
    p.name.toLowerCase().includes('arma tu pizza')
  );

  const handleStartPizzaBuilder = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    setShowPizzaBuilder(true);
  };

  const handlePizzaAddToCart = (config: PizzaConfiguration) => {
    if (!business) return;

    const customPizza: Product = {
      id: `custom-pizza-${Date.now()}`,
      businessId: business.id,
      name: `Pizza ${config.size} Personalizada`,
      description: `Ingredientes: ${config.ingredients.join(', ')}${config.stuffedCrust ? ' + Orilla Rellena' : ''}`,
      price: config.price,
      category: 'Pizza',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop',
      isAvailable: true,
      isConfigurable: true,
      createdAt: new Date().toISOString()
    };

    // Pasar la configuración junto con el producto
    const configuration: CartItem['configuration'] = {
      size: config.size,
      ingredients: config.ingredients,
      stuffedCrust: config.stuffedCrust
    };

    onAddToCart(customPizza, configuration);
  };

  if (!business) return null;

  // Bloquear el menú cuando el negocio no está disponible por clima
  if (business.weatherUnavailable) {
    return (
      <Sheet open={open} onOpenChange={onClose}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{business.name}</SheetTitle>
          </SheetHeader>
          <div className="flex flex-col items-center justify-center gap-4 py-16 text-center">
            <CloudRain className="h-16 w-16 text-sky-400 animate-pulse" />
            <p className="text-lg font-semibold">☔ Verifica disponibilidad</p>
            <p className="text-xl font-bold tracking-wide">554895 7140</p>
            <p className="text-muted-foreground max-w-md">
              Este negocio no está disponible temporalmente por causas climáticas.
            </p>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  const isPizzaBusiness = business.category.toLowerCase().includes('pizza');
  const showPizzaBuilderSection = isPizzaBusiness && (business.isSpecialBusiness === true) && pizzaProducts.length > 0;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <div className="space-y-4">
            {/* Business Header */}
            <div className="relative h-32 -mx-6 -mt-6 mb-4 overflow-hidden">
              <img
                src={business.image}
                alt={business.name}
                className="w-full h-full object-cover"
                style={{ 
                  imageRendering: 'auto',
                  backfaceVisibility: 'hidden'
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <SheetTitle className="text-white text-2xl mb-2">{business.name}</SheetTitle>
                <Badge variant="secondary">{business.category}</Badge>
              </div>
            </div>

            {/* Business Info */}
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{business.rating.toFixed(1)}</span>
                <span className="text-muted-foreground">({business.reviewCount} reseñas)</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{business.deliveryTime} min</span>
              </div>
              <Badge variant={business.isOpen ? 'default' : 'secondary'}>
                {business.isOpen ? 'Abierto' : 'Cerrado'}
              </Badge>
            </div>

            {/* Contact Info */}
            <Card>
              <CardContent className="p-4">
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <Phone className="h-4 w-4 mt-0.5 text-muted-foreground" />
                    <span>{business.phone}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                    <span>{business.fullAddress || business.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Costo de Envío:</span>
                    <span>${business.deliveryFee}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </SheetHeader>

        <div className="space-y-6 py-6">
          {/* Pizza Builder Section - Only for Special Pizza businesses */}
          {showPizzaBuilderSection && (
            <Card className="bg-gradient-to-r from-primary/20 to-primary/10 border-primary/30">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-primary/20 p-3 rounded-full">
                      <Pizza className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">¡Arma tu Pizza!</h3>
                      <p className="text-sm text-muted-foreground">
                        Crea tu combinación perfecta a tu gusto.
                      </p>
                    </div>
                  </div>
                  <Button
                    size="lg"
                    onClick={handleStartPizzaBuilder}
                    className="bg-primary hover:bg-primary/90"
                  >
                    Empezar a Crear
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              type="text"
              placeholder="Buscar en el menú..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter Bar */}
          {uniqueCategories.length > 0 && (
            <div className="mb-6">
              <h3 className="text-sm font-medium text-muted-foreground mb-3">
                Categorías
              </h3>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedCategory === null ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(null)}
                  className="rounded-full"
                >
                  <UtensilsCrossed className="h-4 w-4 mr-1.5" />
                  Todas
                </Button>
                {uniqueCategories.map(category => {
                  const IconComponent = getCategoryIcon(category);
                  return (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory(category)}
                      className="rounded-full"
                    >
                      <IconComponent className="h-4 w-4 mr-1.5" />
                      {category}
                    </Button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Products */}
          <div>
            <h2 className="text-xl font-bold mb-4">Menú</h2>
            {filteredProducts.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No se encontraron productos
              </p>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {filteredProducts.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={onAddToCart}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </SheetContent>

      {/* Pizza Builder Modal */}
      {showPizzaBuilderSection && (
        <PizzaBuilder
          open={showPizzaBuilder}
          onClose={() => setShowPizzaBuilder(false)}
          onAddToCart={handlePizzaAddToCart}
          businessId={business.id}
          pizzaProducts={pizzaProducts}
        />
      )}

      {/* Auth Modal */}
      <AuthModal open={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </Sheet>
  );
};
