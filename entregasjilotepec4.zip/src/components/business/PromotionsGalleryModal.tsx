import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Promotion } from '@/hooks/usePromotions';

interface PromotionsGalleryModalProps {
  open: boolean;
  onClose: () => void;
  promotions: Promotion[];
  businessName: string;
}

export const PromotionsGalleryModal = ({
  open,
  onClose,
  promotions,
  businessName,
}: PromotionsGalleryModalProps) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Promociones de {businessName}</DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[60vh]">
          {promotions.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              Este negocio no tiene promociones activas
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
              {promotions.map((promo) => (
                <div
                  key={promo.id}
                  className="rounded-lg overflow-hidden border bg-card"
                >
                  <img
                    src={promo.imageData}
                    alt={promo.title}
                    className="w-full h-64 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{promo.title}</h3>
                    {promo.description && (
                      <p className="text-sm text-muted-foreground">
                        {promo.description}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
