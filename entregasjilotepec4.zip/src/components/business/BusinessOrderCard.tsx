import { useState } from 'react';
import { Order, OrderStatus, Location, Business } from '@/types';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, MapPin, DollarSign, Package, Printer } from 'lucide-react';
import { AcceptOrderModal } from './AcceptOrderModal';
import { BusinessOrderDetailsModal } from './BusinessOrderDetailsModal';
import { useOrders } from '@/hooks/useOrders';
import { locationService } from '@/services/locationService';
import { toast } from '@/hooks/use-toast';
import { dbOrderToOrder, mapOrderStatusToDbStatus } from '@/lib/typeConversions';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import { generateOrderTicketPDF } from '@/lib/pdfGenerator';

interface BusinessOrderCardProps {
  order: Order;
  businessLocation?: Location;
  business?: Business;
}

export const BusinessOrderCard = ({ order, businessLocation, business }: BusinessOrderCardProps) => {
  const { updateOrder } = useOrders();
  const [showAcceptModal, setShowAcceptModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const handlePrintTicket = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (business) {
      generateOrderTicketPDF(order, business);
    }
  };

  const getStatusBadge = () => {
    switch (order.status) {
      case OrderStatus.PENDING:
        return <Badge variant="outline" className="bg-yellow-500 text-white border-yellow-600">Pendiente</Badge>;
      case OrderStatus.IN_PREPARATION:
        return <Badge className="bg-blue-600 text-white">En Preparación</Badge>;
      case OrderStatus.READY_FOR_PICKUP:
        return <Badge variant="secondary" className="bg-green-600 text-white">Listo para Recoger</Badge>;
      case OrderStatus.ON_THE_WAY:
        return <Badge className="bg-purple-600 text-white">En Camino</Badge>;
      default:
        return null;
    }
  };

  const handleAccept = () => {
    setShowAcceptModal(true);
  };

  const handleReject = async () => {
    await updateOrder({
      id: order.id,
      status: mapOrderStatusToDbStatus(OrderStatus.CANCELLED) as any
    });

    toast({
      title: 'Pedido Rechazado',
      description: 'El pedido ha sido rechazado'
    });
  };

  const handleMarkReady = async () => {
    await updateOrder({
      id: order.id,
      status: mapOrderStatusToDbStatus(OrderStatus.READY_FOR_PICKUP) as any
    });

    toast({
      title: 'Pedido Listo',
      description: 'El pedido está listo para ser recogido por el repartidor'
    });
  };

  const handleDeliver = async () => {
    await updateOrder({
      id: order.id,
      status: mapOrderStatusToDbStatus(OrderStatus.DELIVERED) as any
    });

    toast({
      title: 'Pedido Entregado',
      description: 'El pedido ha sido marcado como entregado exitosamente'
    });
  };

  const handleConfirmAccept = async (preparationTime: number, adjustedDeliveryFee?: number, isPickupAtCounter?: boolean) => {
    console.log('✅ [BUSINESS] Aceptando pedido:', {
      orderId: order.id,
      isPickupAtCounter,
      isPickupAtCounterType: typeof isPickupAtCounter
    });
    
    let finalDeliveryFee = adjustedDeliveryFee ?? order.deliveryFee;

    if (finalDeliveryFee === 0 && !isPickupAtCounter && businessLocation) {
      const distance = locationService.calculateDistance(
        businessLocation,
        order.deliveryLocation
      );
      finalDeliveryFee = locationService.calculateDeliveryFeeByDistance(distance);
    }

    if (isPickupAtCounter) {
      finalDeliveryFee = 0;
    }

    // Todos los pedidos inician en preparación
    const finalStatus = OrderStatus.IN_PREPARATION;
    
    console.log('📊 [BUSINESS] Estado final del pedido:', {
      isPickupAtCounter,
      finalStatus,
      statusString: mapOrderStatusToDbStatus(finalStatus)
    });

    const updateData = {
      id: order.id,
      status: mapOrderStatusToDbStatus(finalStatus) as any,
      delivery_fee: finalDeliveryFee,
      total: order.subtotal + finalDeliveryFee,
      is_pickup_at_counter: isPickupAtCounter
    };

    console.log('📤 [BUSINESS] Enviando actualización a DB:', updateData);

    try {
      await updateOrder(updateData);
      console.log('✅ [BUSINESS] Actualización completada exitosamente');
    } catch (error) {
      console.error('❌ [BUSINESS] Error al actualizar:', error);
    }

    toast({
      title: 'Pedido Aceptado',
      description: isPickupAtCounter 
        ? `Entrega en mostrador - Tiempo de preparación: ${preparationTime} minutos` 
        : `Tiempo de preparación: ${preparationTime} minutos - Costo de envío: $${finalDeliveryFee.toFixed(2)}`
    });

    setShowAcceptModal(false);
  };

  return (
    <>
      <Card className="bg-[hsl(150,50%,85%)] border-[hsl(150,40%,70%)] hover:border-[hsl(150,50%,60%)] transition-all duration-300 hover:shadow-lg animate-fade-in">
        <CardHeader 
          className="bg-gradient-to-br from-[hsl(150,40%,80%)]/50 to-transparent pb-3 cursor-pointer hover:bg-[hsl(150,40%,75%)] transition-colors"
          onClick={() => setShowDetailsModal(true)}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold text-base text-black">
                Pedido #{order.id.slice(0, 8)}
              </p>
              <p className="text-xs text-gray-600 mt-1">
                {formatDistanceToNow(new Date(order.createdAt), { 
                  addSuffix: true, 
                  locale: es 
                })}
              </p>
              {order.notes?.startsWith('[CAPTURA MANUAL ADMIN]') && (
                <Badge className="mt-1 bg-purple-600 text-white text-[10px]">Captura manual</Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              {business && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrintTicket}
                  className="bg-white hover:bg-gray-100 text-gray-700 border-gray-300"
                  title="Imprimir Comanda"
                >
                  <Printer className="h-4 w-4" />
                </Button>
              )}
              {getStatusBadge()}
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4 pt-4">
          <div>
            <p className="font-semibold mb-2 text-black">Artículos:</p>
            {order.items.map((item, index) => (
              <div key={index} className="text-sm text-black">
                <span>{item.quantity}x {item.product.name}</span>

                {item.selectedComplements && item.selectedComplements.length > 0 && (
                  <div className="ml-4 mt-1">
                    <p className="text-xs font-semibold text-green-600">Complementos:</p>
                    <ul className="space-y-0.5">
                      {item.selectedComplements.map((comp, idx) => (
                        <li key={idx} className="text-xs text-gray-600">
                          • {comp.complementName}
                          {comp.complementPrice > 0 && ` (+$${comp.complementPrice})`}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="flex items-center gap-2 text-base bg-[hsl(150,40%,75%)] p-2 rounded-lg border border-[hsl(150,40%,60%)]">
            <DollarSign className="h-5 w-5 text-green-700" />
            <span className="font-bold text-lg text-black">${order.total.toFixed(2)}</span>
            <span className="text-sm text-gray-700 ml-auto">
              ({order.paymentMethod === 'CASH' ? 'Efectivo' : 'Transferencia'})
            </span>
          </div>

          <div className="flex items-start gap-2 text-sm">
            <MapPin className="h-4 w-4 mt-0.5 text-green-700" />
            <span className="text-gray-800">
              {order.deliveryLocation.address || 
               `${order.deliveryLocation.lat.toFixed(4)}, ${order.deliveryLocation.lng.toFixed(4)}`}
            </span>
          </div>

          {order.notes && (
            <div className="text-sm">
              <span className="font-semibold text-black">Notas: </span>
              <span className="text-gray-700">{order.notes}</span>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex gap-2 bg-[hsl(150,40%,80%)] pt-4">
          {order.status === OrderStatus.PENDING && (
            <>
              <Button 
                variant="outline" 
                className="flex-1 hover-scale bg-red-600 hover:bg-red-700 text-white border-red-600"
                onClick={handleReject}
              >
                ✕ Rechazar
              </Button>
              <Button 
                className="flex-1 bg-green-600 hover:bg-green-700 text-white hover-scale"
                onClick={handleAccept}
              >
                ✓ Aceptar
              </Button>
            </>
          )}

          {order.status === OrderStatus.IN_PREPARATION && (
            <>
              <div className="flex items-center gap-2 flex-wrap">
                {order.preparationTime && (
                  <div className="flex items-center gap-2 text-sm font-medium text-black bg-yellow-300 px-3 py-2 rounded-lg border border-yellow-400">
                    <Clock className="h-4 w-4 text-black" />
                    <span>{order.preparationTime}</span>
                  </div>
                )}
                {order.isPickupAtCounter && (
                  <Badge variant="secondary" className="text-xs bg-blue-600 text-white">
                    📦 Mostrador
                  </Badge>
                )}
              </div>
              <Button onClick={handleMarkReady} className="ml-auto bg-green-600 hover:bg-green-700 text-white hover-scale">
                Marcar como Listo
              </Button>
            </>
          )}

          {order.status === OrderStatus.READY_FOR_PICKUP && (
            <>
              {order.isPickupAtCounter ? (
                <Button 
                  onClick={handleDeliver} 
                  className="w-full bg-green-600 hover:bg-green-700 text-white hover-scale"
                >
                  ✓ ENTREGAR
                </Button>
              ) : (
                <div className="w-full text-center py-2">
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 rounded-full animate-pulse-glow border border-blue-300">
                    <Package className="h-4 w-4 text-blue-700" />
                    <span className="text-sm font-medium text-black">Esperando repartidor...</span>
                  </div>
                </div>
              )}
            </>
          )}
        </CardFooter>
      </Card>

      <AcceptOrderModal
        open={showAcceptModal}
        onClose={() => setShowAcceptModal(false)}
        order={order}
        onConfirm={handleConfirmAccept}
      />

      <BusinessOrderDetailsModal
        order={order}
        open={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
      />
    </>
  );
};
