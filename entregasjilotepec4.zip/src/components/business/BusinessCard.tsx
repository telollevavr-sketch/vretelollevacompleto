import { useState } from "react";
import { Business } from "@/types";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Clock, MapPin, DollarSign, ImageIcon, FileText, Truck, CloudRain } from "lucide-react";
import { PromotionsGalleryModal } from "@/components/business/PromotionsGalleryModal";
import { MenuGalleryModal } from "@/components/client/MenuGalleryModal";
import { usePromotions } from "@/hooks/usePromotions";
import { useMenuImages } from "@/hooks/useMenuImages";

interface BusinessCardProps {
  business: Business;
  onSelect: (business: Business) => void;
  promotionCount?: number;
  menuImageCount?: number;
}

export const BusinessCard = ({ business, onSelect, promotionCount, menuImageCount }: BusinessCardProps) => {
  const effectivePromoCount = promotionCount ?? 0;
  const effectiveMenuCount = menuImageCount ?? 0;
  
  const [showPromotions, setShowPromotions] = useState(false);
  const [showMenuGallery, setShowMenuGallery] = useState(false);

  // Lazy-load full data only when modals open
  const { promotions: fullPromotions } = usePromotions(showPromotions ? business.id : undefined);
  const { menuImages: fullMenuImages } = useMenuImages(showMenuGallery ? business.id : undefined);

  const isBlocked = business.isComingSoon || business.weatherUnavailable;

  const handleSelect = () => {
    if (isBlocked) return;
    onSelect(business);
  };

  return (
    <>
      <Card
        className={`overflow-hidden hover:shadow-[0_0_30px_rgba(160,100,220,0.5)] transition-all group bg-[hsl(270,55%,30%)] border-2 border-[hsl(270,70%,50%)] ${isBlocked ? 'cursor-not-allowed' : 'cursor-pointer'}`}
        onClick={handleSelect}
      >
        <div className="relative h-48 overflow-hidden">
          <img
            src={business.image}
            alt={business.name}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            style={{
              imageRendering: "auto",
              backfaceVisibility: "hidden",
            }}
          />
          {business.weatherUnavailable ? (
            <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-2 px-4 text-center">
              <CloudRain className="h-10 w-10 text-sky-300 animate-pulse" />
              <Badge variant="secondary" className="text-base bg-sky-900/80 text-white border-sky-400 whitespace-normal text-center leading-snug">
                ☔ Verifica disponibilidad
              </Badge>
              <span className="text-white font-bold text-lg tracking-wide">554895 7140</span>
            </div>
          ) : (business.isComingSoon || !business.isOpen) ? (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <Badge variant="secondary" className="text-lg bg-[hsl(260,50%,25%)] text-white border-[hsl(270,60%,40%)]">
                {business.isComingSoon ? '🚧 Próximamente' : 'Cerrado'}
              </Badge>
            </div>
          ) : null}
          {!business.isApproved && (
            <Badge variant="destructive" className="absolute top-2 left-2">
              Pendiente de Aprobación
            </Badge>
          )}
          <Badge className="absolute top-2 right-2 bg-gradient-to-r from-[hsl(270,70%,60%)] to-[hsl(280,75%,65%)] text-white border-0">
            {business.category}
          </Badge>
          {business.freeDelivery && (
            <Badge className="absolute bottom-2 left-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 shadow-lg animate-pulse">
              <Truck className="h-3 w-3 mr-1" />
              Envío Gratis
            </Badge>
          )}
        </div>

        <CardContent className="p-4">
          <div className="space-y-3">
            <div>
              <h3 className="font-bold text-xl mb-1 text-gray-800">{business.name}</h3>
              {business.description && <p className="text-sm text-gray-600 line-clamp-2">{business.description}</p>}
            </div>

            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="font-medium text-gray-800">{business.rating.toFixed(1)}</span>
                <span className="text-gray-600">({business.reviewCount})</span>
              </div>

              <div className="flex items-center gap-1 text-gray-600">
                <Clock className="h-4 w-4" />
                <span>{business.estimatedDeliveryTime}</span>
              </div>
            </div>

            {(business.businessDays || business.businessHours) && (
              <div className="text-sm text-gray-700 space-y-1">
                {business.businessDays && <p className="font-medium">📅 {business.businessDays}</p>}
                {business.businessHours && <p className="font-medium">🕒 {business.businessHours}</p>}
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                {business.freeDelivery ? (
                  <span className="text-green-600 font-semibold flex items-center gap-1">
                    <Truck className="h-4 w-4" />
                    ¡Envío Gratis!
                  </span>
                ) : (
                  <>
                    <DollarSign className="h-4 w-4 text-gray-600" />
                    <span className="text-gray-600">Envío: ${business.deliveryFee}</span>
                  </>
                )}
              </div>
              <div className="text-gray-600">Min: ${business.minOrderAmount}</div>
            </div>

            <div className="flex items-start gap-1 text-xs text-gray-600">
              <MapPin className="h-3 w-3 mt-0.5 flex-shrink-0" />
              <span className="line-clamp-1">{business.fullAddress || business.address}</span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0 flex flex-col gap-2">
          <Button
            className="w-full bg-gradient-to-r from-[hsl(270,70%,55%)] to-[hsl(280,75%,62%)] hover:from-[hsl(270,70%,50%)] hover:to-[hsl(280,75%,57%)] text-white border-0 font-semibold text-base h-12 rounded-xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleSelect}
            disabled={business.isComingSoon || business.weatherUnavailable}
          >
            {business.weatherUnavailable
              ? '☔ Verifica disponibilidad: 554895 7140'
              : business.isComingSoon
              ? '🚧 Próximamente'
              : 'Ver Menú'}
          </Button>
          {(effectivePromoCount > 0 || effectiveMenuCount > 0) && (
            <div className="flex gap-2 w-full">
              {effectivePromoCount > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowPromotions(true);
                  }}
                  className="flex-1"
                >
                  <ImageIcon className="h-4 w-4 mr-2" />
                  Promociones ({effectivePromoCount})
                </Button>
              )}
              {effectiveMenuCount > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowMenuGallery(true);
                  }}
                  className="flex-1"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Carta ({effectiveMenuCount})
                </Button>
              )}
            </div>
          )}
        </CardFooter>
      </Card>

      <PromotionsGalleryModal
        open={showPromotions}
        onClose={() => setShowPromotions(false)}
        promotions={fullPromotions}
        businessName={business.name}
      />

      <MenuGalleryModal open={showMenuGallery} onClose={() => setShowMenuGallery(false)} images={fullMenuImages} />
    </>
  );
};
