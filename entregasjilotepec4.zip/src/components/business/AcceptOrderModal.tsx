import { useState } from 'react';
import { Order } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';

interface AcceptOrderModalProps {
  open: boolean;
  onClose: () => void;
  order: Order;
  onConfirm: (preparationTime: number, adjustedDeliveryFee?: number, isPickupAtCounter?: boolean) => void;
}

export const AcceptOrderModal = ({ open, onClose, order, onConfirm }: AcceptOrderModalProps) => {
  const [preparationTime, setPreparationTime] = useState(30);
  const [deliveryFee, setDeliveryFee] = useState(order.deliveryFee);
  const [isPickupAtCounter, setIsPickupAtCounter] = useState(false);
  const [isDeliveryExempt, setIsDeliveryExempt] = useState(false);
  const [previousDeliveryFee, setPreviousDeliveryFee] = useState(order.deliveryFee);

  const handleExemptChange = (checked: boolean) => {
    setIsDeliveryExempt(checked);
    if (checked) {
      setPreviousDeliveryFee(deliveryFee);
      setDeliveryFee(0.001);
    } else {
      setDeliveryFee(previousDeliveryFee);
    }
  };

  const handleConfirm = () => {
    const finalDeliveryFee = isDeliveryExempt ? 0.001 : deliveryFee;
    onConfirm(preparationTime, finalDeliveryFee, isPickupAtCounter);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl">✓</span>
            </div>
            Aceptar Pedido
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="prep-time" className="text-base font-semibold">
              Tiempo de Preparación
            </Label>
            <div className="relative">
              <Input
                id="prep-time"
                type="number"
                value={preparationTime}
                onChange={(e) => setPreparationTime(Number(e.target.value))}
                min={5}
                max={120}
                className="text-lg font-semibold border-primary/20 focus:border-primary"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                min
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="delivery-fee" className="text-base font-semibold">
              Costo de Envío
            </Label>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  $
                </span>
                <Input
                  id="delivery-fee"
                  type="number"
                  value={isDeliveryExempt ? 0 : deliveryFee}
                  onChange={(e) => setDeliveryFee(Number(e.target.value))}
                  min={0}
                  step={0.01}
                  className="text-lg font-semibold pl-8 border-primary/20 focus:border-primary"
                  disabled={isPickupAtCounter || isDeliveryExempt}
                />
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-primary/5 rounded-lg border border-primary/20">
                <Checkbox
                  id="exempt-delivery"
                  checked={isDeliveryExempt}
                  onCheckedChange={handleExemptChange}
                  disabled={isPickupAtCounter}
                />
                <Label 
                  htmlFor="exempt-delivery" 
                  className="text-sm font-medium cursor-pointer"
                >
                  Excento
                </Label>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Ajusta el costo de envío si es necesario
            </p>
          </div>

          <div className="flex items-center justify-between space-x-2 p-4 bg-primary/5 rounded-lg border border-primary/20">
            <div className="space-y-0.5">
              <Label htmlFor="pickup-counter" className="text-base font-semibold">
                Se entrega en mostrador
              </Label>
              <p className="text-xs text-muted-foreground">
                El cliente recogerá el pedido en el mostrador (sin delivery)
              </p>
            </div>
            <Switch
              id="pickup-counter"
              checked={isPickupAtCounter}
              onCheckedChange={setIsPickupAtCounter}
            />
          </div>

          <div className="pt-4 border-t bg-gradient-to-br from-primary/5 to-transparent p-4 rounded-lg space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal:</span>
              <span className="font-medium">${order.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Envío:</span>
              <span className="font-medium">
                ${isPickupAtCounter || isDeliveryExempt ? '0.00' : deliveryFee.toFixed(2)}
                {isDeliveryExempt && !isPickupAtCounter && (
                  <span className="text-xs text-green-600 ml-1">(Excento)</span>
                )}
              </span>
            </div>
            <div className="flex justify-between text-xl font-bold text-primary pt-2 border-t">
              <span>Total:</span>
              <span>${(order.subtotal + (isPickupAtCounter || isDeliveryExempt ? 0 : deliveryFee)).toFixed(2)}</span>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} className="hover-scale">
            Cancelar
          </Button>
          <Button 
            onClick={handleConfirm} 
            className="bg-gradient-to-r from-primary to-primary/80 hover-scale"
          >
            Confirmar Aceptación
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
