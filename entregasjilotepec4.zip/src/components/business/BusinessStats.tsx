import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Order, Product } from '@/types';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { StatCard } from '@/components/shared/StatCard';
import { DollarSign, Package, Star, TrendingUp, ShoppingBag, Truck } from 'lucide-react';
import { useState } from 'react';
import { DateRange } from 'react-day-picker';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { Button } from '@/components/ui/button';
import { isSameDay, isWithinInterval, startOfDay, endOfDay } from 'date-fns';

interface BusinessStatsProps {
  orders: Order[];
  products: Product[];
}

export const BusinessStats = ({ orders, products }: BusinessStatsProps) => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>(() => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 7);
    return { from, to };
  });

  // Quick date filters
  const setQuickRange = (days: number) => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - days);
    setDateRange({ from, to });
  };

  // Filter orders by date range
  const filterByDateRange = (order: Order) => {
    if (!dateRange?.from) return true;
    
    const orderDate = new Date(order.createdAt);
    const from = startOfDay(dateRange.from);
    const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
    
    return isWithinInterval(orderDate, { start: from, end: to });
  };

  const periodOrders = orders.filter(o => o.status === 'DELIVERED' && filterByDateRange(o));
  
  // Separate counter vs delivery orders
  const counterOrders = periodOrders.filter(o => o.isPickupAtCounter);
  const deliveryOrders = periodOrders.filter(o => !o.isPickupAtCounter);
  const totalRevenue = periodOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
  const counterRevenue = counterOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
  const deliveryRevenue = deliveryOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
  const avgOrderValue = periodOrders.length > 0 ? totalRevenue / periodOrders.length : 0;

  // Calculate rating
  const ordersWithRating = orders.filter(o => o.rating && o.rating.businessRating > 0);
  const avgRating = ordersWithRating.length > 0 
    ? ordersWithRating.reduce((sum, o) => sum + (o.rating?.businessRating || 0), 0) / ordersWithRating.length 
    : 0;

  // Sales distribution data
  const salesDistributionData = [
    { 
      name: 'Mostrador', 
      value: counterOrders.length, 
      revenue: counterRevenue,
      color: 'hsl(var(--icon-blue))' 
    },
    { 
      name: 'Entrega', 
      value: deliveryOrders.length, 
      revenue: deliveryRevenue,
      color: 'hsl(var(--icon-green))' 
    }
  ].filter(item => item.value > 0);

  // Sales trend - generate dates within range
  const salesData = (() => {
    if (!dateRange?.from) return [];
    
    const from = startOfDay(dateRange.from);
    const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
    const diffTime = Math.abs(to.getTime() - from.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return Array.from({ length: Math.min(diffDays + 1, 30) }, (_, i) => {
      const date = new Date(from);
      date.setDate(date.getDate() + i);
      const dayOrders = periodOrders.filter(o => isSameDay(new Date(o.createdAt), date));
      const counterDay = dayOrders.filter(o => o.isPickupAtCounter);
      const deliveryDay = dayOrders.filter(o => !o.isPickupAtCounter);
      
      return {
        time: date.toLocaleDateString('es-MX', { day: '2-digit', month: 'short' }),
        mostrador: parseFloat(counterDay.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0).toFixed(2)),
        entrega: parseFloat(deliveryDay.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0).toFixed(2)),
        total: dayOrders.length
      };
    });
  })();

  // Top selling products
  const productSales = new Map<string, { name: string; quantity: number; revenue: number }>();
  periodOrders.forEach(order => {
    order.items.forEach(item => {
      const existing = productSales.get(item.product.id) || { 
        name: item.product.name, 
        quantity: 0, 
        revenue: 0 
      };
      productSales.set(item.product.id, {
        name: item.product.name,
        quantity: existing.quantity + item.quantity,
        revenue: existing.revenue + item.subtotal
      });
    });
  });

  const topProducts = Array.from(productSales.values())
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5)
    .map(p => ({
      name: p.name.length > 20 ? p.name.substring(0, 20) + '...' : p.name,
      vendidos: p.quantity,
      ingresos: parseFloat(p.revenue.toFixed(2))
    }));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Date Range Selector */}
      <Card className="bg-white border-gray-200">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setQuickRange(0)} className="text-gray-700 border-gray-300">
                Hoy
              </Button>
              <Button variant="outline" size="sm" onClick={() => setQuickRange(7)} className="text-gray-700 border-gray-300">
                7 días
              </Button>
              <Button variant="outline" size="sm" onClick={() => setQuickRange(30)} className="text-gray-700 border-gray-300">
                30 días
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Ingresos Totales"
          value={`$${totalRevenue.toFixed(2)}`}
          icon={DollarSign}
          description="Total generado"
          variant="green"
        />
        <StatCard
          title="Pedidos Totales"
          value={periodOrders.length}
          icon={Package}
          description="Completados"
          variant="blue"
        />
        <StatCard
          title="Ventas Mostrador"
          value={`$${counterRevenue.toFixed(2)}`}
          icon={ShoppingBag}
          description={`${counterOrders.length} pedidos`}
          variant="cyan"
        />
        <StatCard
          title="Ventas Entrega"
          value={`$${deliveryRevenue.toFixed(2)}`}
          icon={Truck}
          description={`${deliveryOrders.length} pedidos`}
          variant="orange"
        />
      </div>
      
      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <StatCard
          title="Ticket Promedio"
          value={`$${avgOrderValue.toFixed(2)}`}
          icon={TrendingUp}
          description="Por pedido"
          variant="purple"
        />
        <StatCard
          title="Rating Promedio"
          value={avgRating.toFixed(1)}
          icon={Star}
          description={`${ordersWithRating.length} reseñas`}
          variant="green"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Distribution */}
        {salesDistributionData.length > 0 && (
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                📊 Distribución de Ventas
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={salesDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value, revenue }) => `${name}: ${value} ($${revenue.toFixed(0)})`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {salesDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                    formatter={(value: any, name: string, props: any) => {
                      if (name === 'value') return [value, 'Pedidos'];
                      return [value, name];
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Sales Trend */}
        <Card className="bg-white border-gray-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900">
              📈 Tendencia de Ventas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  stroke="hsl(var(--muted-foreground))"
                  angle={-45}
                  textAnchor="end"
                  height={80}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar 
                  dataKey="mostrador" 
                  fill="hsl(var(--icon-blue))" 
                  stackId="a"
                  radius={[0, 0, 0, 0]}
                  name="Mostrador ($)"
                />
                <Bar 
                  dataKey="entrega" 
                  fill="hsl(var(--icon-green))" 
                  stackId="a"
                  radius={[8, 8, 0, 0]}
                  name="Entrega ($)"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Products */}
      {topProducts.length > 0 && (
        <Card className="bg-white border-gray-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900">
              🏆 Productos Más Vendidos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topProducts}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="name" 
                  stroke="hsl(var(--muted-foreground))"
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar 
                  dataKey="vendidos" 
                  fill="hsl(var(--icon-blue))" 
                  radius={[8, 8, 0, 0]}
                  name="Unidades"
                />
                <Bar 
                  dataKey="ingresos" 
                  fill="hsl(var(--icon-green))" 
                  radius={[8, 8, 0, 0]}
                  name="Ingresos ($)"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
