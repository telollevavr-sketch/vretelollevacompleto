import { Order, OrderStatus } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { MapPin, DollarSign, Clock, Package, User as UserIcon, Phone } from 'lucide-react';
import { OrderItemDetails } from '@/components/shared/OrderItemDetails';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

interface BusinessOrderDetailsModalProps {
  order: Order | null;
  open: boolean;
  onClose: () => void;
}

export const BusinessOrderDetailsModal = ({ order, open, onClose }: BusinessOrderDetailsModalProps) => {
  if (!order) return null;

  const getStatusBadge = () => {
    switch (order.status) {
      case OrderStatus.PENDING:
        return <Badge variant="outline" className="bg-yellow-500 text-white border-yellow-600">Pendiente</Badge>;
      case OrderStatus.IN_PREPARATION:
        return <Badge className="bg-blue-600 text-white">En Preparación</Badge>;
      case OrderStatus.READY_FOR_PICKUP:
        return <Badge variant="secondary" className="bg-green-600 text-white">Listo para Recoger</Badge>;
      case OrderStatus.ON_THE_WAY:
        return <Badge className="bg-purple-600 text-white">En Camino</Badge>;
      case OrderStatus.DELIVERED:
        return <Badge className="bg-green-700 text-white">Entregado</Badge>;
      case OrderStatus.CANCELLED:
        return <Badge variant="destructive">Cancelado</Badge>;
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl">
              Pedido #{order.id.slice(0, 8)}
            </DialogTitle>
            {getStatusBadge()}
          </div>
          <p className="text-sm text-muted-foreground">
            {formatDistanceToNow(new Date(order.createdAt), { 
              addSuffix: true, 
              locale: es 
            })}
          </p>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Información del Cliente */}
          {order.clientInfo && (
            <div className="bg-blue-50 p-4 rounded-lg space-y-2 border border-blue-200">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <UserIcon className="h-5 w-5 text-blue-600" />
                Cliente
              </h3>
              <p className="text-sm font-medium">{order.clientInfo.name}</p>
              {order.clientInfo.phone && (
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  {order.clientInfo.phone}
                </p>
              )}
              {order.clientInfo.address && (
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  {order.clientInfo.address}
                </p>
              )}
            </div>
          )}

          {/* Dirección de Entrega */}
          <div className="bg-muted/50 p-4 rounded-lg space-y-2">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Dirección de Entrega
            </h3>
            <p className="text-sm">
              {order.deliveryLocation.address || 
                `${order.deliveryLocation.lat.toFixed(4)}, ${order.deliveryLocation.lng.toFixed(4)}`}
            </p>
            {order.isPickupAtCounter && (
              <Badge variant="secondary" className="bg-blue-600 text-white">
                📦 Recogida en Mostrador
              </Badge>
            )}
          </div>

          {/* Artículos del Pedido */}
          <div className="space-y-3">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Package className="h-5 w-5" />
              Artículos
            </h3>
            <div className="space-y-2">
              {order.items.map((item, index) => {
                console.log('🔍 [BusinessOrderDetails] Rendering item:', {
                  name: item.product.name,
                  hasComplements: !!item.selectedComplements,
                  complementsCount: item.selectedComplements?.length || 0,
                  complements: item.selectedComplements
                });
                return (
                  <div key={index} className="bg-muted/30 p-3 rounded-lg">
                    <OrderItemDetails 
                      item={item} 
                      index={index} 
                      showPrice={true}
                      compact={false}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Resumen de Pago */}
          <div className="bg-primary/10 p-4 rounded-lg space-y-3">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Resumen de Pago
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span className="font-medium">${order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Costo de envío:</span>
                <span className="font-bold bg-yellow-400 text-black py-1 px-2 rounded">
                  ${order.deliveryFee.toFixed(2)}
                </span>
              </div>
              <div className="border-t pt-2 flex justify-between text-lg font-bold">
                <span>Total:</span>
                <span>${order.total.toFixed(2)}</span>
              </div>
              <div className="text-center pt-1">
                <Badge variant="outline" className="text-sm">
                  {order.paymentMethod === 'CASH' ? '💵 Efectivo' : '💳 Transferencia'}
                </Badge>
              </div>
            </div>
          </div>

          {/* Tiempo de Preparación */}
          {order.preparationTime && (
            <div className="bg-yellow-300 p-3 rounded-lg flex items-center gap-2">
              <Clock className="h-5 w-5 text-black" />
              <span className="font-medium text-black">
                Tiempo de preparación: {order.preparationTime}
              </span>
            </div>
          )}

          {/* Notas */}
          {order.notes && (
            <div className="bg-muted/50 p-4 rounded-lg space-y-2">
              <h3 className="font-semibold text-lg">Notas del Cliente</h3>
              <p className="text-sm text-muted-foreground">{order.notes}</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
