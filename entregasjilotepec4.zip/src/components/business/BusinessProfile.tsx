import { useState, useEffect } from 'react';
import { Business, Location } from '@/types';
import { useBusinesses } from '@/hooks/useBusinesses';
import { usePromotions } from '@/hooks/usePromotions';
import { useMenuImages } from '@/hooks/useMenuImages';
import { compressImage, formatFileSize } from '@/lib/imageCompression';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import { useBusinessTypes } from '@/hooks/useBusinessTypes';
import { LocationPicker } from '@/components/shared/LocationPicker';
import { BusinessScheduleConfig } from '@/components/business/BusinessScheduleConfig';
import { Store, MapPin, Edit2, Save, X, Upload, Trash2, Plus, Image as ImageIcon, RefreshCw, Gift, BookOpen, Truck } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';

interface BusinessProfileProps {
  business: Business;
  onUpdate: (business: Business) => void;
}

export const BusinessProfile = ({ business, onUpdate }: BusinessProfileProps) => {
  const { updateBusiness } = useBusinesses();
  const { businessTypes } = useBusinessTypes();
  const { promotions, createPromotion, deletePromotion } = usePromotions(business.id);
  const { menuImages, createMenuImage, deleteMenuImage } = useMenuImages(business.id);
  const [isEditing, setIsEditing] = useState(false);
  const [uploadingPromo, setUploadingPromo] = useState(false);
  const [uploadingBusinessImage, setUploadingBusinessImage] = useState(false);
  const [uploadingMenuImage, setUploadingMenuImage] = useState(false);
  const [promoData, setPromoData] = useState({ title: '', description: '', imageData: '' });
  const [location, setLocation] = useState<Location>(
    business.location || { lat: 19.4326, lng: -99.1332 }
  );
  const [formData, setFormData] = useState({
    name: business.name,
    description: business.description,
    category: business.category,
    phone: business.phone,
    address: business.address || '',
    fullAddress: business.fullAddress || '',
    deliveryRadius: (business.deliveryRadius ?? 0).toString(),
    minOrderAmount: (business.minOrderAmount ?? 0).toString(),
    deliveryFee: (business.deliveryFee ?? 0).toString(),
    estimatedDeliveryTime: business.estimatedDeliveryTime,
    imageUrl: business.image || '',
    businessDays: business.businessDays || '',
    businessHours: business.businessHours || '',
    freeDelivery: business.freeDelivery || false
  });

  const handleBusinessImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Error',
        description: 'Por favor selecciona una imagen válida (JPG, PNG, etc.)',
        variant: 'destructive'
      });
      return;
    }

    setUploadingBusinessImage(true);
    try {
      const { base64, originalSize, compressedSize } = await compressImage(file, {
        maxWidth: 1024,
        maxHeight: 1024,
        maxSizeKB: 250
      });

      setFormData({ ...formData, imageUrl: base64 });

      toast({
        title: 'Imagen Cargada y Optimizada',
        description: `Original: ${formatFileSize(originalSize)} → Comprimida: ${formatFileSize(compressedSize)}`
      });
    } catch (error) {
      console.error('Error al comprimir imagen:', error);
      toast({
        title: 'Error',
        description: 'No se pudo comprimir la imagen',
        variant: 'destructive'
      });
    } finally {
      setUploadingBusinessImage(false);
    }
  };

  const handlePromoImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Error',
        description: 'Por favor selecciona una imagen válida',
        variant: 'destructive'
      });
      return;
    }

    setUploadingPromo(true);
    try {
      const { base64, originalSize, compressedSize } = await compressImage(file, {
        maxWidth: 1024,
        maxHeight: 1024,
        maxSizeKB: 250
      });

      setPromoData({ ...promoData, imageData: base64 });

      toast({
        title: 'Imagen Optimizada',
        description: `Original: ${formatFileSize(originalSize)} → Comprimida: ${formatFileSize(compressedSize)}`
      });
    } catch (error) {
      console.error('Error al comprimir imagen:', error);
      toast({
        title: 'Error',
        description: 'No se pudo comprimir la imagen',
        variant: 'destructive'
      });
    } finally {
      setUploadingPromo(false);
    }
  };

  const handleMenuImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Error',
        description: 'Por favor selecciona una imagen válida',
        variant: 'destructive'
      });
      return;
    }

    setUploadingMenuImage(true);
    try {
      const { base64, originalSize, compressedSize } = await compressImage(file, {
        maxWidth: 1200,
        maxHeight: 1600,
        maxSizeKB: 300
      });

      createMenuImage({
        business_id: business.id,
        image_data: base64,
        display_order: menuImages.length
      });

      toast({
        title: 'Imagen del Menú Agregada',
        description: `Original: ${formatFileSize(originalSize)} → Comprimida: ${formatFileSize(compressedSize)}`
      });
    } catch (error) {
      console.error('Error al comprimir imagen:', error);
      toast({
        title: 'Error',
        description: 'No se pudo comprimir la imagen',
        variant: 'destructive'
      });
    } finally {
      setUploadingMenuImage(false);
      // Reset input
      e.target.value = '';
    }
  };

  const handleDeleteMenuImage = (imageId: string) => {
    if (confirm('¿Eliminar esta imagen del menú?')) {
      deleteMenuImage(imageId);
    }
  };

  const handleCreatePromotion = () => {
    if (!promoData.title.trim() || !promoData.imageData) {
      toast({
        title: 'Error',
        description: 'Completa el título y sube una imagen',
        variant: 'destructive'
      });
      return;
    }

    createPromotion({
      business_id: business.id,
      title: promoData.title,
      description: promoData.description,
      image_data: promoData.imageData
    });

    setPromoData({ title: '', description: '', imageData: '' });
  };

  const handleDeletePromotion = (promoId: string) => {
    if (confirm('¿Eliminar esta promoción?')) {
      deletePromotion(promoId);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: 'Error',
        description: 'El nombre del negocio es obligatorio',
        variant: 'destructive'
      });
      return;
    }

    updateBusiness({
      id: business.id,
      updates: {
        name: formData.name,
        description: formData.description,
        category: formData.category,
        phone: formData.phone,
        address: formData.address,
        full_address: formData.fullAddress,
        latitude: location.lat,
        longitude: location.lng,
        max_delivery_distance_km: parseFloat(formData.deliveryRadius),
        min_order_amount: parseFloat(formData.minOrderAmount),
        delivery_fee: formData.freeDelivery ? 0 : parseFloat(formData.deliveryFee),
        delivery_time_minutes: parseInt(formData.estimatedDeliveryTime) || 30,
        image_url: formData.imageUrl,
        business_days: formData.businessDays || null,
        business_hours: formData.businessHours || null,
        free_delivery: formData.freeDelivery
      }
    });

    setIsEditing(false);
    toast({
      title: 'Perfil Actualizado',
      description: 'La información del negocio ha sido actualizada exitosamente'
    });
  };

  const handleCancel = () => {
    setIsEditing(false);
    setLocation(business.location || { lat: 19.4326, lng: -99.1332 });
    setFormData({
      name: business.name,
      description: business.description,
      category: business.category,
      phone: business.phone,
      address: business.address || '',
      fullAddress: business.fullAddress || '',
      deliveryRadius: (business.deliveryRadius ?? 0).toString(),
      minOrderAmount: (business.minOrderAmount ?? 0).toString(),
      deliveryFee: (business.deliveryFee ?? 0).toString(),
      estimatedDeliveryTime: business.estimatedDeliveryTime,
      imageUrl: business.image || '',
      businessDays: business.businessDays || '',
      businessHours: business.businessHours || '',
      freeDelivery: business.freeDelivery || false
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white">Perfil del Negocio</h2>
          <p className="text-muted-foreground mt-1">Administra la información de tu negocio</p>
        </div>
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Store className="h-5 w-5 text-primary" />
                Información del Negocio
              </CardTitle>
              <CardDescription className="mt-2">
                Actualiza los datos de tu negocio y configuración de entregas
              </CardDescription>
            </div>
            {!isEditing && (
              <Button onClick={() => setIsEditing(true)} variant="outline" size="sm">
                <Edit2 className="h-4 w-4 mr-2" />
                Editar
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!isEditing ? (
            <div className="space-y-6">
              {/* Business Image */}
              <div className="flex justify-center">
                <Avatar className="h-32 w-32 border-4 border-primary/20 shadow-lg">
                  <AvatarImage src={business.image} />
                  <AvatarFallback className="text-3xl font-semibold bg-primary text-primary-foreground">
                    {business.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Nombre del Negocio</Label>
                  <p className="font-medium text-lg">{business.name}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Tipo de Negocio</Label>
                  <p className="font-medium text-lg">{business.category}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Teléfono</Label>
                  <p className="font-medium text-lg">{business.phone}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Dirección</Label>
                  <p className="font-medium text-lg">{business.address || 'No especificada'}</p>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label className="text-muted-foreground">Domicilio Completo</Label>
                  <p className="font-medium">{business.fullAddress || 'No especificado'}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Radio de Entrega</Label>
                  <p className="font-medium text-lg">{business.deliveryRadius} km</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Pedido Mínimo</Label>
                  <p className="font-medium text-lg">${business.minOrderAmount}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Costo de Envío</Label>
                  {business.freeDelivery ? (
                    <p className="font-medium text-lg text-green-600 flex items-center gap-2">
                      <Truck className="h-5 w-5" />
                      ¡Envío Gratis!
                    </p>
                  ) : (
                    <p className="font-medium text-lg">${business.deliveryFee}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Tiempo Estimado</Label>
                  <p className="font-medium text-lg">{business.estimatedDeliveryTime}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Días de Atención</Label>
                  <p className="font-medium text-lg">{business.businessDays || 'No especificado'}</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-muted-foreground">Horarios</Label>
                  <p className="font-medium text-lg">{business.businessHours || 'No especificado'}</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label className="text-muted-foreground">Descripción</Label>
                <p className="text-foreground">{business.description}</p>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <Label>Ubicación del Negocio</Label>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg space-y-1">
                  <p className="text-sm font-mono">
                    {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
                  </p>
                  {location.address && (
                    <p className="text-sm text-muted-foreground">{location.address}</p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Business Image Upload */}
              <div className="flex flex-col items-center gap-4">
                <Avatar className="h-32 w-32 border-4 border-primary/20 shadow-lg">
                  <AvatarImage src={formData.imageUrl} />
                  <AvatarFallback className="text-3xl font-semibold bg-primary text-primary-foreground">
                    {formData.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="w-full max-w-md space-y-2">
                  <Label htmlFor="business-image-upload">Imagen del Negocio</Label>
                  <div className="flex flex-col gap-2">
                    <Input
                      id="business-image-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleBusinessImageUpload}
                      disabled={uploadingBusinessImage}
                      className="cursor-pointer"
                    />
                    {uploadingBusinessImage && (
                      <p className="text-sm text-primary flex items-center gap-2">
                        <Upload className="h-4 w-4 animate-pulse" />
                        Comprimiendo imagen...
                      </p>
                    )}
                    {formData.imageUrl && !uploadingBusinessImage && (
                      <p className="text-xs text-green-600 font-medium">
                        ✓ Imagen cargada correctamente
                      </p>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Selecciona una imagen (JPG, PNG). Se comprimirá automáticamente a 250KB máximo.
                  </p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    Nombre del Negocio <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Nombre de tu negocio"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">
                    Tipo de Negocio <span className="text-destructive">*</span>
                  </Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {businessTypes.map(type => (
                        <SelectItem key={type.id} value={type.name}>
                          {type.icon && `${type.icon} `}{type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">
                    Teléfono <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="5512345678"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">
                    Dirección <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Calle, Número, Colonia"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    Dirección corta obtenida del mapa
                  </p>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="fullAddress">Domicilio Completo</Label>
                  <Textarea
                    id="fullAddress"
                    value={formData.fullAddress}
                    onChange={(e) => setFormData({ ...formData, fullAddress: e.target.value })}
                    placeholder="Ingresa el domicilio completo con todos los datos postales (calle, número, colonia, código postal, ciudad, estado, país, referencias, etc.)"
                    rows={3}
                  />
                  <p className="text-xs text-muted-foreground">
                    Domicilio completo con datos postales detallados para entregas
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deliveryRadius">
                    Radio de Entrega (km) <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="deliveryRadius"
                    type="number"
                    step="0.1"
                    min="0"
                    value={formData.deliveryRadius}
                    onChange={(e) => setFormData({ ...formData, deliveryRadius: e.target.value })}
                    placeholder="5.0"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minOrderAmount">
                    Pedido Mínimo ($) <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="minOrderAmount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.minOrderAmount}
                    onChange={(e) => setFormData({ ...formData, minOrderAmount: e.target.value })}
                    placeholder="50.00"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deliveryFee">
                    Costo de Envío ($)
                  </Label>
                  <Input
                    id="deliveryFee"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.deliveryFee}
                    onChange={(e) => setFormData({ ...formData, deliveryFee: e.target.value })}
                    placeholder="30.00"
                    disabled={formData.freeDelivery}
                    className={formData.freeDelivery ? 'opacity-50' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="freeDelivery" className="flex items-center gap-2">
                    <Truck className="h-4 w-4 text-green-600" />
                    Envío Gratis
                  </Label>
                  <div className="flex items-center gap-3">
                    <Switch
                      id="freeDelivery"
                      checked={formData.freeDelivery}
                      onCheckedChange={(checked) => setFormData({ ...formData, freeDelivery: checked })}
                    />
                    <span className={`text-sm font-medium ${formData.freeDelivery ? 'text-green-600' : 'text-muted-foreground'}`}>
                      {formData.freeDelivery ? '¡Activo! Los clientes no pagarán envío' : 'Desactivado'}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Al activar esta opción, el costo de envío será $0 para todos los pedidos
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="estimatedDeliveryTime">
                    Tiempo Estimado <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="estimatedDeliveryTime"
                    value={formData.estimatedDeliveryTime}
                    onChange={(e) => setFormData({ ...formData, estimatedDeliveryTime: e.target.value })}
                    placeholder="30-45 min"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessDays">Días de Atención</Label>
                  <Input
                    id="businessDays"
                    value={formData.businessDays}
                    onChange={(e) => setFormData({ ...formData, businessDays: e.target.value })}
                    placeholder="Lun-Dom, Lun-Vie, etc."
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessHours">Horarios</Label>
                  <Input
                    id="businessHours"
                    value={formData.businessHours}
                    onChange={(e) => setFormData({ ...formData, businessHours: e.target.value })}
                    placeholder="10:00 AM - 10:00 PM"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                  placeholder="Describe tu negocio..."
                />
              </div>

              <Separator />

              <div className="space-y-3">
                <Label className="text-base font-semibold">Ubicación del Negocio</Label>
                <p className="text-sm text-muted-foreground">
                  Selecciona la ubicación exacta de tu negocio en el mapa, usa el botón para obtener tu ubicación actual, o ajusta las coordenadas manualmente
                </p>
                
                {/* Editable Coordinates */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="latitude">Latitud</Label>
                    <Input
                      id="latitude"
                      type="number"
                      step="0.000001"
                      value={location.lat}
                      onChange={(e) => setLocation({ ...location, lat: parseFloat(e.target.value) || 0 })}
                      placeholder="19.432608"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="longitude">Longitud</Label>
                    <Input
                      id="longitude"
                      type="number"
                      step="0.000001"
                      value={location.lng}
                      onChange={(e) => setLocation({ ...location, lng: parseFloat(e.target.value) || 0 })}
                      placeholder="-99.133209"
                    />
                  </div>
                </div>
                
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    setLocation({ ...location });
                    toast({
                      title: 'Mapa sincronizado',
                      description: 'El marcador del mapa se ha actualizado con las coordenadas',
                    });
                  }}
                  className="w-full"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Sincronizar coordenadas con el mapa
                </Button>
                
                <LocationPicker
                  location={location}
                  onLocationChange={setLocation}
                  onAddressChange={(addr) => setFormData({ ...formData, address: addr })}
                />
                
                <p className="text-xs text-muted-foreground">
                  Puedes ajustar las coordenadas manualmente y sincronizar con el mapa, o seleccionar la ubicación directamente en el mapa
                </p>
              </div>

              <Separator />

              <div className="flex gap-3 justify-end">
                <Button type="button" variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  Cancelar
                </Button>
                <Button type="submit">
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Cambios
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      {/* Schedule Configuration */}
      <BusinessScheduleConfig 
        businessId={business.id}
        autoScheduleEnabled={business.autoScheduleEnabled || false}
        onAutoScheduleChange={(enabled) => {
          updateBusiness({
            id: business.id,
            updates: { auto_schedule_enabled: enabled }
          });
          toast({
            title: enabled ? 'Horario Automático Activado' : 'Horario Automático Desactivado',
            description: enabled 
              ? 'Tu negocio se abrirá y cerrará automáticamente según los horarios configurados'
              : 'Ahora puedes controlar manualmente cuándo abrir o cerrar'
          });
        }}
      />

      {/* Visual Content Management with Tabs */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5 text-primary" />
            Contenido Visual
          </CardTitle>
          <CardDescription>
            Gestiona las promociones y las imágenes de tu carta de menú
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="promotions" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="promotions" className="flex items-center gap-2">
                <Gift className="h-4 w-4" />
                Promociones
              </TabsTrigger>
              <TabsTrigger value="menu" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Carta de Menú
              </TabsTrigger>
            </TabsList>

            {/* Promotions Tab */}
            <TabsContent value="promotions" className="space-y-6">
              {/* Create Promotion Form */}
              <div className="p-4 border rounded-lg space-y-4 bg-muted/30">
                <h3 className="font-semibold">Agregar Nueva Promoción</h3>
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="promo-title">Título de la Promoción</Label>
                    <Input
                      id="promo-title"
                      placeholder="Ej: 2x1 en pizzas grandes"
                      value={promoData.title}
                      onChange={(e) => setPromoData({ ...promoData, title: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="promo-description">Descripción (opcional)</Label>
                    <Textarea
                      id="promo-description"
                      placeholder="Detalles de la promoción..."
                      value={promoData.description}
                      onChange={(e) => setPromoData({ ...promoData, description: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="promo-image">Imagen de la Promoción</Label>
                    <Input
                      id="promo-image"
                      type="file"
                      accept="image/*"
                      onChange={handlePromoImageUpload}
                      disabled={uploadingPromo}
                    />
                    <p className="text-xs text-muted-foreground">
                      La imagen se comprimirá automáticamente a máximo 250KB
                    </p>
                    {promoData.imageData && (
                      <img
                        src={promoData.imageData}
                        alt="Preview"
                        className="w-full max-w-sm h-48 object-cover rounded-lg mt-2"
                      />
                    )}
                  </div>
                  <Button
                    type="button"
                    onClick={handleCreatePromotion}
                    disabled={uploadingPromo || !promoData.title || !promoData.imageData}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Agregar Promoción
                  </Button>
                </div>
              </div>

              {/* Existing Promotions */}
              <div className="space-y-3">
                <h3 className="font-semibold">Promociones Activas ({promotions.length})</h3>
                {promotions.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No tienes promociones activas. Crea tu primera promoción arriba.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {promotions.map((promo) => (
                      <Card key={promo.id} className="overflow-hidden">
                        <img
                          src={promo.imageData}
                          alt={promo.title}
                          className="w-full h-40 object-cover"
                        />
                        <CardContent className="p-3">
                          <h4 className="font-semibold text-sm mb-1">{promo.title}</h4>
                          {promo.description && (
                            <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                              {promo.description}
                            </p>
                          )}
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeletePromotion(promo.id)}
                            className="w-full"
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            Eliminar
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Menu Images Tab */}
            <TabsContent value="menu" className="space-y-6">
              {/* Upload Menu Image */}
              <div className="p-4 border rounded-lg space-y-4 bg-muted/30">
                <h3 className="font-semibold">Agregar Imagen del Menú</h3>
                <p className="text-sm text-muted-foreground">
                  Sube múltiples imágenes de tu carta de menú para que los clientes puedan verla
                </p>
                <div className="space-y-2">
                  <Label htmlFor="menu-image">Seleccionar Imagen</Label>
                  <Input
                    id="menu-image"
                    type="file"
                    accept="image/*"
                    onChange={handleMenuImageUpload}
                    disabled={uploadingMenuImage}
                  />
                  {uploadingMenuImage && (
                    <p className="text-sm text-primary flex items-center gap-2">
                      <Upload className="h-4 w-4 animate-pulse" />
                      Subiendo imagen...
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Las imágenes se comprimirán automáticamente. Puedes subir varias imágenes.
                  </p>
                </div>
              </div>

              {/* Existing Menu Images */}
              <div className="space-y-3">
                <h3 className="font-semibold">Imágenes del Menú ({menuImages.length})</h3>
                {menuImages.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No tienes imágenes de tu carta. Sube la primera imagen arriba.
                  </p>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {menuImages.map((img, index) => (
                      <div key={img.id} className="relative group">
                        <img
                          src={img.imageData}
                          alt={`Menú ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg border"
                        />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteMenuImage(img.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <span className="absolute top-2 left-2 bg-background/80 text-xs px-2 py-1 rounded">
                          {index + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};