import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { MapView } from '@/components/shared/MapView';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { RefreshCw, MapPin, Phone, Navigation, Star, Package, Clock, AlertCircle } from 'lucide-react';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';
import { EmptyState } from '@/components/shared/EmptyState';
import { toast } from '@/hooks/use-toast';

interface DeliveryPerson {
  id: string;
  name: string;
  phone: string | null;
  avatar_url: string | null;
  latitude: number | null;
  longitude: number | null;
  vehicle_type: string | null;
  vehicle_plate: string | null;
  rating: number | null;
  review_count: number | null;
}

interface ActiveDelivery {
  id: string;
  orderNumber: string;
  total: number;
  deliveryAddress: string;
  deliveryLatitude: number;
  deliveryLongitude: number;
  createdAt: string;
  deliveryPerson: DeliveryPerson | null;
}

interface ActiveDeliveriesTrackingProps {
  businessId: string;
  businessLocation: { lat: number; lng: number };
  businessName: string;
}

export const ActiveDeliveriesTracking = ({ 
  businessId, 
  businessLocation, 
  businessName 
}: ActiveDeliveriesTrackingProps) => {
  const [activeDeliveries, setActiveDeliveries] = useState<ActiveDelivery[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDeliveryId, setSelectedDeliveryId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // Fetch active deliveries (orders that are on_the_way)
  const fetchActiveDeliveries = async () => {
    try {
      console.log('📍 [ActiveDeliveries] Fetching active deliveries for business:', businessId);
      
      const { data, error } = await supabase
        .from('orders')
        .select(`
          id,
          order_number,
          total,
          delivery_address,
          delivery_latitude,
          delivery_longitude,
          created_at,
          delivery_person_id
        `)
        .eq('business_id', businessId)
        .eq('status', 'in_delivery')
        .not('delivery_person_id', 'is', null);

      if (error) throw error;

      // Fetch delivery person details for each order
      const deliveriesWithPersons: ActiveDelivery[] = await Promise.all(
        (data || []).map(async (order) => {
          let deliveryPerson: DeliveryPerson | null = null;
          
          if (order.delivery_person_id) {
            const { data: personData } = await supabase
              .from('profiles')
              .select('id, name, phone, avatar_url, latitude, longitude, vehicle_type, vehicle_plate, rating, review_count')
              .eq('id', order.delivery_person_id)
              .single();
            
            if (personData) {
              deliveryPerson = personData;
            }
          }

          return {
            id: order.id,
            orderNumber: order.order_number,
            total: order.total,
            deliveryAddress: order.delivery_address,
            deliveryLatitude: order.delivery_latitude,
            deliveryLongitude: order.delivery_longitude,
            createdAt: order.created_at,
            deliveryPerson
          };
        })
      );

      console.log('📍 [ActiveDeliveries] Found deliveries:', deliveriesWithPersons.length);
      setActiveDeliveries(deliveriesWithPersons);
      
      // Auto-select first delivery if none selected
      if (deliveriesWithPersons.length > 0 && !selectedDeliveryId) {
        setSelectedDeliveryId(deliveriesWithPersons[0].id);
      }
    } catch (error) {
      console.error('Error fetching active deliveries:', error);
      toast({
        title: 'Error',
        description: 'No se pudieron cargar las entregas activas',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchActiveDeliveries();
  }, [businessId]);

  // Subscribe to order changes (when status changes to delivered or cancelled)
  useEffect(() => {
    const channel = supabase
      .channel(`business-deliveries-${businessId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `business_id=eq.${businessId}`
        },
        (payload) => {
          console.log('📦 [ActiveDeliveries] Order change detected:', payload);
          fetchActiveDeliveries();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [businessId]);

  // Realtime subscription to profiles removed - locations update only on manual refresh

  // Calculate map locations and routes based on selected delivery
  const { mapLocations, mapRoutes } = useMemo(() => {
    const locations: { lat: number; lng: number; name?: string; address?: string; icon: 'business' | 'delivery' | 'client' }[] = [];
    const routes: { orderId: string; orderNumber: string; coordinates: { lat: number; lng: number }[]; color: string }[] = [];

    // Always add business location
    locations.push({
      lat: businessLocation.lat,
      lng: businessLocation.lng,
      name: businessName,
      address: 'Ubicación del negocio',
      icon: 'business'
    });

    // If a delivery is selected, show only that one
    const deliveriesToShow = selectedDeliveryId 
      ? activeDeliveries.filter(d => d.id === selectedDeliveryId)
      : activeDeliveries;

    deliveriesToShow.forEach(delivery => {
      // Add client location
      locations.push({
        lat: delivery.deliveryLatitude,
        lng: delivery.deliveryLongitude,
        name: `Pedido #${delivery.orderNumber}`,
        address: delivery.deliveryAddress,
        icon: 'client'
      });

      // Add delivery person location if available
      if (delivery.deliveryPerson?.latitude && delivery.deliveryPerson?.longitude) {
        locations.push({
          lat: delivery.deliveryPerson.latitude,
          lng: delivery.deliveryPerson.longitude,
          name: delivery.deliveryPerson.name,
          address: `Repartidor - ${delivery.deliveryPerson.vehicle_type || 'Vehículo'}`,
          icon: 'delivery'
        });

        // Create route: Business -> Delivery Person -> Client
        routes.push({
          orderId: delivery.id,
          orderNumber: delivery.orderNumber,
          coordinates: [
            { lat: businessLocation.lat, lng: businessLocation.lng },
            { lat: delivery.deliveryPerson.latitude, lng: delivery.deliveryPerson.longitude },
            { lat: delivery.deliveryLatitude, lng: delivery.deliveryLongitude }
          ],
          color: '#f97316'
        });
      } else {
        // Route without delivery person position: Business -> Client
        routes.push({
          orderId: delivery.id,
          orderNumber: delivery.orderNumber,
          coordinates: [
            { lat: businessLocation.lat, lng: businessLocation.lng },
            { lat: delivery.deliveryLatitude, lng: delivery.deliveryLongitude }
          ],
          color: '#3b82f6'
        });
      }
    });

    return { mapLocations: locations, mapRoutes: routes };
  }, [activeDeliveries, selectedDeliveryId, businessLocation, businessName]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchActiveDeliveries();
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) return `${diffMins} min`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ${diffMins % 60}min`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="bg-[hsl(180,50%,12%)]/60 backdrop-blur rounded-lg p-6 border border-white/10">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2 text-[hsl(180,100%,60%)]">
          <span className="bg-white/10 p-2 rounded-lg">📍</span>
          Entregas en Vivo
          {activeDeliveries.length > 0 && (
            <Badge className="ml-2 bg-orange-500 text-white">
              {activeDeliveries.length}
            </Badge>
          )}
        </h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          disabled={refreshing}
          className="border-gray-300 text-gray-900 bg-white hover:bg-gray-100"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Actualizar
        </Button>
      </div>

      {activeDeliveries.length === 0 ? (
        <EmptyState
          icon={Navigation}
          title="Sin entregas activas"
          description="No hay pedidos en camino en este momento. Los pedidos aparecerán aquí cuando un repartidor los tome."
        />
      ) : (
        <div className="space-y-6">
          {/* Map Section */}
          <Card className="bg-white/5 border-white/10">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <MapPin className="h-5 w-5 text-orange-400" />
                Mapa de Entregas
                {selectedDeliveryId && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedDeliveryId(null)}
                    className="ml-auto text-xs text-white/70 hover:text-white"
                  >
                    Ver todas
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <MapView
                locations={mapLocations}
                routes={mapRoutes}
                height="400px"
                zoom={14}
              />
            </CardContent>
          </Card>

          {/* Delivery Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeDeliveries.map((delivery) => (
              <Card 
                key={delivery.id}
                className={`bg-white/5 border-white/10 cursor-pointer transition-all hover:border-orange-400/50 ${
                  selectedDeliveryId === delivery.id ? 'ring-2 ring-orange-400' : ''
                }`}
                onClick={() => setSelectedDeliveryId(delivery.id)}
              >
                <CardContent className="p-4">
                  {/* Order Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-orange-400" />
                      <span className="font-semibold text-white">#{delivery.orderNumber}</span>
                    </div>
                    <Badge variant="secondary" className="bg-orange-500/20 text-orange-300 border-orange-500/30">
                      En camino
                    </Badge>
                  </div>

                  {/* Delivery Person Info */}
                  {delivery.deliveryPerson ? (
                    <div className="flex items-center gap-3 mb-3 p-2 bg-white/5 rounded-lg">
                      <Avatar className="h-10 w-10 border-2 border-orange-400">
                        <AvatarImage src={delivery.deliveryPerson.avatar_url || undefined} />
                        <AvatarFallback className="bg-orange-500 text-white">
                          {delivery.deliveryPerson.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white truncate">{delivery.deliveryPerson.name}</p>
                        <div className="flex items-center gap-2 text-xs text-white/60">
                          {delivery.deliveryPerson.vehicle_type && (
                            <span>{delivery.deliveryPerson.vehicle_type}</span>
                          )}
                          {delivery.deliveryPerson.rating && (
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              {delivery.deliveryPerson.rating.toFixed(1)}
                            </span>
                          )}
                        </div>
                      </div>
                      {delivery.deliveryPerson.phone && (
                        <a 
                          href={`tel:${delivery.deliveryPerson.phone}`}
                          onClick={(e) => e.stopPropagation()}
                          className="p-2 bg-green-500/20 rounded-full hover:bg-green-500/30 transition-colors"
                        >
                          <Phone className="h-4 w-4 text-green-400" />
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 mb-3 p-2 bg-yellow-500/10 rounded-lg text-yellow-300 text-sm">
                      <AlertCircle className="h-4 w-4" />
                      Sin ubicación del repartidor
                    </div>
                  )}

                  {/* Delivery Info */}
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start gap-2 text-white/70">
                      <MapPin className="h-4 w-4 mt-0.5 text-blue-400 shrink-0" />
                      <span className="line-clamp-2">{delivery.deliveryAddress}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-white/70">
                        <Clock className="h-4 w-4" />
                        <span>Hace {formatTime(delivery.createdAt)}</span>
                      </div>
                      <span className="font-semibold text-white">
                        ${delivery.total.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* View on Map Button */}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full mt-3 border-orange-400/30 text-orange-300 hover:bg-orange-400/10"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedDeliveryId(delivery.id);
                    }}
                  >
                    <Navigation className="h-4 w-4 mr-2" />
                    Ver en Mapa
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
