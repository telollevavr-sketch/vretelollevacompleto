import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { MapView } from '@/components/shared/MapView';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Phone, Bike, MapPin, RefreshCw, Filter, X, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface MapLocation {
  lat: number;
  lng: number;
  name?: string;
  address?: string;
  icon?: 'business' | 'delivery' | 'client';
  phone?: string | null;
  avatarUrl?: string | null;
  vehicleType?: string | null;
  vehiclePlate?: string | null;
  isOnline?: boolean | null;
}

interface DeliveryPerson {
  id: string;
  name: string;
  phone: string | null;
  avatar_url: string | null;
  vehicle_type: string | null;
  vehicle_plate: string | null;
  is_online: boolean | null;
  is_active: boolean | null;
  assigned_business_id: string | null;
  latitude: number | null;
  longitude: number | null;
  rating: number | null;
  review_count: number | null;
}

interface DeliveryPersonListProps {
  businessId: string;
  businessLocation: { lat: number; lng: number };
  businessName: string;
}

export const DeliveryPersonList = ({ 
  businessId, 
  businessLocation, 
  businessName 
}: DeliveryPersonListProps) => {
  const { toast } = useToast();
  const [deliveryPeople, setDeliveryPeople] = useState<DeliveryPerson[]>([]);
  const [deliveryLocations, setDeliveryLocations] = useState<MapLocation[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Filter states
  const [statusFilter, setStatusFilter] = useState<'all' | 'online' | 'offline'>('all');
  const [vehicleFilter, setVehicleFilter] = useState<string>('all');

  const loadDeliveryPeople = async () => {
    console.log('🔄 [BUSINESS MAP] Cargando repartidores para negocio:', businessId);
    
    // Obtener todos los repartidores
    const { data: roles } = await supabase
      .from('user_roles')
      .select('user_id')
      .eq('role', 'delivery');

    if (!roles || roles.length === 0) {
      console.log('📭 [BUSINESS MAP] No hay repartidores en el sistema');
      setDeliveryPeople([]);
      return;
    }

    const deliveryIds = roles.map(r => r.user_id);

    // Obtener SOLO perfiles asignados a este negocio
    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', deliveryIds)
      .eq('assigned_business_id', businessId);

    if (profiles) {
      console.log(`✅ [BUSINESS MAP] ${profiles.length} repartidores adscritos encontrados`);
      setDeliveryPeople(profiles as DeliveryPerson[]);
    }
  };

  const fetchDeliveryPersonsLocations = async () => {
    console.log('🔄 [BUSINESS MAP] Actualizando ubicaciones de repartidores');
    
    const { data: allDeliveryRoles } = await supabase
      .from('user_roles')
      .select('user_id')
      .eq('role', 'delivery');

    if (!allDeliveryRoles || allDeliveryRoles.length === 0) {
      console.log('📭 [BUSINESS MAP] No hay repartidores registrados');
      setDeliveryLocations([]);
      return;
    }

    const allDeliveryPersonIds = allDeliveryRoles.map(r => r.user_id);

    // Obtener SOLO perfiles con ubicación asignados a este negocio
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, name, latitude, longitude, address, phone, avatar_url, vehicle_type, vehicle_plate, is_online, assigned_business_id, rating, review_count')
      .in('id', allDeliveryPersonIds)
      .eq('assigned_business_id', businessId)
      .not('latitude', 'is', null)
      .not('longitude', 'is', null);

    if (!profiles || profiles.length === 0) {
      console.warn('⚠️ [BUSINESS MAP] No se encontraron ubicaciones activas');
      setDeliveryLocations([]);
      return;
    }

    console.log(`📍 [BUSINESS MAP] ${profiles.length} ubicaciones encontradas`);

    const locationsWithAddresses = await Promise.all(
      profiles.map(async (profile) => {
        let currentAddress = profile.address || 'Ubicación actual';
        
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${profile.latitude}&lon=${profile.longitude}&zoom=18&addressdetails=1`,
            { headers: { 'Accept-Language': 'es' } }
          );
          
          if (response.ok) {
            const data = await response.json();
            const addr = data.address;
            const street = addr.road || addr.pedestrian || addr.footway || '';
            const number = addr.house_number || '';
            const suburb = addr.suburb || addr.neighbourhood || addr.quarter || '';
            const city = addr.city || addr.town || addr.village || '';
            
            const parts = [];
            if (street) parts.push(`${street}${number ? ' ' + number : ''}`);
            if (suburb) parts.push(suburb);
            if (city) parts.push(city);
            
            currentAddress = parts.length > 0 ? parts.join(', ') : data.display_name;
          }
        } catch (error) {
          console.error('Error en geocoding inverso:', error);
        }
        
        return {
          lat: profile.latitude!,
          lng: profile.longitude!,
          name: profile.name,
          address: currentAddress,
          icon: 'delivery' as const,
          phone: profile.phone,
          avatarUrl: profile.avatar_url,
          vehicleType: profile.vehicle_type,
          vehiclePlate: profile.vehicle_plate,
          isOnline: profile.is_online
        };
      })
    );
    
    console.log(`✅ [BUSINESS MAP] ${locationsWithAddresses.length} ubicaciones cargadas`);
    setDeliveryLocations(locationsWithAddresses);
  };

  const handleRefreshMap = async () => {
    setIsRefreshing(true);
    console.log('🔄 [BUSINESS MAP] Refresco manual solicitado');
    
    await fetchDeliveryPersonsLocations();
    
    toast({
      title: 'Actualizando ubicaciones',
      description: 'Solicitando ubicación a repartidores...',
    });
    
    setTimeout(() => {
      setIsRefreshing(false);
      toast({
        title: 'Ubicaciones actualizadas',
        description: `${deliveryLocations.length} repartidor(es) en línea`,
      });
    }, 2500);
  };

  useEffect(() => {
    loadDeliveryPeople();
    fetchDeliveryPersonsLocations();
  }, [businessId]);

  // Combinar ubicación del negocio con ubicaciones de repartidores
  const allLocations: MapLocation[] = [
    {
      lat: businessLocation.lat,
      lng: businessLocation.lng,
      name: businessName,
      address: 'Tu negocio',
      icon: 'business' as const
    },
    ...deliveryLocations
  ];

  const onlineDeliveryPeople = deliveryPeople.filter(p => p.is_online);

  // Get unique vehicle types for filter
  const vehicleTypes = Array.from(new Set(deliveryPeople.map(p => p.vehicle_type).filter(Boolean))) as string[];

  // Apply filters to delivery people
  const filteredDeliveryPeople = deliveryPeople.filter(person => {
    // Status filter
    if (statusFilter === 'online' && !person.is_online) return false;
    if (statusFilter === 'offline' && person.is_online) return false;
    
    // Vehicle type filter
    if (vehicleFilter !== 'all' && person.vehicle_type !== vehicleFilter) return false;
    
    return true;
  });

  // Clear all filters
  const handleClearFilters = () => {
    setStatusFilter('all');
    setVehicleFilter('all');
  };

  const hasActiveFilters = statusFilter !== 'all' || vehicleFilter !== 'all';

  return (
    <div className="space-y-6">
      {/* Mapa en tiempo real */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Mapa de Repartidores en Tiempo Real</CardTitle>
            <Badge variant="secondary" className="mt-2">
              <MapPin className="h-3 w-3 mr-1" />
              {deliveryLocations.length} en línea
            </Badge>
          </div>
          <Button 
            onClick={handleRefreshMap} 
            disabled={isRefreshing}
            variant="outline"
            size="sm"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refrescar Ahora
          </Button>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg overflow-hidden border">
            <MapView 
              key={`delivery-map-${deliveryLocations.length}-${allLocations.length}`}
              locations={allLocations}
              height="500px"
            />
          </div>
        </CardContent>
      </Card>

      {/* Lista de repartidores */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Repartidores Disponibles</CardTitle>
              <Badge variant="outline" className="mt-2">
                {onlineDeliveryPeople.length} de {deliveryPeople.length} en línea
              </Badge>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3 mt-4 pt-4 border-t">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filtros:</span>
            </div>
            
            {/* Status filter */}
            <Select value={statusFilter} onValueChange={(value: any) => setStatusFilter(value)}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="online">🟢 En línea</SelectItem>
                <SelectItem value="offline">🔴 Desconectado</SelectItem>
              </SelectContent>
            </Select>

            {/* Vehicle type filter */}
            <Select value={vehicleFilter} onValueChange={setVehicleFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Vehículo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los vehículos</SelectItem>
                {vehicleTypes.map(type => (
                  <SelectItem key={type} value={type}>
                    <div className="flex items-center gap-2">
                      <Bike className="h-3 w-3" />
                      {type}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Clear filters button */}
            {hasActiveFilters && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleClearFilters}
                className="h-9"
              >
                <X className="h-4 w-4 mr-1" />
                Limpiar filtros
              </Button>
            )}

            {/* Results count */}
            {hasActiveFilters && (
              <Badge variant="secondary" className="ml-auto">
                {filteredDeliveryPeople.length} resultado{filteredDeliveryPeople.length !== 1 ? 's' : ''}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            <div className="space-y-4">
              {deliveryPeople.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No hay repartidores disponibles
                </p>
              ) : filteredDeliveryPeople.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground mb-2">
                    No se encontraron repartidores con los filtros aplicados
                  </p>
                  <Button variant="outline" size="sm" onClick={handleClearFilters}>
                    <X className="h-4 w-4 mr-1" />
                    Limpiar filtros
                  </Button>
                </div>
              ) : (
                filteredDeliveryPeople.map((person) => (
                  <div
                    key={person.id}
                    className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={person.avatar_url || ''} alt={person.name} />
                      <AvatarFallback>
                        {person.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium truncate">{person.name}</p>
                        <Badge 
                          variant={person.is_online ? "default" : "secondary"}
                          className="shrink-0"
                        >
                          {person.is_online ? '🟢 En línea' : '🔴 Desconectado'}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        {person.phone && (
                          <div className="flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            <span>{person.phone}</span>
                          </div>
                        )}
                        {person.vehicle_type && (
                          <div className="flex items-center gap-1">
                            <Bike className="h-3 w-3" />
                            <span>{person.vehicle_type}</span>
                            {person.vehicle_plate && (
                              <span className="text-xs">({person.vehicle_plate})</span>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline" className="text-xs">
                          Adscrito a tu negocio
                        </Badge>
                        
                        {person.review_count && person.review_count > 0 ? (
                          <div className="flex items-center gap-1">
                            <div className="flex items-center gap-0.5">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm font-medium">
                                {Number(person.rating || 0).toFixed(1)}
                              </span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              ({person.review_count} {person.review_count === 1 ? 'reseña' : 'reseñas'})
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">
                            Sin calificaciones
                          </span>
                        )}
                      </div>
                    </div>

                    {person.is_online && person.latitude && person.longitude && (
                      <Badge variant="secondary" className="shrink-0">
                        <MapPin className="h-3 w-3 mr-1" />
                        GPS Activo
                      </Badge>
                    )}
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};
