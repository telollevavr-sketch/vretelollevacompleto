import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Search, X, Download, FileSpreadsheet } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useCategories } from "@/hooks/useCategories";
import { useProducts } from "@/hooks/useProducts";
import { exportMenuToExcel, exportToTSV } from "@/lib/businessExport";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ProductManagementProps {
  businessId: string;
  businessName: string;
  isSpecialBusiness?: boolean;
}

export const ProductManagement = ({ businessId, businessName, isSpecialBusiness = false }: ProductManagementProps) => {
  const { categories } = useCategories();
  const { products, isLoading, createProduct, updateProduct, deleteProduct } = useProducts(businessId);
  const { toast } = useToast();
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("Todas");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    imageUrl: "",
    isAvailable: true,
    isPromotionalCombo: false,
    isSpecialty: false,
    isPricedCombo: false,
    pricedItemsCount: 1,
    comboConfig: {
      itemCount: 2,
      itemType: "pizza",
      itemLabelPrefix: "Pizza",
      items: [
        { size: "mediana", label: "Pizza 1", itemType: "pizza" },
        { size: "mediana", label: "Pizza 2", itemType: "pizza" },
      ] as { size: string; label: string; itemType: string }[],
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const productData: any = {
      business_id: businessId,
      name: formData.name,
      description: formData.description,
      price: parseFloat(formData.price),
      category: formData.category,
      image_url: formData.imageUrl || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c",
      is_available: formData.isAvailable,
      is_promotional_combo: formData.isPromotionalCombo,
      is_specialty: formData.isSpecialty,
      is_priced_combo: formData.isPricedCombo,
      priced_items_count: formData.isPricedCombo ? formData.pricedItemsCount : 1,
      combo_configuration: formData.isPromotionalCombo ? formData.comboConfig : null,
    };

    if (editingProduct) {
      updateProduct({ id: editingProduct, updates: productData });
    } else {
      createProduct(productData);
    }

    handleCloseModal();
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product.id);

    // Cargar configuración del combo si existe
    let comboConfig: {
      itemCount: number;
      itemType: string;
      itemLabelPrefix: string;
      items: { size: string; label: string; itemType: string }[];
    } = {
      itemCount: 2,
      itemType: "pizza",
      itemLabelPrefix: "Pizza",
      items: [
        { size: "mediana", label: "Pizza 1", itemType: "pizza" },
        { size: "mediana", label: "Pizza 2", itemType: "pizza" },
      ],
    };

    if (product.comboConfiguration) {
      const globalType = product.comboConfiguration.itemType || "pizza";
      // Si tiene la nueva estructura
      if (product.comboConfiguration.itemCount) {
        // Asegurar que cada item tenga itemType
        const itemsWithType = (product.comboConfiguration.items || []).map((item: any, idx: number) => ({
          size: item.size || "mediana",
          label: item.label || `Producto ${idx + 1}`,
          itemType: item.itemType || globalType,
        }));
        comboConfig = {
          ...product.comboConfiguration,
          items: itemsWithType,
        };
      }
      // Si tiene la estructura antigua (migración)
      else if (product.comboConfiguration.pizzas) {
        comboConfig = {
          itemCount: product.comboConfiguration.pizzas.length,
          itemType: "pizza",
          itemLabelPrefix: "Pizza",
          items: product.comboConfiguration.pizzas.map((item: any, idx: number) => ({
            size: item.size || "mediana",
            label: item.label || `Pizza ${idx + 1}`,
            itemType: "pizza",
          })),
        };
      }
    }

    setFormData({
      name: product.name,
      description: product.description,
      price: product.price.toString(),
      category: product.category,
      imageUrl: product.image,
      isAvailable: product.isAvailable,
      isPromotionalCombo: product.isPromotionalCombo || false,
      isSpecialty: product.isSpecialty || false,
      isPricedCombo: product.isPricedCombo || false,
      pricedItemsCount: product.pricedItemsCount || 1,
      comboConfig,
    });
    setShowModal(true);
  };

  const handleDelete = (productId: string) => {
    if (confirm("¿Estás seguro de eliminar este producto?")) {
      deleteProduct(productId);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingProduct(null);
    setFormData({
      name: "",
      description: "",
      price: "",
      category: "",
      imageUrl: "",
      isAvailable: true,
      isPromotionalCombo: false,
      isSpecialty: false,
      isPricedCombo: false,
      pricedItemsCount: 1,
      comboConfig: {
        itemCount: 2,
        itemType: "pizza",
        itemLabelPrefix: "Pizza",
        items: [
          { size: "mediana", label: "Pizza 1", itemType: "pizza" },
          { size: "mediana", label: "Pizza 2", itemType: "pizza" },
        ] as { size: string; label: string; itemType: string }[],
      },
    });
  };

  const toggleAvailability = (productId: string, currentAvailability: boolean) => {
    updateProduct({
      id: productId,
      updates: { is_available: !currentAvailability },
    });
  };

  const handleExportExcel = () => {
    exportMenuToExcel(filteredProducts, businessName);
    toast({
      title: "Exportación exitosa",
      description: "El menú se ha exportado a Excel correctamente",
    });
  };

  const handleExportTSV = () => {
    const tsvData = filteredProducts.map((product, index) => ({
      "#": index + 1,
      Nombre: product.name,
      Categoría: product.category,
      Precio: product.price,
      Disponible: product.isAvailable ? "Sí" : "No",
    }));
    exportToTSV(tsvData, `menu-${businessName.replace(/\s+/g, "_")}`);
    toast({
      title: "Exportación exitosa",
      description: "El menú se ha exportado a TSV correctamente",
    });
  };

  // Obtener categorías únicas de los productos
  const uniqueCategories = ["Todas", ...new Set(products.map((p) => p.category))].sort();

  // Filtrar productos por búsqueda y categoría
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "Todas" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">Gestión de Productos</h2>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={handleExportExcel}>
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Exportar a Excel (.xlsx)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportTSV}>
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Exportar a TSV
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={() => setShowModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Agregar Producto
            </Button>
          </div>
        </div>

        {/* Barra de búsqueda */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar en el menú..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0"
              onClick={() => setSearchQuery("")}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Filtro por categorías */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Categorías</Label>
          <div className="flex flex-wrap gap-2">
            {uniqueCategories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                className={`cursor-pointer transition-colors ${
                  selectedCategory === category
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : "bg-black text-white border-black hover:bg-black/80"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
                {selectedCategory === category && category !== "Todas" && (
                  <X
                    className="ml-1 h-3 w-3"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCategory("Todas");
                    }}
                  />
                )}
              </Badge>
            ))}
          </div>
        </div>

        {isLoading ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-muted-foreground">Cargando productos...</p>
            </CardContent>
          </Card>
        ) : products.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-muted-foreground">No hay productos. Agrega tu primer producto.</p>
            </CardContent>
          </Card>
        ) : filteredProducts.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-muted-foreground">No se encontraron productos con los filtros seleccionados.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredProducts.map((product) => (
              <Card key={product.id}>
                <CardContent className="py-4">
                  <div className="flex gap-4">
                    <img src={product.image} alt={product.name} className="w-24 h-24 rounded-lg object-cover" />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold">{product.name}</h3>
                          <p className="text-sm text-muted-foreground">{product.category}</p>
                          <p className="font-bold mt-1">${product.price}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={product.isAvailable}
                            onCheckedChange={() => toggleAvailability(product.id, product.isAvailable)}
                          />
                          <span className="text-sm">{product.isAvailable ? "Disponible" : "No disponible"}</span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEdit(product)}>
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(product.id)}>
                          <Trash2 className="h-4 w-4 mr-1" />
                          Eliminar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={showModal} onOpenChange={handleCloseModal}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>{editingProduct ? "Editar Producto" : "Nuevo Producto"}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
            <div className="flex-1 overflow-y-auto pr-2 space-y-4">
              {/* Grid de 2 columnas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Columna Izquierda - Información básica */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Descripción</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      required
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">Precio</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Categoría</Label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => setFormData({ ...formData, category: value })}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.name}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="imageUrl">URL de la Imagen</Label>
                    <Input
                      id="imageUrl"
                      type="url"
                      placeholder="https://ejemplo.com/imagen.jpg"
                      value={formData.imageUrl}
                      onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">URL de imagen o GIF del producto</p>
                  </div>

                  {formData.imageUrl && (
                    <img
                      src={formData.imageUrl}
                      alt="Preview"
                      className="w-full h-28 object-cover rounded-lg"
                      onError={(e) => {
                        e.currentTarget.src = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c";
                      }}
                    />
                  )}

                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.isAvailable}
                      onCheckedChange={(checked) => setFormData({ ...formData, isAvailable: checked })}
                    />
                    <Label>Disponible</Label>
                  </div>
                </div>

                {/* Columna Derecha - Opciones especiales */}
                <div className="space-y-4">
                  {isSpecialBusiness && (
                    <>
                      <div className="flex items-center gap-2 p-3 bg-muted/30 rounded-lg">
                        <Switch
                          checked={formData.isPromotionalCombo}
                          onCheckedChange={(checked) =>
                            setFormData({
                              ...formData,
                              isPromotionalCombo: checked,
                              isSpecialty: checked ? false : formData.isSpecialty,
                            })
                          }
                        />
                        <Label className="text-sm">Es una promoción (2x1, combos)</Label>
                      </div>

                      {formData.isPromotionalCombo && (
                        <div className="space-y-3 p-3 bg-muted/50 rounded-lg border">
                          <h4 className="font-semibold text-sm">Configuración del Combo</h4>

                          <div className="space-y-2 p-2 bg-amber-500/10 rounded border border-amber-500/30">
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={formData.isPricedCombo}
                                onCheckedChange={(checked) =>
                                  setFormData({ ...formData, isPricedCombo: checked, pricedItemsCount: 1 })
                                }
                              />
                              <div>
                                <Label className="text-sm font-medium">💰 Precio calculado por especialidad</Label>
                                <p className="text-xs text-muted-foreground">
                                  El precio se calcula según los de mayor precio
                                </p>
                              </div>
                            </div>

                            {formData.isPricedCombo && (
                              <div className="ml-6 space-y-2">
                                <Label className="text-xs">¿Cuántos items se cobran?</Label>
                                <Select
                                  value={formData.pricedItemsCount.toString()}
                                  onValueChange={(val) => setFormData({ ...formData, pricedItemsCount: parseInt(val) })}
                                >
                                  <SelectTrigger className="h-8">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="1">1 item (2x1: paga el mayor)</SelectItem>
                                    <SelectItem value="2">2 items (3x2: paga los 2 mayores)</SelectItem>
                                    <SelectItem value="3">3 items (4x3: paga los 3 mayores)</SelectItem>
                                    <SelectItem value="4">4 items (5x4: paga los 4 mayores)</SelectItem>
                                  </SelectContent>
                                </Select>
                                <p className="text-xs text-muted-foreground">
                                  Ej: 3x2 = cliente elige 3, paga los 2 de mayor precio
                                </p>
                              </div>
                            )}
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="itemCount" className="text-xs">
                              Cantidad de Items
                            </Label>
                            <Input
                              id="itemCount"
                              type="number"
                              min="1"
                              max="10"
                              className="h-8"
                              value={formData.comboConfig.itemCount}
                              onChange={(e) => {
                                const count = parseInt(e.target.value) || 1;
                                const defaultType = formData.comboConfig.itemType || "pizza";
                                const newItems = Array.from({ length: count }, (_, idx) => ({
                                  size: formData.comboConfig.items[idx]?.size || "mediana",
                                  label: formData.comboConfig.items[idx]?.label || `Producto ${idx + 1}`,
                                  itemType: formData.comboConfig.items[idx]?.itemType || defaultType,
                                }));

                                setFormData({
                                  ...formData,
                                  comboConfig: {
                                    ...formData.comboConfig,
                                    itemCount: count,
                                    items: newItems,
                                  },
                                });
                              }}
                            />
                          </div>

                          {/* Grid de slots en 2 columnas */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                            {formData.comboConfig.items.map((item, idx) => (
                              <div key={idx} className="p-2 bg-background rounded border space-y-1">
                                <span className="text-xs font-semibold text-primary">Slot {idx + 1}</span>

                                <Input
                                  className="h-7 text-xs"
                                  placeholder="Etiqueta"
                                  value={item.label}
                                  onChange={(e) => {
                                    const newItems = [...formData.comboConfig.items];
                                    newItems[idx] = { ...newItems[idx], label: e.target.value };
                                    setFormData({
                                      ...formData,
                                      comboConfig: {
                                        ...formData.comboConfig,
                                        items: newItems,
                                      },
                                    });
                                  }}
                                />

                                <Select
                                  value={item.itemType || "pizza"}
                                  onValueChange={(type) => {
                                    const newItems = [...formData.comboConfig.items];
                                    newItems[idx] = { ...newItems[idx], itemType: type };
                                    setFormData({
                                      ...formData,
                                      comboConfig: {
                                        ...formData.comboConfig,
                                        items: newItems,
                                      },
                                    });
                                  }}
                                >
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue placeholder="Tipo" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pizza">🍕 Pizza</SelectItem>
                                    <SelectItem value="hamburguesa">🍔 Hamburguesa</SelectItem>
                                    <SelectItem value="hotdog">🌭 Hot Dog</SelectItem>
                                    <SelectItem value="torta">🥖 Torta</SelectItem>
                                    <SelectItem value="taco">🌮 Taco</SelectItem>
                                    <SelectItem value="burrito">🌯 Burrito</SelectItem>
                                    <SelectItem value="salsa">🧂 Salsa</SelectItem>
                                    <SelectItem value="queso">🧀 Queso</SelectItem>
                                    <SelectItem value="bebida">🥤 Bebida</SelectItem>
                                    <SelectItem value="refresco">🥤 Refresco</SelectItem>
                                    <SelectItem value="refresco 2l">🥤 Refresco 2L</SelectItem>
                                    <SelectItem value="refresco 3l">🥤 Refresco 3L</SelectItem>
                                    <SelectItem value="frappé">🥤 Frappé</SelectItem>
                                    <SelectItem value="café">🥤 Café</SelectItem>
                                    <SelectItem value="esquimo">🥤 Esquimo</SelectItem>
                                    <SelectItem value="cerveza">Cerveza</SelectItem>
                                    <SelectItem value="aderezo">Aderezo</SelectItem>
                                    <SelectItem value="agua">Agua</SelectItem>
                                    <SelectItem value="botana">Botana</SelectItem>
                                    <SelectItem value="carne">Carne</SelectItem>
                                    <SelectItem value="para acompañar">Para acompañar</SelectItem>
                                    <SelectItem value="sabores">Sabores</SelectItem>
                                    <SelectItem value="chocolatería">Chocolatería</SelectItem>
                                    <SelectItem value="tés">Tés</SelectItem>
                                    <SelectItem value="tisanas">Tisanas</SelectItem>
                                    <SelectItem value="frutales">Frutales</SelectItem>
                                    <SelectItem value="extra">Extra</SelectItem>
                                    <SelectItem value="postre">🍰 Postre</SelectItem>
                                    <SelectItem value="base">Base</SelectItem>
                                    <SelectItem value="topping">Topping</SelectItem>
                                    <SelectItem value="empanadas">Empanadas</SelectItem>
                                    <SelectItem value="pastas">Pastas</SelectItem>
                                    <SelectItem value="jugos">Jugos</SelectItem>
                                    <SelectItem value="quesadilla">Quesadillas</SelectItem>
                                    <SelectItem value="waffles">Waffles</SelectItem>
                                    <SelectItem value="creppas">Creppas</SelectItem>
                                    <SelectItem value="hotcakes">Hotcakes</SelectItem>
                                    <SelectItem value="moka">Moka</SelectItem>
                                    <SelectItem value="moka blanco">Moka blanco</SelectItem>
                                    <SelectItem value="latte de sabor">Latte de sabor</SelectItem>
                                    <SelectItem value="latte de sabor 20oz">Latte de sabor 20oz</SelectItem>
                                    <SelectItem value="frappé clásico">Frappé clásico</SelectItem>
                                    <SelectItem value="frappé clásico 20oz">Frappé clásico 20oz</SelectItem>
                                    <SelectItem value="frappé bebida 12oz">Frappé bebida 12oz</SelectItem>
                                    <SelectItem value="frappé bebida 16oz">Frappé bebida 16oz</SelectItem>
                                    <SelectItem value="frappesaurio">Frappesaurio</SelectItem>
                                    <SelectItem value="frappesaurio 20oz">Frappesaurio 20oz</SelectItem>
                                    <SelectItem value="rollo sushi">Rollo sushi</SelectItem>
                                    <SelectItem value="proteina">Proteina</SelectItem>
                                    <SelectItem value="complemento">Complemento</SelectItem>
                                    <SelectItem value="tu gusto (frio/caliente)">Tu gusto (frio/caliente)</SelectItem>
                                    <SelectItem value="agua mineral">Agua mineral</SelectItem>
                                    <SelectItem value="leche">Leche</SelectItem>
                                    <SelectItem value="decorado">Decorado</SelectItem>
                                    <SelectItem value="chocolatería 12oz">Chocolatería 12oz</SelectItem>
                                    <SelectItem value="chocolatería 16oz">Chocolatería 16oz</SelectItem>
                                    <SelectItem value="frappé bebida 12oz">Frappé bebida 12oz</SelectItem>
                                    <SelectItem value="frappé bebida 16oz">Frappé bebida 16oz</SelectItem>
                                    <SelectItem value="frappé bebida 20oz">Frappé bebida 20oz</SelectItem>
                                    <SelectItem value="smoothie 12oz">Smoothie 12oz</SelectItem>
                                    <SelectItem value="smoothie 16oz">Smoothie 16oz</SelectItem>
                                    <SelectItem value="soda italiana 12oz">Soda italiana 12oz</SelectItem>
                                    <SelectItem value="soda italiana 16oz">Soda italiana 16oz</SelectItem>
                                    <SelectItem value="soda italiana 20ozoz">Soda italiana 20ozoz</SelectItem>
                                    <SelectItem value="frappesaurio 12oz">Frappesaurio 12oz</SelectItem>
                                    <SelectItem value="frappesaurio 16oz">Frappesaurio 16oz</SelectItem>
                                    <SelectItem value="latte 12oz">Latte 12oz</SelectItem>
                                    <SelectItem value="latte 16oz">Latte 16oz</SelectItem>
                                    <SelectItem value="tisana 12oz">Tisana 12oz</SelectItem>
                                    <SelectItem value="tisana 16oz">Tisana 16oz</SelectItem>
                                    <SelectItem value="tisana 20oz">Tisana 20oz</SelectItem>
                                    <SelectItem value="chai latte 12oz">Chai latte 12oz</SelectItem>
                                    <SelectItem value="chai latte 16oz">Chai latte 16oz</SelectItem>
                                    <SelectItem value="chai latte 20oz">Chai latte 20oz</SelectItem>
                                    <SelectItem value="masala chai 12oz">Masala chai 12oz</SelectItem>
                                    <SelectItem value="masala chai 16oz">Masala chai 16oz</SelectItem>
                                    <SelectItem value="masala chai 20oz">Masala chai 20oz</SelectItem>
                                    <SelectItem value="infusiones frutales 20oz">Infusiones frutales 20oz</SelectItem>
                                    <SelectItem value="chamoyada 20oz">Chamoyada 20oz</SelectItem>
                                    <SelectItem value="chai sucio 12oz">Chai sucio 12oz</SelectItem>
                                    <SelectItem value="chai sucio 16oz">Chai sucio 16oz</SelectItem>
                                    <SelectItem value="otro">Otro</SelectItem>
                                  </SelectContent>
                                </Select>
                                <Select
                                  value={item.size || "-"}
                                  onValueChange={(size) => {
                                    const newItems = [...formData.comboConfig.items];
                                    newItems[idx] = { ...newItems[idx], size: size === "-" ? "" : size };
                                    setFormData({
                                      ...formData,
                                      comboConfig: {
                                        ...formData.comboConfig,
                                        items: newItems,
                                      },
                                    });
                                  }}
                                >
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue placeholder="Tamaño" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="-">Sin tamaño</SelectItem>
                                    <SelectItem value="chica">Chica</SelectItem>
                                    <SelectItem value="mediana">Mediana</SelectItem>
                                    <SelectItem value="grande">Grande</SelectItem>
                                    <SelectItem value="familiar">Familiar</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex items-center gap-2 p-3 bg-muted/30 rounded-lg">
                        <Switch
                          checked={formData.isSpecialty}
                          onCheckedChange={(checked) =>
                            setFormData({
                              ...formData,
                              isSpecialty: checked,
                              isPromotionalCombo: checked ? false : formData.isPromotionalCombo,
                            })
                          }
                        />
                        <Label className="text-sm">Es una especialidad</Label>
                      </div>

                      {formData.isSpecialty && (
                        <div className="space-y-2 p-3 bg-primary/10 rounded-lg border border-primary/20">
                          <p className="text-xs text-muted-foreground">
                            ✨ El cliente seleccionará UNA especialidad al agregar este producto.
                          </p>
                        </div>
                      )}
                    </>
                  )}

                  {!isSpecialBusiness && (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-sm text-muted-foreground text-center">
                        Las opciones de combo y especialidad están disponibles para negocios especiales.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Botones fijos en la parte inferior */}
            <div className="flex gap-2 pt-4 mt-4 border-t flex-shrink-0">
              <Button type="button" variant="outline" onClick={handleCloseModal} className="flex-1">
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                {editingProduct ? "Actualizar" : "Crear"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};
