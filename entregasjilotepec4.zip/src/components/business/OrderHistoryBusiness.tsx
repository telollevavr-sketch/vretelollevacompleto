import { Order, OrderStatus } from '@/types';
import { useOrders } from '@/hooks/useOrders';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { format, isWithinInterval, startOfDay, endOfDay } from 'date-fns';
import { es } from 'date-fns/locale';
import { Package, Calendar, DollarSign, Printer, FileSpreadsheet, Filter } from 'lucide-react';
import { OrderItemDetails } from '@/components/shared/OrderItemDetails';
import { generateOrderTicketPDF } from '@/lib/pdfGenerator';
import { useAllBusinesses } from '@/hooks/useAllBusinesses';
import { exportBusinessOrdersToExcel } from '@/lib/statsExport';
import { toast } from 'sonner';
import { useState } from 'react';
import { DateRange } from 'react-day-picker';
import { DateRangePicker } from '@/components/shared/DateRangePicker';
import { Label } from '@/components/ui/label';

interface OrderHistoryBusinessProps {
  businessId: string;
}

export const OrderHistoryBusiness = ({ businessId }: OrderHistoryBusinessProps) => {
  const { orders } = useOrders(businessId, 'business');
  const { businesses } = useAllBusinesses();
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  
  const currentBusiness = businesses.find(b => b.id === businessId);

  // Quick date filters
  const setQuickRange = (days: number | null) => {
    if (days === null) {
      setDateRange(undefined);
      return;
    }
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - days);
    setDateRange({ from, to });
  };

  // Apply date filter
  const filteredOrders = orders.filter(order => {
    if (dateRange?.from) {
      const orderDate = new Date(order.createdAt);
      const from = startOfDay(dateRange.from);
      const to = dateRange.to ? endOfDay(dateRange.to) : endOfDay(dateRange.from);
      if (!isWithinInterval(orderDate, { start: from, end: to })) return false;
    }
    return true;
  });

  const completedOrders = filteredOrders.filter(o => o.status === OrderStatus.DELIVERED);
  const cancelledOrders = filteredOrders.filter(o => o.status === OrderStatus.CANCELLED);

  const totalRevenue = completedOrders.reduce((sum, order) => sum + order.totalAmount, 0);
  const avgOrderValue = completedOrders.length > 0 
    ? totalRevenue / completedOrders.length 
    : 0;
  const counterOrders = completedOrders.filter(o => o.isPickupAtCounter);
  const deliveryOrders = completedOrders.filter(o => !o.isPickupAtCounter);
  
  const activeOrders = filteredOrders.filter(o => 
    o.status !== OrderStatus.DELIVERED && 
    o.status !== OrderStatus.CANCELLED
  );

  const getStatusBadge = (status: OrderStatus) => {
    const variants: Record<OrderStatus, 'default' | 'secondary' | 'destructive'> = {
      [OrderStatus.PENDING]: 'secondary',
      [OrderStatus.IN_PREPARATION]: 'default',
      [OrderStatus.READY_FOR_PICKUP]: 'default',
      [OrderStatus.ON_THE_WAY]: 'default',
      [OrderStatus.DELIVERED]: 'default',
      [OrderStatus.CANCELLED]: 'destructive'
    };

    const labels: Record<OrderStatus, string> = {
      [OrderStatus.PENDING]: 'Pendiente',
      [OrderStatus.IN_PREPARATION]: 'En Preparación',
      [OrderStatus.READY_FOR_PICKUP]: 'Listo',
      [OrderStatus.ON_THE_WAY]: 'En Camino',
      [OrderStatus.DELIVERED]: 'Entregado',
      [OrderStatus.CANCELLED]: 'Cancelado'
    };

    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    );
  };

  const handlePrintTicket = (order: Order) => {
    if (!currentBusiness) {
      console.error('No se encontró información del negocio');
      return;
    }
    
    try {
      generateOrderTicketPDF(order, currentBusiness);
    } catch (error) {
      console.error('Error al generar el ticket PDF:', error);
    }
  };

  const handleExportCompletedOrders = () => {
    try {
      if (completedOrders.length === 0) {
        toast.error('No hay pedidos completados para exportar');
        return;
      }
      
      if (!currentBusiness) {
        toast.error('No se encontró información del negocio');
        return;
      }
      
      exportBusinessOrdersToExcel(completedOrders, currentBusiness.name);
      toast.success('Pedidos exportados exitosamente');
    } catch (error) {
      console.error('Error exporting orders:', error);
      toast.error('Error al exportar los pedidos');
    }
  };

  const OrderCard = ({ order }: { order: Order }) => (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm text-muted-foreground">Pedido #{order.id}</p>
                {order.isPickupAtCounter && (
                  <Badge variant="outline" className="text-xs">
                    📦 Mostrador
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                {format(new Date(order.createdAt), "d 'de' MMMM, yyyy 'a las' HH:mm", { locale: es })}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {getStatusBadge(order.status)}
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  handlePrintTicket(order);
                }}
                className="h-8 w-8 p-0"
                title="Imprimir ticket"
              >
                <Printer className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            {order.items.map((item, idx) => (
              <OrderItemDetails
                key={idx}
                item={item}
                index={idx}
                showPrice={false}
                compact={true}
              />
            ))}
          </div>

          <div className="space-y-2 pt-3 border-t">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Subtotal:</span>
              <span className="font-medium">${order.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Costo de envío:</span>
              <span className="font-medium">${order.deliveryFee.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between pt-2 border-t">
              <span className="font-bold text-lg">Total:</span>
              <span className="font-bold text-lg">${order.total.toFixed(2)}</span>
            </div>
          </div>

          {order.rating && (
            <div className="pt-2 border-t">
              <p className="text-sm font-medium">Calificación: ⭐ {order.rating.businessRating}/5</p>
              {order.rating.businessComment && (
                <p className="text-sm text-muted-foreground mt-1">"{order.rating.businessComment}"</p>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-4">Historial de Pedidos</h2>
        
        {/* Filters Section */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 mb-4">
              <Filter className="h-5 w-5 text-primary" />
              <Label className="text-base font-semibold">Filtros</Label>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-end">
              <div className="flex-1 space-y-2">
                <Label>Rango de Fechas</Label>
                <DateRangePicker 
                  dateRange={dateRange} 
                  onDateRangeChange={setDateRange} 
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setQuickRange(7)}
                  className={dateRange?.from && !dateRange?.to && 
                    Math.abs(new Date().getTime() - dateRange.from.getTime()) / (1000 * 60 * 60 * 24) <= 7 
                    ? 'border-primary' : ''}
                >
                  7 días
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setQuickRange(30)}
                  className={dateRange?.from && !dateRange?.to && 
                    Math.abs(new Date().getTime() - dateRange.from.getTime()) / (1000 * 60 * 60 * 24) <= 30 
                    ? 'border-primary' : ''}
                >
                  30 días
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setQuickRange(null)}
                  className={!dateRange ? 'border-primary' : ''}
                >
                  Todo
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <Package className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Total Completados</p>
                  <p className="text-2xl font-bold">{completedOrders.length}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {counterOrders.length} mostrador • {deliveryOrders.length} delivery
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <DollarSign className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Ingresos Totales</p>
                  <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <Calendar className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Ticket Promedio</p>
                  <p className="text-2xl font-bold">${avgOrderValue.toFixed(2)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <Package className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Pedidos Activos</p>
                  <p className="text-2xl font-bold">{activeOrders.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Tabs defaultValue="completed">
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="completed">
              Completados ({completedOrders.length})
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              Cancelados ({cancelledOrders.length})
            </TabsTrigger>
            <TabsTrigger value="all">
              Todos ({orders.length})
            </TabsTrigger>
          </TabsList>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCompletedOrders}
            disabled={completedOrders.length === 0}
            className="gap-2"
          >
            <FileSpreadsheet className="h-4 w-4" />
            Exportar Completados
          </Button>
        </div>

        <TabsContent value="completed" className="space-y-4">
          {completedOrders.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                No hay pedidos completados
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {completedOrders.map(order => (
                <OrderCard key={order.id} order={order} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="cancelled" className="space-y-4">
          {cancelledOrders.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                No hay pedidos cancelados
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {cancelledOrders.map(order => (
                <OrderCard key={order.id} order={order} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="all" className="space-y-4">
          {filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                {dateRange?.from 
                  ? 'No hay pedidos en el rango de fechas seleccionado' 
                  : 'No hay pedidos'}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredOrders.map(order => (
                <OrderCard key={order.id} order={order} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};