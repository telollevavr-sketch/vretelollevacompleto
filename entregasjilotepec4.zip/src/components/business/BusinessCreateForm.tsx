import { useState } from 'react';
import { Location } from '@/types';
import { useBusinesses } from '@/hooks/useBusinesses';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from '@/hooks/use-toast';
import { useCategories } from '@/hooks/useCategories';
import { LocationPicker } from '@/components/shared/LocationPicker';
import { Store, MapPin, Save, Upload } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';

export const BusinessCreateForm = () => {
  const { createBusiness } = useBusinesses();
  const [location, setLocation] = useState<Location>({ lat: 19.4326, lng: -99.1332 });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { categories } = useCategories();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    phone: '',
    address: '',
    deliveryRadius: '5',
    minOrderAmount: '50',
    deliveryFee: '30',
    estimatedDeliveryTime: '30-45 min',
    image: '',
    businessDays: '',
    businessHours: ''
  });

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 6 * 1024 * 1024) {
        toast({
          title: 'Error',
          description: 'La imagen no debe superar los 6MB',
          variant: 'destructive'
        });
        return;
      }

      try {
        // Si es un GIF, no comprimir para mantener la animación
        if (file.type === 'image/gif') {
          toast({
            title: 'Procesando GIF...',
            description: 'Cargando imagen animada'
          });

          const reader = new FileReader();
          reader.onloadend = () => {
            const base64 = reader.result as string;
            setFormData({ ...formData, image: base64 });
            
            const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
            toast({
              title: 'GIF Cargado',
              description: `Tamaño: ${sizeInMB} MB`
            });
          };
          reader.onerror = () => {
            toast({
              title: 'Error',
              description: 'No se pudo cargar el GIF',
              variant: 'destructive'
            });
          };
          reader.readAsDataURL(file);
        } else {
          // Para otras imágenes, aplicar compresión
          const { compressImage, formatFileSize } = await import('@/lib/imageCompression');
          
          toast({
            title: 'Procesando imagen...',
            description: 'Comprimiendo y optimizando la imagen'
          });

          const { base64, originalSize, compressedSize } = await compressImage(file, {
            maxWidth: 1024,
            maxHeight: 1024,
            maxSizeKB: 250
          });

          setFormData({ ...formData, image: base64 });

          toast({
            title: 'Imagen Optimizada',
            description: `Tamaño original: ${formatFileSize(originalSize)} → Optimizado: ${formatFileSize(compressedSize)}`
          });
        }
      } catch (error) {
        console.error('Error al procesar imagen:', error);
        toast({
          title: 'Error',
          description: 'No se pudo procesar la imagen',
          variant: 'destructive'
        });
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: 'Error',
        description: 'El nombre del negocio es obligatorio',
        variant: 'destructive'
      });
      return;
    }

    if (!formData.phone.trim()) {
      toast({
        title: 'Error',
        description: 'El teléfono es obligatorio',
        variant: 'destructive'
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('No hay usuario autenticado');
      }

      createBusiness({
        user_id: user.id,
        name: formData.name,
        description: formData.description,
        category: formData.category,
        phone: formData.phone,
        address: formData.address,
        latitude: location.lat,
        longitude: location.lng,
        max_delivery_distance_km: parseFloat(formData.deliveryRadius),
        min_order_amount: parseFloat(formData.minOrderAmount),
        delivery_fee: parseFloat(formData.deliveryFee),
        delivery_time_minutes: parseInt(formData.estimatedDeliveryTime) || 30,
        business_type: 'restaurant',
        business_days: formData.businessDays || null,
        business_hours: formData.businessHours || null,
        is_active: false // Pending admin approval
      });

      toast({
        title: 'Negocio Creado',
        description: 'Tu negocio ha sido creado y está pendiente de aprobación por un administrador',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Crear Negocio</h2>
          <p className="text-muted-foreground mt-1">Registra tu negocio en la plataforma</p>
        </div>
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Store className="h-5 w-5 text-primary" />
            <div>
              <CardTitle>Información del Negocio</CardTitle>
              <CardDescription className="mt-2">
                Completa los datos de tu negocio. Una vez creado, estará pendiente de aprobación.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Business Image Upload */}
            <div className="flex flex-col items-center gap-4">
              <Avatar className="h-32 w-32 border-4 border-primary/20 shadow-lg">
                <AvatarImage src={formData.image} />
                <AvatarFallback className="text-3xl font-semibold bg-primary text-primary-foreground">
                  {formData.name ? formData.name.charAt(0).toUpperCase() : <Store className="h-12 w-12" />}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col items-center gap-2">
                <Label htmlFor="business-image" className="cursor-pointer">
                  <Button variant="outline" size="sm" type="button" asChild>
                    <span>
                      <Upload className="h-4 w-4 mr-2" />
                      Subir Imagen
                    </span>
                  </Button>
                </Label>
                <Input
                  id="business-image"
                  type="file"
                  accept="image/*,image/gif"
                  className="hidden"
                  onChange={handleImageUpload}
                />
                <p className="text-xs text-muted-foreground">Máximo 6MB. Los GIF mantienen su animación</p>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">
                  Nombre del Negocio <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Nombre de tu negocio"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">
                  Categoría <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.name}>
                        {cat.icon && `${cat.icon} `}{cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">
                  Teléfono <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="5512345678"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Dirección</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Calle, Número, Colonia"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deliveryRadius">
                  Radio de Entrega (km) <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="deliveryRadius"
                  type="number"
                  step="0.1"
                  min="0"
                  value={formData.deliveryRadius}
                  onChange={(e) => setFormData({ ...formData, deliveryRadius: e.target.value })}
                  placeholder="5.0"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="minOrderAmount">
                  Pedido Mínimo ($) <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="minOrderAmount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.minOrderAmount}
                  onChange={(e) => setFormData({ ...formData, minOrderAmount: e.target.value })}
                  placeholder="50.00"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deliveryFee">
                  Costo de Envío ($) <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="deliveryFee"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.deliveryFee}
                  onChange={(e) => setFormData({ ...formData, deliveryFee: e.target.value })}
                  placeholder="30.00"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="estimatedDeliveryTime">
                  Tiempo Estimado <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="estimatedDeliveryTime"
                  value={formData.estimatedDeliveryTime}
                  onChange={(e) => setFormData({ ...formData, estimatedDeliveryTime: e.target.value })}
                  placeholder="30-45 min"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessDays">Días de Atención</Label>
                <Input
                  id="businessDays"
                  value={formData.businessDays}
                  onChange={(e) => setFormData({ ...formData, businessDays: e.target.value })}
                  placeholder="Lun-Dom, Lun-Vie, etc."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessHours">Horarios</Label>
                <Input
                  id="businessHours"
                  value={formData.businessHours}
                  onChange={(e) => setFormData({ ...formData, businessHours: e.target.value })}
                  placeholder="10:00 AM - 10:00 PM"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={4}
                placeholder="Describe tu negocio..."
              />
            </div>

            <Separator />

            <div className="space-y-3">
              <Label className="text-base font-semibold">Ubicación del Negocio</Label>
              <p className="text-sm text-muted-foreground">
                Selecciona la ubicación exacta de tu negocio en el mapa o usa el botón para obtener tu ubicación actual
              </p>
              <LocationPicker
                location={location}
                onLocationChange={setLocation}
              />
            </div>

            <Separator />

            <div className="flex gap-3 justify-end">
              <Button type="submit" disabled={isSubmitting}>
                <Save className="h-4 w-4 mr-2" />
                {isSubmitting ? 'Creando...' : 'Crear Negocio'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
