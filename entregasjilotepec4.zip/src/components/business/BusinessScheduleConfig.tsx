import { useState, useEffect } from 'react';
import { useBusinessSchedules } from '@/hooks/useBusinessSchedules';
import { useBusinesses } from '@/hooks/useBusinesses';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { Clock, Save, Copy, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface BusinessScheduleConfigProps {
  businessId: string;
  autoScheduleEnabled: boolean;
  onAutoScheduleChange: (enabled: boolean) => void;
}

interface DaySchedule {
  dayOfWeek: number;
  dayName: string;
  isOpen: boolean;
  openingTime: string;
  closingTime: string;
}

const DEFAULT_OPENING = '09:00';
const DEFAULT_CLOSING = '21:00';

export const BusinessScheduleConfig = ({ 
  businessId, 
  autoScheduleEnabled,
  onAutoScheduleChange 
}: BusinessScheduleConfigProps) => {
  const { schedules, isLoading, upsertAllSchedules, isUpdating, DAY_NAMES } = useBusinessSchedules(businessId);
  
  const [localSchedules, setLocalSchedules] = useState<DaySchedule[]>([]);
  const [hasChanges, setHasChanges] = useState(false);

  // Initialize schedules
  useEffect(() => {
    const initialSchedules: DaySchedule[] = DAY_NAMES.map((dayName, index) => {
      const existingSchedule = schedules.find(s => s.dayOfWeek === index);
      return {
        dayOfWeek: index,
        dayName,
        isOpen: existingSchedule?.isOpen ?? true,
        openingTime: existingSchedule?.openingTime?.substring(0, 5) ?? DEFAULT_OPENING,
        closingTime: existingSchedule?.closingTime?.substring(0, 5) ?? DEFAULT_CLOSING,
      };
    });
    setLocalSchedules(initialSchedules);
    setHasChanges(false);
  }, [schedules, DAY_NAMES]);

  const handleDayChange = (dayOfWeek: number, field: keyof DaySchedule, value: string | boolean) => {
    setLocalSchedules(prev => prev.map(day => 
      day.dayOfWeek === dayOfWeek ? { ...day, [field]: value } : day
    ));
    setHasChanges(true);
  };

  const handleApplyToAll = () => {
    const monday = localSchedules.find(s => s.dayOfWeek === 1);
    if (!monday) return;

    setLocalSchedules(prev => prev.map(day => ({
      ...day,
      isOpen: monday.isOpen,
      openingTime: monday.openingTime,
      closingTime: monday.closingTime,
    })));
    setHasChanges(true);
    toast({
      title: 'Horario Aplicado',
      description: 'El horario del Lunes se ha aplicado a todos los días',
    });
  };

  const handleSave = () => {
    const schedulesToSave = localSchedules.map(schedule => ({
      businessId,
      dayOfWeek: schedule.dayOfWeek,
      isOpen: schedule.isOpen,
      openingTime: `${schedule.openingTime}:00`,
      closingTime: `${schedule.closingTime}:00`,
    }));

    upsertAllSchedules(schedulesToSave);
    setHasChanges(false);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="flex items-center justify-center">
            <Clock className="h-6 w-6 animate-spin text-primary mr-2" />
            <span>Cargando horarios...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          Horarios de Atención
        </CardTitle>
        <CardDescription>
          Configura los horarios de apertura y cierre automático de tu negocio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Auto Schedule Toggle */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
          <div className="space-y-0.5">
            <Label className="text-base font-medium">Apertura/Cierre Automático</Label>
            <p className="text-sm text-muted-foreground">
              {autoScheduleEnabled 
                ? 'El negocio se abrirá y cerrará automáticamente según los horarios configurados'
                : 'Controla manualmente cuándo abrir o cerrar tu negocio'
              }
            </p>
          </div>
          <Switch
            checked={autoScheduleEnabled}
            onCheckedChange={onAutoScheduleChange}
          />
        </div>

        {autoScheduleEnabled && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              El sistema actualizará el estado de tu negocio cada 5 minutos según estos horarios.
              Zona horaria: Ciudad de México (UTC-6)
            </AlertDescription>
          </Alert>
        )}

        {/* Schedule Grid */}
        <div className="space-y-3">
          <div className="grid grid-cols-12 gap-2 px-2 text-sm font-medium text-muted-foreground">
            <div className="col-span-3">Día</div>
            <div className="col-span-2 text-center">Abierto</div>
            <div className="col-span-3 text-center">Apertura</div>
            <div className="col-span-1 text-center">-</div>
            <div className="col-span-3 text-center">Cierre</div>
          </div>

          {localSchedules.map((schedule) => (
            <div 
              key={schedule.dayOfWeek}
              className={`grid grid-cols-12 gap-2 items-center p-2 rounded-lg transition-colors ${
                schedule.isOpen ? 'bg-green-50 dark:bg-green-950/20' : 'bg-red-50 dark:bg-red-950/20'
              }`}
            >
              <div className="col-span-3 font-medium text-sm">
                {schedule.dayName}
              </div>
              <div className="col-span-2 flex justify-center">
                <Switch
                  checked={schedule.isOpen}
                  onCheckedChange={(checked) => handleDayChange(schedule.dayOfWeek, 'isOpen', checked)}
                />
              </div>
              <div className="col-span-3">
                <Input
                  type="time"
                  value={schedule.openingTime}
                  onChange={(e) => handleDayChange(schedule.dayOfWeek, 'openingTime', e.target.value)}
                  disabled={!schedule.isOpen}
                  className={`text-center text-sm h-9 ${!schedule.isOpen ? 'opacity-50' : ''}`}
                />
              </div>
              <div className="col-span-1 text-center text-muted-foreground">-</div>
              <div className="col-span-3">
                <Input
                  type="time"
                  value={schedule.closingTime}
                  onChange={(e) => handleDayChange(schedule.dayOfWeek, 'closingTime', e.target.value)}
                  disabled={!schedule.isOpen}
                  className={`text-center text-sm h-9 ${!schedule.isOpen ? 'opacity-50' : ''}`}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <Button
            variant="outline"
            onClick={handleApplyToAll}
            className="flex-1"
          >
            <Copy className="h-4 w-4 mr-2" />
            Aplicar Lunes a Todos
          </Button>
          <Button
            onClick={handleSave}
            disabled={!hasChanges || isUpdating}
            className="flex-1"
          >
            <Save className="h-4 w-4 mr-2" />
            {isUpdating ? 'Guardando...' : 'Guardar Horarios'}
          </Button>
        </div>

        {hasChanges && (
          <p className="text-sm text-amber-600 text-center">
            ⚠️ Tienes cambios sin guardar
          </p>
        )}
      </CardContent>
    </Card>
  );
};
