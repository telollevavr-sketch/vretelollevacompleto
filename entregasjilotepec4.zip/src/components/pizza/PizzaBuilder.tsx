import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { PIZZA_INGREDIENTS } from '@/types';
import { Product } from '@/types';
import { ArrowLeft, ShoppingCart } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import pizzaChica from '@/assets/pizza-chica.jpg';
import pizzaMediana from '@/assets/pizza-mediana.jpg';
import pizzaGrande from '@/assets/pizza-grande.jpg';
import pizzaFamiliar from '@/assets/pizza-familiar.jpg';

interface PizzaBuilderProps {
  open: boolean;
  onClose: () => void;
  onAddToCart: (pizzaConfig: PizzaConfiguration) => void;
  businessId: string;
  pizzaProducts: Product[];
}

export interface PizzaConfiguration {
  size: string;
  ingredients: string[];
  stuffedCrust: boolean;
  notes: string;
  price: number;
}

export const PizzaBuilder = ({ open, onClose, onAddToCart, businessId, pizzaProducts }: PizzaBuilderProps) => {
  const [step, setStep] = useState(1);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [stuffedCrust, setStuffedCrust] = useState(false);
  const [notes, setNotes] = useState('');

  const pizzaImages: { [key: string]: string } = {
    'chica': pizzaChica,
    'mediana': pizzaMediana,
    'grande': pizzaGrande,
    'familiar': pizzaFamiliar
  };

  const getMaxIngredients = () => 4; // Todos los tamaños tienen 4 ingredientes según los productos

  const handleSizeSelect = (product: Product) => {
    setSelectedProduct(product);
    setSelectedIngredients([]);
    setStep(2);
  };

  const handleIngredientToggle = (ingredient: string) => {
    if (selectedIngredients.includes(ingredient)) {
      setSelectedIngredients(selectedIngredients.filter(i => i !== ingredient));
    } else {
      const maxIngredients = getMaxIngredients();
      if (selectedIngredients.length < maxIngredients) {
        setSelectedIngredients([...selectedIngredients, ingredient]);
      } else {
        toast({
          title: "Límite alcanzado",
          description: `Solo puedes seleccionar ${maxIngredients} ingredientes para este tamaño.`,
          variant: "destructive"
        });
      }
    }
  };

  const getStuffedCrustPrice = () => {
    if (!selectedProduct) return 0;
    const sizeName = selectedProduct.name.toLowerCase();
    const priceMap: { [key: string]: number } = {
      'chica': 35,
      'mediana': 45,
      'grande': 55,
      'familiar': 65
    };
    
    for (const key in priceMap) {
      if (sizeName.includes(key)) {
        return priceMap[key];
      }
    }
    return 0;
  };

  const calculateTotal = () => {
    if (!selectedProduct) return 0;
    let total = selectedProduct.price;
    if (stuffedCrust) total += getStuffedCrustPrice();
    return total;
  };

  const handleAddToCart = () => {
    if (!selectedProduct) return;

    if (selectedIngredients.length === 0) {
      toast({
        title: "Selecciona ingredientes",
        description: "Debes seleccionar al menos 1 ingrediente.",
        variant: "destructive"
      });
      return;
    }

    const config: PizzaConfiguration = {
      size: selectedProduct.name,
      ingredients: selectedIngredients,
      stuffedCrust,
      notes,
      price: calculateTotal()
    };

    onAddToCart(config);
    handleReset();
    onClose();
  };

  const handleReset = () => {
    setStep(1);
    setSelectedProduct(null);
    setSelectedIngredients([]);
    setStuffedCrust(false);
    setNotes('');
  };

  const handleBack = () => {
    if (step === 2) {
      setStep(1);
      setSelectedIngredients([]);
    }
  };

  const allIngredients = [
    ...PIZZA_INGREDIENTS.carnes,
    ...PIZZA_INGREDIENTS.vegetales,
    ...PIZZA_INGREDIENTS.salsas,
    ...PIZZA_INGREDIENTS.quesos
  ];

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen) {
        handleReset();
        onClose();
      }
    }}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            Arma tu Pizza
          </DialogTitle>
          <DialogDescription>
            Personaliza tu pizza eligiendo el tamaño, ingredientes y extras de tu preferencia.
          </DialogDescription>
          {step === 2 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="absolute left-4 top-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
          )}
        </DialogHeader>

        {step === 1 && (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">Paso 1: Elige el Tamaño</h3>
              <p className="text-muted-foreground">Sigue los pasos para crear tu pizza ideal.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pizzaProducts.map((product) => {
                const sizeName = product.name.toLowerCase();
                let imageKey = 'chica';
                if (sizeName.includes('mediana')) imageKey = 'mediana';
                else if (sizeName.includes('grande')) imageKey = 'grande';
                else if (sizeName.includes('familiar')) imageKey = 'familiar';
                
                return (
                  <Card
                    key={product.id}
                    className="cursor-pointer hover:border-primary transition-all hover:scale-[1.02] overflow-hidden group"
                    onClick={() => handleSizeSelect(product)}
                  >
                    <div className="relative h-40 overflow-hidden">
                      <img 
                        src={pizzaImages[imageKey]} 
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-4">
                        <h4 className="text-2xl font-bold mb-1 drop-shadow-lg">
                          {product.name.replace('Arma tu pizza ', '').replace(' 4 ingredientes', '')}
                        </h4>
                        <p className="text-sm mb-2 drop-shadow-md">4 ingredientes</p>
                        <p className="text-3xl font-bold drop-shadow-lg">
                          ${product.price.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {step === 2 && selectedProduct && (
          <div className="space-y-6">
            <div className="bg-primary/10 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg">{selectedProduct.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    Selecciona hasta {getMaxIngredients()} ingredientes
                  </p>
                </div>
                <Badge variant="secondary" className="text-lg">
                  {selectedIngredients.length}/{getMaxIngredients()}
                </Badge>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Paso 2: Elige tus Ingredientes</h4>
              
              {/* Carnes */}
              <div className="space-y-2">
                <h5 className="text-sm font-medium text-muted-foreground">Carnes</h5>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {PIZZA_INGREDIENTS.carnes.map((ingredient) => (
                    <div key={ingredient} className="flex items-center space-x-2">
                      <Checkbox
                        id={ingredient}
                        checked={selectedIngredients.includes(ingredient)}
                        onCheckedChange={() => handleIngredientToggle(ingredient)}
                        disabled={
                          !selectedIngredients.includes(ingredient) &&
                          selectedIngredients.length >= getMaxIngredients()
                        }
                      />
                      <Label
                        htmlFor={ingredient}
                        className="text-sm cursor-pointer"
                      >
                        {ingredient}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Vegetales */}
              <div className="space-y-2">
                <h5 className="text-sm font-medium text-muted-foreground">Vegetales</h5>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {PIZZA_INGREDIENTS.vegetales.map((ingredient) => (
                    <div key={ingredient} className="flex items-center space-x-2">
                      <Checkbox
                        id={ingredient}
                        checked={selectedIngredients.includes(ingredient)}
                        onCheckedChange={() => handleIngredientToggle(ingredient)}
                        disabled={
                          !selectedIngredients.includes(ingredient) &&
                          selectedIngredients.length >= getMaxIngredients()
                        }
                      />
                      <Label
                        htmlFor={ingredient}
                        className="text-sm cursor-pointer"
                      >
                        {ingredient}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Salsas */}
              <div className="space-y-2">
                <h5 className="text-sm font-medium text-muted-foreground">Salsas y Aderezos</h5>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {PIZZA_INGREDIENTS.salsas.map((ingredient) => (
                    <div key={ingredient} className="flex items-center space-x-2">
                      <Checkbox
                        id={ingredient}
                        checked={selectedIngredients.includes(ingredient)}
                        onCheckedChange={() => handleIngredientToggle(ingredient)}
                        disabled={
                          !selectedIngredients.includes(ingredient) &&
                          selectedIngredients.length >= getMaxIngredients()
                        }
                      />
                      <Label
                        htmlFor={ingredient}
                        className="text-sm cursor-pointer"
                      >
                        {ingredient}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quesos */}
              <div className="space-y-2">
                <h5 className="text-sm font-medium text-muted-foreground">Quesos</h5>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {PIZZA_INGREDIENTS.quesos.map((ingredient) => (
                    <div key={ingredient} className="flex items-center space-x-2">
                      <Checkbox
                        id={ingredient}
                        checked={selectedIngredients.includes(ingredient)}
                        onCheckedChange={() => handleIngredientToggle(ingredient)}
                        disabled={
                          !selectedIngredients.includes(ingredient) &&
                          selectedIngredients.length >= getMaxIngredients()
                        }
                      />
                      <Label
                        htmlFor={ingredient}
                        className="text-sm cursor-pointer"
                      >
                        {ingredient}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-4 border-t pt-4">
              <h4 className="font-semibold">Paso 3: Agrega Extras (Opcional)</h4>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <Label htmlFor="stuffedCrust" className="cursor-pointer">
                  Orilla Rellena de Queso (+${getStuffedCrustPrice()})
                </Label>
                <Switch
                  id="stuffedCrust"
                  checked={stuffedCrust}
                  onCheckedChange={setStuffedCrust}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Indicaciones especiales (ej: masa delgada, mitad y mitad)</Label>
                <Textarea
                  id="notes"
                  placeholder="Escribe tus indicaciones especiales aquí..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </div>

            <div className="flex items-center justify-between border-t pt-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-3xl font-bold text-primary">${calculateTotal()}.00</p>
              </div>
              <Button
                size="lg"
                onClick={handleAddToCart}
                disabled={selectedIngredients.length === 0}
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                Agregar al Carrito
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};