import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Phone, ShoppingBag, FileText, MessageCircle } from 'lucide-react';
import { AntojoBusiness } from '@/hooks/useAntojoBusinesses';
import { openWhatsApp } from '@/lib/deviceUtils';

const isPdfUrl = (url: string) => url.toLowerCase().endsWith('.pdf');

interface AntojoBusinessCardProps {
  business: AntojoBusiness;
  onSelect: (business: AntojoBusiness) => void;
}

export const AntojoBusinessCard = ({ business, onSelect }: AntojoBusinessCardProps) => {
  const handleRequestInfo = (e: React.MouseEvent) => {
    e.stopPropagation();
    openWhatsApp('525548957140', `Necesito carta/información de ${business.name}`);
  };

  return (
    <Card className="overflow-hidden border-[hsl(var(--antojo-gold)/0.25)] bg-card transition-all hover:border-[hsl(var(--antojo-terracotta)/0.5)] hover:shadow-lg hover:shadow-[hsl(var(--antojo-terracotta)/0.1)]">
      {/* Business Image */}
      {business.image_url && (
        <div className="relative w-full max-h-48 overflow-hidden">
          <img src={business.image_url} alt={business.name} className="w-full h-48 object-cover" />
          <button
            onClick={handleRequestInfo}
            className="absolute bottom-0 left-0 right-0 flex items-center justify-center gap-2 bg-[hsl(142_70%_28%/0.9)] px-3 py-2 text-xs font-semibold text-white backdrop-blur-sm transition-colors hover:bg-[hsl(142_70%_24%/0.95)]"
          >
            <MessageCircle className="h-3.5 w-3.5" />
            Solicitar carta e información adicional
          </button>
        </div>
      )}

      {/* Menu Image/PDF (if no business image) */}
      {!business.image_url && business.menu_image && (
        isPdfUrl(business.menu_image) ? (
          <div className="p-4">
            <a href={business.menu_image} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-lg border border-[hsl(var(--antojo-terracotta)/0.3)] bg-[hsl(var(--antojo-cream))] p-3 text-sm font-semibold text-[hsl(var(--antojo-terracotta))] hover:bg-[hsl(var(--antojo-terracotta)/0.1)] transition-colors">
              <FileText className="h-5 w-5" />
              📄 Ver Menú (PDF)
            </a>
          </div>
        ) : (
          <div className="relative w-full max-h-48 overflow-hidden">
            <img src={business.menu_image} alt={`Menú de ${business.name}`} className="w-full h-48 object-cover" />
            <button
              onClick={handleRequestInfo}
              className="absolute bottom-0 left-0 right-0 flex items-center justify-center gap-2 bg-[hsl(142_70%_28%/0.9)] px-3 py-2 text-xs font-semibold text-white backdrop-blur-sm transition-colors hover:bg-[hsl(142_70%_24%/0.95)]"
            >
              <MessageCircle className="h-3.5 w-3.5" />
              Solicitar carta e información adicional
            </button>
          </div>
        )
      )}

      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-lg text-card-foreground">{business.name}</CardTitle>
          {business.category && (
            <Badge className="shrink-0 border border-[hsl(var(--antojo-green)/0.3)] bg-[hsl(var(--antojo-green)/0.12)] text-xs text-[hsl(var(--antojo-green))] font-semibold">
              {business.category}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <MapPin className="h-3.5 w-3.5 flex-shrink-0 text-[hsl(var(--antojo-terracotta))]" />
          <span className="truncate">{business.address}</span>
        </div>
        {business.phone && (
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Phone className="h-3.5 w-3.5 flex-shrink-0 text-[hsl(var(--antojo-green))]" />
            <span>{business.phone}</span>
          </div>
        )}
      </CardHeader>

      {/* Show info request button when no image at all */}
      {!business.image_url && !business.menu_image && (
        <div className="px-6 pb-1">
          <button
            onClick={handleRequestInfo}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-[hsl(142_70%_28%)] px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-[hsl(142_70%_24%)]"
          >
            <MessageCircle className="h-3.5 w-3.5" />
            Solicitar carta e información adicional
          </button>
        </div>
      )}

      <CardContent className="space-y-3">
        {/* Menu Image/PDF shown below if business image exists */}
        {business.image_url && business.menu_image && (
          isPdfUrl(business.menu_image) ? (
            <a href={business.menu_image} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-lg border border-[hsl(var(--antojo-terracotta)/0.3)] bg-[hsl(var(--antojo-cream))] p-3 text-sm font-semibold text-[hsl(var(--antojo-terracotta))] hover:bg-[hsl(var(--antojo-terracotta)/0.1)] transition-colors">
              <FileText className="h-5 w-5" />
              📄 Ver Menú (PDF)
            </a>
          ) : (
            <div className="w-full max-h-40 overflow-hidden rounded-lg">
              <img src={business.menu_image} alt={`Menú de ${business.name}`} className="w-full object-cover rounded-lg" />
            </div>
          )
        )}

        {/* Menu Text / Pizarra */}
        {business.menu_text && (
          <div className="rounded-lg border border-[hsl(var(--antojo-gold)/0.3)] bg-[hsl(var(--antojo-cream))] p-3">
            <p className="whitespace-pre-line text-sm font-medium leading-relaxed text-foreground">
              {business.menu_text}
            </p>
          </div>
        )}

        <Button
          onClick={() => onSelect(business)}
          className="w-full text-white font-semibold hover:opacity-90 transition-opacity"
          style={{ background: 'var(--gradient-antojo)' }}
        >
          <ShoppingBag className="h-4 w-4 mr-2" />
          Hacer Pedido
        </Button>
      </CardContent>
    </Card>
  );
};
