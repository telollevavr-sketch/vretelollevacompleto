import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Camera, Send, MapPin, Store } from 'lucide-react';
import { AntojoBusiness } from '@/hooks/useAntojoBusinesses';
import { useAntojoOrders } from '@/hooks/useAntojoOrders';
import { useAuth } from '@/contexts/AuthContext';
import { LocationPicker } from '@/components/shared/LocationPicker';
import { toast } from '@/hooks/use-toast';
import { compressImage, formatFileSize } from '@/lib/imageCompression';
import { locationService } from '@/services/locationService';
import { openExternalUrl } from '@/lib/deviceUtils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface AntojoOrderFormProps {
  business?: AntojoBusiness | null;
  isCustomBusiness?: boolean;
  onBack: () => void;
  onSuccess: () => void;
}

export const AntojoOrderForm = ({ business, isCustomBusiness, onBack, onSuccess }: AntojoOrderFormProps) => {
  const { user, profile } = useAuth();
  const { createOrder } = useAntojoOrders(user?.id, 'client');
  const [orderDescription, setOrderDescription] = useState('');
  const [orderImage, setOrderImage] = useState<string | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState({ lat: 20.0796, lng: -99.6538 });
  const [customBusinessName, setCustomBusinessName] = useState('');
  const [customBusinessDesc, setCustomBusinessDesc] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<string>('cash');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const bLat = business?.latitude || 0;
  const bLng = business?.longitude || 0;
  const distanceKm = !isCustomBusiness
    ? locationService.calculateDistance(
        { lat: bLat, lng: bLng },
        { lat: deliveryLocation.lat, lng: deliveryLocation.lng }
      )
    : 0;
  const deliveryFee = !isCustomBusiness
    ? locationService.calculateAntojoDeliveryFee(distanceKm)
    : 0;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: 'Imagen demasiado grande', description: 'El archivo no debe superar 10MB', variant: 'destructive' });
      e.target.value = '';
      return;
    }
    try {
      const compressed = await compressImage(file, { maxWidth: 480, maxHeight: 480, maxSizeKB: 60, initialQuality: 0.5, minQuality: 0.2 });
      setOrderImage(compressed.base64);
      toast({
        title: 'Imagen optimizada',
        description: `${formatFileSize(compressed.originalSize)} → ${formatFileSize(compressed.compressedSize)}`,
      });
    } catch {
      toast({ title: 'Error al comprimir imagen', description: 'No se pudo optimizar la imagen', variant: 'destructive' });
    } finally {
      e.target.value = '';
    }
  };

  const handleSubmitClick = () => {
    if (!user) return;
    if (!orderDescription && !orderImage) {
      toast({ title: 'Escribe tu pedido', description: 'Describe lo que quieres o sube una foto de tu nota', variant: 'destructive' });
      return;
    }
    if (!deliveryAddress) {
      toast({ title: 'Falta dirección', description: 'Selecciona tu ubicación de entrega', variant: 'destructive' });
      return;
    }
    if (isCustomBusiness && !customBusinessName) {
      toast({ title: 'Nombre del negocio requerido', variant: 'destructive' });
      return;
    }

    if (isCustomBusiness) {
      setShowConfirmModal(true);
    } else {
      executeSubmit();
    }
  };

  const executeSubmit = async () => {
    if (!user) return;
    setIsSubmitting(true);
    try {
      const orderNumber = `ANT-${Date.now().toString(36).toUpperCase()}`;
      const businessName = isCustomBusiness ? customBusinessName : (business?.name || 'Sin nombre');
      const paymentLabel = paymentMethod === 'cash' ? 'Efectivo' : 'Transferencia';

      createOrder({
        order_number: orderNumber,
        client_id: user.id,
        antojo_business_id: isCustomBusiness ? null : (business?.id || null),
        custom_business_name: isCustomBusiness ? customBusinessName : null,
        custom_business_description: isCustomBusiness ? (customBusinessDesc || null) : null,
        order_description: orderDescription || null,
        order_image: orderImage || null,
        delivery_address: deliveryAddress,
        delivery_latitude: deliveryLocation.lat,
        delivery_longitude: deliveryLocation.lng,
        business_latitude: bLat,
        business_longitude: bLng,
        delivery_fee: isCustomBusiness ? 0 : Math.round(deliveryFee * 100) / 100,
        sale_total: null,
        total: null,
        status: 'pending',
        payment_method: paymentMethod as any,
        delivery_person_id: null,
        notes: notes || null,
      });

      const whatsappMessage = isCustomBusiness
        ? [
            `🛒 *Nuevo Pedido Antojo - ${orderNumber}*`,
            ``,
            `👤 *Cliente:* ${profile?.name || 'Sin nombre'}`,
            `📱 *Teléfono:* ${profile?.phone || 'No registrado'}`,
            ``,
            `🏪 *Negocio:* ${businessName}`,
            customBusinessDesc ? `📍 *Referencia:* ${customBusinessDesc}` : '',
            ``,
            `📋 *Pedido:* ${orderDescription || '(Ver imagen adjunta)'}`,
            ``,
            `🏠 *Dirección de entrega:* ${deliveryAddress}`,
            `https://maps.google.com/?q=${deliveryLocation.lat},${deliveryLocation.lng}`,
            ``,
            `💰 *Envío:* Por confirmar`,
            `💵 *Pago:* ${paymentLabel}`,
            notes ? `\n📝 *Notas:* ${notes}` : '',
          ].filter(Boolean).join('\n')
        : [
            `🛒 *Nuevo Pedido Antojo - ${orderNumber}*`,
            ``,
            `👤 *Cliente:* ${profile?.name || 'Sin nombre'}`,
            `📱 *Teléfono:* ${profile?.phone || 'No registrado'}`,
            ``,
            `🏪 *Negocio:* ${businessName}`,
            ``,
            `📋 *Pedido:* ${orderDescription || '(Ver imagen adjunta)'}`,
            ``,
            `📍 *Ubicación del negocio:*`,
            `https://maps.google.com/?q=${bLat},${bLng}`,
            ``,
            `🏠 *Dirección de entrega:* ${deliveryAddress}`,
            `https://maps.google.com/?q=${deliveryLocation.lat},${deliveryLocation.lng}`,
            ``,
            `💰 *Envío:* $${deliveryFee.toFixed(2)}`,
            `💵 *Pago:* ${paymentLabel}`,
            notes ? `\n📝 *Notas:* ${notes}` : '',
          ].filter(Boolean).join('\n');

      openExternalUrl(`https://wa.me/525548957140?text=${encodeURIComponent(whatsappMessage)}`);

      onSuccess();
    } catch {
      toast({ title: 'Error', description: 'No se pudo enviar el pedido', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const title = isCustomBusiness
    ? 'Pedido a negocio personalizado'
    : `Pedido a: ${business?.name}`;

  const subtitle = isCustomBusiness
    ? 'Indica el nombre del negocio'
    : business?.address;

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <Button
        variant="outline"
        onClick={onBack}
        className="border-[hsl(var(--antojo-terracotta)/0.3)] text-[hsl(var(--antojo-terracotta))] hover:bg-[hsl(var(--antojo-cream))]"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Volver
      </Button>

      <Card className="border-[hsl(var(--antojo-gold)/0.25)] bg-card shadow-sm">
        <CardHeader className="border-b border-[hsl(var(--antojo-gold)/0.15)]">
          <CardTitle className="flex items-center gap-2 text-card-foreground">
            {isCustomBusiness
              ? <Store className="h-5 w-5 text-[hsl(var(--antojo-terracotta))]" />
              : <MapPin className="h-5 w-5 text-[hsl(var(--antojo-green))]" />}
            {title}
          </CardTitle>
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        </CardHeader>
        <CardContent className="space-y-5 pt-5">
          {/* Custom business fields */}
          {isCustomBusiness && (
            <>
              <div className="space-y-2">
                <Label className="text-foreground font-semibold">🏪 Nombre del negocio *</Label>
                <Input
                  placeholder="Ej: Tacos Don Pepe"
                  value={customBusinessName}
                  onChange={(e) => setCustomBusinessName(e.target.value)}
                  className="border-[hsl(var(--antojo-gold)/0.3)] bg-background text-foreground placeholder:text-muted-foreground focus-visible:ring-[hsl(var(--antojo-terracotta))]"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-foreground font-semibold">📍 Descripción o referencia del negocio</Label>
                <Input
                  placeholder="Ej: Está en la esquina del mercado municipal"
                  value={customBusinessDesc}
                  onChange={(e) => setCustomBusinessDesc(e.target.value)}
                  className="border-[hsl(var(--antojo-gold)/0.3)] bg-background text-foreground placeholder:text-muted-foreground focus-visible:ring-[hsl(var(--antojo-terracotta))]"
                />
              </div>
            </>
          )}

          {/* Order description */}
          <div className="space-y-2">
            <Label className="text-foreground font-semibold">📋 ¿Qué deseas pedir?</Label>
            <Textarea
              placeholder="Escribe aquí tu pedido detallado... (ejemplo: 2 tacos de bistec, 1 quesadilla de queso, 1 refresco)"
              value={orderDescription}
              onChange={(e) => setOrderDescription(e.target.value)}
              className="min-h-[120px] border-[hsl(var(--antojo-gold)/0.3)] bg-background text-foreground placeholder:text-muted-foreground focus-visible:ring-[hsl(var(--antojo-terracotta))]"
            />
          </div>

          {/* Image upload */}
          <div className="space-y-2">
            <Label className="text-foreground font-semibold">📷 O sube una foto de tu nota de compra</Label>
            <div className="flex items-center gap-3">
              <label className="flex-1 cursor-pointer">
                <div className="flex items-center justify-center gap-2 rounded-lg border-2 border-dashed border-[hsl(var(--antojo-terracotta)/0.3)] bg-[hsl(var(--antojo-cream)/0.5)] p-4 transition-colors hover:border-[hsl(var(--antojo-terracotta)/0.6)] hover:bg-[hsl(var(--antojo-cream))]">
                  <Camera className="h-5 w-5 text-[hsl(var(--antojo-terracotta))]" />
                  <span className="text-sm text-muted-foreground">
                    {orderImage ? '✅ Imagen cargada' : 'Tomar foto o seleccionar imagen'}
                  </span>
                </div>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
              {orderImage && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setOrderImage(null)}
                  className="border-destructive/30 text-destructive hover:bg-destructive/10"
                >
                  Quitar
                </Button>
              )}
            </div>
            {orderImage && (
              <img src={orderImage} alt="Nota de compra" className="w-full max-h-48 object-contain rounded-lg border border-[hsl(var(--antojo-gold)/0.2)]" />
            )}
          </div>

          {/* Delivery location */}
          <div className="space-y-2">
            <Label className="text-foreground font-semibold">🏠 Dirección de entrega</Label>
            <LocationPicker
              location={deliveryLocation}
              onLocationChange={setDeliveryLocation}
              onAddressChange={setDeliveryAddress}
            />
          </div>

          {/* Delivery fee info */}
          {!isCustomBusiness && (
            <div className="space-y-1 rounded-lg border border-[hsl(var(--antojo-green)/0.3)] bg-[hsl(var(--antojo-green)/0.08)] p-3">
              <div className="flex justify-between text-sm text-foreground">
                <span>📏 Distancia estimada:</span>
                <span className="font-medium">{distanceKm.toFixed(1)} km</span>
              </div>
              <div className="flex justify-between text-base font-bold text-[hsl(var(--antojo-green))]">
                <span>🚴 Costo de envío:</span>
                <span>${deliveryFee.toFixed(2)}</span>
              </div>
              <p className="text-xs text-muted-foreground">El total de la compra será establecido por el repartidor al recoger tu pedido</p>
            </div>
          )}

          {/* Payment method */}
          <div className="space-y-2">
            <Label className="text-foreground font-semibold">💰 Método de pago</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger className="border-[hsl(var(--antojo-gold)/0.3)] bg-background text-foreground focus:ring-[hsl(var(--antojo-terracotta))]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">💵 Efectivo</SelectItem>
                <SelectItem value="transfer">💳 Transferencia</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label className="text-foreground font-semibold">📝 Notas adicionales (opcional)</Label>
            <Textarea
              placeholder="Instrucciones especiales..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="min-h-[60px] border-[hsl(var(--antojo-gold)/0.3)] bg-background text-foreground placeholder:text-muted-foreground focus-visible:ring-[hsl(var(--antojo-terracotta))]"
            />
          </div>

          <Button
            onClick={handleSubmitClick}
            disabled={isSubmitting || (!orderDescription && !orderImage)}
            className="w-full text-white font-bold text-base hover:opacity-90 transition-opacity disabled:opacity-50"
            size="lg"
            style={{ background: 'var(--gradient-antojo-green)' }}
          >
            <Send className="h-4 w-4 mr-2" />
            {isSubmitting ? 'Enviando...' : '🌮 Enviar Pedido'}
          </Button>
        </CardContent>
      </Card>

      {/* Modal de confirmación */}
      <AlertDialog open={showConfirmModal} onOpenChange={setShowConfirmModal}>
        <AlertDialogContent className="z-[9999] border-[hsl(var(--antojo-gold)/0.3)]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">🌮 Confirmación de envío</AlertDialogTitle>
            <AlertDialogDescription>
              El costo de envío será confirmado por nuestro equipo una vez verificada la ubicación del negocio. Te contactaremos por WhatsApp para confirmarte el monto.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={executeSubmit}
              className="text-white font-semibold"
              style={{ background: 'var(--gradient-antojo-green)' }}
            >
              Aceptar y Enviar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
