import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Order } from '@/types';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { StatCard } from '@/components/shared/StatCard';
import { DollarSign, Package, Star, TrendingUp } from 'lucide-react';
import { useBusinesses } from '@/hooks/useBusinesses';

interface ClientStatsProps {
  orders: Order[];
  userId: string;
}

export const ClientStats = ({ orders, userId }: ClientStatsProps) => {
  const { businesses } = useBusinesses();
  
  // Filter user orders
  const myOrders = orders.filter(o => o.clientId === userId);
  const completedOrders = myOrders.filter(o => o.status === 'DELIVERED');
  
  // Calculate metrics
  const totalSpent = completedOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
  const totalOrders = completedOrders.length;
  const avgOrderValue = totalOrders > 0 ? totalSpent / totalOrders : 0;

  // Calculate average rating given
  const ordersWithRating = myOrders.filter(o => o.rating && o.rating.businessRating > 0);
  const avgRatingGiven = ordersWithRating.length > 0 
    ? ordersWithRating.reduce((sum, o) => sum + (o.rating?.businessRating || 0), 0) / ordersWithRating.length 
    : 0;

  // Spending by month (last 6 months)
  const monthlySpending = Array.from({ length: 6 }, (_, i) => {
    const date = new Date();
    date.setMonth(date.getMonth() - (5 - i));
    const monthOrders = completedOrders.filter(o => {
      const orderDate = new Date(o.createdAt);
      return orderDate.getMonth() === date.getMonth() && orderDate.getFullYear() === date.getFullYear();
    });
    const spending = monthOrders.reduce((sum, o) => sum + (o.totalAmount || o.total || 0), 0);
    return {
      mes: date.toLocaleDateString('es-MX', { month: 'short' }),
      gasto: parseFloat(spending.toFixed(2)),
      pedidos: monthOrders.length
    };
  });

  // Favorite restaurants
  const restaurantOrders = new Map<string, { name: string; orders: number; spent: number }>();
  completedOrders.forEach(order => {
    const business = businesses.find(b => b.id === order.businessId);
    if (business) {
      const existing = restaurantOrders.get(order.businessId) || { 
        name: business.name, 
        orders: 0, 
        spent: 0 
      };
      restaurantOrders.set(order.businessId, {
        name: business.name,
        orders: existing.orders + 1,
        spent: existing.spent + (order.totalAmount || order.total || 0)
      });
    }
  });

  const favoriteRestaurants = Array.from(restaurantOrders.values())
    .sort((a, b) => b.orders - a.orders)
    .slice(0, 5)
    .map(r => ({
      name: r.name.length > 20 ? r.name.substring(0, 20) + '...' : r.name,
      pedidos: r.orders,
      gasto: parseFloat(r.spent.toFixed(2))
    }));

  // Top products
  const productOrders = new Map<string, { name: string; count: number }>();
  completedOrders.forEach(order => {
    order.items.forEach(item => {
      const existing = productOrders.get(item.product.id) || { 
        name: item.product.name, 
        count: 0 
      };
      productOrders.set(item.product.id, {
        name: item.product.name,
        count: existing.count + item.quantity
      });
    });
  });

  const topProducts = Array.from(productOrders.values())
    .sort((a, b) => b.count - a.count)
    .slice(0, 5)
    .map((p, index) => ({
      name: p.name.length > 25 ? p.name.substring(0, 25) + '...' : p.name,
      cantidad: p.count,
      color: ['hsl(var(--icon-green))', 'hsl(var(--icon-blue))', 'hsl(var(--icon-orange))', 'hsl(var(--icon-purple))', 'hsl(var(--icon-cyan))'][index]
    }));

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Gasto Total"
          value={`$${totalSpent.toFixed(2)}`}
          icon={DollarSign}
          description="En la plataforma"
          variant="green"
        />
        <StatCard
          title="Pedidos Totales"
          value={totalOrders}
          icon={Package}
          description="Completados"
          variant="blue"
        />
        <StatCard
          title="Ticket Promedio"
          value={`$${avgOrderValue.toFixed(2)}`}
          icon={TrendingUp}
          description="Por pedido"
          variant="orange"
        />
        <StatCard
          title="Rating Promedio"
          value={avgRatingGiven > 0 ? avgRatingGiven.toFixed(1) : 'N/A'}
          icon={Star}
          description={`${ordersWithRating.length} calificaciones`}
          variant="purple"
        />
      </div>

      {/* Monthly Spending */}
      <Card className="border-gray-200 bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900">
            📊 Historial de Gastos (Últimos 6 meses)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlySpending}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="mes" stroke="hsl(var(--muted-foreground))" />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar 
                dataKey="gasto" 
                fill="hsl(var(--icon-green))" 
                radius={[8, 8, 0, 0]}
                name="Gasto ($)"
              />
              <Bar 
                dataKey="pedidos" 
                fill="hsl(var(--icon-blue))" 
                radius={[8, 8, 0, 0]}
                name="Pedidos (#)"
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Favorite Restaurants */}
        {favoriteRestaurants.length > 0 && (
          <Card className="border-gray-200 bg-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                ❤️ Restaurantes Favoritos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={favoriteRestaurants} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    stroke="hsl(var(--muted-foreground))"
                    width={150}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Bar 
                    dataKey="pedidos" 
                    fill="hsl(var(--icon-cyan))" 
                    radius={[0, 8, 8, 0]}
                    name="Pedidos"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Top Products */}
        {topProducts.length > 0 && (
          <Card className="border-gray-200 bg-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                🍕 Productos Más Pedidos
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={topProducts}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="cantidad"
                  >
                    {topProducts.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};
