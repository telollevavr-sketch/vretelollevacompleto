import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useProductComplements } from '@/hooks/useProductComplements';
import { LoadingSpinner } from '@/components/shared/LoadingSpinner';

const COMPLEMENT_CATEGORIES = [
  { value: 'QUESO', label: 'Quesos', icon: '🧀' },
  { value: 'SALSA', label: 'Salsas', icon: '🌶️' },
  { value: 'EXTRA', label: 'Extras', icon: '🍟' },
  { value: 'BEBIDA', label: 'Bebidas', icon: '🥤' },
  { value: 'OTRO', label: 'Otros', icon: '➕' },
];

interface SelectedComplement {
  complementId: string;
  complementName: string;
  complementPrice: number;
  complementCategory: string;
}

interface ComplementsSelectorProps {
  productId: string;
  selectedComplements: SelectedComplement[];
  onComplementToggle: (complement: SelectedComplement) => void;
}

export function ComplementsSelector({
  productId,
  selectedComplements,
  onComplementToggle,
}: ComplementsSelectorProps) {
  const { complements, isLoading } = useProductComplements(productId);

  if (isLoading) {
    return <LoadingSpinner />;
  }

  const availableComplements = complements.filter(c => c.isAvailable);

  if (availableComplements.length === 0) {
    return null;
  }

  const groupedComplements = COMPLEMENT_CATEGORIES.reduce((acc, cat) => {
    acc[cat.value] = availableComplements.filter(comp => {
      // Normalizar categorías: convertir a mayúsculas y eliminar "S" final para aceptar singular/plural
      const normalizedCategory = comp.category.toUpperCase().replace(/S$/, '');
      const normalizedExpected = cat.value.replace(/S$/, '');
      return normalizedCategory === normalizedExpected;
    });
    return acc;
  }, {} as Record<string, typeof availableComplements>);

  const hasAnyComplements = Object.values(groupedComplements).some(arr => arr.length > 0);

  if (!hasAnyComplements) {
    return null;
  }

  return (
    <div className="mt-4 border-t pt-4">
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="complements" className="border-none">
          <AccordionTrigger className="text-sm font-semibold hover:no-underline">
            ➕ Agregar Complementos
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              {COMPLEMENT_CATEGORIES.map((category) => {
                const categoryComplements = groupedComplements[category.value];
                if (!categoryComplements || categoryComplements.length === 0) return null;

                return (
                  <div key={category.value}>
                    <h4 className="text-sm font-semibold mb-2 flex items-center gap-1">
                      <span>{category.icon}</span>
                      <span>{category.label}</span>
                    </h4>
                    <div className="space-y-2">
                      {categoryComplements.map((complement) => {
                        const isSelected = selectedComplements.some(
                          sc => sc.complementId === complement.id
                        );

                        return (
                          <div
                            key={complement.id}
                            className="flex items-center space-x-2 p-2 hover:bg-accent/50 rounded transition-colors"
                          >
                            <Checkbox
                              id={`complement-${complement.id}`}
                              checked={isSelected}
                              onCheckedChange={() =>
                                onComplementToggle({
                                  complementId: complement.id,
                                  complementName: complement.name,
                                  complementPrice: complement.price,
                                  complementCategory: complement.category,
                                })
                              }
                            />
                            <Label
                              htmlFor={`complement-${complement.id}`}
                              className="flex-1 cursor-pointer text-sm"
                            >
                              <span>{complement.name}</span>
                              <span className="ml-2 text-muted-foreground">
                                {complement.price > 0 ? `(+$${complement.price})` : '(Gratis)'}
                              </span>
                            </Label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
