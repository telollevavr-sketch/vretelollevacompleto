import { useState } from 'react';
import { Order, OrderStatus } from '@/types';
import { useOrders } from '@/hooks/useOrders';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { MapPin, Clock, DollarSign, Star } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import { RatingModal } from './RatingModal';
import { OrderItemDetails } from '@/components/shared/OrderItemDetails';

interface OrderHistoryProps {
  userId: string;
  onTrackOrder: (orderId: string) => void;
}

export const OrderHistory = ({ userId, onTrackOrder }: OrderHistoryProps) => {
  const { orders } = useOrders(userId, 'client');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showRatingModal, setShowRatingModal] = useState(false);

  const getStatusBadge = (status: OrderStatus) => {
    const variants: Record<OrderStatus, any> = {
      [OrderStatus.PENDING]: { variant: "outline", label: "Pendiente" },
      [OrderStatus.IN_PREPARATION]: { variant: "default", label: "En Preparación" },
      [OrderStatus.READY_FOR_PICKUP]: { variant: "secondary", label: "Listo" },
      [OrderStatus.ON_THE_WAY]: { variant: "default", label: "En Camino" },
      [OrderStatus.DELIVERED]: { variant: "default", label: "Entregado" },
      [OrderStatus.CANCELLED]: { variant: "destructive", label: "Cancelado" }
    };

    const { variant, label } = variants[status];
    return <Badge variant={variant}>{label}</Badge>;
  };

  const handleRate = (order: Order) => {
    setSelectedOrder(order);
    setShowRatingModal(true);
  };

  const handleRatingComplete = () => {
    setShowRatingModal(false);
    setSelectedOrder(null);
  };

  if (orders.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="text-center">
          <p className="text-lg font-semibold text-muted-foreground mb-2">
            No hay pedidos
          </p>
          <p className="text-sm text-muted-foreground">
            Tus pedidos anteriores aparecerán aquí
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Historial de Pedidos</h2>

        {orders.map(order => (
          <Card key={order.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Pedido #{order.id.slice(0, 8)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(order.createdAt), {
                      addSuffix: true,
                      locale: es
                    })}
                  </p>
                </div>
                {getStatusBadge(order.status)}
              </div>
            </CardHeader>

            <CardContent className="space-y-3">
              <div>
                <p className="font-semibold mb-2">Artículos:</p>
                <div className="space-y-3">
                  {order.items.map((item, index) => (
                    <OrderItemDetails
                      key={index}
                      item={item}
                      index={index}
                      showPrice={true}
                      compact={false}
                    />
                  ))}
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span className="font-medium">${order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Costo de envío:</span>
                  <span className="font-medium">${order.deliveryFee.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    <span className="font-bold text-lg">${order.total.toFixed(2)}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {order.paymentMethod === 'CASH' ? 'Efectivo' : 'Transferencia'}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-2 text-sm">
                  <MapPin className="h-4 w-4 mt-0.5" />
                  <span className="text-muted-foreground">
                    {order.deliveryLocation.address ||
                      `${order.deliveryLocation.lat.toFixed(4)}, ${order.deliveryLocation.lng.toFixed(4)}`}
                  </span>
                </div>

                {order.preparationTime && (
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4" />
                    <span className="text-muted-foreground">
                      Tiempo de preparación: {order.preparationTime} minutos
                    </span>
                  </div>
                )}

                {order.notes && (
                  <div className="flex items-start gap-2 text-sm p-3 bg-yellow-100 dark:bg-yellow-900/20 border border-yellow-300 dark:border-yellow-700 rounded-lg">
                    <span className="font-semibold text-yellow-800 dark:text-yellow-400">Notas especiales:</span>
                    <span className="text-yellow-900 dark:text-yellow-300 flex-1">{order.notes}</span>
                  </div>
                )}
              </div>

              <Separator />

              <div className="flex gap-2">
                {[OrderStatus.IN_PREPARATION, OrderStatus.READY_FOR_PICKUP, OrderStatus.ON_THE_WAY].includes(order.status) && (
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => onTrackOrder(order.id)}
                  >
                    Rastrear Pedido
                  </Button>
                )}

                {order.status === OrderStatus.DELIVERED && !order.isRated && (
                  <Button
                    className="flex-1"
                    onClick={() => handleRate(order)}
                  >
                    <Star className="h-4 w-4 mr-2" />
                    Calificar
                  </Button>
                )}

                {order.isRated && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Star className="h-4 w-4 fill-primary text-primary" />
                    <span>Calificado</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedOrder && (
        <RatingModal
          open={showRatingModal}
          onClose={() => setShowRatingModal(false)}
          order={selectedOrder}
          onComplete={handleRatingComplete}
        />
      )}
    </>
  );
};
