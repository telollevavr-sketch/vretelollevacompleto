import { useState, useEffect } from "react";
import { CartItem, PaymentMethod, OrderStatus, Business } from "@/types";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Minus, Plus, Trash2, MapPin, AlertTriangle, Navigation, Loader2 } from "lucide-react";
import { useOrders } from "@/hooks/useOrders";
import { useNotifications } from "@/hooks/useNotifications";
import { useBusinesses } from "@/hooks/useBusinesses";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { LocationPicker } from "@/components/shared/LocationPicker";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Phone } from "lucide-react";
import { PromotionalComboSelector } from "./PromotionalComboSelector";
import { SpecialtySelector } from "./SpecialtySelector";
import { ComplementsSelector } from "./ComplementsSelector";
import { supabase } from "@/integrations/supabase/client";
import { locationService } from "@/services/locationService";
import { openExternalUrl } from "@/lib/deviceUtils";

interface ShoppingCartProps {
  open: boolean;
  onClose: () => void;
  items: CartItem[];
  businessId: string;
  onUpdateCart: (items: CartItem[]) => void;
}

export const ShoppingCart = ({ open, onClose, items, businessId, onUpdateCart }: ShoppingCartProps) => {
  const [deliveryLocation, setDeliveryLocation] = useState({ lat: 19.952444, lng: -99.545139 });
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.CASH);
  const [notes, setNotes] = useState("");
  const [showOutOfRangeWarning, setShowOutOfRangeWarning] = useState(false);
  const [calculatedDistance, setCalculatedDistance] = useState<number>(0);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [gpsError, setGpsError] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);

  const { createOrder } = useOrders();
  const { businesses } = useBusinesses();
  const { user } = useAuth();

  const business = businesses.find((b) => b.id === businessId);
  const maxDeliveryDistance = business?.deliveryRadius || 0;

  // Calcular distancia cuando cambia la ubicación o el negocio
  useEffect(() => {
    if (business?.location && deliveryLocation) {
      const distance = locationService.calculateDistance(business.location, deliveryLocation);
      setCalculatedDistance(distance);
    }
  }, [business?.location, deliveryLocation]);

  // Mostrar modal de ubicación al abrir el carrito con productos
  useEffect(() => {
    if (open && items.length > 0) {
      setShowLocationModal(true);
      setGpsError(false);
    }
  }, [open]);

  // Handler para solicitar GPS
  const handleRequestGPS = () => {
    if (!navigator.geolocation) {
      setGpsError(true);
      setShowLocationModal(false);
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const newLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setDeliveryLocation(newLocation);
        checkDeliveryCoverage(newLocation);
        setGpsError(false);
        setGpsLoading(false);
        setShowLocationModal(false);
        toast({
          title: "Ubicación obtenida",
          description: "Tu ubicación GPS ha sido establecida correctamente",
        });
      },
      (error) => {
        console.error("GPS error:", error);
        setGpsError(true);
        setGpsLoading(false);
        setShowLocationModal(false);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  // Verificar cobertura de entrega
  const checkDeliveryCoverage = (newLocation: { lat: number; lng: number }): boolean => {
    if (!business?.location || !maxDeliveryDistance) return true;

    const distance = locationService.calculateDistance(business.location, newLocation);
    setCalculatedDistance(distance);

    if (distance > maxDeliveryDistance) {
      setShowOutOfRangeWarning(true);
      return false;
    }
    return true;
  };

  // Handler para cambio de ubicación con validación
  const handleLocationChange = (newLocation: { lat: number; lng: number }) => {
    setDeliveryLocation(newLocation);
    checkDeliveryCoverage(newLocation);
  };

  const isOutOfRange = maxDeliveryDistance > 0 && calculatedDistance > maxDeliveryDistance;

  // Actualizar subtotales individuales de cada item
  const updatedItems = items.map((item) => {
    let productTotal: number;

    // Si es un combo con precio calculado (2x1, 3x2, etc.), calcular según pricedItemsCount
    if (item.product.isPricedCombo && item.comboSelections && item.comboSelections.length > 0) {
      // pricedItemsCount indica cuántos items cobrar: 1=2x1, 2=3x2, 3=4x3, etc.
      const pricedCount = item.product.pricedItemsCount || 1;
      let totalPrice = 0;

      for (let unitIdx = 0; unitIdx < item.quantity; unitIdx++) {
        const unitSelections = item.comboSelections.filter((sel) => sel.unitIndex === unitIdx);
        const unitPrices = unitSelections.map((sel) => sel.specialtyPrice || 0);
        // Ordenar precios de mayor a menor y tomar los primeros N
        const sortedPrices = [...unitPrices].sort((a, b) => b - a);
        const pricesToCharge = sortedPrices.slice(0, pricedCount);
        const unitTotal = pricesToCharge.reduce((sum, p) => sum + p, 0);
        totalPrice += unitTotal;
      }
      productTotal = totalPrice;
    } else {
      productTotal = item.product.price * item.quantity;
    }

    const complementsTotal = (item.selectedComplements || []).reduce(
      (compSum, comp) => compSum + comp.complementPrice * item.quantity,
      0,
    );
    return {
      ...item,
      subtotal: productTotal + complementsTotal,
    };
  });

  const subtotal = updatedItems.reduce((sum, item) => sum + item.subtotal, 0);

  // Calcular delivery fee basado en distancia (gratis si el negocio tiene freeDelivery)
  let deliveryFee = 0;
  const hasFreeDelivery = business?.freeDelivery === true;
  if (!hasFreeDelivery && business?.location && deliveryLocation) {
    const distance = locationService.calculateDistance(business.location, deliveryLocation);
    deliveryFee = locationService.calculateDeliveryFeeByDistance(distance);
  }

  const total = subtotal + deliveryFee;

  const handleQuantityChange = (index: number, delta: number) => {
    const newItems = [...items];
    const newQuantity = Math.max(1, newItems[index].quantity + delta);

    // Si hay comboSelections, filtrar las que excedan la nueva cantidad
    if (newItems[index].comboSelections && newQuantity < newItems[index].quantity) {
      newItems[index].comboSelections = newItems[index].comboSelections!.filter((sel) => sel.unitIndex < newQuantity);
    }

    newItems[index].quantity = newQuantity;
    onUpdateCart(newItems);
  };

  const handleRemoveItem = (index: number) => {
    const newItems = items.filter((_, i) => i !== index);
    onUpdateCart(newItems);
  };

  const handleToggleComplement = (
    itemIndex: number,
    complement: {
      complementId: string;
      complementName: string;
      complementPrice: number;
      complementCategory: string;
    },
  ) => {
    const newItems = [...items];
    const item = newItems[itemIndex];

    if (!item.selectedComplements) {
      item.selectedComplements = [];
    }

    const existingIndex = item.selectedComplements.findIndex((c) => c.complementId === complement.complementId);

    if (existingIndex >= 0) {
      item.selectedComplements.splice(existingIndex, 1);
    } else {
      item.selectedComplements.push(complement);
    }

    onUpdateCart(newItems);
  };

  const handleSelectSpecialty = async (
    itemIndex: number,
    unitIndex: number,
    pizzaIndex: number,
    specialtyId: string,
    specialtyName: string,
    specialtyPrice?: number,
  ) => {
    const newItems = [...items];
    const item = newItems[itemIndex];

    if (!item.comboSelections) {
      item.comboSelections = [];
    }

    // Obtener los ingredientes y precio de la especialidad seleccionada
    const { data: specialty } = await supabase
      .from("pizza_specialties")
      .select("description, price")
      .eq("id", specialtyId)
      .single();

    // Usar el precio pasado o el de la base de datos
    const finalPrice = specialtyPrice ?? (specialty?.price ? Number(specialty.price) : 0);

    // Buscar si ya existe una selección para este unitIndex + pizzaIndex
    const existingIndex = item.comboSelections.findIndex(
      (sel) => sel.unitIndex === unitIndex && sel.pizzaIndex === pizzaIndex,
    );

    const config = item.product.comboConfiguration;
    const itemsArray = (config?.items || config?.pizzas || []) as Array<{
      size: string;
      label: string;
      itemType?: string;
    }>;
    const comboItem = itemsArray[pizzaIndex];
    const pizzaSize = comboItem?.size || "";
    const itemType = comboItem?.itemType || config?.itemType || "pizza";
    const itemLabel = comboItem?.label || `Producto ${pizzaIndex + 1}`;

    const selection = {
      unitIndex,
      pizzaIndex,
      specialtyId,
      specialtyName,
      specialtyPrice: finalPrice,
      size: pizzaSize,
      specialtyIngredients: specialty?.description || undefined,
      itemType,
      itemLabel,
    };

    if (existingIndex >= 0) {
      // Actualizar selección existente
      item.comboSelections[existingIndex] = selection;
    } else {
      // Agregar nueva selección
      item.comboSelections.push(selection);
    }

    onUpdateCart(newItems);
  };

  const handleSelectSingleSpecialty = async (
    itemIndex: number,
    specialtyId: string,
    specialtyName: string,
    ingredients?: string,
  ) => {
    const newItems = [...items];
    const item = newItems[itemIndex];

    item.specialtySelection = {
      specialtyId,
      specialtyName,
      specialtyIngredients: ingredients,
    };

    onUpdateCart(newItems);
  };

  const handlePlaceOrder = async () => {
    if (items.length === 0 || !user || !business) {
      toast({
        title: "Error",
        description: "Tu carrito está vacío",
        variant: "destructive",
      });
      return;
    }

    if (!deliveryAddress) {
      toast({
        title: "Error",
        description: "Por favor selecciona una ubicación de entrega",
        variant: "destructive",
      });
      return;
    }

    // Validar cobertura de entrega
    if (isOutOfRange) {
      setShowOutOfRangeWarning(true);
      return;
    }

    // Validar que todos los combos promocionales tengan especialidades seleccionadas
    const hasIncompleteCombo = items.some((item) => {
      if (item.product.isPromotionalCombo && item.product.comboConfiguration) {
        const config = item.product.comboConfiguration;
        const itemsArray = config.items || config.pizzas || [];
        const selectionsPerUnit = itemsArray.length;
        const requiredTotal = selectionsPerUnit * item.quantity;
        const currentSelections = item.comboSelections?.length || 0;
        return currentSelections < requiredTotal;
      }
      return false;
    });

    if (hasIncompleteCombo) {
      toast({
        title: "Error",
        description: "Por favor selecciona todas las especialidades de tus promociones",
        variant: "destructive",
      });
      return;
    }

    // Validar que todos los productos de especialidad tengan especialidad seleccionada
    const hasIncompleteSpecialty = items.some((item) => {
      if (item.product.isSpecialty) {
        return !item.specialtySelection;
      }
      return false;
    });

    if (hasIncompleteSpecialty) {
      toast({
        title: "Error",
        description: "Por favor selecciona la especialidad de todos tus productos",
        variant: "destructive",
      });
      return;
    }

    try {
      // Generar mensaje de WhatsApp con ingredientes de especialidades
      const itemsList = updatedItems
        .map((item) => {
          const itemPrice = item.product.price * item.quantity;
          const complementsTotal = (item.selectedComplements || []).reduce(
            (sum, comp) => sum + comp.complementPrice * item.quantity,
            0,
          );

          let itemText = `${item.quantity}x ${item.product.name} - $${itemPrice.toFixed(2)}`;

          // Agregar especialidades CON ingredientes si es un combo promocional
          if (item.product.isPromotionalCombo && item.comboSelections && item.comboSelections.length > 0) {
            // Helper para obtener icono según tipo
            const getIcon = (type: string) => {
              const icons: { [key: string]: string } = {
                pizza: "🍕",
                torta: "🥖",
                salsa: "🧂",
                queso: "🧀",
                bebida: "🥤",
                refresco: "🥤",
                postre: "🍰",
                hamburguesa: "🍔",
                taco: "🌮",
                burrito: "🌯",
                hot: "🌭",
                hotdog: "🌭",
              };
              return icons[type?.toLowerCase()] || "🎁";
            };

            // Agrupar por unidad si hay múltiples unidades
            if (item.quantity > 1) {
              for (let unitIdx = 0; unitIdx < item.quantity; unitIdx++) {
                const unitSelections = item.comboSelections.filter((sel) => sel.unitIndex === unitIdx);
                itemText += `\n   📦 Unidad ${unitIdx + 1}:`;
                unitSelections.forEach((selection) => {
                  const icon = getIcon(selection.itemType || "pizza");
                  const label = selection.itemLabel || `Producto ${selection.pizzaIndex + 1}`;
                  itemText += `\n      ${icon} ${label}: ${selection.specialtyName}`;
                  if (selection.specialtyIngredients) {
                    itemText += ` (${selection.specialtyIngredients})`;
                  }
                });
              }
            } else {
              // Una sola unidad, mostrar sin agrupación
              item.comboSelections.forEach((selection) => {
                const icon = getIcon(selection.itemType || "pizza");
                const label = selection.itemLabel || `Producto ${selection.pizzaIndex + 1}`;
                itemText += `\n   ${icon} ${label}: ${selection.specialtyName}`;
                if (selection.specialtyIngredients) {
                  itemText += `\n      Ingredientes: ${selection.specialtyIngredients}`;
                }
              });
            }
          }

          // Agregar especialidad individual si es un producto de especialidad
          if (item.product.isSpecialty && item.specialtySelection) {
            itemText += `\n   Especialidad: ${item.specialtySelection.specialtyName}`;
            if (item.specialtySelection.specialtyIngredients) {
              itemText += `\n      Ingredientes: ${item.specialtySelection.specialtyIngredients}`;
            }
          }

          // Agregar ingredientes si es una pizza personalizada
          if (item.configuration?.ingredients && item.configuration.ingredients.length > 0) {
            itemText += `\n   Ingredientes: ${item.configuration.ingredients.join(", ")}`;
          }

          // Agregar extras
          if (item.configuration?.extraCheese) {
            itemText += "\n   + Extra queso";
          }
          if (item.configuration?.stuffedCrust) {
            itemText += "\n   + Orilla rellena de queso";
          }

          // Agregar complementos
          if (item.selectedComplements && item.selectedComplements.length > 0) {
            itemText += "\n   Complementos:";
            item.selectedComplements.forEach((comp) => {
              const compPrice = comp.complementPrice > 0 ? ` (+$${comp.complementPrice.toFixed(2)})` : " (Gratis)";
              itemText += `\n   + ${comp.complementName}${compPrice}`;
            });
            if (complementsTotal > 0) {
              itemText += `\n   Subtotal con complementos: $${item.subtotal.toFixed(2)}`;
            }
          }

          return itemText;
        })
        .join("\n\n");

      const whatsappMessage = encodeURIComponent(
        `🍕 *Nuevo Pedido - ${business.name}*\n\n` +
          `📋 *Artículos:*\n${itemsList}\n\n` +
          `💵 *Subtotal:* $${subtotal.toFixed(2)}\n` +
          `🚚 *Envío:* ${hasFreeDelivery ? "¡GRATIS!" : `$${deliveryFee.toFixed(2)}`}\n` +
          `💰 *Total:* $${total.toFixed(2)}\n\n` +
          `📍 *Dirección:* ${deliveryAddress}\n` +
          `💳 *Pago:* ${paymentMethod === PaymentMethod.CASH ? "Efectivo" : "Transferencia"}\n` +
          `${notes ? `\n📝 *Notas:* ${notes}` : ""}`,
      );

      const newOrder = await createOrder({
        order_number: `${Math.floor(Math.random() * 100000)}`,
        client_id: user.id,
        business_id: business.id,
        items: updatedItems as any,
        subtotal,
        delivery_fee: deliveryFee,
        total,
        status: "pending",
        payment_method: paymentMethod === PaymentMethod.CASH ? "cash" : "transfer",
        delivery_latitude: deliveryLocation.lat,
        delivery_longitude: deliveryLocation.lng,
        delivery_address: deliveryAddress,
        notes: notes || null,
      });

      // Abrir WhatsApp después de crear el pedido exitosamente
      // Usar openExternalUrl para compatibilidad con iOS en modo standalone
      openExternalUrl(`https://wa.me/525548957140?text=${whatsappMessage}`);

      toast({
        title: "Pedido creado",
        description: "Tu pedido ha sido enviado al negocio",
      });

      onUpdateCart([]);
      onClose();
    } catch (error) {
      console.error("Error al crear pedido:", error);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Carrito de Compras</SheetTitle>
        </SheetHeader>

        <div className="space-y-6 py-4">
          {/* Items */}
          <div className="space-y-4">
            {items.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Tu carrito está vacío</p>
            ) : (
              items.map((item, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex gap-4">
                    <img src={item.product.image} alt={item.product.name} className="w-20 h-20 object-cover rounded" />
                    <div className="flex-1">
                      <h4 className="font-semibold">{item.product.name}</h4>
                      <p className="text-sm text-muted-foreground">${item.product.price}</p>

                      {/* Show selected complements */}
                      {item.selectedComplements && item.selectedComplements.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs font-semibold text-green-600 dark:text-green-400">Complementos:</p>
                          <ul className="ml-4 space-y-1">
                            {item.selectedComplements.map((comp, idx) => (
                              <li key={idx} className="text-xs text-muted-foreground">
                                • {comp.complementName}
                                {comp.complementPrice > 0 && ` (+$${comp.complementPrice})`}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="flex items-center gap-2 mt-2">
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-8 w-8"
                          onClick={() => handleQuantityChange(index, -1)}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-8 w-8"
                          onClick={() => handleQuantityChange(index, 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 ml-auto"
                          onClick={() => handleRemoveItem(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Selector de especialidades para combos promocionales */}
                  {item.product.isPromotionalCombo && (
                    <PromotionalComboSelector
                      item={item}
                      onSelectSpecialty={(unitIndex, pizzaIndex, specialtyId, specialtyName) =>
                        handleSelectSpecialty(index, unitIndex, pizzaIndex, specialtyId, specialtyName)
                      }
                    />
                  )}

                  {/* Selector de especialidad individual */}
                  {item.product.isSpecialty && (
                    <SpecialtySelector
                      businessId={businessId}
                      selectedSpecialtyId={item.specialtySelection?.specialtyId}
                      onSpecialtySelect={(specialtyId, specialtyName, ingredients) =>
                        handleSelectSingleSpecialty(index, specialtyId, specialtyName, ingredients)
                      }
                    />
                  )}

                  {/* Selector de complementos */}
                  <ComplementsSelector
                    productId={item.product.id}
                    selectedComplements={item.selectedComplements || []}
                    onComplementToggle={(complement) => handleToggleComplement(index, complement)}
                  />
                </div>
              ))
            )}
          </div>

          {items.length > 0 && (
            <>
              {/* Location Picker */}
              <div className="space-y-2">
                {/* Alerta de GPS si falló */}
                {gpsError && (
                  <Alert variant="destructive" className="mb-2">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>⚠️ GPS no disponible.</strong> Activa tu ubicación en la configuración de tu dispositivo o selecciona tu ubicación manualmente en el mapa.
                      <Button
                        variant="link"
                        className="p-0 h-auto ml-1 text-destructive underline"
                        onClick={() => setShowLocationModal(true)}
                      >
                        Intentar de nuevo
                      </Button>
                    </AlertDescription>
                  </Alert>
                )}
                <Label className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Ubicación de Entrega <span className="text-destructive">*</span>
                </Label>
                <LocationPicker
                  location={deliveryLocation}
                  onLocationChange={handleLocationChange}
                  onAddressChange={setDeliveryAddress}
                />

                {/* Indicador visual de distancia */}
                {business?.location && calculatedDistance > 0 && (
                  <div
                    className={`p-3 rounded-lg flex items-center gap-2 ${
                      isOutOfRange
                        ? "bg-destructive/10 text-destructive border border-destructive/20"
                        : "bg-green-50 text-green-700 border border-green-200 dark:bg-green-950 dark:text-green-400 dark:border-green-800"
                    }`}
                  >
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span className="text-sm">
                      Distancia al negocio: <strong>{calculatedDistance.toFixed(1)} km</strong>
                      {isOutOfRange && <span className="ml-2">(Máximo permitido: {maxDeliveryDistance} km)</span>}
                    </span>
                  </div>
                )}

                {deliveryAddress && (
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm font-medium">Dirección de entrega:</p>
                    <p className="text-sm text-muted-foreground mt-1">{deliveryAddress}</p>
                  </div>
                )}
              </div>

              {/* Payment Method */}
              <div className="space-y-2">
                <Label>Forma de Pago</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant={paymentMethod === PaymentMethod.CASH ? "default" : "outline"}
                    onClick={() => setPaymentMethod(PaymentMethod.CASH)}
                  >
                    Efectivo
                  </Button>
                  <Button
                    variant={paymentMethod === PaymentMethod.TRANSFER ? "default" : "outline"}
                    onClick={() => setPaymentMethod(PaymentMethod.TRANSFER)}
                  >
                    Transferencia
                  </Button>
                </div>

                {/* Transfer Information Alert */}
                {paymentMethod === PaymentMethod.TRANSFER && (
                  <Alert className="bg-yellow-400 border-yellow-500 text-black">
                    <Phone className="h-4 w-4 text-black" />
                    <AlertDescription className="text-black">
                      <strong>Información importante:</strong>
                      <br />
                      Favor de llamar vía telefónica a el Negocio al tel:{" "}
                      <strong>{business?.phone || "No disponible"}</strong> para solicitar el número de cuenta para
                      transferir.
                      <br />
                      Su pedido será confirmado en cuanto se aplique el cargo.
                    </AlertDescription>
                  </Alert>
                )}
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label>Notas Especiales</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Indicar... Aclaración de ingredientes (ejem: sin cebolla, con rajas) ó indicación a repartidor (ejem: zaguán azul, en la tiendita)                    Indique aquí, si desea recoger en el Negocio"
                  rows={4}
                />
              </div>

              <Separator />

              {/* Summary */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Envío</span>
                  {hasFreeDelivery ? (
                    <span className="text-green-600 font-semibold">🎉 ¡Gratis!</span>
                  ) : (
                    <span>${deliveryFee.toFixed(2)}</span>
                  )}
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                {hasFreeDelivery ? (
                  <div className="text-xs text-center bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-400 font-medium py-2 px-3 rounded-md">
                    <p>🎉 ¡Este negocio ofrece envío GRATIS en todos los pedidos!</p>
                  </div>
                ) : (
                  <div className="text-xs text-center pt-2 bg-blue-50 text-blue-700 font-medium py-2 px-3 rounded-md">
                    <p>*Costo de envío calculado: ${deliveryFee.toFixed(2)}</p>
                    <p className="mt-1">El negocio puede ajustar o excentar esta tarifa al confirmar tu pedido.</p>
                    <p className="mt-1">
                      "Si su pedido es recogido en el negocio, al finalizar la compra se descontará el envío."
                    </p>
                  </div>
                )}

                {/* Aviso de WhatsApp con parpadeo */}
                <div className="text-sm text-center text-white font-medium py-3 px-4 rounded-md animate-blink mt-3">
                  <p>
                    Es necesario confirmar el pedido por Whatsapp, el sistema abrirá automáticamente Whatsapp, si no se
                    abre en automático, favor de enviar el mensaje "PEDIDO" al: <strong>5548957140</strong>
                  </p>
                </div>
              </div>

              {/* Place Order Button */}
              <Button onClick={handlePlaceOrder} className="w-full" size="lg">
                Realizar Pedido
              </Button>
            </>
          )}
        </div>
      </SheetContent>
      {/* Modal de Advertencia - Zona sin Cobertura */}
      <AlertDialog open={showOutOfRangeWarning} onOpenChange={setShowOutOfRangeWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-yellow-100 dark:bg-yellow-900 flex items-center justify-center">
                <AlertTriangle className="h-8 w-8 text-yellow-600 dark:text-yellow-400" />
              </div>
            </div>
            <AlertDialogTitle className="text-center text-xl">⚠️ Zona sin Cobertura</AlertDialogTitle>
            <AlertDialogDescription className="text-center space-y-2">
              <p>
                La ubicación seleccionada está a{" "}
                <strong className="text-foreground">{calculatedDistance.toFixed(1)} km</strong> del negocio.
              </p>
              <p>
                El radio de entrega máximo de <strong className="text-foreground">{business?.name}</strong> es de{" "}
                <strong className="text-foreground">{maxDeliveryDistance} km</strong>.
              </p>
              <p className="text-yellow-600 dark:text-yellow-400 font-medium mt-3">
                Por favor, selecciona una ubicación más cercana al negocio para poder realizar tu pedido.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center">
            <AlertDialogAction onClick={() => setShowOutOfRangeWarning(false)}>
              Entendido, cambiaré la ubicación
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Modal de Solicitud de Ubicación GPS */}
      <AlertDialog open={showLocationModal} onOpenChange={setShowLocationModal}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Navigation className="h-8 w-8 text-primary" />
              </div>
            </div>
            <AlertDialogTitle className="text-center text-xl">📍 Ubicación necesaria</AlertDialogTitle>
            <AlertDialogDescription className="text-center space-y-2">
              <p>
                Para calcular el <strong className="text-foreground">costo de envío</strong> necesitamos acceder a tu ubicación.
              </p>
              <p className="text-muted-foreground">
                Esto nos permite encontrar la ruta más cercana y darte un precio justo de entrega.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col gap-2 sm:flex-col">
            <Button
              onClick={handleRequestGPS}
              disabled={gpsLoading}
              className="w-full"
              size="lg"
            >
              {gpsLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Obteniendo ubicación...
                </>
              ) : (
                <>
                  <Navigation className="h-4 w-4 mr-2" />
                  Usar Mi Ubicación
                </>
              )}
            </Button>
            <AlertDialogAction
              onClick={() => setShowLocationModal(false)}
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
            >
              <MapPin className="h-4 w-4 mr-2" />
              Seleccionar manualmente en el mapa
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Sheet>
  );
};
