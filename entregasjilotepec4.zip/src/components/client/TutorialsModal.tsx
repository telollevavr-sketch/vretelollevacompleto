import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { PlayCircle, Users, Store, Bike } from "lucide-react";
import logo from "@/assets/vrtelolleva-logo.png";

interface TutorialsModalProps {
  open: boolean;
  onClose: () => void;
}

const tutorialSections = [
  {
    id: "clients",
    title: "Para los Clientes",
    icon: Users,
    videos: [
      {
        title: "Página de bienvenida",
        url: "https://www.facebook.com/share/r/1CU6d5Tuv3/",
      },
      {
        title: "Ingresar como usuario",
        url: "https://www.facebook.com/share/v/1AVCcHpHbu/",
      },
      {
        title: "Elegir productos y Realizar Pedido",
        url: "https://www.facebook.com/share/v/1Bp1WxHm7H/",
      },
      {
        title: "Raastrear envío / Calificar tu experiencia",
        url: "https://www.facebook.com/share/v/19wMQuv7FN/",
      },
    ],
  },
  {
    id: "businesses",
    title: "Para los Negocios",
    icon: Store,
    videos: [
      {
        title: "Ingreso a la plataforma",
        url: "https://www.facebook.com/share/v/1A6RdaTnUE/",
      },
      {
        title: "Barra de navegación",
        url: "https://www.facebook.com/share/v/1CopL7nLEi/",
      },
      {
        title: "Agregar productos/especialidades",
        url: "https://www.facebook.com/share/v/1GJoGgVNS2/",
      },
      {
        title: "Procesar pedidos",
        url: "https://www.facebook.com/share/v/17khLuH27e/",
      },
    ],
  },
  {
    id: "delivery",
    title: "Para los Repartidores",
    icon: Bike,
    videos: [
      {
        title: "Cómo registrarse como repartidor",
        url: "https://facebook.com/placeholder-video-9",
      },
      {
        title: "Cómo aceptar entregas",
        url: "https://facebook.com/placeholder-video-10",
      },
      {
        title: "Cómo usar el mapa de navegación",
        url: "https://facebook.com/placeholder-video-11",
      },
      {
        title: "Cómo completar entregas y recibir pagos",
        url: "https://facebook.com/placeholder-video-12",
      },
    ],
  },
];

export function TutorialsModal({ open, onClose }: TutorialsModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-[hsl(260,45%,15%)] to-[hsl(250,40%,20%)] border-[hsl(270,40%,35%)]">
        <DialogHeader>
          <div className="flex flex-col items-center gap-4 mb-2">
            <img src={logo} alt="vrtelolleva" className="h-16 w-auto" />
            <DialogTitle className="text-3xl font-bold text-white flex items-center gap-2">🎬 Tutoriales</DialogTitle>
          </div>
          <p className="text-center text-white/70 text-sm">Aprende a usar vrtelolleva con estos videos tutoriales</p>
        </DialogHeader>

        <Accordion type="single" collapsible className="w-full mt-4" defaultValue="clients">
          {tutorialSections.map((section) => {
            const IconComponent = section.icon;
            return (
              <AccordionItem
                key={section.id}
                value={section.id}
                className="border-[hsl(270,40%,35%)] mb-3 rounded-lg overflow-hidden bg-[hsl(260,35%,18%)]/60"
              >
                <AccordionTrigger className="px-4 py-3 hover:bg-[hsl(270,40%,25%)]/50 text-white hover:no-underline">
                  <div className="flex items-center gap-3">
                    <IconComponent className="h-5 w-5 text-[hsl(270,70%,60%)]" />
                    <span className="font-semibold">{section.title}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 py-3">
                  <div className="space-y-2">
                    {section.videos.map((video, index) => (
                      <a
                        key={index}
                        href={video.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 p-3 rounded-md bg-[hsl(260,35%,22%)]/60 hover:bg-[hsl(270,40%,28%)]/80 transition-all group border border-transparent hover:border-[hsl(270,70%,60%)]/30"
                      >
                        <PlayCircle className="h-5 w-5 text-[hsl(270,70%,60%)] group-hover:scale-110 transition-transform" />
                        <span className="text-white/90 group-hover:text-white text-sm">{video.title}</span>
                      </a>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>

        <div className="mt-6 text-center text-white/50 text-xs">
          ¿Necesitas más ayuda? Contáctanos en nuestras redes sociales
        </div>
      </DialogContent>
    </Dialog>
  );
}
