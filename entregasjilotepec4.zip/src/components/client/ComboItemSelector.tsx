import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { usePizzaSpecialties } from '@/hooks/usePizzaSpecialties';

interface ComboItemSelectorProps {
  businessId: string;
  comboItem: {
    label: string;
    size?: string;
    itemType?: string;
  };
  itemType: string;
  icon: string;
  isPricedCombo?: boolean; // Si true, mostrar precio de cada especialidad
  currentSelection?: {
    specialtyId: string;
    specialtyName: string;
    specialtyPrice?: number;
  };
  onSelectSpecialty: (specialtyId: string, specialtyName: string, specialtyPrice?: number) => void;
}

export const ComboItemSelector = ({
  businessId,
  comboItem,
  itemType,
  icon,
  isPricedCombo = false,
  currentSelection,
  onSelectSpecialty,
}: ComboItemSelectorProps) => {
  // Cada slot usa su propio itemType para filtrar especialidades
  const { specialties, isLoading } = usePizzaSpecialties(businessId, itemType);

  const sizeLabel = comboItem.size ? ` (${comboItem.size})` : '';

  return (
    <div className="space-y-2">
      <Label className="text-xs text-muted-foreground flex items-center gap-1">
        <span>{icon}</span>
        <span>{comboItem.label}{sizeLabel}</span>
      </Label>
      <Select
        value={currentSelection?.specialtyId || ''}
        onValueChange={(specialtyId) => {
          const specialty = specialties.find((s) => s.id === specialtyId);
          if (specialty) {
            onSelectSpecialty(specialtyId, specialty.name, specialty.price);
          }
        }}
        disabled={isLoading}
      >
        <SelectTrigger className="h-9 bg-background">
          <SelectValue placeholder={`Elige ${itemType}`} />
        </SelectTrigger>
        <SelectContent className="z-[9999] bg-background">
          {isLoading ? (
            <SelectItem value="loading" disabled>
              Cargando...
            </SelectItem>
          ) : specialties.length === 0 ? (
            <SelectItem value="empty" disabled>
              No hay {itemType}s disponibles
            </SelectItem>
          ) : (
            specialties.map((specialty) => (
              <SelectItem key={specialty.id} value={specialty.id}>
                <div className="flex flex-col py-1">
                  <span className="font-medium">
                    {specialty.name}
                    {isPricedCombo && specialty.price && specialty.price > 0 && (
                      <span className="ml-2 text-primary font-semibold">
                        ${specialty.price.toFixed(0)}
                      </span>
                    )}
                  </span>
                  {specialty.description && (
                    <span className="text-xs text-muted-foreground mt-0.5">
                      {specialty.description}
                    </span>
                  )}
                </div>
              </SelectItem>
            ))
          )}
        </SelectContent>
      </Select>
    </div>
  );
};
