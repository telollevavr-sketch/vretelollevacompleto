import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Filter, X } from 'lucide-react';

const BUSINESS_CATEGORIES = [
  { name: 'Bebidas', icon: '🥤' },
  { name: 'Comida Rápida', icon: '🍟' },
  { name: 'Desayunos', icon: '🍳' },
  { name: 'Frappés', icon: '🧋' },
  { name: 'Hamburguesas', icon: '🍔' },
  { name: 'Mexicana', icon: '🌮' },
  { name: 'Pizza', icon: '🍕' },
  { name: 'Pizzas', icon: '🍕' },
  { name: 'Plato Fuerte', icon: '🍽️' },
  { name: 'Postres', icon: '🍰' },
  { name: 'Restaurante', icon: '🍴' },
  { name: 'Snacks', icon: '🥨' },
  { name: 'Tacos', icon: '🌮' },
  { name: 'Tortería', icon: '🥖' },
];
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

interface BusinessFiltersProps {
  onFilterChange: (filters: FilterState) => void;
}

export interface FilterState {
  categories: string[];
  minRating: number;
  openOnly: boolean;
}

export const BusinessFilters = ({ onFilterChange }: BusinessFiltersProps) => {
  const [open, setOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    minRating: 0,
    openOnly: false,
  });

  const toggleCategory = (category: string) => {
    const newCategories = filters.categories.includes(category)
      ? filters.categories.filter((c) => c !== category)
      : [...filters.categories, category];
    
    const newFilters = { ...filters, categories: newCategories };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const updateFilter = (key: keyof FilterState, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const clearFilters = () => {
    const defaultFilters: FilterState = {
      categories: [],
      minRating: 0,
      openOnly: false,
    };
    setFilters(defaultFilters);
    onFilterChange(defaultFilters);
  };

  const activeFiltersCount = 
    filters.categories.length +
    (filters.openOnly ? 1 : 0) +
    (filters.minRating > 0 ? 1 : 0);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" className="relative">
          <Filter className="h-4 w-4 mr-2" />
          Filtros
          {activeFiltersCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center"
            >
              {activeFiltersCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Filtros</SheetTitle>
          <SheetDescription>
            Personaliza tu búsqueda de restaurantes
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 mt-6">
          {/* Business Types */}
          <div>
            <Label className="text-base mb-3 block">Tipos de Negocio</Label>
            <div className="flex flex-wrap gap-2">
              {BUSINESS_CATEGORIES.map((category) => (
                <Badge
                  key={category.name}
                  variant={filters.categories.includes(category.name) ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => toggleCategory(category.name)}
                >
                  {category.icon} {category.name}
                </Badge>
              ))}
            </div>
          </div>

          {/* Open Only */}
          <div className="flex items-center justify-between">
            <Label htmlFor="open-only" className="text-base">
              Solo negocios abiertos
            </Label>
            <Switch
              id="open-only"
              checked={filters.openOnly}
              onCheckedChange={(checked) => updateFilter('openOnly', checked)}
            />
          </div>

          {/* Min Rating */}
          <div>
            <Label className="text-base mb-3 block">
              Calificación mínima: {filters.minRating.toFixed(1)}
            </Label>
            <Slider
              value={[filters.minRating]}
              onValueChange={([value]) => updateFilter('minRating', value)}
              max={5}
              step={0.5}
              className="mt-2"
            />
          </div>

          {/* Clear Filters */}
          {activeFiltersCount > 0 && (
            <Button
              variant="outline"
              className="w-full"
              onClick={clearFilters}
            >
              <X className="h-4 w-4 mr-2" />
              Limpiar filtros
            </Button>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};
