import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ClientStats } from './ClientStats';
import { useOrders } from '@/hooks/useOrders';
import { Home } from 'lucide-react';

interface ClientDashboardStatsProps {
  userId: string;
  onBack: () => void;
}

export const ClientDashboardStats = ({ userId, onBack }: ClientDashboardStatsProps) => {
  const { orders } = useOrders(userId, 'client');

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="border-gray-200 bg-white p-6 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">📊 Mis Estadísticas</h2>
            <p className="text-gray-600">Resumen de tu actividad en la plataforma</p>
          </div>
          <Button variant="outline" onClick={onBack}>
            <Home className="h-4 w-4 mr-2" />
            Volver
          </Button>
        </div>
      </Card>
      
      <ClientStats orders={orders} userId={userId} />
    </div>
  );
};
