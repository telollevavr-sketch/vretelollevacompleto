import { useEffect, useState } from 'react';
import { Order, OrderStatus, Business } from '@/types';
import { useOrders } from '@/hooks/useOrders';
import { useBusinesses } from '@/hooks/useBusinesses';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { MapView } from '@/components/shared/MapView';
import { OrderMessages } from '@/components/shared/OrderMessages';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { 
  Clock, 
  MapPin, 
  Phone, 
  Store, 
  Bike,
  Package,
  CheckCircle2,
  DollarSign,
  X
} from 'lucide-react';

interface OrderTrackingProps {
  orderId: string;
  onBack: () => void;
  userId: string;
  userRole: string;
}

export const OrderTracking = ({ orderId, onBack, userId, userRole }: OrderTrackingProps) => {
  const { orders, isLoading: loadingOrders } = useOrders(userId, userRole);
  const { businesses } = useBusinesses();
  const [deliveryLocation, setDeliveryLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [showDeliveryFeeInfo, setShowDeliveryFeeInfo] = useState(() => {
    const hasSeenInfo = sessionStorage.getItem(`deliveryFeeInfo-${orderId}`);
    return !hasSeenInfo;
  });
  
  const order = orders.find(o => o.id === orderId) || null;
  const business = order ? businesses.find(b => b.id === order.businessId) || null : null;

  const handleCloseDeliveryFeeInfo = () => {
    sessionStorage.setItem(`deliveryFeeInfo-${orderId}`, 'true');
    setShowDeliveryFeeInfo(false);
  };

  // Función para obtener ubicación del repartidor bajo demanda
  const fetchDeliveryLocation = async () => {
    if (!order || !order.deliveryPersonId || order.status !== OrderStatus.ON_THE_WAY) return;
    
    try {
      console.log('📍 Obteniendo ubicación del repartidor:', order.deliveryPersonId);
      const { data, error } = await supabase
        .from('profiles')
        .select('latitude, longitude')
        .eq('id', order.deliveryPersonId)
        .single();

      if (error) {
        console.error('Error obteniendo ubicación:', error);
        return;
      }

      if (data?.latitude && data?.longitude) {
        console.log('📍 Ubicación obtenida:', data);
        setDeliveryLocation({
          lat: data.latitude,
          lng: data.longitude
        });
      }
    } catch (error) {
      console.error('Error fetching location:', error);
    }
  };

  // Cargar ubicación inicial al abrir el seguimiento
  useEffect(() => {
    if (!order || !order.deliveryPersonId || order.status !== OrderStatus.ON_THE_WAY) {
      setDeliveryLocation(null);
      return;
    }
    fetchDeliveryLocation();
  }, [order?.deliveryPersonId, order?.status]);

  // Regresar automáticamente a la pantalla inicial cuando el pedido se complete o cancele
  useEffect(() => {
    if (order && (order.status === OrderStatus.DELIVERED || order.status === OrderStatus.CANCELLED)) {
      const timer = setTimeout(() => {
        onBack();
      }, 3000); // Esperar 3 segundos para que el usuario vea el estado final

      return () => clearTimeout(timer);
    }
  }, [order?.status, onBack]);

  if (loadingOrders) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="text-white/60">Cargando pedido...</p>
        </div>
      </div>
    );
  }

  if (!order || !business) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-12 text-white/60">
          <p>No se encontró el pedido</p>
          <Button variant="outline" onClick={onBack} className="mt-4">
            Volver a Inicio
          </Button>
        </div>
      </div>
    );
  }

  const statusSteps = [
    { status: OrderStatus.PENDING, label: 'Pendiente', icon: Clock },
    { status: OrderStatus.IN_PREPARATION, label: 'En Preparación', icon: Store },
    { status: OrderStatus.READY_FOR_PICKUP, label: 'Listo', icon: Package },
    { status: OrderStatus.ON_THE_WAY, label: 'En Camino', icon: Bike },
    { status: OrderStatus.DELIVERED, label: 'Entregado', icon: CheckCircle2 }
  ];

  const currentStepIndex = statusSteps.findIndex(s => s.status === order.status);
  const progress = ((currentStepIndex + 1) / statusSteps.length) * 100;

  const getStatusColor = (status: OrderStatus) => {
    if (status === OrderStatus.CANCELLED) return 'destructive';
    return currentStepIndex >= statusSteps.findIndex(s => s.status === status) 
      ? 'default' 
      : 'secondary';
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl animate-fade-in">
      <Button variant="outline" onClick={onBack} className="mb-6 hover-scale">
        ← Volver
      </Button>

      <div className="space-y-6">
        {/* Header */}
        <Card className="border-primary/20 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">Pedido #{order.id.slice(0, 8)}</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {format(new Date(order.createdAt), "d 'de' MMMM, yyyy 'a las' HH:mm", { locale: es })}
                </p>
              </div>
              <Badge 
                variant={order.status === OrderStatus.CANCELLED ? 'destructive' : 'default'}
                className="text-sm px-3 py-1"
              >
                {order.status === OrderStatus.CANCELLED ? 'Cancelado' : 'Activo'}
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Delivery Fee Info Alert - Only shown once per session */}
        {showDeliveryFeeInfo && business && order.status !== OrderStatus.CANCELLED && order.status !== OrderStatus.DELIVERED && (
          <Alert className="border-blue-500 bg-blue-50 dark:bg-blue-950/30">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                <DollarSign className="h-5 w-5 text-blue-600 mt-0.5" />
                <div className="flex-1">
                  <AlertTitle className="text-blue-900 dark:text-blue-100">
                    Costo de Envío Autorizado
                  </AlertTitle>
                  <AlertDescription className="text-blue-700 dark:text-blue-300">
                    <p className="text-2xl font-bold mt-2">${order.deliveryFee.toFixed(2)}</p>
                    <p className="text-sm mt-1">Este es el costo de envío autorizado por el negocio</p>
                  </AlertDescription>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleCloseDeliveryFeeInfo}
                className="h-6 w-6 shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </Alert>
        )}

        {/* Progress */}
        {order.status !== OrderStatus.CANCELLED && (
          <Card className="border-primary/20 shadow-lg">
            <CardContent className="pt-6">
              <Progress value={progress} className="mb-8 h-2" />
              <div className="grid grid-cols-5 gap-2">
                {statusSteps.map((step, index) => {
                  const Icon = step.icon;
                  const isActive = index <= currentStepIndex;
                  
                  return (
                    <div key={step.status} className="text-center animate-scale-in">
                      <div className={`mx-auto w-14 h-14 rounded-full flex items-center justify-center mb-2 transition-all duration-300 ${
                        isActive 
                          ? 'bg-gradient-to-br from-primary to-primary/80 text-primary-foreground shadow-lg scale-110' 
                          : 'bg-muted'
                      }`}>
                        <Icon className="h-7 w-7" />
                      </div>
                      <p className={`text-xs ${isActive ? 'font-semibold text-primary' : 'text-muted-foreground'}`}>
                        {step.label}
                      </p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Real-time Tracking Map */}
        {order.status !== OrderStatus.CANCELLED && order.status !== OrderStatus.DELIVERED && business?.location && order.deliveryLocation && (
          <Card className="border-primary/10 shadow-lg">
            <CardHeader className="bg-gradient-to-br from-primary/5 to-transparent">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Seguimiento de Ubicación
                </CardTitle>
                {order.status === OrderStatus.ON_THE_WAY && (
                  <Button variant="outline" size="sm" onClick={fetchDeliveryLocation}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Actualizar
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              {/* Mensaje de estado del repartidor */}
              {order.status === OrderStatus.ON_THE_WAY && !deliveryLocation && (
                <div className="mb-4 p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                  <div className="flex items-start gap-3">
                    <Bike className="h-5 w-5 text-orange-600 mt-0.5 animate-pulse" />
                    <div>
                      <p className="font-medium text-sm text-orange-900 dark:text-orange-100">
                        Esperando ubicación del repartidor...
                      </p>
                      <p className="text-xs text-orange-700 dark:text-orange-300 mt-1">
                        El repartidor debe activar su ubicación para que puedas seguir tu pedido en tiempo real
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="h-[400px] rounded-lg overflow-hidden">
                <MapView
                  locations={[
                    {
                      lat: business.location.lat,
                      lng: business.location.lng,
                      name: business.name,
                      address: business.fullAddress || business.address,
                      icon: 'business'
                    },
                    {
                      lat: order.deliveryLocation.lat,
                      lng: order.deliveryLocation.lng,
                      name: 'Tu ubicación',
                      address: order.deliveryLocation.address || 'Dirección de entrega',
                      icon: 'client'
                    },
                    ...(deliveryLocation ? [{
                      lat: deliveryLocation.lat,
                      lng: deliveryLocation.lng,
                      name: 'Repartidor',
                      address: 'En camino a tu ubicación',
                      icon: 'delivery' as const
                    }] : [])
                  ]}
                  interactive={false}
                  height="400px"
                />
              </div>
              <div className={`mt-4 grid gap-3 ${deliveryLocation ? 'grid-cols-3' : 'grid-cols-2'}`}>
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 rounded-lg border border-emerald-200 dark:border-emerald-800">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-emerald-500"></div>
                    <p className="font-medium text-sm text-emerald-900 dark:text-emerald-100">Negocio</p>
                  </div>
                  <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-1">{business.name}</p>
                </div>
                {deliveryLocation ? (
                  <div className="p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded-full bg-orange-500 animate-pulse"></div>
                      <p className="font-medium text-sm text-orange-900 dark:text-orange-100">Repartidor</p>
                    </div>
                    <p className="text-xs text-orange-700 dark:text-orange-300 mt-1">En vivo</p>
                  </div>
                ) : order.status === OrderStatus.ON_THE_WAY && (
                  <div className="p-3 bg-gray-50 dark:bg-gray-950/20 rounded-lg border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded-full bg-gray-400"></div>
                      <p className="font-medium text-sm text-gray-700 dark:text-gray-300">Repartidor</p>
                    </div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Sin ubicación</p>
                  </div>
                )}
                <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-blue-500"></div>
                    <p className="font-medium text-sm text-blue-900 dark:text-blue-100">Tu ubicación</p>
                  </div>
                  <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">Destino</p>
                </div>
              </div>
              {[OrderStatus.ON_THE_WAY].includes(order.status) && (
                <div className="mt-4 p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <div className="flex items-start gap-3">
                    <Bike className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium text-sm">Tu pedido está en camino</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        El repartidor se dirige a tu ubicación
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Business Info */}
          <Card className="border-primary/10 hover:border-primary/30 transition-colors">
            <CardHeader className="bg-gradient-to-br from-primary/5 to-transparent">
              <CardTitle className="text-lg flex items-center gap-2">
                <Store className="h-5 w-5 text-primary" />
                Negocio
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center gap-3">
                <Store className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{business.name}</p>
                  <p className="text-sm text-muted-foreground">{business.category}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-muted-foreground" />
                <p className="text-sm">{business.phone}</p>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                <p className="text-sm">{business.fullAddress || business.address}</p>
              </div>
            </CardContent>
          </Card>

          {/* Delivery Info */}
          <Card className="border-primary/10 hover:border-primary/30 transition-colors">
            <CardHeader className="bg-gradient-to-br from-primary/5 to-transparent">
              <CardTitle className="text-lg flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Entrega
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Dirección</p>
                  <p className="text-sm text-muted-foreground">
                    {order.deliveryLocation.address || 'Sin dirección específica'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Tiempo estimado</p>
                  <p className="text-sm text-muted-foreground">{business.estimatedDeliveryTime || '30-40 min'}</p>
                </div>
              </div>
              {order.preparationTime && (
                <div className="flex items-center gap-3">
                  <Store className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Preparación</p>
                    <p className="text-sm text-muted-foreground">{order.preparationTime}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Order Items */}
        <Card className="border-primary/10 shadow-lg">
          <CardHeader className="bg-gradient-to-br from-primary/5 to-transparent">
            <CardTitle className="text-lg flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              Artículos del Pedido
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {order.items.map((item, index) => (
                <div key={index}>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <p className="font-medium">
                        {item.quantity}x {item.product.name}
                      </p>
                      
                      {/* Complements */}
                      {item.selectedComplements && item.selectedComplements.length > 0 && (
                        <div className="ml-4 mt-2">
                          <p className="text-xs font-semibold text-primary">Complementos:</p>
                          <ul className="space-y-0.5 mt-1">
                            {item.selectedComplements.map((comp, idx) => (
                              <li key={idx} className="text-xs text-muted-foreground">
                                • {comp.complementName}
                                {comp.complementPrice > 0 && ` (+$${comp.complementPrice.toFixed(2)})`}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {item.configuration && Object.keys(item.configuration).length > 0 && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {Object.entries(item.configuration).map(([key, values]) => 
                            `${key}: ${Array.isArray(values) ? values.join(', ') : values}`
                          ).join(' | ')}
                        </p>
                      )}
                      {item.notes && (
                        <p className="text-sm text-muted-foreground mt-1">
                          Nota: {item.notes}
                        </p>
                      )}
                    </div>
                    <p className="font-medium">${item.subtotal.toFixed(2)}</p>
                  </div>
                  {index < order.items.length - 1 && <Separator className="mt-4" />}
                </div>
              ))}

              <Separator />

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>${(order.totalAmount - order.deliveryFee).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm bg-yellow-400 text-black font-bold py-2 px-3 rounded-md">
                  <span>Envío</span>
                  <span>${order.deliveryFee.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>${order.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <div className="pt-4 border-t space-y-3">
                <p className="text-sm text-muted-foreground">
                  <strong>Método de pago:</strong> {order.paymentMethod === 'CASH' ? 'Efectivo' : 'Transferencia'}
                </p>
                {order.notes && (
                  <div className="p-3 bg-yellow-100 dark:bg-yellow-900/20 border border-yellow-300 dark:border-yellow-700 rounded-lg">
                    <p className="text-sm">
                      <span className="font-bold text-yellow-800 dark:text-yellow-400">Notas especiales:</span>
                      <span className="ml-2 text-yellow-900 dark:text-yellow-300">{order.notes}</span>
                    </p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

          {/* Messages Section - Prominently displayed */}
          {order.status === 'ON_THE_WAY' && order.deliveryPersonId && (
            <Card className="border-blue-500/50 shadow-2xl bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30">
              <CardHeader className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border-b-2 border-blue-200 dark:border-blue-800">
                <CardTitle className="text-lg flex items-center gap-2 text-blue-700 dark:text-blue-300">
                  💬 Mensajes con el Repartidor
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <OrderMessages
                  order={order}
                  currentUserId={order.clientId}
                  currentUserRole="CLIENT"
                  onOrderUpdate={() => {}}
                />
              </CardContent>
            </Card>
          )}
      </div>
    </div>
  );
};