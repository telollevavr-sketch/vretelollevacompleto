import { CartItem } from '@/types';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ComboItemSelector } from './ComboItemSelector';

interface PromotionalComboSelectorProps {
  item: CartItem;
  onSelectSpecialty: (unitIndex: number, pizzaIndex: number, specialtyId: string, specialtyName: string, specialtyPrice?: number) => void;
}

// Definir iconos según el tipo de item
const getIcon = (type: string) => {
  const icons: { [key: string]: string } = {
    pizza: '🍕',
    torta: '🥖',
    salsa: '🧂',
    queso: '🧀',
    bebida: '🥤',
    refresco: '🥤',
    postre: '🍰',
    hamburguesa: '🍔',
    taco: '🌮',
    burrito: '🌯',
    hot: '🌭',
    hotdog: '🌭',
  };
  return icons[type.toLowerCase()] || '🎁';
};

export const PromotionalComboSelector = ({
  item,
  onSelectSpecialty,
}: PromotionalComboSelectorProps) => {
  if (!item.product.isPromotionalCombo || !item.product.comboConfiguration) {
    return null;
  }

  const config = item.product.comboConfiguration;
  
  // Compatibilidad con estructura antigua y nueva
  const items = config.items || config.pizzas || [];
  const globalItemType = (config.itemType || 'pizza').toLowerCase();
  const isPricedCombo = item.product.isPricedCombo || false;

  // Obtener tipos únicos de items para mostrar en el título
  const uniqueTypes = [...new Set(items.map((i: any) => (i.itemType || globalItemType).toLowerCase()))];
  const titleTypes = uniqueTypes.map(t => `${getIcon(t)} ${t}s`).join(' + ');

  return (
    <div className="space-y-3 mt-3 p-3 bg-primary/5 rounded-lg border border-primary/20">
      <h4 className="font-semibold text-sm text-primary">
        🎁 Promoción: Elige tus items
      </h4>
      <p className="text-xs text-muted-foreground">
        Este combo incluye: {titleTypes}
        {isPricedCombo && (
          <span className="block mt-1 text-primary font-medium">
            💰 Pagas el de mayor precio
          </span>
        )}
      </p>
      
      <div className="space-y-4">
        {Array.from({ length: item.quantity }).map((_, unitIndex) => (
          <div key={unitIndex} className={unitIndex > 0 ? "border-t pt-3 mt-3" : ""}>
            {item.quantity > 1 && (
              <h5 className="font-medium text-xs text-muted-foreground mb-2">
                📦 Unidad {unitIndex + 1} de {item.quantity}
              </h5>
            )}
            
            <div className="grid gap-3">
              {items.map((comboItem: any, pizzaIndex: number) => {
                // Cada slot puede tener su propio itemType
                const slotItemType = (comboItem.itemType || globalItemType).toLowerCase();
                const currentSelection = item.comboSelections?.find(
                  (sel) => sel.unitIndex === unitIndex && sel.pizzaIndex === pizzaIndex
                );

                return (
                  <ComboItemSelector
                    key={pizzaIndex}
                    businessId={item.product.businessId}
                    comboItem={comboItem}
                    itemType={slotItemType}
                    icon={getIcon(slotItemType)}
                    isPricedCombo={isPricedCombo}
                    currentSelection={currentSelection}
                    onSelectSpecialty={(specialtyId, specialtyName, specialtyPrice) => 
                      onSelectSpecialty(unitIndex, pizzaIndex, specialtyId, specialtyName, specialtyPrice)
                    }
                  />
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {items.length > 0 && (!item.comboSelections || item.comboSelections.length < items.length * item.quantity) && (
        <p className="text-xs text-destructive mt-2">
          ⚠️ Selecciona todas las especialidades para continuar
        </p>
      )}
    </div>
  );
};
