import { useState } from 'react';
import { Order } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';
import { useOrders } from '@/hooks/useOrders';
import { toast } from '@/hooks/use-toast';

interface RatingModalProps {
  open: boolean;
  onClose: () => void;
  order: Order;
  onComplete: () => void;
}

export const RatingModal = ({ open, onClose, order, onComplete }: RatingModalProps) => {
  const { updateOrder } = useOrders();
  const [businessRating, setBusinessRating] = useState(0);
  const [deliveryRating, setDeliveryRating] = useState(0);
  const [comment, setComment] = useState('');

  const handleSubmit = () => {
    if (businessRating === 0 || deliveryRating === 0) {
      toast({
        title: 'Error',
        description: 'Por favor califica tanto el negocio como la entrega',
        variant: 'destructive'
      });
      return;
    }

    updateOrder({
      id: order.id,
      business_rating: businessRating,
      delivery_rating: deliveryRating,
      rating: Math.round((businessRating + deliveryRating) / 2),
      review: comment || undefined
    });

    toast({
      title: 'Calificación enviada',
      description: '¡Gracias por tu opinión!'
    });

    onComplete();
    onClose();
  };

  const StarRating = ({ 
    rating, 
    setRating, 
    label 
  }: { 
    rating: number; 
    setRating: (rating: number) => void; 
    label: string;
  }) => (
    <div className="space-y-3 p-4 rounded-lg bg-gradient-to-br from-primary/5 to-transparent border border-primary/10">
      <p className="font-semibold text-base">{label}</p>
      <div className="flex gap-1 justify-center">
        {[1, 2, 3, 4, 5].map(star => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            className="transition-all duration-200 hover:scale-125 active:scale-95"
          >
            <Star
              className={`h-10 w-10 transition-colors ${
                star <= rating
                  ? 'fill-primary text-primary drop-shadow-glow'
                  : 'text-muted-foreground hover:text-primary/50'
              }`}
            />
          </button>
        ))}
      </div>
      {rating > 0 && (
        <p className="text-center text-sm text-primary font-medium">
          {rating === 5 ? '¡Excelente!' : rating === 4 ? 'Muy bien' : rating === 3 ? 'Bueno' : rating === 2 ? 'Regular' : 'Mejorable'}
        </p>
      )}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <Star className="h-6 w-6 text-primary fill-primary" />
            Califica tu pedido
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <StarRating
            rating={businessRating}
            setRating={setBusinessRating}
            label="Calidad del negocio"
          />

          <StarRating
            rating={deliveryRating}
            setRating={setDeliveryRating}
            label="Servicio de entrega"
          />

          <div className="space-y-2">
            <p className="font-semibold">Comentarios (opcional)</p>
            <Textarea
              placeholder="Cuéntanos sobre tu experiencia..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1 hover-scale">
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit} 
            className="flex-1 bg-gradient-to-r from-primary to-primary/80 hover-scale"
          >
            Enviar Calificación
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
