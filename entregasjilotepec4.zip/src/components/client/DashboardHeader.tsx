import { User } from '@/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, User as UserIcon, History, LogOut, BarChart3 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { NotificationCenter } from '@/components/shared/NotificationCenter';
import logo from '@/assets/vrtelolleva-logo.png';

interface DashboardHeaderProps {
  user: User;
  cartItemCount: number;
  onCartClick: () => void;
  onProfileClick: () => void;
  onOrdersClick: () => void;
  onStatsClick: () => void;
}

export const DashboardHeader = ({
  user,
  cartItemCount,
  onCartClick,
  onProfileClick,
  onOrdersClick,
  onStatsClick
}: DashboardHeaderProps) => {
  const { signOut } = useAuth();
  
  const handleLogout = async () => {
    await signOut();
    window.location.href = '/home';
  };

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[hsl(260,45%,10%)]/80 backdrop-blur-md supports-[backdrop-filter]:bg-[hsl(260,45%,10%)]/80">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={logo} alt="vrtelolleva" className="h-10 w-auto" />
          <div>
            <h1 className="text-2xl font-bold text-white">vrtelolleva</h1>
            <p className="text-sm text-white/60">¡Hola, {user.name}!</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <NotificationCenter userId={user.id} />

          <Button variant="ghost" size="icon" onClick={onProfileClick} className="text-white hover:bg-white/10">
            <UserIcon className="h-5 w-5" />
          </Button>

          <Button variant="ghost" size="icon" onClick={onOrdersClick} className="text-white hover:bg-white/10">
            <History className="h-5 w-5" />
          </Button>

          <Button variant="ghost" size="icon" onClick={onStatsClick} className="text-white hover:bg-white/10">
            <BarChart3 className="h-5 w-5" />
          </Button>

          <Button variant="ghost" size="icon" onClick={onCartClick} className="relative text-white hover:bg-white/10">
            <ShoppingCart className="h-5 w-5" />
            {cartItemCount > 0 && (
              <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                {cartItemCount}
              </Badge>
            )}
          </Button>

          <Button variant="logout" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Salir
          </Button>
        </div>
      </div>
    </header>
  );
};
