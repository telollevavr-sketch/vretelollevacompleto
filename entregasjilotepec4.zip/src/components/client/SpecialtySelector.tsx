import { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';
import { usePizzaSpecialties } from '@/hooks/usePizzaSpecialties';

interface SpecialtySelectorProps {
  businessId: string;
  onSpecialtySelect: (specialtyId: string, specialtyName: string, ingredients?: string) => void;
  selectedSpecialtyId?: string;
}

export const SpecialtySelector = ({
  businessId,
  onSpecialtySelect,
  selectedSpecialtyId,
}: SpecialtySelectorProps) => {
  const { specialties, isLoading } = usePizzaSpecialties(businessId);
  const [selectedId, setSelectedId] = useState<string>(selectedSpecialtyId || '');

  useEffect(() => {
    if (selectedSpecialtyId) {
      setSelectedId(selectedSpecialtyId);
    }
  }, [selectedSpecialtyId]);

  const handleSpecialtyChange = (specialtyId: string) => {
    setSelectedId(specialtyId);
    const specialty = specialties.find(s => s.id === specialtyId);
    if (specialty) {
      onSpecialtySelect(
        specialty.id,
        specialty.name,
        specialty.description || undefined
      );
    }
  };

  if (isLoading) {
    return (
      <div className="p-4 bg-muted/30 rounded-lg">
        <p className="text-sm text-muted-foreground">Cargando especialidades...</p>
      </div>
    );
  }

  if (specialties.length === 0) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          No hay especialidades disponibles para este producto.
        </AlertDescription>
      </Alert>
    );
  }

  const selectedSpecialty = specialties.find(s => s.id === selectedId);

  return (
    <div className="space-y-3 p-4 bg-primary/5 dark:bg-primary/10 rounded-lg border border-primary/20">
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
        <Label className="font-semibold text-foreground">
          Selecciona tu Especialidad
        </Label>
      </div>

      <Select value={selectedId} onValueChange={handleSpecialtyChange}>
        <SelectTrigger className="w-full bg-background">
          <SelectValue placeholder="Elige una especialidad..." />
        </SelectTrigger>
        <SelectContent className="bg-background border-border">
          {specialties.map((specialty) => (
            <SelectItem key={specialty.id} value={specialty.id}>
              <div className="flex flex-col">
                <span className="font-medium">{specialty.name}</span>
                {specialty.description && (
                  <span className="text-xs text-muted-foreground">
                    {specialty.description}
                  </span>
                )}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {selectedSpecialty && selectedSpecialty.description && (
        <div className="p-3 bg-background/50 rounded border border-primary/10">
          <p className="text-xs font-medium text-muted-foreground mb-1">
            Ingredientes:
          </p>
          <p className="text-sm text-foreground">
            {selectedSpecialty.description}
          </p>
        </div>
      )}

      {!selectedId && (
        <Alert className="bg-yellow-500/10 border-yellow-500/20">
          <Info className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-700 dark:text-yellow-400 text-xs">
            Por favor selecciona una especialidad antes de realizar el pedido
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};
