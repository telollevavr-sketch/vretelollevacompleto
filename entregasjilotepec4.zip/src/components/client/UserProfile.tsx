import { useState, useEffect } from 'react';
import { User, Location } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { User as UserIcon, Mail, Phone, MapPin, Edit2, Save, X } from 'lucide-react';
import { LocationPicker } from '@/components/shared/LocationPicker';
import { Separator } from '@/components/ui/separator';
import { PasswordChangeCard } from './PasswordChangeCard';

interface UserProfileProps {
  user: User;
  onUpdate: (updatedUser: User) => void;
}

export const UserProfile = ({ user, onUpdate }: UserProfileProps) => {
  const { updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [location, setLocation] = useState<Location>(
    user.location || { lat: 19.4326, lng: -99.1332 }
  );
  const [formData, setFormData] = useState({
    name: user.name,
    phone: user.phone || '',
    address: user.address || ''
  });

  // Sync with user prop when not editing
  useEffect(() => {
    if (!isEditing) {
      setFormData({
        name: user.name,
        phone: user.phone || '',
        address: user.address || ''
      });
      setLocation(user.location || { lat: 19.4326, lng: -99.1332 });
    }
  }, [user, isEditing]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast({
        title: 'Error',
        description: 'El nombre es obligatorio',
        variant: 'destructive'
      });
      return;
    }

    try {
      await updateProfile({
        name: formData.name,
        phone: formData.phone,
        address: formData.address
      });
      
      setIsEditing(false);
      toast({
        title: 'Perfil actualizado',
        description: 'Tus datos han sido guardados correctamente'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudo actualizar el perfil',
        variant: 'destructive'
      });
    }
  };

  const handleCancel = () => {
    setFormData({
      name: user.name,
      phone: user.phone || '',
      address: user.address || ''
    });
    setLocation(user.location || { lat: 19.4326, lng: -99.1332 });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Mi Perfil</h2>
          <p className="text-muted-foreground mt-1">Gestiona tu información personal</p>
        </div>
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="h-5 w-5 text-primary" />
                Información Personal
              </CardTitle>
              <CardDescription className="mt-2">
                Actualiza tus datos de contacto y ubicación de entrega
              </CardDescription>
            </div>
            {!isEditing && (
              <Button onClick={() => setIsEditing(true)} variant="outline" size="sm">
                <Edit2 className="h-4 w-4 mr-2" />
                Editar
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!isEditing ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <UserIcon className="h-4 w-4" />
                    <span>Nombre</span>
                  </div>
                  <p className="font-medium text-lg">{user.name}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    <span>Email</span>
                  </div>
                  <p className="font-medium text-lg">{user.email}</p>
                </div>

                {user.phone && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span>Teléfono</span>
                    </div>
                    <p className="font-medium text-lg">{user.phone}</p>
                  </div>
                )}

                {user.address && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>Dirección</span>
                    </div>
                    <p className="font-medium text-lg">{user.address}</p>
                  </div>
                )}
              </div>

              {user.location && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>Ubicación de Entrega</span>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg space-y-1">
                      <p className="text-sm font-mono">
                        {user.location.lat.toFixed(6)}, {user.location.lng.toFixed(6)}
                      </p>
                      {user.location.address && (
                        <p className="text-sm text-muted-foreground">{user.location.address}</p>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    Nombre <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Tu nombre completo"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={user.email}
                    disabled
                    className="bg-muted cursor-not-allowed"
                  />
                  <p className="text-xs text-muted-foreground">
                    El email no se puede modificar
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="5512345678"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Input
                    id="address"
                    placeholder="Calle, Número, Colonia"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <Label className="text-base font-semibold">Ubicación de Entrega</Label>
                <p className="text-sm text-muted-foreground">
                  Selecciona tu ubicación exacta en el mapa o usa el botón para obtener tu ubicación actual
                </p>
                <LocationPicker
                  location={location}
                  onLocationChange={setLocation}
                />
              </div>

              <Separator />

              <div className="flex gap-3 justify-end">
                <Button type="button" variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  Cancelar
                </Button>
                <Button type="submit">
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Cambios
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      <PasswordChangeCard />
    </div>
  );
};
