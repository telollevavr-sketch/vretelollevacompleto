import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { ErrorBoundary } from '@/components/shared/ErrorBoundary';
import HomePage from "./pages/HomePage";
import AuthPage from "./pages/AuthPage";
import InstallPage from "./pages/InstallPage";
import ClientDashboard from "./pages/ClientDashboard";
import BusinessDashboard from "./pages/BusinessDashboard";
import DeliveryDashboard from "./pages/DeliveryDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import PublicBusinessPage from "./pages/PublicBusinessPage";
import AntojosPage from "./pages/AntojosPage";
import NotFound from "./pages/NotFound";
import { LoadingSpinner } from "./components/shared/LoadingSpinner";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000),
    },
  },
});

const AppContent = () => {
  const { user, userRole, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  const getDashboard = () => {
    if (!user) return <Navigate to="/home" replace />;

    switch (userRole) {
      case 'client':
        return <ClientDashboard />;
      case 'business':
        return <BusinessDashboard />;
      case 'delivery':
        return <DeliveryDashboard />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return <Navigate to="/home" replace />;
    }
  };

  return (
    <Routes>
      <Route path="/" element={getDashboard()} />
      <Route path="/home" element={<HomePage />} />
      <Route path="/auth" element={<AuthPage />} />
      <Route path="/install" element={<InstallPage />} />
      <Route path="/negocio/:businessId" element={<PublicBusinessPage />} />
      <Route path="/antojos" element={<AntojosPage />} />
      <Route path="/client-dashboard" element={user && userRole === 'client' ? <ClientDashboard /> : <Navigate to="/home" replace />} />
      <Route path="/business-dashboard" element={user && userRole === 'business' ? <BusinessDashboard /> : <Navigate to="/home" replace />} />
      <Route path="/delivery-dashboard" element={user && userRole === 'delivery' ? <DeliveryDashboard /> : <Navigate to="/home" replace />} />
      <Route path="/admin-dashboard" element={user && userRole === 'admin' ? <AdminDashboard /> : <Navigate to="/home" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <ErrorBoundary>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <AppContent />
            </BrowserRouter>
          </ErrorBoundary>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
