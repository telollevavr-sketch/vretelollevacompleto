import { Location } from '@/types';

class LocationService {
  getCurrentPosition(): Promise<Location> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          // Return default location (Mexico City) if permission denied
          resolve({
            lat: 19.4326,
            lng: -99.1332,
            address: 'Ciudad de México'
          });
        }
      );
    });
  }

  calculateDistance(from: Location, to: Location): number {
    const R = 6371; // Earth radius in km
    const dLat = this.toRad(to.lat - from.lat);
    const dLon = this.toRad(to.lng - from.lng);
    
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(from.lat)) * Math.cos(this.toRad(to.lat)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRad(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  calculateDeliveryFee(distance: number, baseFee: number): number {
    // Base fee + 5 pesos per km
    return Math.round(baseFee + (distance * 5));
  }

  calculateDeliveryFeeByDistance(distance: number): number {
    // Primer kilómetro = $30 + cada km adicional (o fracción) = $16.50
    if (distance <= 0) return 0;
    if (distance <= 1) return 30;
    
    // Redondear hacia arriba para cobrar fracciones completas
    const additionalKms = Math.ceil(distance - 1);
    return 30 + (additionalKms * 16.50);
  }

  calculateAntojoDeliveryFee(distance: number): number {
    // Primer kilómetro = $35 + cada km adicional (o fracción) = $16.50
    if (distance <= 0) return 0;
    if (distance <= 1) return 35;
    
    const additionalKms = Math.ceil(distance - 1);
    return 35 + (additionalKms * 16.50);
  }

  async getAddressFromCoordinates(lat: number, lng: number): Promise<string> {
    try {
      // Use Nominatim (OpenStreetMap's geocoding service)
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`,
        {
          headers: {
            'User-Agent': 'FoodDeliveryApp/1.0'
          }
        }
      );
      
      if (!response.ok) {
        throw new Error('Geocoding failed');
      }
      
      const data = await response.json();
      
      // Build a readable address with street, number, neighborhood, and postal code
      const address = data.address;
      const parts = [
        address.road && address.house_number ? `${address.road} ${address.house_number}` : address.road,
        address.suburb || address.neighbourhood,
        address.postcode
      ].filter(Boolean);
      
      return parts.join(', ') || data.display_name || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    } catch (error) {
      console.error('Error fetching address:', error);
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }
  }
}

export const locationService = new LocationService();
