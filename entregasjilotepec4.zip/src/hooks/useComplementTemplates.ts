import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ComplementTemplate {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string | null;
  isActive: boolean;
}

export function useComplementTemplates() {
  const queryClient = useQueryClient();

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['complement-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('complement_templates')
        .select('*')
        .eq('is_active', true)
        .order('category', { ascending: true })
        .order('name', { ascending: true });

      if (error) {
        console.error('Error fetching templates:', error);
        toast.error('Error al cargar plantillas');
        throw error;
      }

      return data.map((template) => ({
        id: template.id,
        name: template.name,
        category: template.category,
        price: template.price,
        description: template.description,
        isActive: template.is_active,
      })) as ComplementTemplate[];
    },
  });

  const applyTemplate = useMutation({
    mutationFn: async ({
      templateId,
      productId,
    }: {
      templateId: string;
      productId: string;
    }) => {
      // Obtener la plantilla
      const template = templates.find((t) => t.id === templateId);
      if (!template) throw new Error('Template not found');

      // Crear el complemento basado en la plantilla
      const { data, error } = await supabase
        .from('product_complements')
        .insert({
          product_id: productId,
          name: template.name,
          category: template.category,
          price: template.price,
          description: template.description,
          is_available: true,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['product-complements'] });
      queryClient.invalidateQueries({ queryKey: ['product-complement-counts'] });
      toast.success('Complemento agregado desde plantilla');
    },
    onError: (error: Error) => {
      console.error('Error applying template:', error);
      toast.error('Error al aplicar plantilla');
    },
  });

  const applyMultipleTemplates = useMutation({
    mutationFn: async ({
      templateIds,
      productId,
    }: {
      templateIds: string[];
      productId: string;
    }) => {
      const selectedTemplates = templates.filter((t) =>
        templateIds.includes(t.id)
      );

      const complementsToInsert = selectedTemplates.map((template) => ({
        product_id: productId,
        name: template.name,
        category: template.category,
        price: template.price,
        description: template.description,
        is_available: true,
      }));

      const { data, error } = await supabase
        .from('product_complements')
        .insert(complementsToInsert)
        .select();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['product-complements'] });
      queryClient.invalidateQueries({ queryKey: ['product-complement-counts'] });
      toast.success(`${data.length} complementos agregados desde plantillas`);
    },
    onError: (error: Error) => {
      console.error('Error applying templates:', error);
      toast.error('Error al aplicar plantillas');
    },
  });

  return {
    templates,
    isLoading,
    applyTemplate,
    applyMultipleTemplates,
  };
}
