import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export type DeliveryIncident = {
  id: string;
  delivery_person_id: string;
  amount: number;
  notes: string | null;
  occurred_at: string;
  deliveryName?: string;
};

interface Filters {
  from?: Date;
  to?: Date;
  deliveryPersonId?: string;
}

export function useDeliveryIncidents({ from, to, deliveryPersonId }: Filters) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const fromKey = from ? from.toISOString().slice(0, 10) : '';
  const toKey = to ? to.toISOString().slice(0, 10) : '';

  const query = useQuery({
    queryKey: ['delivery-incidents', fromKey, toKey, deliveryPersonId || 'all'],
    queryFn: async () => {
      let q = supabase
        .from('delivery_incidents')
        .select('id, delivery_person_id, amount, notes, occurred_at, profiles:delivery_person_id(name)');

      if (from) {
        const start = new Date(from);
        start.setHours(0, 0, 0, 0);
        q = q.gte('occurred_at', start.toISOString());
      }
      if (to) {
        const end = new Date(to);
        end.setHours(23, 59, 59, 999);
        q = q.lte('occurred_at', end.toISOString());
      }
      if (deliveryPersonId && deliveryPersonId !== 'all') {
        q = q.eq('delivery_person_id', deliveryPersonId);
      }

      const { data, error } = await q.order('occurred_at', { ascending: false }).limit(500);
      if (error) throw error;

      return (data || []).map((r: any) => ({
        id: r.id,
        delivery_person_id: r.delivery_person_id,
        amount: Number(r.amount || 0),
        notes: r.notes,
        occurred_at: r.occurred_at,
        deliveryName: r.profiles?.name || undefined,
      })) as DeliveryIncident[];
    },
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  const createIncident = useMutation({
    mutationFn: async (input: {
      delivery_person_id: string;
      amount: number;
      notes?: string | null;
      occurred_at?: string;
    }) => {
      const { data: userData } = await supabase.auth.getUser();
      const { error } = await supabase.from('delivery_incidents').insert({
        delivery_person_id: input.delivery_person_id,
        amount: input.amount,
        notes: input.notes || null,
        occurred_at: input.occurred_at || new Date().toISOString(),
        created_by: userData.user?.id ?? null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['delivery-incidents'] });
      toast({ title: 'Entrega registrada' });
    },
    onError: (e: any) =>
      toast({ title: 'Error al guardar', description: e.message, variant: 'destructive' }),
  });

  const updateIncident = useMutation({
    mutationFn: async ({
      id,
      delivery_person_id,
      amount,
      notes,
    }: {
      id: string;
      delivery_person_id: string;
      amount: number;
      notes: string | null;
    }) => {
      const { error } = await supabase
        .from('delivery_incidents')
        .update({ delivery_person_id, amount, notes })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['delivery-incidents'] });
      toast({ title: 'Entrega actualizada' });
    },
    onError: (e: any) =>
      toast({ title: 'Error al actualizar', description: e.message, variant: 'destructive' }),
  });

  const deleteIncident = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('delivery_incidents').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['delivery-incidents'] });
      toast({ title: 'Entrega eliminada' });
    },
    onError: (e: any) =>
      toast({ title: 'Error al eliminar', description: e.message, variant: 'destructive' }),
  });

  const incidents = query.data || [];
  const total = incidents.reduce((sum, i) => sum + i.amount, 0);

  return {
    incidents,
    total,
    count: incidents.length,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    createIncident: createIncident.mutateAsync,
    isCreating: createIncident.isPending,
    updateIncident: updateIncident.mutateAsync,
    isUpdating: updateIncident.isPending,
    deleteIncident: deleteIncident.mutateAsync,
  };
}
