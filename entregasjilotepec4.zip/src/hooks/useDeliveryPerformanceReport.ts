import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DeliveryPerformanceItem {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  vehicleType: string | null;
  vehiclePlate: string | null;
  isActive: boolean;
  isOnline: boolean;
  assignedBusinessId: string | null;
  assignedBusinessName: string | null;
  totalOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  successRate: number;
  rating: number;
  reviewCount: number;
}

interface UseDeliveryPerformanceReportParams {
  searchTerm?: string;
  isActive?: boolean | null;
  businessId?: string;
  isOnline?: boolean | null;
}

export function useDeliveryPerformanceReport({
  searchTerm,
  isActive,
  businessId,
  isOnline,
}: UseDeliveryPerformanceReportParams = {}) {
  const { data: reportData = [], isLoading } = useQuery({
    queryKey: ['delivery-performance', searchTerm, isActive, businessId, isOnline],
    queryFn: async () => {
      // Get delivery users
      const { data: deliveryRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'delivery');

      if (rolesError) throw rolesError;

      const deliveryUserIds = (deliveryRoles || []).map(r => r.user_id);

      if (deliveryUserIds.length === 0) return [];

      // Get profiles for delivery users
      let profilesQuery = supabase
        .from('profiles')
        .select('*')
        .in('id', deliveryUserIds);

      if (isActive !== null && isActive !== undefined) {
        profilesQuery = profilesQuery.eq('is_active', isActive);
      }
      if (businessId) {
        profilesQuery = profilesQuery.eq('assigned_business_id', businessId);
      }
      if (isOnline !== null && isOnline !== undefined) {
        profilesQuery = profilesQuery.eq('is_online', isOnline);
      }

      const { data: profiles, error: profilesError } = await profilesQuery;

      if (profilesError) throw profilesError;

      // Get all orders with delivery person
      const { data: orders, error: ordersError } = await supabase
        .from('orders')
        .select('id, delivery_person_id, status')
        .not('delivery_person_id', 'is', null);

      if (ordersError) throw ordersError;

      // Get businesses for assigned_business_id lookup
      const { data: businesses, error: businessesError } = await supabase
        .from('businesses')
        .select('id, name');

      if (businessesError) throw businessesError;

      const businessMap = new Map(businesses?.map(b => [b.id, b.name]) || []);

      // Count orders per delivery person
      const ordersByDelivery = new Map<string, { total: number; delivered: number; cancelled: number }>();
      
      (orders || []).forEach(order => {
        if (!order.delivery_person_id) return;
        
        const existing = ordersByDelivery.get(order.delivery_person_id) || { total: 0, delivered: 0, cancelled: 0 };
        existing.total += 1;
        
        if (order.status === 'delivered') {
          existing.delivered += 1;
        } else if (order.status === 'cancelled') {
          existing.cancelled += 1;
        }
        
        ordersByDelivery.set(order.delivery_person_id, existing);
      });

      // Build report
      let result: DeliveryPerformanceItem[] = (profiles || []).map(profile => {
        const orderStats = ordersByDelivery.get(profile.id) || { total: 0, delivered: 0, cancelled: 0 };
        
        return {
          id: profile.id,
          name: profile.name,
          email: profile.email,
          phone: profile.phone,
          vehicleType: profile.vehicle_type,
          vehiclePlate: profile.vehicle_plate,
          isActive: profile.is_active ?? true,
          isOnline: profile.is_online ?? false,
          assignedBusinessId: profile.assigned_business_id,
          assignedBusinessName: profile.assigned_business_id ? businessMap.get(profile.assigned_business_id) || null : null,
          totalOrders: orderStats.total,
          deliveredOrders: orderStats.delivered,
          cancelledOrders: orderStats.cancelled,
          successRate: orderStats.total > 0 ? (orderStats.delivered / orderStats.total) * 100 : 0,
          rating: Number(profile.rating) || 0,
          reviewCount: profile.review_count || 0,
        };
      });

      // Filter by search term
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        result = result.filter(
          item =>
            item.name.toLowerCase().includes(term) ||
            item.email.toLowerCase().includes(term)
        );
      }

      return result.sort((a, b) => b.deliveredOrders - a.deliveredOrders);
    },
  });

  return {
    reportData,
    isLoading,
  };
}
