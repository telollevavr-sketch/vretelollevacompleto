import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { PizzaSpecialty } from '@/types';

export function usePizzaSpecialties(businessId?: string, specialtyType?: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: specialties = [], isLoading } = useQuery({
    queryKey: ['pizza-specialties', businessId, specialtyType],
    queryFn: async () => {
      let query = supabase.from('pizza_specialties').select('*');

      if (businessId) {
        query = query.eq('business_id', businessId);
      }

      // Filtrar por tipo si se especifica (case-insensitive)
      if (specialtyType) {
        query = query.ilike('specialty_type', specialtyType.toLowerCase());
      }

      const { data, error } = await query
        .eq('is_active', true)
        .order('name');

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        businessId: item.business_id,
        name: item.name,
        description: item.description || '',
        price: Number((item as any).price) || 0,
        isActive: item.is_active,
        specialtyType: item.specialty_type || 'pizza',
        createdAt: item.created_at,
      })) as PizzaSpecialty[];
    },
    enabled: !!businessId,
  });

  const createSpecialty = useMutation({
    mutationFn: async (specialty: {
      business_id: string;
      name: string;
      description?: string;
      specialty_type?: string;
    }) => {
      const { data, error } = await supabase
        .from('pizza_specialties')
        .insert({
          ...specialty,
          specialty_type: (specialty.specialty_type || 'pizza').toLowerCase() // Normalizar a minúsculas
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pizza-specialties'] });
      toast({
        title: 'Especialidad creada',
        description: 'La especialidad ha sido agregada',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateSpecialty = useMutation({
    mutationFn: async ({
      id,
      updates,
    }: {
      id: string;
      updates: Partial<{
        name: string;
        description: string;
        is_active: boolean;
        specialty_type: string;
      }>;
    }) => {
      const { data, error } = await supabase
        .from('pizza_specialties')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pizza-specialties'] });
      toast({
        title: 'Especialidad actualizada',
        description: 'Los cambios han sido guardados',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteSpecialty = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('pizza_specialties')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pizza-specialties'] });
      toast({
        title: 'Especialidad eliminada',
        description: 'La especialidad ha sido removida',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    specialties,
    isLoading,
    createSpecialty: createSpecialty.mutate,
    updateSpecialty: updateSpecialty.mutate,
    deleteSpecialty: deleteSpecialty.mutate,
  };
}
