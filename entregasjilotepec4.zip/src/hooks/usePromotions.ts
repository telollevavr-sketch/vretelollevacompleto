import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface Promotion {
  id: string;
  businessId: string;
  businessName: string;
  title: string;
  description?: string;
  imageData: string;
  isActive: boolean;
  createdAt: string;
}

export const usePromotions = (businessId?: string) => {
  const queryClient = useQueryClient();

  // Fetch promotions (all or by business)
  const { data: promotions = [], isLoading, isError, refetch } = useQuery({
    queryKey: ['promotions', businessId],
    queryFn: async () => {
      let query = supabase
        .from('business_promotions')
        .select('*, businesses:business_id ( name )')
        .eq('is_active', true);

      if (businessId) {
        query = query.eq('business_id', businessId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map(p => ({
        id: p.id,
        businessId: p.business_id,
        businessName: p.businesses?.name || 'Negocio desconocido',
        title: p.title,
        description: p.description || '',
        imageData: p.image_data,
        isActive: p.is_active,
        createdAt: p.created_at,
      }));
    },
    enabled: !!businessId,
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  // Create promotion
  const { mutate: createPromotion } = useMutation({
    mutationFn: async (data: {
      business_id: string;
      title: string;
      description?: string;
      image_data: string;
    }) => {
      const { error } = await supabase.from('business_promotions').insert([data]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promotions'] });
      toast({
        title: 'Promoción creada',
        description: 'La promoción se ha creado exitosamente',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'No se pudo crear la promoción: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  // Delete promotion
  const { mutate: deletePromotion } = useMutation({
    mutationFn: async (promotionId: string) => {
      const { error } = await supabase
        .from('business_promotions')
        .delete()
        .eq('id', promotionId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promotions'] });
      toast({
        title: 'Promoción eliminada',
        description: 'La promoción se ha eliminado exitosamente',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'No se pudo eliminar la promoción: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    promotions,
    isLoading,
    isError,
    refetch,
    createPromotion,
    deletePromotion,
  };
};
