import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';
import { Business } from '@/types';
import { dbBusinessToBusiness } from '@/lib/typeConversions';

type DbBusiness = Database['public']['Tables']['businesses']['Row'];
type BusinessUpdate = Database['public']['Tables']['businesses']['Update'];

export function useAllBusinesses() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: businesses = [], isLoading } = useQuery<Business[]>({
    queryKey: ['all-businesses-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('businesses')
        .select('*')
        .order('name');

      if (error) throw error;
      return (data as DbBusiness[]).map(dbBusinessToBusiness);
    },
    staleTime: 60000, // 60 segundos de cache
    refetchOnWindowFocus: false,
  });

  const updateBusiness = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: BusinessUpdate }) => {
      const { data, error } = await supabase
        .from('businesses')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-businesses-admin'] });
      queryClient.invalidateQueries({ queryKey: ['businesses'] });
      toast({
        title: 'Negocio actualizado',
        description: 'Los cambios han sido guardados',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteBusiness = useMutation({
    mutationFn: async (businessId: string) => {
      const { error } = await supabase
        .from('businesses')
        .delete()
        .eq('id', businessId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-businesses-admin'] });
      queryClient.invalidateQueries({ queryKey: ['businesses'] });
      toast({
        title: 'Negocio eliminado',
        description: 'El negocio ha sido eliminado correctamente',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    businesses,
    isLoading,
    updateBusiness: updateBusiness.mutate,
    deleteBusiness: deleteBusiness.mutate,
  };
}
