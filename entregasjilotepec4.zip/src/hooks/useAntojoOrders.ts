import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface AntojoOrder {
  id: string;
  order_number: string;
  client_id: string;
  antojo_business_id: string | null;
  custom_business_name: string | null;
  custom_business_description: string | null;
  order_description: string | null;
  order_image: string | null;
  delivery_address: string;
  delivery_latitude: number;
  delivery_longitude: number;
  business_latitude: number;
  business_longitude: number;
  delivery_fee: number;
  sale_total: number | null;
  total: number | null;
  status: string;
  payment_method: string;
  delivery_person_id: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  antojo_businesses?: {
    name: string;
    address: string;
    phone: string | null;
  };
}

export const useAntojoOrders = (userId?: string, role?: string) => {
  const queryClient = useQueryClient();

  const { data: orders = [], isLoading, refetch } = useQuery({
    queryKey: ['antojo-orders', userId, role],
    queryFn: async () => {
      let query = supabase
        .from('antojo_orders')
        .select('*, antojo_businesses(name, address, phone)')
        .order('created_at', { ascending: false });

      if (role === 'client' && userId) {
        query = query.eq('client_id', userId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as AntojoOrder[];
    },
    enabled: !!userId || role === 'admin',
    staleTime: 30000,
  });

  const createOrder = useMutation({
    mutationFn: async (order: Omit<AntojoOrder, 'id' | 'created_at' | 'updated_at' | 'antojo_businesses'>) => {
      const { antojo_businesses: _, ...orderData } = order as any;
      const { data, error } = await supabase
        .from('antojo_orders')
        .insert({
          ...orderData,
          payment_method: orderData.payment_method as 'cash' | 'transfer',
        })
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-orders'] });
      toast({ title: '¡Pedido enviado!', description: 'Tu pedido de antojo ha sido registrado' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const updateOrder = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<AntojoOrder> & { id: string }) => {
      const { antojo_businesses: _, ...cleanUpdates } = updates as any;
      const { data, error } = await supabase
        .from('antojo_orders')
        .update({ ...cleanUpdates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-orders'] });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const deleteOrder = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('antojo_orders')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-orders'] });
      toast({ title: 'Pedido eliminado' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  return {
    orders,
    isLoading,
    refetch,
    createOrder: createOrder.mutate,
    updateOrder: updateOrder.mutate,
    deleteOrder: deleteOrder.mutate,
  };
};
