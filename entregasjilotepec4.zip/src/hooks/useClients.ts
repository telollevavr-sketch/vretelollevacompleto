import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ClientOrder {
  id: string;
  order_number: string;
  created_at: string;
  total: number;
  status: string;
  business_name?: string;
}

export interface ClientWithStats {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  address: string | null;
  createdAt: string;
  lastOrderDate: string | null;
  orderCount: number;
  totalSpent: number;
  orders: ClientOrder[];
}

export const useClients = () => {
  return useQuery({
    queryKey: ['clients-with-stats'],
    queryFn: async (): Promise<ClientWithStats[]> => {
      // Query 1: Get all client profiles
      const { data: clientRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'client');

      if (rolesError) throw rolesError;

      if (!clientRoles || clientRoles.length === 0) {
        return [];
      }

      const clientIds = clientRoles.map(r => r.user_id);

      // Query 2: Get profiles for these clients
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, name, email, phone, address, created_at')
        .in('id', clientIds);

      if (profilesError) throw profilesError;

      if (!profiles || profiles.length === 0) {
        return [];
      }

      // Query 3: Get all orders for these clients with business names
      const { data: orders, error: ordersError } = await supabase
        .from('orders')
        .select(`
          id,
          order_number,
          created_at,
          total,
          status,
          client_id,
          business_id,
          businesses (name)
        `)
        .in('client_id', clientIds)
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;

      // Create a map of client orders
      const ordersByClient = new Map<string, ClientOrder[]>();
      const statsByClient = new Map<string, { count: number; total: number; lastDate: string | null }>();

      (orders || []).forEach(order => {
        const clientId = order.client_id;
        
        const clientOrder: ClientOrder = {
          id: order.id,
          order_number: order.order_number,
          created_at: order.created_at,
          total: order.total,
          status: order.status,
          business_name: (order.businesses as any)?.name || 'Negocio desconocido'
        };

        if (!ordersByClient.has(clientId)) {
          ordersByClient.set(clientId, []);
          statsByClient.set(clientId, { count: 0, total: 0, lastDate: null });
        }

        ordersByClient.get(clientId)!.push(clientOrder);
        
        const stats = statsByClient.get(clientId)!;
        stats.count += 1;
        stats.total += order.total;
        
        if (!stats.lastDate || new Date(order.created_at) > new Date(stats.lastDate)) {
          stats.lastDate = order.created_at;
        }
      });

      // Combine profiles with order statistics
      const clientsWithStats: ClientWithStats[] = profiles.map(profile => {
        const stats = statsByClient.get(profile.id) || { count: 0, total: 0, lastDate: null };
        const clientOrders = ordersByClient.get(profile.id) || [];

        return {
          id: profile.id,
          name: profile.name,
          email: profile.email,
          phone: profile.phone,
          address: profile.address,
          createdAt: profile.created_at,
          lastOrderDate: stats.lastDate,
          orderCount: stats.count,
          totalSpent: stats.total,
          orders: clientOrders
        };
      });

      // Sort by order count descending
      return clientsWithStats.sort((a, b) => b.orderCount - a.orderCount);
    },
    staleTime: 60000, // Cache for 1 minute
  });
};
