import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Tables, TablesInsert, TablesUpdate } from '@/integrations/supabase/types';

type DbProductComplement = Tables<'product_complements'>;
type ProductComplementInsert = TablesInsert<'product_complements'>;
type ProductComplementUpdate = TablesUpdate<'product_complements'>;

export interface ProductComplement {
  id: string;
  productId: string;
  name: string;
  price: number;
  category: string;
  description?: string;
  isAvailable: boolean;
  createdAt: string;
}

const dbComplementToComplement = (db: DbProductComplement): ProductComplement => ({
  id: db.id,
  productId: db.product_id,
  name: db.name,
  price: Number(db.price),
  category: db.category,
  description: db.description || undefined,
  isAvailable: db.is_available,
  createdAt: db.created_at,
});

export function useProductComplements(productId?: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: complements = [], isLoading } = useQuery({
    queryKey: ['product-complements', productId],
    queryFn: async () => {
      let query = supabase
        .from('product_complements')
        .select('*')
        .order('category', { ascending: true })
        .order('name', { ascending: true });

      if (productId) {
        query = query.eq('product_id', productId);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data.map(dbComplementToComplement);
    },
    enabled: !!productId,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const createComplement = useMutation({
    mutationFn: async (complement: Omit<ProductComplementInsert, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('product_complements')
        .insert(complement)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['product-complements'] });
      queryClient.invalidateQueries({ queryKey: ['product-complement-counts'] });
      toast({
        title: 'Complemento creado',
        description: 'El complemento se ha creado correctamente',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateComplement = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: ProductComplementUpdate }) => {
      const { data, error } = await supabase
        .from('product_complements')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['product-complements'] });
      queryClient.invalidateQueries({ queryKey: ['product-complement-counts'] });
      toast({
        title: 'Complemento actualizado',
        description: 'El complemento se ha actualizado correctamente',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteComplement = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('product_complements')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['product-complements'] });
      queryClient.invalidateQueries({ queryKey: ['product-complement-counts'] });
      toast({
        title: 'Complemento eliminado',
        description: 'El complemento se ha eliminado correctamente',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    complements,
    isLoading,
    createComplement,
    updateComplement,
    deleteComplement,
  };
}
