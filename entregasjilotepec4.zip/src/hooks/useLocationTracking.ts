import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface UseLocationTrackingProps {
  userId: string;
  isOnline: boolean;
  enabled?: boolean;
}

export const useLocationTracking = ({ userId, isOnline, enabled = true }: UseLocationTrackingProps) => {

  // Función para actualizar la ubicación una vez (el "pulso")
  const updateLocationOnce = async () => {
    if (!navigator.geolocation) {
      console.error('❌ Geolocalización no soportada por el navegador');
      return Promise.reject('Geolocalización no soportada');
    }

    console.log('📍 [LOCATION TRACKING] Solicitando ubicación para usuario:', userId);

    return new Promise<void>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude, accuracy } = position.coords;
          
          console.log('✅ [LOCATION TRACKING] Ubicación obtenida:', { 
            latitude: latitude.toFixed(6), 
            longitude: longitude.toFixed(6),
            accuracy: `${accuracy.toFixed(0)}m`,
            userId 
          });

          try {
            const { data, error } = await supabase
              .from('profiles')
              .update({
                latitude,
                longitude,
              })
              .eq('id', userId)
              .select();

            if (error) {
              console.error('❌ [LOCATION TRACKING] Error actualizando en BD:', error);
              reject(error);
            } else {
              console.log('✅ [LOCATION TRACKING] Ubicación guardada en BD:', data);
              resolve();
            }
          } catch (error) {
            console.error('❌ [LOCATION TRACKING] Error al actualizar ubicación:', error);
            reject(error);
          }
        },
        (error) => {
          console.error('❌ [LOCATION TRACKING] Error obteniendo ubicación:', {
            code: error.code,
            message: error.message
          });
          reject(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 0
        }
      );
    });
  };

  // Solo actualizar ubicación una vez al ponerse en línea
  useEffect(() => {
    if (!enabled || !isOnline) return;
    if (!navigator.geolocation) return;

    console.log('🚀 [LOCATION TRACKING] Actualizando ubicación inicial para usuario:', userId);
    updateLocationOnce().catch(err => {
      console.error('❌ [LOCATION TRACKING] Error en actualización inicial:', err);
    });
  }, [userId, isOnline, enabled]);

  return { updateLocationOnce };
};
