import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ProductReportItem {
  productId: string;
  productName: string;
  productCategory: string;
  productPrice: number;
  productDescription: string | null;
  isAvailable: boolean;
  isPromotionalCombo: boolean;
  isSpecialty: boolean;
  productCreatedAt: string;
  businessId: string;
  businessName: string;
  businessCategory: string;
  businessIsActive: boolean;
  complementsCount: number;
  complementsList: string;
  specialtiesList: string;
}

export function useProductsReport() {
  const { data: reportData = [], isLoading } = useQuery({
    queryKey: ['products-report'],
    queryFn: async () => {
      // Fetch products with business info
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select(`
          id,
          name,
          category,
          price,
          description,
          is_available,
          is_promotional_combo,
          is_specialty,
          created_at,
          business_id,
          businesses!inner (
            id,
            name,
            category,
            is_active
          )
        `)
        .order('name');

      if (productsError) throw productsError;

      // Fetch all complements
      const { data: complements, error: complementsError } = await supabase
        .from('product_complements')
        .select('id, name, product_id');

      if (complementsError) throw complementsError;

      // Fetch all specialties
      const { data: specialties, error: specialtiesError } = await supabase
        .from('pizza_specialties')
        .select('id, name, business_id');

      if (specialtiesError) throw specialtiesError;

      // Map complements by product_id
      const complementsByProduct = new Map<string, string[]>();
      complements?.forEach(c => {
        const existing = complementsByProduct.get(c.product_id) || [];
        existing.push(c.name);
        complementsByProduct.set(c.product_id, existing);
      });

      // Map specialties by business_id
      const specialtiesByBusiness = new Map<string, string[]>();
      specialties?.forEach(s => {
        const existing = specialtiesByBusiness.get(s.business_id) || [];
        existing.push(s.name);
        specialtiesByBusiness.set(s.business_id, existing);
      });

      // Build report data
      const reportItems: ProductReportItem[] = (products || []).map(product => {
        const business = product.businesses as unknown as {
          id: string;
          name: string;
          category: string;
          is_active: boolean;
        };

        const productComplements = complementsByProduct.get(product.id) || [];
        const businessSpecialties = specialtiesByBusiness.get(business.id) || [];

        return {
          productId: product.id,
          productName: product.name,
          productCategory: product.category,
          productPrice: product.price,
          productDescription: product.description,
          isAvailable: product.is_available ?? true,
          isPromotionalCombo: product.is_promotional_combo,
          isSpecialty: product.is_specialty,
          productCreatedAt: product.created_at,
          businessId: business.id,
          businessName: business.name,
          businessCategory: business.category,
          businessIsActive: business.is_active,
          complementsCount: productComplements.length,
          complementsList: productComplements.join(', '),
          specialtiesList: businessSpecialties.join(', '),
        };
      });

      return reportItems;
    },
  });

  return {
    reportData,
    isLoading,
  };
}
