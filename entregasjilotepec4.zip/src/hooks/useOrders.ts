import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';
import { Order } from '@/types';
import { dbOrderToOrder } from '@/lib/typeConversions';

type DbOrder = Database['public']['Tables']['orders']['Row'];
type OrderInsert = Database['public']['Tables']['orders']['Insert'];
type OrderUpdate = Database['public']['Tables']['orders']['Update'];

export function useOrders(userId?: string, userRole?: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['orders', userId, userRole],
    queryFn: async () => {
      if (!userId) return [];

      let query = supabase.from('orders').select('*, businesses(name)');

      // Filter based on user role
      if (userRole === 'client') {
        query = query.eq('client_id', userId);
      } else if (userRole === 'delivery') {
        // For delivery, show orders assigned to them OR available orders (ready and unassigned)
        query = query.or(`delivery_person_id.eq.${userId},and(delivery_person_id.is.null,status.eq.ready)`);
      } else if (userRole === 'business') {
        // For business, we need to join with businesses table
        const { data: business } = await supabase
          .from('businesses')
          .select('id')
          .eq('user_id', userId)
          .single();
        
        if (business) {
          query = query.eq('business_id', business.id);
        }
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      
      // OPTIMIZACIÓN: Batch query para perfiles de clientes (elimina N+1)
      const clientIds = [...new Set(data.map(o => o.client_id))];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, name, phone, address')
        .in('id', clientIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);
      
      return data.map((order) => {
        const baseOrder = dbOrderToOrder(order);
        const clientProfile = profileMap.get(order.client_id);
        const manualName = (order as any).manual_client_name as string | null;
        const manualPhone = (order as any).manual_client_phone as string | null;
        const clientInfo = manualName
          ? {
              id: order.client_id,
              name: manualName,
              phone: manualPhone || undefined,
              address: undefined,
            }
          : clientProfile
          ? {
              id: clientProfile.id,
              name: clientProfile.name,
              phone: clientProfile.phone || undefined,
              address: clientProfile.address || undefined,
            }
          : undefined;
        return {
          ...baseOrder,
          businessName: (order as any).businesses?.name || undefined,
          clientInfo,
        };
      });
    },
    enabled: !!userId,
    staleTime: 30000, // 30 segundos de cache
    refetchOnWindowFocus: false,
  });

  // Real-time subscription filtered by role to reduce websocket traffic
  useEffect(() => {
    if (!userId) return;

    // Build role-specific filter to avoid receiving unrelated order changes
    let filter: string | undefined;
    if (userRole === 'client') {
      filter = `client_id=eq.${userId}`;
    } else if (userRole === 'delivery') {
      filter = `delivery_person_id=eq.${userId}`;
    }
    // For business/admin we need broader visibility, so no server-side filter
    // but we still scope the channel name to avoid conflicts

    const channelName = `orders-${userRole}-${userId}`;
    const subscriptionConfig: any = {
      event: '*' as const,
      schema: 'public',
      table: 'orders',
      ...(filter ? { filter } : {}),
    };

    const channel = supabase
      .channel(channelName)
      .on('postgres_changes', subscriptionConfig, () => {
        // Only invalidate this user's specific query key
        queryClient.invalidateQueries({ queryKey: ['orders', userId, userRole] });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, userRole, queryClient]);

  const createOrder = useMutation({
    mutationFn: async (order: OrderInsert) => {
      const { data, error } = await supabase
        .from('orders')
        .insert(order)
        .select('*, businesses(name)')
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: async (data) => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      
      // Send push notification to admins and business owner
      try {
        const businessName = data.businesses?.name || 'Negocio';
        await supabase.functions.invoke('send-push-notification', {
          body: {
            orderId: data.id,
            orderNumber: data.order_number,
            businessName,
            businessId: data.business_id, // Include business ID to notify the business owner
          },
        });
        console.log('[useOrders] Push notification sent for order:', data.order_number);
      } catch (pushError) {
        console.error('[useOrders] Error sending push notification:', pushError);
        // Don't fail the order creation if push fails
      }
      
      toast({
        title: 'Orden creada',
        description: 'Tu orden ha sido enviada',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateOrder = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string } & Partial<OrderUpdate>) => {
      const { error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast({
        title: 'Orden actualizada',
        description: 'El estado de la orden ha sido actualizado',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteOrder = useMutation({
    mutationFn: async (orderId: string) => {
      const { error } = await supabase
        .from('orders')
        .delete()
        .eq('id', orderId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast({
        title: 'Pedido eliminado',
        description: 'El pedido ha sido eliminado correctamente',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error al eliminar',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    orders,
    isLoading,
    createOrder: createOrder.mutateAsync,
    updateOrder: updateOrder.mutateAsync,
    deleteOrder: deleteOrder.mutateAsync,
  };
}
