import { useEffect, useRef, useCallback, useState } from 'react';
import { Order } from '@/types';

export const useOrderSound = (
  orders: Order[], 
  isEnabled: boolean,
  soundFile: string = '/sounds/new-order-alert.mp3',
  volume: number = 0.7
) => {
  const previousOrderIds = useRef<Set<string>>(new Set());
  const isInitialized = useRef(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const stopAlertSound = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsPlaying(false);
    console.log('[useOrderSound] Alert sound stopped manually');
  }, []);

  const playAlertSound = useCallback(() => {
    try {
      // Stop any currently playing sound
      stopAlertSound();

      // Create audio element with custom MP3
      const audio = new Audio(soundFile);
      audio.volume = volume;
      audio.loop = true; // Enable looping
      audioRef.current = audio;

      // Play the sound in a loop
      audio.play().then(() => {
        setIsPlaying(true);
        console.log('[useOrderSound] Alert sound started (30 second loop)');
        
        // Stop after 30 seconds
        timeoutRef.current = setTimeout(() => {
          stopAlertSound();
          console.log('[useOrderSound] Alert sound stopped after 30 seconds');
        }, 30000);
      }).catch((error) => {
        console.error('[useOrderSound] Error playing sound:', error);
        setIsPlaying(false);
      });
    } catch (error) {
      console.error('[useOrderSound] Error creating audio:', error);
    }
  }, [stopAlertSound, soundFile, volume]);

  useEffect(() => {
    if (!isEnabled) return;

    const currentOrderIds = new Set(orders.map(o => o.id));

    // Skip first render to avoid playing sound on initial load
    if (!isInitialized.current) {
      previousOrderIds.current = currentOrderIds;
      isInitialized.current = true;
      console.log('[useOrderSound] Initialized with', currentOrderIds.size, 'orders');
      return;
    }

    // Check for new orders (orders that weren't in the previous set)
    const newOrders = orders.filter(o => !previousOrderIds.current.has(o.id));

    if (newOrders.length > 0) {
      console.log('[useOrderSound] New orders detected:', newOrders.length);
      playAlertSound();
    }

    previousOrderIds.current = currentOrderIds;
  }, [orders, isEnabled, playAlertSound]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, []);

  return { playAlertSound, stopAlertSound, isPlaying };
};
