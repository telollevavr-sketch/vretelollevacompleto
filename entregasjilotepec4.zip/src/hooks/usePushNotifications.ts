import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

const VAPID_PUBLIC_KEY = 'BPJ1XCZXOrCCoy_75LXfjwdyOEvM97W2SWtH062vsjDVEMZwf_VBFrkSF73qlKLK8pzEdafR6cEQ6OTiseRJe9c';

// Convert VAPID key to Uint8Array
function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export const usePushNotifications = (userId?: string) => {
  const { toast } = useToast();
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);

  // Check if push notifications are supported
  useEffect(() => {
    const supported = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
    setIsSupported(supported);
    
    if (supported) {
      setPermission(Notification.permission);
    }
  }, []);

  // Check existing subscription
  useEffect(() => {
    const checkSubscription = async () => {
      if (!userId || !isSupported) {
        setIsLoading(false);
        return;
      }

      try {
        const registration = await navigator.serviceWorker.ready;
        const subscription = await (registration as any).pushManager.getSubscription();
        
        if (subscription) {
          // Verify it's in the database
          const { data } = await supabase
            .from('push_subscriptions')
            .select('id')
            .eq('user_id', userId)
            .eq('endpoint', subscription.endpoint)
            .single();
          
          setIsSubscribed(!!data);
        } else {
          setIsSubscribed(false);
        }
      } catch (error) {
        console.error('[usePushNotifications] Error checking subscription:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkSubscription();
  }, [userId, isSupported]);

  const subscribe = useCallback(async () => {
    if (!userId || !isSupported) {
      toast({
        title: 'Error',
        description: 'Las notificaciones push no están soportadas en este navegador',
        variant: 'destructive',
      });
      return false;
    }

    try {
      setIsLoading(true);

      // Request permission if needed
      if (Notification.permission === 'default') {
        const result = await Notification.requestPermission();
        setPermission(result);
        
        if (result !== 'granted') {
          toast({
            title: 'Permiso denegado',
            description: 'Necesitas permitir las notificaciones para recibir alertas',
            variant: 'destructive',
          });
          return false;
        }
      } else if (Notification.permission === 'denied') {
        toast({
          title: 'Notificaciones bloqueadas',
          description: 'Las notificaciones están bloqueadas. Habilítalas en la configuración del navegador.',
          variant: 'destructive',
        });
        return false;
      }

      // Get service worker registration
      const registration = await navigator.serviceWorker.ready;

      // Subscribe to push
      const subscription = await (registration as any).pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });

      const subscriptionJSON = subscription.toJSON();

      // Save to database
      const { error } = await supabase.from('push_subscriptions').upsert({
        user_id: userId,
        endpoint: subscriptionJSON.endpoint!,
        p256dh: subscriptionJSON.keys!.p256dh,
        auth: subscriptionJSON.keys!.auth,
      }, {
        onConflict: 'user_id,endpoint',
      });

      if (error) throw error;

      setIsSubscribed(true);
      toast({
        title: 'Notificaciones activadas',
        description: 'Recibirás alertas cuando lleguen nuevos pedidos',
      });

      console.log('[usePushNotifications] Subscribed successfully');
      return true;
    } catch (error: any) {
      console.error('[usePushNotifications] Error subscribing:', error);
      toast({
        title: 'Error',
        description: 'No se pudo activar las notificaciones',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [userId, isSupported, toast]);

  const unsubscribe = useCallback(async () => {
    if (!userId) return false;

    try {
      setIsLoading(true);

      const registration = await navigator.serviceWorker.ready;
      const subscription = await (registration as any).pushManager.getSubscription();

      if (subscription) {
        // Unsubscribe from push
        await subscription.unsubscribe();

        // Remove from database
        await supabase
          .from('push_subscriptions')
          .delete()
          .eq('user_id', userId)
          .eq('endpoint', subscription.endpoint);
      }

      setIsSubscribed(false);
      toast({
        title: 'Notificaciones desactivadas',
        description: 'Ya no recibirás alertas de nuevos pedidos',
      });

      console.log('[usePushNotifications] Unsubscribed successfully');
      return true;
    } catch (error: any) {
      console.error('[usePushNotifications] Error unsubscribing:', error);
      toast({
        title: 'Error',
        description: 'No se pudo desactivar las notificaciones',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [userId, toast]);

  const toggle = useCallback(async () => {
    if (isSubscribed) {
      return unsubscribe();
    } else {
      return subscribe();
    }
  }, [isSubscribed, subscribe, unsubscribe]);

  return {
    isSubscribed,
    isLoading,
    permission,
    isSupported,
    subscribe,
    unsubscribe,
    toggle,
  };
};
