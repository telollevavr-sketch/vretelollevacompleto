import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';
import { Business } from '@/types';
import { dbBusinessToBusiness } from '@/lib/typeConversions';
import { useAuth } from '@/contexts/AuthContext';

type DbBusiness = Database['public']['Tables']['businesses']['Row'];
type BusinessInsert = Database['public']['Tables']['businesses']['Insert'];
type BusinessUpdate = Database['public']['Tables']['businesses']['Update'];

export function useBusinesses(options?: { skipMyBusiness?: boolean }) {
  const skipMyBusiness = options?.skipMyBusiness ?? false;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { loading: authLoading } = useAuth();

  const { data: businesses = [], isLoading, isError: isErrorBusinesses, refetch: refetchBusinesses } = useQuery<Business[]>({
    queryKey: ['businesses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('businesses')
        .select('id, user_id, name, category, description, address, full_address, latitude, longitude, phone, image_url, rating, review_count, is_open, is_coming_soon, weather_unavailable, delivery_time_minutes, min_order_amount, delivery_fee, is_active, is_special_business, free_delivery, delivery_tracking_enabled, auto_schedule_enabled, business_days, business_hours, max_delivery_distance_km, business_type, business_type_id, accepts_cash, accepts_transfer, opening_time, closing_time, created_at, updated_at')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      return (data as DbBusiness[]).map(dbBusinessToBusiness);
    },
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const { data: myBusiness, isLoading: isLoadingMyBusiness } = useQuery<Business | null>({
    queryKey: ['my-business'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from('businesses')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data ? dbBusinessToBusiness(data as DbBusiness) : null;
    },
    enabled: !skipMyBusiness,
    refetchOnWindowFocus: false,
  });

  const createBusiness = useMutation({
    mutationFn: async (business: BusinessInsert) => {
      const { data, error } = await supabase
        .from('businesses')
        .insert(business)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['businesses'] });
      queryClient.invalidateQueries({ queryKey: ['my-business'] });
      toast({
        title: 'Negocio creado',
        description: 'El negocio ha sido creado exitosamente',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateBusiness = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: BusinessUpdate }) => {
      const { data, error } = await supabase
        .from('businesses')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['businesses'] });
      queryClient.invalidateQueries({ queryKey: ['my-business'] });
      toast({
        title: 'Negocio actualizado',
        description: 'Los cambios han sido guardados',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    businesses,
    myBusiness,
    isLoading: isLoading || (!skipMyBusiness && isLoadingMyBusiness),
    isError: isErrorBusinesses,
    refetch: refetchBusinesses,
    createBusiness: createBusiness.mutate,
    updateBusiness: updateBusiness.mutate,
  };
}
