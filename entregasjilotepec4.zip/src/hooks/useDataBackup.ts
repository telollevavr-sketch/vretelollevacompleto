import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface TableStats {
  name: string;
  displayName: string;
  count: number;
  estimatedSize: string;
  importance: 'alta' | 'media' | 'baja';
}

export interface BackupData {
  profiles: any[];
  businesses: any[];
  products: any[];
  orders: any[];
  userRoles: any[];
  categories: any[];
  businessTypes: any[];
  pizzaSpecialties: any[];
  productComplements: any[];
  complementTemplates: any[];
  businessMenuImages: any[];
  businessPromotions: any[];
  notifications: any[];
  orderMessages: any[];
}

export interface BackupResult {
  data: BackupData;
  stats: TableStats[];
  isLoading: boolean;
  progress: number;
  error: string | null;
  fetchAllData: (includeImages?: boolean) => Promise<BackupData | null>;
}

const TABLE_CONFIG = [
  { key: 'profiles', table: 'profiles', displayName: 'Perfiles de Usuario', importance: 'alta' as const },
  { key: 'userRoles', table: 'user_roles', displayName: 'Roles de Usuario', importance: 'alta' as const },
  { key: 'categories', table: 'categories', displayName: 'Categorías', importance: 'media' as const },
  { key: 'businessTypes', table: 'business_types', displayName: 'Tipos de Negocio', importance: 'media' as const },
  { key: 'businesses', table: 'businesses', displayName: 'Negocios', importance: 'alta' as const },
  { key: 'products', table: 'products', displayName: 'Productos', importance: 'alta' as const },
  { key: 'productComplements', table: 'product_complements', displayName: 'Complementos de Producto', importance: 'media' as const },
  { key: 'complementTemplates', table: 'complement_templates', displayName: 'Plantillas de Complementos', importance: 'baja' as const },
  { key: 'pizzaSpecialties', table: 'pizza_specialties', displayName: 'Especialidades de Pizza', importance: 'media' as const },
  { key: 'orders', table: 'orders', displayName: 'Pedidos', importance: 'alta' as const },
  { key: 'orderMessages', table: 'order_messages', displayName: 'Mensajes de Pedidos', importance: 'baja' as const },
  { key: 'notifications', table: 'notifications', displayName: 'Notificaciones', importance: 'baja' as const },
  { key: 'businessMenuImages', table: 'business_menu_images', displayName: 'Imágenes de Menú', importance: 'media' as const },
  { key: 'businessPromotions', table: 'business_promotions', displayName: 'Promociones', importance: 'baja' as const },
];

const estimateSize = (data: any[], includeImages: boolean): string => {
  const jsonString = JSON.stringify(data);
  let bytes = new Blob([jsonString]).size;
  
  // Si no incluimos imágenes, restamos el tamaño estimado de los campos de imagen
  if (!includeImages) {
    data.forEach(item => {
      if (item.image_data) {
        bytes -= new Blob([item.image_data]).size;
      }
    });
  }
  
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};

export const useDataBackup = (): BackupResult => {
  const [data, setData] = useState<BackupData>({
    profiles: [],
    businesses: [],
    products: [],
    orders: [],
    userRoles: [],
    categories: [],
    businessTypes: [],
    pizzaSpecialties: [],
    productComplements: [],
    complementTemplates: [],
    businessMenuImages: [],
    businessPromotions: [],
    notifications: [],
    orderMessages: [],
  });
  
  const [stats, setStats] = useState<TableStats[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const fetchTableData = async (tableName: string): Promise<any[]> => {
    try {
      const allData: any[] = [];
      let from = 0;
      const pageSize = 1000;
      let hasMore = true;

      while (hasMore) {
        const { data: pageData, error } = await (supabase
          .from(tableName as any)
          .select('*')
          .range(from, from + pageSize - 1) as any);

        if (error) {
          console.error(`Error en ${tableName}:`, error.message);
          return [];
        }

        if (pageData && pageData.length > 0) {
          allData.push(...pageData);
          from += pageSize;
          hasMore = pageData.length === pageSize;
        } else {
          hasMore = false;
        }
      }

      console.log(`${tableName}: ${allData.length} registros`);
      return allData;
    } catch (err) {
      console.error(`Excepción en ${tableName}:`, err);
      return [];
    }
  };

  const fetchAllData = useCallback(async (includeImages: boolean = true): Promise<BackupData | null> => {
    setIsLoading(true);
    setProgress(0);
    setError(null);

    const newData: BackupData = {
      profiles: [],
      businesses: [],
      products: [],
      orders: [],
      userRoles: [],
      categories: [],
      businessTypes: [],
      pizzaSpecialties: [],
      productComplements: [],
      complementTemplates: [],
      businessMenuImages: [],
      businessPromotions: [],
      notifications: [],
      orderMessages: [],
    };

    const newStats: TableStats[] = [];
    const totalTables = TABLE_CONFIG.length;

    try {
      for (let i = 0; i < TABLE_CONFIG.length; i++) {
        const config = TABLE_CONFIG[i];
        
        try {
          const tableData = await fetchTableData(config.table);
          
          // Si no incluimos imágenes, limpiamos los campos de imagen
          let processedData = tableData;
          if (!includeImages && (config.table === 'business_menu_images' || config.table === 'business_promotions')) {
            processedData = tableData.map(item => ({
              ...item,
              image_data: '[IMAGEN_EXCLUIDA]'
            }));
          }
          
          // Use type assertion for dynamic key assignment
          const dataKey = config.key as keyof BackupData;
          newData[dataKey] = processedData as any;
          
          newStats.push({
            name: config.table,
            displayName: config.displayName,
            count: tableData.length,
            estimatedSize: estimateSize(processedData, includeImages),
            importance: config.importance,
          });
        } catch (tableError) {
          console.error(`Error fetching ${config.table}:`, tableError);
          newStats.push({
            name: config.table,
            displayName: config.displayName,
            count: 0,
            estimatedSize: 'Error',
            importance: config.importance,
          });
        }
        
        setProgress(Math.round(((i + 1) / totalTables) * 100));
      }

      setData(newData);
      setStats(newStats);
      setIsLoading(false);
      return newData;
    } catch (err) {
      console.error('Error fetching backup data:', err);
      setError('Error al obtener datos para respaldo');
      setIsLoading(false);
      return null;
    }
  }, []);

  return {
    data,
    stats,
    isLoading,
    progress,
    error,
    fetchAllData,
  };
};
