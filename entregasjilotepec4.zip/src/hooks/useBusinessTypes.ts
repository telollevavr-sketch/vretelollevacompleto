import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';

type DbBusinessType = Database['public']['Tables']['business_types']['Row'];
type BusinessTypeInsert = Database['public']['Tables']['business_types']['Insert'];
type BusinessTypeUpdate = Database['public']['Tables']['business_types']['Update'];

export function useBusinessTypes() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: businessTypes = [], isLoading } = useQuery({
    queryKey: ['business-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('business_types')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      return data as DbBusinessType[];
    },
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const { data: allBusinessTypes = [], isLoading: isLoadingAll } = useQuery({
    queryKey: ['all-business-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('business_types')
        .select('*')
        .order('name');

      if (error) throw error;
      return data as DbBusinessType[];
    },
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const createBusinessType = useMutation({
    mutationFn: async (businessType: BusinessTypeInsert) => {
      const { data, error } = await supabase
        .from('business_types')
        .insert(businessType)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-types'] });
      queryClient.invalidateQueries({ queryKey: ['all-business-types'] });
      toast({
        title: 'Tipo de negocio creado',
        description: 'El tipo de negocio ha sido agregado exitosamente',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateBusinessType = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: BusinessTypeUpdate }) => {
      const { data, error } = await supabase
        .from('business_types')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-types'] });
      queryClient.invalidateQueries({ queryKey: ['all-business-types'] });
      toast({
        title: 'Tipo de negocio actualizado',
        description: 'Los cambios han sido guardados',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteBusinessType = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('business_types')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-types'] });
      queryClient.invalidateQueries({ queryKey: ['all-business-types'] });
      toast({
        title: 'Tipo de negocio eliminado',
        description: 'El tipo de negocio ha sido removido',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    businessTypes,
    allBusinessTypes,
    isLoading: isLoading || isLoadingAll,
    createBusinessType: createBusinessType.mutate,
    updateBusinessType: updateBusinessType.mutate,
    deleteBusinessType: deleteBusinessType.mutate,
  };
}
