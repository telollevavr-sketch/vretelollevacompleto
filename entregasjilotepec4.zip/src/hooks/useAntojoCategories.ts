import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface AntojoCategory {
  id: string;
  name: string;
  icon: string | null;
  is_active: boolean;
  created_at: string;
}

export const useAntojoCategories = () => {
  const queryClient = useQueryClient();

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['antojo-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('antojo_categories')
        .select('*')
        .order('name');
      if (error) throw error;
      return data as AntojoCategory[];
    },
    staleTime: 120000,
  });

  const createCategory = useMutation({
    mutationFn: async (cat: { name: string; icon?: string }) => {
      const { data, error } = await supabase
        .from('antojo_categories')
        .insert(cat)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-categories'] });
      toast({ title: 'Categoría creada' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const updateCategory = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<AntojoCategory> & { id: string }) => {
      const { data, error } = await supabase
        .from('antojo_categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-categories'] });
      toast({ title: 'Categoría actualizada' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const deleteCategory = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('antojo_categories')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-categories'] });
      toast({ title: 'Categoría eliminada' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  return {
    categories,
    isLoading,
    createCategory: createCategory.mutate,
    updateCategory: updateCategory.mutate,
    deleteCategory: deleteCategory.mutate,
  };
};
