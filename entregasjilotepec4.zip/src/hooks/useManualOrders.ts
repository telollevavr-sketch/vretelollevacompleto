import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export const MANUAL_ORDERS_PAGE_SIZE = 20;

export type ManualOrderRow = {
  id: string;
  order_number: string;
  created_at: string;
  total: number;
  manual_client_name: string | null;
  manual_client_phone: string | null;
  notes: string | null;
  business_id: string;
  businessName?: string;
};

export function useManualOrders(search: string, page: number) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const term = search.trim();

  const query = useQuery({
    queryKey: ['manual-orders', term, page],
    queryFn: async () => {
      let q = supabase
        .from('orders')
        .select(
          'id, order_number, created_at, total, manual_client_name, manual_client_phone, notes, business_id, businesses(name)'
        )
        .or('manual_client_name.not.is.null,notes.ilike.%[CAPTURA MANUAL ADMIN]%');

      if (term) {
        const safe = term.replace(/[,%]/g, ' ');
        q = q.or(
          `order_number.ilike.%${safe}%,manual_client_name.ilike.%${safe}%,manual_client_phone.ilike.%${safe}%`
        );
      }

      const from = page * MANUAL_ORDERS_PAGE_SIZE;
      const { data, error } = await q
        .order('created_at', { ascending: false })
        .range(from, from + MANUAL_ORDERS_PAGE_SIZE - 1);

      if (error) throw error;

      return (data || []).map((o: any) => ({
        id: o.id,
        order_number: o.order_number,
        created_at: o.created_at,
        total: Number(o.total || 0),
        manual_client_name: o.manual_client_name,
        manual_client_phone: o.manual_client_phone,
        notes: o.notes,
        business_id: o.business_id,
        businessName: o.businesses?.name || undefined,
      })) as ManualOrderRow[];
    },
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  const updateClient = useMutation({
    mutationFn: async ({
      id,
      name,
      phone,
    }: {
      id: string;
      name: string;
      phone: string | null;
    }) => {
      const { error } = await supabase
        .from('orders')
        .update({ manual_client_name: name, manual_client_phone: phone })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['manual-orders'] });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      toast({ title: 'Pedido actualizado', description: 'Se guardaron los datos del cliente' });
    },
    onError: (e: any) => {
      toast({ title: 'Error al guardar', description: e.message, variant: 'destructive' });
    },
  });

  return {
    orders: query.data || [],
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    updateClient: updateClient.mutateAsync,
    isUpdating: updateClient.isPending,
  };
}
