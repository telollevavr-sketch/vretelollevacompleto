import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function useProductComplementCounts(businessId?: string) {
  const { data: counts = {}, isLoading } = useQuery({
    queryKey: ['product-complement-counts', businessId],
    queryFn: async () => {
      if (!businessId) return {};

      // Get all products for this business
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('id')
        .eq('business_id', businessId);

      if (productsError) throw productsError;
      if (!products || products.length === 0) return {};

      const productIds = products.map(p => p.id);

      // Get complement counts grouped by product_id
      const { data, error } = await supabase
        .from('product_complements')
        .select('product_id')
        .in('product_id', productIds);

      if (error) throw error;

      // Count complements per product
      const countsMap: Record<string, number> = {};
      productIds.forEach(id => {
        countsMap[id] = 0;
      });

      data?.forEach(complement => {
        countsMap[complement.product_id] = (countsMap[complement.product_id] || 0) + 1;
      });

      return countsMap;
    },
    enabled: !!businessId,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  return {
    counts,
    isLoading,
  };
}
