import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface BusinessSchedule {
  id: string;
  businessId: string;
  dayOfWeek: number; // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  isOpen: boolean;
  openingTime: string; // Format: "HH:MM:SS"
  closingTime: string; // Format: "HH:MM:SS"
  createdAt: string;
  updatedAt: string;
}

interface DbBusinessSchedule {
  id: string;
  business_id: string;
  day_of_week: number;
  is_open: boolean;
  opening_time: string;
  closing_time: string;
  created_at: string;
  updated_at: string;
}

const DAY_NAMES = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

function dbToSchedule(db: DbBusinessSchedule): BusinessSchedule {
  return {
    id: db.id,
    businessId: db.business_id,
    dayOfWeek: db.day_of_week,
    isOpen: db.is_open,
    openingTime: db.opening_time,
    closingTime: db.closing_time,
    createdAt: db.created_at,
    updatedAt: db.updated_at,
  };
}

export function useBusinessSchedules(businessId: string | undefined) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: schedules = [], isLoading } = useQuery<BusinessSchedule[]>({
    queryKey: ['business-schedules', businessId],
    queryFn: async () => {
      if (!businessId) return [];

      const { data, error } = await supabase
        .from('business_schedules')
        .select('*')
        .eq('business_id', businessId)
        .order('day_of_week');

      if (error) throw error;
      return (data as DbBusinessSchedule[]).map(dbToSchedule);
    },
    enabled: !!businessId,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const upsertSchedule = useMutation({
    mutationFn: async (schedule: {
      businessId: string;
      dayOfWeek: number;
      isOpen: boolean;
      openingTime: string;
      closingTime: string;
    }) => {
      const { data, error } = await supabase
        .from('business_schedules')
        .upsert({
          business_id: schedule.businessId,
          day_of_week: schedule.dayOfWeek,
          is_open: schedule.isOpen,
          opening_time: schedule.openingTime,
          closing_time: schedule.closingTime,
        }, {
          onConflict: 'business_id,day_of_week'
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-schedules', businessId] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const upsertAllSchedules = useMutation({
    mutationFn: async (schedules: {
      businessId: string;
      dayOfWeek: number;
      isOpen: boolean;
      openingTime: string;
      closingTime: string;
    }[]) => {
      const { data, error } = await supabase
        .from('business_schedules')
        .upsert(
          schedules.map(s => ({
            business_id: s.businessId,
            day_of_week: s.dayOfWeek,
            is_open: s.isOpen,
            opening_time: s.openingTime,
            closing_time: s.closingTime,
          })),
          { onConflict: 'business_id,day_of_week' }
        )
        .select();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-schedules', businessId] });
      toast({
        title: 'Horarios Guardados',
        description: 'Los horarios se han actualizado correctamente',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteSchedule = useMutation({
    mutationFn: async (scheduleId: string) => {
      const { error } = await supabase
        .from('business_schedules')
        .delete()
        .eq('id', scheduleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-schedules', businessId] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    schedules,
    isLoading,
    upsertSchedule: upsertSchedule.mutate,
    upsertAllSchedules: upsertAllSchedules.mutate,
    deleteSchedule: deleteSchedule.mutate,
    isUpdating: upsertSchedule.isPending || upsertAllSchedules.isPending,
    DAY_NAMES,
  };
}
