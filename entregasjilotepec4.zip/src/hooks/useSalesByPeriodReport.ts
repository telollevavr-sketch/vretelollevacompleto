import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfWeek, startOfMonth, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export type GroupBy = 'day' | 'week' | 'month';

export interface SalesPeriodItem {
  period: string;
  periodLabel: string;
  totalOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  pendingOrders: number;
  grossSales: number;
  deliveryFees: number;
  netSales: number;
  averageTicket: number;
}

interface UseSalesByPeriodReportParams {
  startDate?: Date;
  endDate?: Date;
  groupBy: GroupBy;
  businessId?: string;
  status?: string;
}

export function useSalesByPeriodReport({
  startDate,
  endDate,
  groupBy,
  businessId,
  status,
}: UseSalesByPeriodReportParams) {
  const { data: reportData = [], isLoading } = useQuery({
    queryKey: ['sales-by-period', startDate?.toISOString(), endDate?.toISOString(), groupBy, businessId, status],
    queryFn: async () => {
      let query = supabase
        .from('orders')
        .select('id, created_at, status, subtotal, delivery_fee, total, business_id');

      if (startDate) {
        query = query.gte('created_at', startDate.toISOString());
      }
      if (endDate) {
        query = query.lte('created_at', endDate.toISOString());
      }
      if (businessId) {
        query = query.eq('business_id', businessId);
      }
      if (status && status !== 'all') {
        query = query.eq('status', status as 'pending' | 'accepted' | 'preparing' | 'ready' | 'in_delivery' | 'delivered' | 'cancelled');
      }

      const { data: orders, error } = await query.order('created_at', { ascending: true });

      if (error) throw error;

      // Group orders by period
      const groupedData = new Map<string, SalesPeriodItem>();

      (orders || []).forEach(order => {
        const orderDate = parseISO(order.created_at);
        let periodKey: string;
        let periodLabel: string;

        switch (groupBy) {
          case 'week':
            const weekStart = startOfWeek(orderDate, { weekStartsOn: 1 });
            periodKey = format(weekStart, 'yyyy-MM-dd');
            periodLabel = `Sem. ${format(weekStart, 'dd MMM yyyy', { locale: es })}`;
            break;
          case 'month':
            const monthStart = startOfMonth(orderDate);
            periodKey = format(monthStart, 'yyyy-MM');
            periodLabel = format(monthStart, 'MMMM yyyy', { locale: es });
            break;
          default: // day
            periodKey = format(orderDate, 'yyyy-MM-dd');
            periodLabel = format(orderDate, 'dd MMM yyyy', { locale: es });
        }

        const existing = groupedData.get(periodKey) || {
          period: periodKey,
          periodLabel,
          totalOrders: 0,
          deliveredOrders: 0,
          cancelledOrders: 0,
          pendingOrders: 0,
          grossSales: 0,
          deliveryFees: 0,
          netSales: 0,
          averageTicket: 0,
        };

        existing.totalOrders += 1;
        
        if (order.status === 'delivered') {
          existing.deliveredOrders += 1;
          existing.grossSales += Number(order.subtotal) || 0;
          existing.deliveryFees += Number(order.delivery_fee) || 0;
          existing.netSales += Number(order.total) || 0;
        } else if (order.status === 'cancelled') {
          existing.cancelledOrders += 1;
        } else {
          existing.pendingOrders += 1;
        }

        groupedData.set(periodKey, existing);
      });

      // Calculate averages
      const result = Array.from(groupedData.values()).map(item => ({
        ...item,
        averageTicket: item.deliveredOrders > 0 ? item.netSales / item.deliveredOrders : 0,
      }));

      return result.sort((a, b) => a.period.localeCompare(b.period));
    },
    staleTime: 120000,
    refetchOnWindowFocus: false,
  });

  const totals = reportData.reduce(
    (acc, item) => ({
      totalOrders: acc.totalOrders + item.totalOrders,
      deliveredOrders: acc.deliveredOrders + item.deliveredOrders,
      cancelledOrders: acc.cancelledOrders + item.cancelledOrders,
      pendingOrders: acc.pendingOrders + item.pendingOrders,
      grossSales: acc.grossSales + item.grossSales,
      deliveryFees: acc.deliveryFees + item.deliveryFees,
      netSales: acc.netSales + item.netSales,
    }),
    {
      totalOrders: 0,
      deliveredOrders: 0,
      cancelledOrders: 0,
      pendingOrders: 0,
      grossSales: 0,
      deliveryFees: 0,
      netSales: 0,
    }
  );

  return {
    reportData,
    isLoading,
    totals: {
      ...totals,
      averageTicket: totals.deliveredOrders > 0 ? totals.netSales / totals.deliveredOrders : 0,
    },
  };
}
