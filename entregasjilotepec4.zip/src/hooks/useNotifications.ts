import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from './use-toast';
import type { Database } from '@/integrations/supabase/types';

type DbNotification = Database['public']['Tables']['notifications']['Row'];
type DbNotificationInsert = Database['public']['Tables']['notifications']['Insert'];

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message: string;
  is_read: boolean;
  order_id?: string;
  created_at: string;
}

export const useNotifications = (userId?: string) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications', userId],
    queryFn: async () => {
      if (!userId) return [];
      
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return data as Notification[];
    },
    enabled: !!userId,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  // Real-time subscription for notifications
  useEffect(() => {
    if (!userId) return;

    const channel = supabase
      .channel(`notifications-${userId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          queryClient.invalidateQueries({ queryKey: ['notifications', userId] });
          
          // Show toast for new notifications
          if (payload.eventType === 'INSERT') {
            const newNotif = payload.new as any;
            toast({
              title: newNotif.title,
              description: newNotif.message,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, queryClient, toast]);

  const createNotification = useMutation({
    mutationFn: async (notification: {
      user_id: string;
      type: string;
      title: string;
      message: string;
      is_read: boolean;
      order_id?: string;
    }) => {
      console.log('📬 [NOTIFICATIONS] Intentando crear notificación:', {
        ...notification,
        timestamp: new Date().toISOString()
      });
      
      const { data, error } = await supabase
        .from('notifications')
        .insert([notification as DbNotificationInsert])
        .select()
        .single();

      if (error) {
        console.error('❌ [NOTIFICATIONS] Error al crear notificación:', {
          error,
          code: error.code,
          message: error.message,
          details: error.details,
          hint: error.hint,
          notification
        });
        throw error;
      }
      
      console.log('✅ [NOTIFICATIONS] Notificación creada exitosamente:', data);
      return data;
    },
    onSuccess: (data) => {
      console.log('🔄 [NOTIFICATIONS] Invalidando queries de notificaciones para user:', data.user_id);
      queryClient.invalidateQueries({ queryKey: ['notifications', data.user_id] });
    },
    onError: (error: any) => {
      console.error('❌ [NOTIFICATIONS] Error en mutation:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      toast({
        title: "Error al crear notificación",
        description: error.message || "No se pudo crear la notificación",
        variant: "destructive"
      });
    }
  });

  const markAsRead = useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', userId] });
    }
  });

  const markAllAsRead = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', userId)
        .eq('is_read', false);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', userId] });
    }
  });

  return {
    notifications,
    isLoading,
    createNotification: createNotification.mutate,
    createNotificationAsync: createNotification.mutateAsync,
    markAsRead: markAsRead.mutate,
    markAllAsRead: markAllAsRead.mutate,
    isCreating: createNotification.isPending,
  };
};
