import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface SalesByBusinessItem {
  businessId: string;
  businessName: string;
  category: string;
  isActive: boolean;
  productCount: number;
  totalOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  pendingOrders: number;
  totalSales: number;
  averageTicket: number;
  rating: number;
  reviewCount: number;
}

interface UseSalesByBusinessReportParams {
  searchTerm?: string;
  category?: string;
  isActive?: boolean | null;
  startDate?: Date;
  endDate?: Date;
}

export function useSalesByBusinessReport({
  searchTerm,
  category,
  isActive,
  startDate,
  endDate,
}: UseSalesByBusinessReportParams = {}) {
  const { data: reportData = [], isLoading } = useQuery({
    queryKey: ['sales-by-business', searchTerm, category, isActive, startDate?.toISOString(), endDate?.toISOString()],
    queryFn: async () => {
      // Fetch all businesses
      let businessesQuery = supabase
        .from('businesses')
        .select('id, name, category, is_active, rating, review_count');

      if (category) {
        businessesQuery = businessesQuery.eq('category', category);
      }
      if (isActive !== null && isActive !== undefined) {
        businessesQuery = businessesQuery.eq('is_active', isActive);
      }

      const { data: businesses, error: businessesError } = await businessesQuery;

      if (businessesError) throw businessesError;

      // Fetch products count per business
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('id, business_id');

      if (productsError) throw productsError;

      const productCountByBusiness = new Map<string, number>();
      (products || []).forEach(p => {
        const count = productCountByBusiness.get(p.business_id) || 0;
        productCountByBusiness.set(p.business_id, count + 1);
      });

      // Fetch orders with optional date filter
      let ordersQuery = supabase
        .from('orders')
        .select('id, business_id, status, total');

      if (startDate) {
        ordersQuery = ordersQuery.gte('created_at', startDate.toISOString());
      }
      if (endDate) {
        ordersQuery = ordersQuery.lte('created_at', endDate.toISOString());
      }

      const { data: orders, error: ordersError } = await ordersQuery;

      if (ordersError) throw ordersError;

      // Aggregate orders by business
      const ordersByBusiness = new Map<string, { 
        total: number; 
        delivered: number; 
        cancelled: number; 
        pending: number;
        sales: number;
      }>();

      (orders || []).forEach(order => {
        const existing = ordersByBusiness.get(order.business_id) || {
          total: 0,
          delivered: 0,
          cancelled: 0,
          pending: 0,
          sales: 0,
        };

        existing.total += 1;

        if (order.status === 'delivered') {
          existing.delivered += 1;
          existing.sales += Number(order.total) || 0;
        } else if (order.status === 'cancelled') {
          existing.cancelled += 1;
        } else {
          existing.pending += 1;
        }

        ordersByBusiness.set(order.business_id, existing);
      });

      // Build report
      let result: SalesByBusinessItem[] = (businesses || []).map(business => {
        const orderStats = ordersByBusiness.get(business.id) || {
          total: 0,
          delivered: 0,
          cancelled: 0,
          pending: 0,
          sales: 0,
        };

        return {
          businessId: business.id,
          businessName: business.name,
          category: business.category,
          isActive: business.is_active ?? false,
          productCount: productCountByBusiness.get(business.id) || 0,
          totalOrders: orderStats.total,
          deliveredOrders: orderStats.delivered,
          cancelledOrders: orderStats.cancelled,
          pendingOrders: orderStats.pending,
          totalSales: orderStats.sales,
          averageTicket: orderStats.delivered > 0 ? orderStats.sales / orderStats.delivered : 0,
          rating: Number(business.rating) || 0,
          reviewCount: business.review_count || 0,
        };
      });

      // Filter by search term
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        result = result.filter(item => item.businessName.toLowerCase().includes(term));
      }

      return result.sort((a, b) => b.totalSales - a.totalSales);
    },
    staleTime: 120000,
    refetchOnWindowFocus: false,
  });

  // Get unique categories
  const categories = [...new Set(reportData.map(item => item.category))].sort();

  return {
    reportData,
    isLoading,
    categories,
  };
}
