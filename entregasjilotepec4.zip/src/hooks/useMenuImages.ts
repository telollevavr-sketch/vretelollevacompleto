import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface MenuImage {
  id: string;
  businessId: string;
  imageData: string;
  displayOrder: number;
  isActive: boolean;
  createdAt: string;
}

export const useMenuImages = (businessId?: string) => {
  const queryClient = useQueryClient();

  // Fetch menu images
  const { data: menuImages = [], isLoading } = useQuery({
    queryKey: ['menuImages', businessId],
    queryFn: async () => {
      if (!businessId) return [];

      const { data, error } = await supabase
        .from('business_menu_images')
        .select('*')
        .eq('business_id', businessId)
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) throw error;

      return (data || []).map(img => ({
        id: img.id,
        businessId: img.business_id,
        imageData: img.image_data,
        displayOrder: img.display_order,
        isActive: img.is_active,
        createdAt: img.created_at,
      }));
    },
    enabled: !!businessId,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  // Create menu image
  const { mutate: createMenuImage } = useMutation({
    mutationFn: async (data: {
      business_id: string;
      image_data: string;
      display_order?: number;
    }) => {
      const { error } = await supabase.from('business_menu_images').insert([data]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menuImages'] });
      toast({
        title: 'Imagen agregada',
        description: 'La imagen del menú se ha agregado exitosamente',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'No se pudo agregar la imagen: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  // Delete menu image
  const { mutate: deleteMenuImage } = useMutation({
    mutationFn: async (imageId: string) => {
      const { error } = await supabase
        .from('business_menu_images')
        .delete()
        .eq('id', imageId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menuImages'] });
      toast({
        title: 'Imagen eliminada',
        description: 'La imagen del menú se ha eliminado exitosamente',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'No se pudo eliminar la imagen: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    menuImages,
    isLoading,
    createMenuImage,
    deleteMenuImage,
  };
};
