import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface AntojoBusiness {
  id: string;
  name: string;
  address: string;
  phone: string | null;
  latitude: number;
  longitude: number;
  menu_image: string | null;
  menu_text: string | null;
  image_url: string | null;
  category: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useAntojoBusinesses = () => {
  const queryClient = useQueryClient();

  const { data: businesses = [], isLoading, isError, refetch } = useQuery({
    queryKey: ['antojo-businesses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('antojo_businesses')
        .select('*')
        .order('name');
      if (error) throw error;
      return data as AntojoBusiness[];
    },
    staleTime: 60000,
  });

  const createBusiness = useMutation({
    mutationFn: async (business: Omit<AntojoBusiness, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('antojo_businesses')
        .insert(business)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-businesses'] });
      toast({ title: 'Negocio de antojo creado' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const updateBusiness = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<AntojoBusiness> & { id: string }) => {
      const { data, error } = await supabase
        .from('antojo_businesses')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-businesses'] });
      toast({ title: 'Negocio actualizado' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const deleteBusiness = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('antojo_businesses')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antojo-businesses'] });
      toast({ title: 'Negocio eliminado' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  return {
    businesses,
    isLoading,
    isError,
    refetch,
    createBusiness: createBusiness.mutate,
    updateBusiness: updateBusiness.mutate,
    deleteBusiness: deleteBusiness.mutate,
  };
};
