export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      antojo_businesses: {
        Row: {
          address: string
          category: string | null
          created_at: string
          id: string
          image_url: string | null
          is_active: boolean
          latitude: number
          longitude: number
          menu_image: string | null
          menu_text: string | null
          name: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          address: string
          category?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          latitude: number
          longitude: number
          menu_image?: string | null
          menu_text?: string | null
          name: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          address?: string
          category?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          latitude?: number
          longitude?: number
          menu_image?: string | null
          menu_text?: string | null
          name?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      antojo_categories: {
        Row: {
          created_at: string
          icon: string | null
          id: string
          is_active: boolean
          name: string
        }
        Insert: {
          created_at?: string
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
        }
        Update: {
          created_at?: string
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
        }
        Relationships: []
      }
      antojo_orders: {
        Row: {
          antojo_business_id: string | null
          business_latitude: number
          business_longitude: number
          client_id: string
          created_at: string
          custom_business_description: string | null
          custom_business_name: string | null
          delivery_address: string
          delivery_fee: number
          delivery_latitude: number
          delivery_longitude: number
          delivery_person_id: string | null
          id: string
          notes: string | null
          order_description: string | null
          order_image: string | null
          order_number: string
          payment_method: Database["public"]["Enums"]["payment_method"]
          sale_total: number | null
          status: Database["public"]["Enums"]["order_status"]
          total: number | null
          updated_at: string
        }
        Insert: {
          antojo_business_id?: string | null
          business_latitude: number
          business_longitude: number
          client_id: string
          created_at?: string
          custom_business_description?: string | null
          custom_business_name?: string | null
          delivery_address: string
          delivery_fee?: number
          delivery_latitude: number
          delivery_longitude: number
          delivery_person_id?: string | null
          id?: string
          notes?: string | null
          order_description?: string | null
          order_image?: string | null
          order_number: string
          payment_method: Database["public"]["Enums"]["payment_method"]
          sale_total?: number | null
          status?: Database["public"]["Enums"]["order_status"]
          total?: number | null
          updated_at?: string
        }
        Update: {
          antojo_business_id?: string | null
          business_latitude?: number
          business_longitude?: number
          client_id?: string
          created_at?: string
          custom_business_description?: string | null
          custom_business_name?: string | null
          delivery_address?: string
          delivery_fee?: number
          delivery_latitude?: number
          delivery_longitude?: number
          delivery_person_id?: string | null
          id?: string
          notes?: string | null
          order_description?: string | null
          order_image?: string | null
          order_number?: string
          payment_method?: Database["public"]["Enums"]["payment_method"]
          sale_total?: number | null
          status?: Database["public"]["Enums"]["order_status"]
          total?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "antojo_orders_antojo_business_id_fkey"
            columns: ["antojo_business_id"]
            isOneToOne: false
            referencedRelation: "antojo_businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      business_menu_images: {
        Row: {
          business_id: string
          created_at: string | null
          display_order: number | null
          id: string
          image_data: string
          is_active: boolean | null
          updated_at: string | null
        }
        Insert: {
          business_id: string
          created_at?: string | null
          display_order?: number | null
          id?: string
          image_data: string
          is_active?: boolean | null
          updated_at?: string | null
        }
        Update: {
          business_id?: string
          created_at?: string | null
          display_order?: number | null
          id?: string
          image_data?: string
          is_active?: boolean | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "business_menu_images_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      business_promotions: {
        Row: {
          business_id: string
          created_at: string
          description: string | null
          id: string
          image_data: string
          is_active: boolean
          title: string
          updated_at: string
        }
        Insert: {
          business_id: string
          created_at?: string
          description?: string | null
          id?: string
          image_data: string
          is_active?: boolean
          title: string
          updated_at?: string
        }
        Update: {
          business_id?: string
          created_at?: string
          description?: string | null
          id?: string
          image_data?: string
          is_active?: boolean
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "business_promotions_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      business_schedules: {
        Row: {
          business_id: string
          closing_time: string
          created_at: string | null
          day_of_week: number
          id: string
          is_open: boolean | null
          opening_time: string
          updated_at: string | null
        }
        Insert: {
          business_id: string
          closing_time: string
          created_at?: string | null
          day_of_week: number
          id?: string
          is_open?: boolean | null
          opening_time: string
          updated_at?: string | null
        }
        Update: {
          business_id?: string
          closing_time?: string
          created_at?: string | null
          day_of_week?: number
          id?: string
          is_open?: boolean | null
          opening_time?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "business_schedules_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      business_types: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      businesses: {
        Row: {
          accepts_cash: boolean | null
          accepts_transfer: boolean | null
          address: string
          auto_schedule_enabled: boolean | null
          business_days: string | null
          business_hours: string | null
          business_type: Database["public"]["Enums"]["business_type"]
          business_type_id: string | null
          category: string
          closing_time: string | null
          created_at: string
          delivery_fee: number | null
          delivery_time_minutes: number | null
          delivery_tracking_enabled: boolean | null
          description: string | null
          free_delivery: boolean | null
          full_address: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          is_coming_soon: boolean | null
          is_open: boolean | null
          is_special_business: boolean
          latitude: number
          longitude: number
          max_delivery_distance_km: number | null
          min_order_amount: number | null
          name: string
          opening_time: string | null
          phone: string | null
          rating: number | null
          review_count: number | null
          updated_at: string
          user_id: string
          weather_unavailable: boolean
        }
        Insert: {
          accepts_cash?: boolean | null
          accepts_transfer?: boolean | null
          address: string
          auto_schedule_enabled?: boolean | null
          business_days?: string | null
          business_hours?: string | null
          business_type: Database["public"]["Enums"]["business_type"]
          business_type_id?: string | null
          category: string
          closing_time?: string | null
          created_at?: string
          delivery_fee?: number | null
          delivery_time_minutes?: number | null
          delivery_tracking_enabled?: boolean | null
          description?: string | null
          free_delivery?: boolean | null
          full_address?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          is_coming_soon?: boolean | null
          is_open?: boolean | null
          is_special_business?: boolean
          latitude: number
          longitude: number
          max_delivery_distance_km?: number | null
          min_order_amount?: number | null
          name: string
          opening_time?: string | null
          phone?: string | null
          rating?: number | null
          review_count?: number | null
          updated_at?: string
          user_id: string
          weather_unavailable?: boolean
        }
        Update: {
          accepts_cash?: boolean | null
          accepts_transfer?: boolean | null
          address?: string
          auto_schedule_enabled?: boolean | null
          business_days?: string | null
          business_hours?: string | null
          business_type?: Database["public"]["Enums"]["business_type"]
          business_type_id?: string | null
          category?: string
          closing_time?: string | null
          created_at?: string
          delivery_fee?: number | null
          delivery_time_minutes?: number | null
          delivery_tracking_enabled?: boolean | null
          description?: string | null
          free_delivery?: boolean | null
          full_address?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          is_coming_soon?: boolean | null
          is_open?: boolean | null
          is_special_business?: boolean
          latitude?: number
          longitude?: number
          max_delivery_distance_km?: number | null
          min_order_amount?: number | null
          name?: string
          opening_time?: string | null
          phone?: string | null
          rating?: number | null
          review_count?: number | null
          updated_at?: string
          user_id?: string
          weather_unavailable?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "businesses_business_type_id_fkey"
            columns: ["business_type_id"]
            isOneToOne: false
            referencedRelation: "business_types"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      complement_templates: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          price: number
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          price?: number
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price?: number
          updated_at?: string
        }
        Relationships: []
      }
      delivery_incidents: {
        Row: {
          amount: number
          created_at: string
          created_by: string | null
          delivery_person_id: string
          id: string
          notes: string | null
          occurred_at: string
          updated_at: string
        }
        Insert: {
          amount: number
          created_at?: string
          created_by?: string | null
          delivery_person_id: string
          id?: string
          notes?: string | null
          occurred_at?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          created_at?: string
          created_by?: string | null
          delivery_person_id?: string
          id?: string
          notes?: string | null
          occurred_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "delivery_incidents_delivery_person_id_fkey"
            columns: ["delivery_person_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          order_id: string | null
          title: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          order_id?: string | null
          title: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          order_id?: string | null
          title?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      order_messages: {
        Row: {
          created_at: string
          id: string
          message: string
          order_id: string
          sender_id: string
          sender_role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          order_id: string
          sender_id: string
          sender_role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          order_id?: string
          sender_id?: string
          sender_role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: [
          {
            foreignKeyName: "order_messages_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          accepted_at: string | null
          business_id: string
          business_rating: number | null
          cancelled_at: string | null
          client_id: string
          created_at: string
          delivered_at: string | null
          delivery_address: string
          delivery_fee: number
          delivery_latitude: number
          delivery_longitude: number
          delivery_person_id: string | null
          delivery_rating: number | null
          id: string
          is_pickup_at_counter: boolean | null
          items: Json
          manual_client_name: string | null
          manual_client_phone: string | null
          notes: string | null
          order_number: string
          payment_method: Database["public"]["Enums"]["payment_method"]
          rating: number | null
          ready_at: string | null
          review: string | null
          status: Database["public"]["Enums"]["order_status"]
          subtotal: number
          total: number
          updated_at: string
        }
        Insert: {
          accepted_at?: string | null
          business_id: string
          business_rating?: number | null
          cancelled_at?: string | null
          client_id: string
          created_at?: string
          delivered_at?: string | null
          delivery_address: string
          delivery_fee?: number
          delivery_latitude: number
          delivery_longitude: number
          delivery_person_id?: string | null
          delivery_rating?: number | null
          id?: string
          is_pickup_at_counter?: boolean | null
          items: Json
          manual_client_name?: string | null
          manual_client_phone?: string | null
          notes?: string | null
          order_number: string
          payment_method: Database["public"]["Enums"]["payment_method"]
          rating?: number | null
          ready_at?: string | null
          review?: string | null
          status?: Database["public"]["Enums"]["order_status"]
          subtotal: number
          total: number
          updated_at?: string
        }
        Update: {
          accepted_at?: string | null
          business_id?: string
          business_rating?: number | null
          cancelled_at?: string | null
          client_id?: string
          created_at?: string
          delivered_at?: string | null
          delivery_address?: string
          delivery_fee?: number
          delivery_latitude?: number
          delivery_longitude?: number
          delivery_person_id?: string | null
          delivery_rating?: number | null
          id?: string
          is_pickup_at_counter?: boolean | null
          items?: Json
          manual_client_name?: string | null
          manual_client_phone?: string | null
          notes?: string | null
          order_number?: string
          payment_method?: Database["public"]["Enums"]["payment_method"]
          rating?: number | null
          ready_at?: string | null
          review?: string | null
          status?: Database["public"]["Enums"]["order_status"]
          subtotal?: number
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      password_resets: {
        Row: {
          created_at: string | null
          created_by: string | null
          expires_at: string | null
          id: string
          temp_password: string
          used_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          expires_at?: string | null
          id?: string
          temp_password: string
          used_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          expires_at?: string | null
          id?: string
          temp_password?: string
          used_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "password_resets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      pizza_specialties: {
        Row: {
          business_id: string
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          price: number | null
          specialty_type: string | null
          updated_at: string
        }
        Insert: {
          business_id: string
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          price?: number | null
          specialty_type?: string | null
          updated_at?: string
        }
        Update: {
          business_id?: string
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price?: number | null
          specialty_type?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "pizza_specialties_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      product_complements: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          is_available: boolean
          name: string
          price: number
          product_id: string
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          is_available?: boolean
          name: string
          price?: number
          product_id: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          is_available?: boolean
          name?: string
          price?: number
          product_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_complements_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          business_id: string
          category: string
          combo_configuration: Json | null
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          is_available: boolean | null
          is_priced_combo: boolean | null
          is_promotional_combo: boolean
          is_specialty: boolean
          name: string
          preparation_time_minutes: number | null
          price: number
          priced_items_count: number | null
          updated_at: string
        }
        Insert: {
          business_id: string
          category: string
          combo_configuration?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_available?: boolean | null
          is_priced_combo?: boolean | null
          is_promotional_combo?: boolean
          is_specialty?: boolean
          name: string
          preparation_time_minutes?: number | null
          price: number
          priced_items_count?: number | null
          updated_at?: string
        }
        Update: {
          business_id?: string
          category?: string
          combo_configuration?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_available?: boolean | null
          is_priced_combo?: boolean | null
          is_promotional_combo?: boolean
          is_specialty?: boolean
          name?: string
          preparation_time_minutes?: number | null
          price?: number
          priced_items_count?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          assigned_business_id: string | null
          avatar_url: string | null
          created_at: string
          email: string
          id: string
          is_active: boolean | null
          is_online: boolean | null
          latitude: number | null
          longitude: number | null
          name: string
          phone: string | null
          rating: number | null
          review_count: number | null
          role_type: string | null
          updated_at: string
          vehicle_plate: string | null
          vehicle_type: string | null
        }
        Insert: {
          address?: string | null
          assigned_business_id?: string | null
          avatar_url?: string | null
          created_at?: string
          email: string
          id: string
          is_active?: boolean | null
          is_online?: boolean | null
          latitude?: number | null
          longitude?: number | null
          name: string
          phone?: string | null
          rating?: number | null
          review_count?: number | null
          role_type?: string | null
          updated_at?: string
          vehicle_plate?: string | null
          vehicle_type?: string | null
        }
        Update: {
          address?: string | null
          assigned_business_id?: string | null
          avatar_url?: string | null
          created_at?: string
          email?: string
          id?: string
          is_active?: boolean | null
          is_online?: boolean | null
          latitude?: number | null
          longitude?: number | null
          name?: string
          phone?: string | null
          rating?: number | null
          review_count?: number | null
          role_type?: string | null
          updated_at?: string
          vehicle_plate?: string | null
          vehicle_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_assigned_business_id_fkey"
            columns: ["assigned_business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string | null
          endpoint: string
          id: string
          p256dh: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string | null
          endpoint: string
          id?: string
          p256dh: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string | null
          endpoint?: string
          id?: string
          p256dh?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "push_subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_manage_user_role: {
        Args: {
          new_role: Database["public"]["Enums"]["app_role"]
          operation: string
          target_user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "client" | "business" | "delivery"
      business_type: "restaurant" | "pharmacy" | "supermarket" | "other"
      order_status:
        | "pending"
        | "accepted"
        | "preparing"
        | "ready"
        | "in_delivery"
        | "delivered"
        | "cancelled"
      payment_method: "cash" | "transfer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "client", "business", "delivery"],
      business_type: ["restaurant", "pharmacy", "supermarket", "other"],
      order_status: [
        "pending",
        "accepted",
        "preparing",
        "ready",
        "in_delivery",
        "delivered",
        "cancelled",
      ],
      payment_method: ["cash", "transfer"],
    },
  },
} as const
