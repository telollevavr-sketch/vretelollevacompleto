# Eliminar sección "Platillos Estrella" de la Landing Page

## Objetivo
Quitar la sección "Platillos Estrella" de la página de inicio y eliminar todo el código involucrado, para acelerar el despliegue inicial de la app.

## Cambios

### 1. `src/pages/HomePage.tsx`
- Eliminar la sección JSX completa de "Platillos Estrella" (encabezado, skeletons, grid de productos y manejo de error con `BackendError`).
- Eliminar el hook `useFeaturedProducts` y sus referencias (`isLoadingFeatured`, `isErrorFeatured`, `refetchFeatured`).
- Eliminar importaciones que solo usa esa sección: `useFeaturedProducts`, `ProductCard`, y `Product` si quedara sin uso.
- Ajustar el `enabled` de la consulta `batch-counts` (actualmente espera a que terminen los destacados) para que dependa solo de la carga de negocios.

### 2. `src/hooks/useFeaturedProducts.ts`
- Eliminar el archivo completo. Verificado: solo lo usa `HomePage.tsx`; ninguna otra pantalla lo referencia.

## Resultado
- La landing deja de ejecutar la consulta de productos destacados (una consulta menos a la base de datos en cada carga inicial).
- Menos procesamiento (agrupación/selección aleatoria) y menos renderizado en el arranque.

## Verificación
- Confirmar que la landing carga sin errores, sin la sección de Platillos Estrella, y que no quedan referencias al hook eliminado (compilación limpia).
