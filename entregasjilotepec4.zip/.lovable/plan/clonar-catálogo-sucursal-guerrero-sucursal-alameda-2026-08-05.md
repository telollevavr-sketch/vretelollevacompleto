# Clonar catálogo: Sucursal Guerrero → Sucursal Alameda

## Situación actual (verificada en la base de datos)

Sucursal Guerrero (`d7550d98…`) tiene:
- 118 productos, distribuidos en 19 categorías
- 18 de esos productos son combos promocionales
- 72 complementos ligados a esos productos
- 63 especialidades (pizzas)
- 8 imágenes de menú

Sucursal Alameda (`b80b2d5e…`) está completamente vacía: 0 productos, 0 complementos, 0 especialidades. Por eso no hay riesgo de duplicados ni de sobrescribir nada.

## Qué se va a copiar

1. **Productos (118)** — nombre, descripción, precio, categoría, imagen, disponibilidad, tiempo de preparación y todas las banderas de combo (combo promocional, configuración del combo, combo con precio, número de productos con precio, especialidad).
2. **Complementos (72)** — se recrean ligados al producto clonado correspondiente en Alameda.
3. **Especialidades (63)** — nombre, descripción, tipo, precio y estado activo.
4. **Categorías** — no son una tabla aparte por negocio: viajan como campo dentro de cada producto, así que las 19 categorías aparecen automáticamente al copiar los productos.

No se copian: pedidos, calificaciones, horarios ni datos de perfil del negocio (dirección, teléfono, costos de envío). Guerrero tampoco tiene promociones cargadas.

## Cómo funciona la copia

- Cada registro nuevo recibe su propio identificador; los catálogos quedan independientes. Editar o borrar algo en Alameda después no afecta a Guerrero.
- La configuración de los combos se copia tal cual: revisé su contenido y hace referencia a tipos y etiquetas ("pizza", "bebida", "sabores"), no a identificadores de productos concretos, así que sigue siendo válida en la nueva sucursal.
- Los complementos se enlazan emparejando por nombre y categoría del producto dentro de la misma operación de copia, para que ningún complemento quede huérfano ni apuntando a Guerrero.

## Detalle técnico

Una sola operación de datos con tres pasos encadenados:

```text
1. INSERT INTO products      SELECT ... FROM products WHERE business_id = Guerrero
   (con business_id = Alameda, id nuevo) -- usando CTE que devuelve el mapeo
2. INSERT INTO product_complements  usando el mapeo (nombre+categoría) viejo→nuevo
3. INSERT INTO pizza_specialties    SELECT ... WHERE business_id = Guerrero
```

Se ejecuta como una sola inserción de datos (no una migración de esquema), y al terminar se verifican los conteos en Alameda: 118 / 72 / 63.

## Riesgo

Bajo. Solo se insertan filas nuevas en la sucursal Alameda; no se modifica ni se elimina nada existente.
