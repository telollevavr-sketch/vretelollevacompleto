# Finalizar reconexión de vrtelolleva.com

## Estado verificado ahora mismo

- DNS de `vrtelolleva.com` y `www.vrtelolleva.com` ya resuelve correctamente a `185.158.133.1`.
- Sin embargo, `https://vrtelolleva.com` devuelve HTTP 421 `Misdirected Request`, lo que significa que el tráfico llega a Lovable/Cloudflare pero el dominio todavía no está asociado a este proyecto.
- El mensaje de Entri solo confirma que los registros DNS se enviaron; la app no se servirá hasta que Lovable termine de asociar el dominio.

## Cómo saber que ya se resolvió

1. **Project Settings → Domains en Lovable**: el dominio debe pasar de `Verifying`/`Offline` a `Ready` o `Active`.
2. **Navegador (modo incógnito)**: `https://vrtelolleva.com` debe mostrar la app (lista de negocios), no la página por defecto de Hostinger ni el error 421.
3. **Ruta interna**: `https://vrtelolleva.com/negocio/59369986` debe cargar sin 404.
4. **Certificado**: el candado debe estar verde y el certificado será de Lovable/Cloudflare, no de Hostinger.

## Acción necesaria

- En Lovable, ir a **Project Settings → Project → Domains**, buscar `vrtelolleva.com` y presionar **Recover / Verify**.
- Esperar la propagación: normalmente es inmediato o unos minutos, pero en casos extremos puede tardar hasta 48 horas.
- Si el dominio ya está `Active` pero no se ve la app actualizada, abrir el diálogo de **Publish** y presionar **Update**.

## Pasos a seguir

- [ ] Presionar Recover / Verify en Lovable Domains.
- [ ] Verificar que el estado pase a `Active`.
- [ ] Probar `https://vrtelolleva.com` en una ventana de incógnito.
- [ ] Publicar / Update si la app no se muestra actualizada.
