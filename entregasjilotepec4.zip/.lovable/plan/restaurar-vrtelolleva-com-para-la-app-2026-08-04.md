# Restaurar `vrtelolleva.com` para la app

## Diagnóstico confirmado

Los registros DNS ya apuntan correctamente a Lovable:

- `vrtelolleva.com` resuelve a `185.158.133.1`.
- `www.vrtelolleva.com` resuelve a `185.158.133.1`.
- No quedan registros `A`, `AAAA`, `ALIAS` o `CNAME` adicionales de Hostinger para `@` o `www`.
- Los registros de correo de Hostinger (MX, SPF, DMARC, DKIM) se conservaron.
- Sin embargo, Lovable todavía no sirve el dominio: `https://vrtelolleva.com` devuelve `421 Misdirected Request`, lo que indica que el dominio no está asociado a este proyecto en Lovable.

## Cambios exactos en la pantalla mostrada

| Registro actual | Acción | Motivo |
|---|---|---|
| `CNAME` — `www` — `www.vrtelolleva.com.cdn.hstgr.net` | **Eliminar** | Envía `www` al alojamiento web de Hostinger. |
| `ALIAS` — `@` — `vrtelolleva.com.cdn.hstgr.net` | **Eliminar** | Envía el dominio raíz al alojamiento web de Hostinger. |
| `TXT` — `_lovable` — `lovable_verify=...` | **Conservar provisionalmente** | Es la verificación de propiedad. Al conectar el dominio, confirmar que el valor mostrado por Lovable sea exactamente el mismo; si entrega otro, editar este registro y sustituirlo. Solo debe existir un TXT `_lovable`. |
| Los tres `CNAME` `hostingermail-…._domainkey` | **Conservar** | DKIM del correo de Hostinger. |
| `CNAME` — `autodiscover` | **Conservar** | Configuración automática del correo. |
| `CNAME` — `autoconfig` | **Conservar** | Configuración automática del correo. |
| `TXT` — `_dmarc` | **Conservar** | Política DMARC del correo. |
| `TXT` — `@` — `v=spf1 include:_spf.mail.hostinger.com ~all` | **Conservar** | SPF del correo. |
| `MX` — `@` — `mx1.hostinger.com` y `mx2.hostinger.com` | **Conservar** | Recepción de correo. |
| `A` — `ftp` — `62.72.50.209` | **Conservar**, salvo que ya no uses FTP | No afecta la web raíz ni `www`. |

## Registros nuevos

Después de borrar el `ALIAS @` y el `CNAME www`, crear:

| Tipo | Nombre | Valor | TTL |
|---|---|---|---|
| `A` | `@` | `185.158.133.1` | `300` o predeterminado |
| `A` | `www` | `185.158.133.1` | `300` o predeterminado |

No debe quedar ningún otro `A`, `AAAA`, `ALIAS` o `CNAME` con nombre `@` o `www`. En Hostinger, primero hay que eliminar los registros actuales porque no permite que `www` sea simultáneamente `CNAME` y `A`.

## Orden seguro de ejecución

1. En Lovable, abrir **Project Settings → Project → Domains → Connect Domain**. (Hecho)
2. Agregar `vrtelolleva.com` y, por separado, `www.vrtelolleva.com`. (Hecho)
3. Comparar el TXT `_lovable` solicitado con el que ya aparece en Hostinger. Conservarlo si coincide; reemplazar únicamente su valor si cambió. (Hecho — el valor actual coincide)
4. En Hostinger, eliminar solamente el `ALIAS @` y el `CNAME www` indicados arriba. (Hecho)
5. Crear los dos registros `A` nuevos con valor `185.158.133.1`. (Hecho)
6. En Lovable, buscar `vrtelolleva.com` en **Domains** y presionar **Recover / Verify** para que el dominio vuelva a estar asociado a este proyecto.
7. Verificar el estado en Lovable pase a **Ready** o **Active** (puede tardar minutos a horas).
8. Publicar nuevamente la app.
9. Verificar `https://vrtelolleva.com`, `https://www.vrtelolleva.com` y una ruta interna como `/negocio/...`.

La propagación normalmente tarda de unos minutos a varias horas y, en casos excepcionales, hasta 72 horas. No hay que volver a instalar manualmente el certificado SSL de Hostinger para la app; al quedar el dominio conectado, Lovable emitirá el certificado correspondiente.