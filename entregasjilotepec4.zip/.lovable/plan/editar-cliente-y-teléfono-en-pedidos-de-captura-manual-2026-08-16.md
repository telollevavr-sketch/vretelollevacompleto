# Editar cliente y teléfono en pedidos de Captura Manual

## Objetivo
Dentro del formulario de Captura Manual (Administrador), poder listar los pedidos capturados manualmente, buscarlos y corregir el **Nombre del cliente** y el **Teléfono del cliente**.

## Qué se agrega

### 1. Listado de pedidos manuales
Debajo del formulario, una sección "Pedidos capturados manualmente" con una tabla que muestra:
- Número de pedido
- Fecha
- Negocio
- Cliente y teléfono
- Total
- Botón "Editar"

Solo se listan los pedidos con captura manual (los que tienen nombre de cliente manual guardado o la nota `[CAPTURA MANUAL ADMIN]`), ordenados del más reciente al más antiguo, con paginación de 20 en 20 para no consumir recursos de más.

### 2. Búsqueda
Un campo de búsqueda que filtra por número de pedido, nombre de cliente, teléfono o nombre de negocio. La búsqueda se ejecuta contra la base de datos (con pequeño retraso al escribir) para no traer todos los pedidos a la vez.

### 3. Edición
Al pulsar "Editar" se abre un modal con dos campos: Nombre del cliente (obligatorio, máx. 100) y Teléfono (opcional, máx. 20). Al guardar se actualiza solo ese pedido y la lista se refresca. No se modifican productos, totales, fechas ni estatus.

## Detalles técnicos
- Nuevo hook `src/hooks/useManualOrders.ts`: consulta `orders` seleccionando columnas explícitas (`id, order_number, created_at, total, manual_client_name, manual_client_phone, notes, business_id, businesses(name)`), filtro `notes.ilike.%[CAPTURA MANUAL ADMIN]%` u `manual_client_name.not.is.null`, `range()` para paginación, `staleTime` 60s y `refetchOnWindowFocus: false`.
- Mutación de actualización: `update({ manual_client_name, manual_client_phone })` sobre el `id`, invalidando `['manual-orders']` y `['orders']`.
- Nuevo componente `src/components/admin/ManualOrdersEditor.tsx` (tabla + buscador + modal de edición), montado debajo del formulario dentro de `ManualOrderCapture.tsx`.
- Sin cambios de esquema ni de RLS: el admin ya puede actualizar pedidos.
- Contraste: texto oscuro sobre fondo claro en la tabla, siguiendo el estándar de visibilidad de datos.
