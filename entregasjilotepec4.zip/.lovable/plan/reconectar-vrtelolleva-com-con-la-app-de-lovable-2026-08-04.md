# Reconectar vrtelolleva.com con la app de Lovable

El SSL ya quedó resuelto, pero el dominio todavía no muestra la app.

## Estado verificado ahora mismo

- Certificado SSL: válido, emitido el 3-ago-2026 y vigente hasta el 1-nov-2026. Ya no hay error de certificado.
- `https://vrtelolleva.com/` responde 200, pero devuelve la **"Página por defecto" de Hostinger**, no la app.
- `https://vrtelolleva.com/negocio/59369986` devuelve **404**.
- El DNS de `@` y `www` apunta a servidores de Hostinger (`77.37.53.x`, `91.108.98.x` y registros AAAA de `hstgr.net`), no a la IP de Lovable `185.158.133.1`.
- En Lovable, Project Settings → Domains muestra `vrtelolleva.com` en estado **Offline**.

Conclusión: falta el último paso, volver a apuntar el DNS del dominio a Lovable. Hostinger arregló el certificado de su propio hosting, pero el dominio sigue sirviendo el sitio vacío de Hostinger en lugar de la app.

## Pasos para que todo vuelva a funcionar

1. En hPanel de Hostinger: **Dominios → vrtelolleva.com → Editor de zona DNS** (o Administrar dominio → DNS).
2. Eliminar los registros que apuntan al hosting de Hostinger:
   - Registros **A** de `@` y `www` (valores `77.37.53.x` / `91.108.98.x`).
   - Registros **AAAA** de `@` y `www` (los IPv6 `2a02:4780:...`). Esto es clave: si queda un AAAA, el navegador seguirá yendo a Hostinger.
   - Cualquier **CNAME** de `www` hacia `*.hstgr.net`.
3. Crear los registros que pide Lovable:

```text
Tipo   Host       Valor
A      @          185.158.133.1
A      www        185.158.133.1
TXT    _lovable   lovable_verify=e2b293c0-84cb-4e88-8346-6d40097e5af8
```

4. En Lovable: Project Settings → Domains → botón **Recover** en `vrtelolleva.com`.
5. Esperar la propagación (normalmente 15 min – 2 h, hasta 24 h en el peor caso). El estado pasará de Verifying → Setting up → **Active**, y Lovable emite su propio certificado SSL automáticamente y lo renueva solo.
6. Opcional: agregar también `www.vrtelolleva.com` como dominio en Lovable y marcar uno como Primary para que el otro redirija.

## Notas importantes

- No hay cambios de código que hacer: la app publicada funciona correctamente en `https://entregasjilotepec4.lovable.app`. El problema es 100% de DNS.
- Al mover el DNS a Lovable, el hosting web de Hostinger para ese dominio deja de usarse (no se pierde nada, la app vive en Lovable).
- Si en ese dominio se usa **correo** de Hostinger, no tocar los registros **MX**, **SPF/TXT de correo** ni **DKIM**; solo cambiar A / AAAA / CNAME de `@` y `www`.
- Si se prefiere mantener Hostinger delante como proxy, entonces habría que conectar el dominio en Lovable en modo proxy (CNAME) — pero es más frágil; la ruta recomendada es apuntar directo a Lovable.

## Mientras se propaga

Compartir `https://entregasjilotepec4.lovable.app`, que ya funciona con HTTPS válido.
