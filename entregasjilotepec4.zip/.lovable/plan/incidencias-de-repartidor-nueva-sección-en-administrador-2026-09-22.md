# Incidencias de Repartidor (nueva sección en Administrador)

Nueva pestaña "Incidencias" en el Panel de Administración para llevar un registro diario de incidencias de repartidores.

## Cómo se usa

- Botón grande **+ Nueva incidencia** arriba de la lista.
- Al pulsarlo se abre una ventana con solo dos campos obligatorios:
  1. **Repartidor** (lista desplegable con los repartidores registrados)
  2. **Monto**: dos botones, **$5** y **$10**
  - Campo opcional de **Comentarios**.
- Al guardar se registra automáticamente la fecha y la hora.

## Filtros y totales

- Filtro por **rango de fechas** (mismo selector de fechas que ya usan los informes).
- Filtro por **repartidor** (o "Todos").
- Arriba de la tabla, dos tarjetas: **número de registros** y **suma total en pesos** de lo filtrado.

## Tabla de registros

Columnas: Fecha y hora, Repartidor, Monto, Comentarios, y acciones para **editar** o **eliminar** un registro (solo administrador).

## Detalle técnico

- Nueva tabla `delivery_incidents`: `delivery_person_id`, `amount` (numeric, 5 o 10), `notes`, `occurred_at` (por defecto ahora), `created_by`, `created_at`, `updated_at` con su trigger.
- GRANT a `authenticated` y `service_role`; RLS activa: solo usuarios con rol `admin` (`has_role(auth.uid(),'admin')`) pueden ver, crear, editar y borrar.
- Nuevo hook `src/hooks/useDeliveryIncidents.ts` con consulta filtrada por fecha/repartidor (columnas explícitas, `staleTime` 60s) y mutaciones de alta, edición y baja.
- Nuevo componente `src/components/admin/DeliveryIncidents.tsx` (tarjetas de resumen, `DateRangePicker` existente, selector de repartidor desde `useUsers`, diálogo de alta).
- Alta en `src/pages/AdminDashboard.tsx` como nueva pestaña con su icono, siguiendo el estilo morado actual.
- Los repartidores se leen de los perfiles con rol `delivery` (como en Repartidores).

## Fuera de alcance

- No afecta pedidos, pagos ni informes existentes.
