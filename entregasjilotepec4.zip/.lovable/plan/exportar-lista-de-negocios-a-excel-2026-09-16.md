# Exportar lista de negocios a Excel

## Objetivo
Entregar un archivo descargable con los 75 negocios registrados, listo para abrir o copiar en Excel.

## Qué se hará
1. Consultar la tabla de negocios de la base de datos (solo lectura).
2. Generar el archivo `negocios.xlsx` con una fila por negocio y estas columnas:
   - Nombre
   - Categoría
   - Dirección
   - Teléfono
   - Calificación y número de reseñas
   - Estado: Abierto, Activo, Próximamente, No disponible por clima
   - Envío gratis, Costo de envío, Pedido mínimo, Tiempo de entrega
   - Días y horario de atención
   - Acepta efectivo / transferencia
   - Fecha de registro
3. Guardar el archivo como entregable descargable en Archivos (Files), desde donde podrás abrirlo directamente en Excel o copiar y pegar su contenido.

## Detalles técnicos
- La exportación es de solo lectura; no modifica ningún dato.
- Se generará como `.xlsx` (formato nativo de Excel) usando la librería de hojas de cálculo del entorno.
- Requiere salir del modo de planificación para crear el archivo.

## Resultado
Un archivo `negocios.xlsx` con los 75 negocios, descargable desde esta conversación.
