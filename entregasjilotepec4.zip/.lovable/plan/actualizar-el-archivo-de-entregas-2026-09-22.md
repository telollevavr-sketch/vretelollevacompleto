# Actualizar el archivo de Entregas

## Cambios
- Partir del archivo actual para conservar los 25 repartidores, montos, filtros, fórmulas y formato.
- Convertir la columna **Fecha** de la hoja **Registros** en un campo de fecha validado y formateado, compatible con el selector de calendario disponible en Excel y Google Sheets.
- Convertir la columna **Hora** en un campo con lista desplegable de horarios cada 30 minutos, desde 00:00 hasta 23:30.
- Mantener la posibilidad de escribir una fecha u hora válida manualmente.
- Proteger las validaciones contra valores incorrectos mediante mensajes claros.

## Verificación y entrega
- Recalcular todas las fórmulas del resumen.
- Confirmar que no existan errores de fórmula.
- Comprobar las listas de Fecha, Hora, Repartidor y Monto.
- Generar una nueva versión descargable del archivo Excel sin sobrescribir la anterior.

## Nota de compatibilidad
El calendario visual depende de la versión de Excel utilizada; la celda quedará configurada como fecha válida y Google Sheets mostrará su selector de calendario. Para Hora se usará una lista desplegable, ya que Excel no incluye un selector visual nativo de reloj dentro de archivos `.xlsx`.
