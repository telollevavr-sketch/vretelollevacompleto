# Nombre y teléfono de cliente en Captura Manual

## Objetivo
En el formulario de Captura Manual (Administrador) poder escribir el **Nombre del Cliente** y el **Teléfono del Cliente**. Solo en esos pedidos manuales, esos datos deben mostrarse en lugar del perfil del administrador que los capturó, en toda la app (estadísticas, informes, exportaciones, ficha del negocio, mapas, depurador).

## Cambios

### 1. Base de datos
Agregar dos columnas opcionales a la tabla `orders`:
- `manual_client_name` (texto, opcional)
- `manual_client_phone` (texto, opcional)

Se guardan vacías en los pedidos normales, así nada del flujo actual cambia.

### 2. Formulario de Captura Manual
- Dos campos nuevos junto a Negocio / Fecha: "Nombre del cliente" y "Teléfono del cliente".
- Nombre obligatorio; teléfono opcional (validación de longitud y limpieza de espacios).
- Al registrar el pedido se guardan en las columnas nuevas; el `client_id` sigue siendo el del admin (necesario por las reglas de seguridad y el historial).
- Se limpian con el botón "Limpiar".

### 3. Visualización en toda la app
En la carga de pedidos, cuando el pedido traiga `manual_client_name`, la información de cliente que ve la app usa ese nombre y teléfono en vez del perfil del admin. Esto hace que se refleje automáticamente en:
- Estadísticas del Administrador y Mapa de Pedidos
- Depurador de Pedidos
- Ficha/detalle del pedido en el Negocio
- Exportaciones de Excel/informes (columnas "Nombre del Cliente" y "Teléfono Cliente")

Los pedidos normales siguen mostrando el perfil real del cliente, sin cambios.

## Detalles técnicos
- Migración: `ALTER TABLE public.orders ADD COLUMN manual_client_name text, ADD COLUMN manual_client_phone text;` (sin cambios de RLS ni grants).
- `src/components/admin/ManualOrderCapture.tsx`: estados nuevos + inputs + insert de las columnas.
- `src/hooks/useOrders.ts`: al construir `clientInfo`, priorizar `order.manual_client_name` / `manual_client_phone` sobre el perfil obtenido de `profiles`.
- `src/lib/typeConversions.ts` / `src/types/index.ts`: exponer bandera `isManualCapture` opcional si se requiere para etiquetado (ya existe el badge basado en la nota `[CAPTURA MANUAL ADMIN]`).
- Sin cambios en lógica de totales, estados ni informes: consumen `clientInfo`.
