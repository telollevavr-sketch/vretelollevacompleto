# Archivo Excel de "Entregas" de repartidores

Un archivo `.xlsx` descargable que replica la sección Entregas del panel de administración, para llevar el registro sin entrar a la app.

## Qué incluirá el archivo

**Hoja 1 – Registros**
Columnas: Fecha, Hora, Repartidor, Monto, Comentarios.
- Repartidor: lista desplegable con los nombres que me adjuntes.
- Monto: lista desplegable con $5 y $10 únicamente.
- Fecha y hora: se escriben al capturar (con formato ya aplicado).
- Filas preparadas para captura continua (aprox. 2,000).
- Filtros automáticos en los encabezados para buscar por fecha o repartidor.

**Hoja 2 – Resumen**
- Selector de rango de fechas (desde / hasta) y selector de repartidor ("Todos" o uno específico).
- Número de registros que cumplen el filtro.
- Suma total en pesos de esos registros.
- Tabla con el total por repartidor dentro del rango elegido.

Todo con fórmulas vivas: al capturar o cambiar filtros, los totales se recalculan solos. Funciona igual si lo subes a Google Sheets.

## Estilo

Encabezados en morado con letra blanca, texto oscuro sobre fondo claro, montos en formato de moneda.

## Qué necesito de ti

La lista de repartidores (el adjunto que mencionaste). Con eso genero el archivo y te lo dejo descargable en esta conversación.

## Detalle técnico

- Generación con openpyxl: validaciones de datos para repartidor y monto, `SUMIFS`/`COUNTIFS` en la hoja de resumen, autofiltro y anchos de columna.
- Recalculado y verificado sin errores de fórmula antes de entregarlo.
- No modifica la app ni la base de datos; es solo un entregable descargable.
